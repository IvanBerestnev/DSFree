<?php
function checkpass($vals)
{
#print_r($vals);die();
#print_r($_SERVER);die();
$http_orign = $_SERVER['HTTP_ORIGIN'];

$name = $vals['name'];
$password = $vals['password'];

$hash_name = hash('sha256', $name);
$hash_pass = hash('sha256', $password);


If($name == "root" or $name == "")
{
#header('Location: '.$http_orign.'/dentsoftfree/');

echo "<script>setTimeout(() => window.location.reload());</script>";

die();
}

If($password == "")
{
#header('Location: '.$http_orign.'/dentsoftfree/');

echo "<script>setTimeout(() => window.location.reload());</script>";

die();
}

include_once("../users/_dsf.php");
$ar_user = dsf();

#print_r($ar_user);die();

$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];



$connection = mysqli_connect ("localhost",$name_user,$pass_user);



If($connection)
{
#echo "connected";die();
$cookie = md5(uniqid(rand(),1));

#print_r($_SERVER);die();

#echo $_SERVER["REMOTE_ADDR"];
$ip = $_SERVER["REMOTE_ADDR"];

#echo $db;die();

mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from dsf_auth_pre where name = '$hash_name' and pass = '$hash_pass'";
#echo $sql;
$query = mysqli_query($connection,$sql);
#echo mysqli_error($query);

If(mysqli_num_rows ($query) !== 0)
{

#echo "123";
$ua = $_SERVER['HTTP_USER_AGENT'];
$hash_ua = hash('sha256', $ua);

setcookie("dsf_cookie", $cookie, time()+3600, "/", "");

$sql = "insert into dsf_good_auth values ('$name','$cookie',now(),'$ip','$hash_ua')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);
echo "<script>setTimeout(() => window.location.reload());</script>";



die();
}
Else{
//Авторизация не прошла. хэш вводимых пользователей не проходит

$sql = "insert into dsf_bad_auth values ('$name',now(),'$ip')";
$query = mysqli_query($connection,$sql);

#echo "<meta http-equiv=\"refresh\" content=\"0\">";

echo "<script>setTimeout(() => window.location.reload());</script>";

die();
}


}


}
?>