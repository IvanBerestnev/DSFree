<?php

function is_banned_ip()
{

$ip = $_SERVER["REMOTE_ADDR"];

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_ban_list where ip = '$ip'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) == 0)
{

$unix_date_now = strtotime("now");
$unix_date_past = $unix_date_now-1200;


$date_now = date("Y-m-d H:i:s", $unix_date_now);
$date_past = date("Y-m-d H:i:s", $unix_date_past);



$sql = "select * from dsf_bad_auth where ip = '$ip' and time BETWEEN STR_TO_DATE('$date_past', '%Y-%m-%d %H:%i:%s') AND STR_TO_DATE('$date_now', '%Y-%m-%d %H:%i:%s')";

#echo $sql;die();

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$ar_nba = array("1"=>"2","2"=>"1");
$num_ba = mysqli_num_rows($query);

If(isset($ar_nba[$num_ba]))
{
$result['bad_auth'] = $ar_nba[$num_ba];
}
Else{
$result['ban_auth'] = "";
}


}
Else{
$result['good'] = "";
}




}
Else{

$ar_ban = mysqli_fetch_assoc($query);

If($ar_ban['ip'] !== "")
{
$banned_ip = $ar_ban['ip'];
$result['ban_perman'] = $banned_ip;
}
Else{
//этого варианта не должно быть
}






}




return $result;
}


?>