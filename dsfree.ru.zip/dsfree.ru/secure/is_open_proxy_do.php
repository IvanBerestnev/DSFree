<?php

function is_open_proxy_do()
{

$i=0;
//Проверка - использует ли открытые прокси
$proxy_headers = array('HTTP_VIA','HTTP_X_FORWARDED_FOR','HTTP_FORWARDED_FOR','HTTP_X_FORWARDED','HTTP_FORWARDED','HTTP_CLIENT_IP','HTTP_FORWARDED_FOR_IP',  'VIA','X_FORWARDED_FOR','FORWARDED_FOR','X_FORWARDED','FORWARDED','CLIENT_IP','FORWARDED_FOR_IP','HTTP_PROXY_CONNECTION');
Foreach($proxy_headers as $x){If(isset($_SERVER[$x])){$i=1; return $i; die();}}


return $i;
}


?>