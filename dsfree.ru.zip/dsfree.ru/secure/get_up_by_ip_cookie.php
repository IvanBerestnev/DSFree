<?php

function get_up_by_ip_cookie($ip,$cookie)
{

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from dsf_good_auth where cookie = '$cookie' and ip = '$ip'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);
#echo mysql_error();die();
$ar_author = mysqli_fetch_assoc($query);

#print_r($ar_author);die();


$name_user = $ar_author['name'];

include_once("../users/".$name_user.".php");
$ar_user = user();
$ar_user['name'] = $name_user;
return $ar_user;

}
?>