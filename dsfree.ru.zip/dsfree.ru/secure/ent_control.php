<?php

function ent_control($val)
{

include_once("is_open_proxy_do.php");


$i = is_open_proxy_do();



If($i==0)
{
include_once("is_banned_ip.php");
$ar_ban_ip = is_banned_ip();

#print_r($ar_ban_ip);

$work_js = "
<script>
function getXmlHttp() {
var xmlhttp;
try {
xmlhttp = new ActiveXObject(\"Msxml2.XMLHTTP\");
} catch (e) {
try {
xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");
} catch (E) {
xmlhttp = false;
}
}
if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
xmlhttp = new XMLHttpRequest();
}
return xmlhttp;
}
  

function author()
{
var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
var name = document.getElementById('name').value;
var pass = document.getElementById('password').value;
var str = \"autoriz[name]=\" + encodeURIComponent(name) + \"&autoriz[password]=\" + encodeURIComponent(pass);
xmlhttp.send(str);
xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

document.getElementById('run').innerHTML = xmlhttp.responseText; // Выводим ответ серверa

var cont = document.getElementById('run');
var elements = cont.getElementsByTagName('script');

var len = elements.length;
for (var i = 0; i < len; i++) {

eval.call(window, elements[i].innerHTML);  
}


}
}
}
}


</script>
";

If($val == "mobile")
{
	
$ar['js_auth'] = $work_js;

$ar['txt_auth'] = "
<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td height = \"15%\" align = \"center\">
<input id = \"name\" type = \"text\" style = \"width: 85%; height: 50%; font-size: 55px; text-align: center; \" value = \"administrator\">
</td>
<td rowspan = \"2\">
<table align = \"center\" border = \"1\" width = \"90%\" height = \"90%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"author();\" align = \"center\" style = \"font-size: 70px; color: black; \">
вход
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td height = \"15%\" align = \"center\">
<input id = \"password\" type = \"password\" style = \"width: 85%; height: 50%; font-size: 55px; text-align: center;\" value = \"administrator\">
</td>
</tr>
</table>
";

}
Else{


If(isset($ar_ban_ip['good']))
{
$ar['txt_auth'] = "<table border = \"0\" width = \"90%\" height = \"70%\" style = \"border-collapse: collapse; table-layout: fixed;\" cellpadding=\"0\" cellspacing= \"0\"><tr><td align = \"left\"><input pattern = \"[A-Za-z]{6,}\" type=\"text\" class = \"avt\" id = \"name\" placeholder = \"имя\" autocomplete=\"false\"></td><td onclick = \"author();\" rowspan = \"2\" style = \" cursor: pointer; font-size: 19px;\" width = \"30%\" align = \"center\"><div id = \"enter\">Вход</div></td></tr><tr><td align = \"left\"><input size = \"10\" class = \"avt\" type = \"password\" id = \"password\" placeholder = \"пароль\" autocomplete=\"false\"></td></tr>
<tr>
<td colspan = \"2\" align = \"center\" style = \"background-color: F3F3F3;\"><span style = \"font-style:italic; \">У Вас <span style = \"font-weight: bold; color: red;\">3</span> попытки ввода пароля. В случае неправильного ввода - блокировка IP адреса на 20 минут</span></td>
</tr>
</table>";


$ar['js_auth'] = $work_js;
}
ElseIf(isset($ar_ban_ip['bad_auth']))
{

$ar_try_txt = array("2"=>" попытки ","1"=>" попытка ");

$ar['txt_auth'] = "<table border = \"0\" width = \"90%\" height = \"70%\" style = \"border-collapse: collapse; table-layout: fixed;\" cellpadding=\"0\" cellspacing= \"0\"><tr><td align = \"left\"><input pattern = \"[A-Za-z]{6,}\" type=\"text\" class = \"avt\" id = \"name\" placeholder = \"имя\" autocomplete=\"false\"></td><td onclick = \"author();\" rowspan = \"2\" style = \" cursor: pointer; font-size: 19px;\" width = \"30%\" align = \"center\"><div id = \"enter\">Вход</div></td></tr><tr><td align = \"left\"><input size = \"10\" class = \"avt\" type = \"password\" id = \"password\" placeholder = \"пароль\" autocomplete=\"false\"></td></tr>
<tr>
<td colspan = \"2\" align = \"center\" style = \"background-color: F3F3F3;\"><span style = \"font-style:italic; \">У Вас <span style = \"font-weight: bold; color: red;\">".$ar_ban_ip['bad_auth']."</span>".$ar_try_txt[$ar_ban_ip['bad_auth']]."ввода пароля. В случае неправильного ввода - блокировка IP адреса на 20 минут</span></td>
</tr>
</table>";

$ar['js_auth'] = $work_js;

}
ElseIf(isset($ar_ban_ip['ban_auth']))
{
$ar['txt_auth'] = "<table border = \"0\" width = \"90%\" height = \"60%\" style = \"border-collapse: collapse; table-layout: fixed;\" cellpadding=\"0\" cellspacing= \"0\"><tr height = \"30%\"><td valign = \"middle\" style = \"font-family: arial; font-size: 20px; font-weight: bold;\">Уважаемый пользователь</td><tr><td style = \"font-family: arial; font-size: 18px; font-style:itallic;\">Политика безопасности не позволяет использовать программу, если Вы ввели неправильно имя/пароль 3 раза подряд. Данное средство служит для защиты программы от перебора паролей(тип атаки - брутфорс). Автоматическая разблокировка произойдет через 20 минут с момента последнего ввода.</td></tr></table>";
$ar['js_auth'] = "";
}





}


}
Else{
$ar['txt_auth'] = "<table border = \"0\" width = \"90%\" height = \"60%\" style = \"border-collapse: collapse; table-layout: fixed;\" cellpadding=\"0\" cellspacing= \"0\"><tr height = \"30%\"><td valign = \"middle\" style = \"font-family: arial; font-size: 20px; font-weight: bold;\">Уважаемый пользователь</td><tr><td style = \"font-family: arial; font-size: 18px; font-style:itallic;\">Политика безопасности сайта не позволяет использовать прокси-сервер в своей работе. Если Вы не используете данную технологию, обратитесь к разработчику.</td></tr></table>";
$ar['js_auth'] = "";
}




return $ar;

}

?>
