<?php

function dsf()
{
$ar['name'] = "dsf_user_sys";
$ar['pass'] = "WGguo4gdAwP0";
$ar['db'] = "dsf_sys";
return $ar;
}


?>