<?php

function user()
{
//Необходимо изменить содержание. ковычки оставляем. заполняем все на английском. БЕЗ ПРОБЕЛОВ.Допускается _
$ar['name'] = "administrator";
$ar['pass'] = "administrator";
$ar['grant'] = "admin";
$ar['db'] = "dsfree";
return $ar;
}

?>