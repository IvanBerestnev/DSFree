<?php

function handle_self($data)
{


If(isset($data['load_page']))
{



If($data['load_page'] == "loading_ssetka")
{
$vals = $data['data'];
include_once("../components/pages/loading_ssetka.php");
loading_ssetka($vals);
}

ElseIf($data['load_page'] == "show_modal_general_setting")
{

#$vals = $data['data'];
include_once("../components/pages/show_modal_general_setting.php");
show_modal_general_setting();

}
ElseIf($data['load_page'] == "load_settings")
{
$vals = $data['data'];
include_once("../components/pages/load_settings.php");
load_settings($vals);
}

ElseIf($data['load_page'] == "open_page_edit_default_ssetka")
{
$vals = $data['data'];
include_once("../components/pages/open_page_edit_default_ssetka.php");
open_page_edit_default_ssetka($vals);
}

ElseIf($data['load_page'] == "load_calendar_jurpacs")
{
$vals = $data['data'];
include_once("../components/pages/load_calendar_jurpacs.php");
load_calendar_jurpacs($vals);
}

ElseIf($data['load_page'] == "load_page_screen")
{
$vals = $data['data'];
include_once("../components/pages/load_page_screen.php");
load_page_screen($vals);
}

ElseIf($data['load_page'] == "change_color_doc")
{
$vals = $data['data'];
include_once("../components/pages/change_color_doc.php");
change_color_doc($vals);
}

ElseIf($data['load_page'] == "permissions_default")
{
$vals = $data['data'];
include_once("../components/pages/permissions_default.php");
permissions_default($vals);
}

ElseIf($data['load_page'] == "load_primary_docums")
{
$vals = $data['data'];
include_once("../components/pages/load_primary_docums.php");
load_primary_docums($vals);
}

ElseIf($data['load_page'] == "choice_pac_primary_docum")
{
$vals = $data['data'];
include_once("../components/pages/choice_pac_primary_docum.php");
choice_pac_primary_docum($vals);
}

ElseIf($data['load_page'] == "open_first_docum")
{
$vals = $data['data'];
include_once("../components/pages/open_first_docum.php");
open_first_docum($vals);
}

ElseIf($data['load_page'] == "open_page_other_lica_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/pages/open_page_other_lica_dogovor_pmu.php");
open_page_other_lica_dogovor_pmu($vals);
}

ElseIf($data['load_page'] == "edit_first_docum")
{
$vals = $data['data'];
include_once("../components/pages/edit_first_docum.php");
edit_first_docum($vals);
}

ElseIf($data['load_page'] == "add_new_ds")
{
$vals = $data['data'];
include_once("../components/pages/add_new_ds.php");
add_new_ds($vals);
}
ElseIf($data['load_page'] == "edit_medcart_templ_razdel_self")
{
$vals = $data['data'];
include_once("../components/pages/edit_medcart_templ_razdel_self.php");
edit_medcart_templ_razdel_self($vals);
}
ElseIf($data['load_page'] == "page_delete_ds")
{
$vals = $data['data'];
include_once("../components/pages/page_delete_ds.php");
page_delete_ds($vals);
}
ElseIf($data['load_page'] == "page_delete_struct_templ_medcart")
{
$vals = $data['data'];
include_once("../components/pages/page_delete_struct_templ_medcart.php");
page_delete_struct_templ_medcart($vals);
}
ElseIf($data['load_page'] == "page_delete_razdel_templ_medcart")
{
$vals = $data['data'];
include_once("../components/pages/page_delete_razdel_templ_medcart.php");
page_delete_razdel_templ_medcart($vals);
}
ElseIf($data['load_page'] == "page_delete_temple_medcart_self_only_text")
{
$vals = $data['data'];
include_once("../components/pages/page_delete_temple_medcart_self_only_text.php");
page_delete_temple_medcart_self_only_text($vals);
}
ElseIf($data['load_page'] == "page_add_new_visit")
{
$vals = $data['data'];
include_once("../components/pages/page_add_new_visit.php");
page_add_new_visit($vals);
}
ElseIf($data['load_page'] == "load_medcart_general_sp")
{
$vals = $data['data'];
include_once("../components/pages/load_medcart_general_sp.php");
load_medcart_general_sp($vals);
}
ElseIf($data['load_page'] == "edit_sp_medcart")
{
$vals = $data['data'];
include_once("../components/pages/edit_sp_medcart.php");
edit_sp_medcart($vals);
}
ElseIf($data['load_page'] == "page_medcart_self_add_new_razd")
{
$vals = $data['data'];
include_once("../components/pages/page_medcart_self_add_new_razd.php");
page_medcart_self_add_new_razd($vals);
}
ElseIf($data['load_page'] == "load_page_temple_razd_visit")
{
$vals = $data['data'];
include_once("../components/pages/load_page_temple_razd_visit.php");
load_page_temple_razd_visit($vals);
}
ElseIf($data['load_page'] == "load_page_edit_param_medcart_self")
{
$vals = $data['data'];
include_once("../components/pages/load_page_edit_param_medcart_self.php");
load_page_edit_param_medcart_self($vals);
}
ElseIf($data['load_page'] == "open_page_act_dw")
{
$vals = $data['data'];
include_once("../components/pages/open_page_act_dw.php");
open_page_act_dw($vals);
}
ElseIf($data['load_page'] == "open_page_add_act_dw")
{
$vals = $data['data'];
include_once("../components/pages/open_page_add_act_dw.php");
open_page_add_act_dw($vals);
}
ElseIf($data['load_page'] == "load_add_page_price")
{
$vals = $data['data'];
include_once("../components/pages/load_add_page_price.php");
load_add_page_price($vals);
}
ElseIf($data['load_page'] == "load_modal_page_settings")
{
$vals = $data['data'];
include_once("../components/pages/load_modal_page_settings.php");
load_modal_page_settings($vals);
}
ElseIf($data['load_page'] == "open_modal_load_sp_clients")
{
$vals = $data['data'];
include_once("../components/pages/open_modal_load_sp_clients.php");
open_modal_load_sp_clients($vals);
}
ElseIf($data['load_page'] == "modal_block_act_dw_admin")
{
$vals = $data['data'];
include_once("../components/pages/modal_block_act_dw_admin.php");
modal_block_act_dw_admin($vals);
}
ElseIf($data['load_page'] == "modal_page_inventar")
{
$vals = $data['data'];
include_once("../components/pages/modal_page_inventar.php");
modal_page_inventar($vals);
}
ElseIf($data['load_page'] == "modal_edit_position_ds")
{
$vals = $data['data'];
include_once("../components/pages/modal_edit_position_ds.php");
modal_edit_position_ds($vals);
}
ElseIf($data['load_page'] == "modal_page_import_new_template")
{
$vals = $data['data'];
include_once("../components/pages/modal_page_import_new_template.php");
modal_page_import_new_template($vals);
}
ElseIf($data['load_page'] == "modal_act_add_external_medcart_temple")
{
$vals = $data['data'];
include_once("../components/pages/modal_act_add_external_medcart_temple.php");
modal_act_add_external_medcart_temple($vals);
}
ElseIf($data['load_page'] == "open_modal_ids_edit_self")
{
$vals = $data['data'];
include_once("../components/pages/open_modal_ids_edit_self.php");
open_modal_ids_edit_self($vals);
}
ElseIf($data['load_page'] == "open_page_other_lica_ids")
{
$vals = $data['data'];
include_once("../components/pages/open_page_other_lica_ids.php");
open_page_other_lica_ids($vals);
}
ElseIf($data['load_page'] == "open_modal_mark_ent")
{
$vals = $data['data'];
include_once("../components/pages/open_modal_mark_ent.php");
open_modal_mark_ent($vals);
}







}
ElseIf(isset($data['load_block']))
{

If($data['load_block'] == "load_menu_choice_type_setka")
{
$vals = $data['data'];
include_once("../components/blocks/load_menu_choice_type_setka.php");
load_menu_choice_type_setka($vals);
}

ElseIf($data['load_block'] == "load_menu_ctlr_type_setka")
{
$vals = $data['data'];
include_once("../components/blocks/load_menu_ctlr_type_setka.php");
load_menu_ctlr_type_setka($vals);
}


ElseIf($data['load_block'] == "load_menu_setka_self")
{
$vals = $data['data'];
include_once("../components/blocks/load_menu_setka_self.php");
load_menu_setka_self($vals);
}

ElseIf($data['load_block'] == "load_users_dsfree")
{
#$vals = $data['data'];
include_once("../components/blocks/load_users_dsfree.php");
load_users_dsfree();
}

ElseIf($data['load_block'] == "show_info_setka_in_addsetka")
{
$vals = $data['data'];
include_once("../components/blocks/show_info_setka_in_addsetka.php");
show_info_setka_in_addsetka($vals);
}

ElseIf($data['load_block'] == "load_ctrl_jurpacs")
{
$vals = $data['data'];
include_once("../components/blocks/load_ctrl_jurpacs.php");
load_ctrl_jurpacs($vals);
}

ElseIf($data['load_block'] == "ctrl_jurpacs_doc_review")
{
$vals = $data['data'];
include_once("../components/blocks/ctrl_jurpacs_doc_review.php");
ctrl_jurpacs_doc_review($vals);
}

ElseIf($data['load_block'] == "load_jurpacs")
{
$vals = $data['data'];
include_once("../components/blocks/load_jurpacs.php");
load_jurpacs($vals);
}

ElseIf($data['load_block'] == "get_data")
{
$vals = $data['data'];
include_once("../components/blocks/get_data.php");
get_data($vals);
}

ElseIf($data['load_block'] == "calendar_choice_data_self")
{
$vals = $data['data'];
include_once("../components/blocks/calendar_choice_data_self.php");
calendar_choice_data_self($vals);
}

ElseIf($data['load_block'] == "ctrl_jurpacs_spdocs_review")
{
$vals = $data['data'];
include_once("../components/blocks/ctrl_jurpacs_spdocs_review.php");
ctrl_jurpacs_spdocs_review($vals);
}


ElseIf($data['load_block'] == "change_color_cell_jurpac")
{
$vals = $data['data'];
include_once("../components/blocks/change_color_cell_jurpac.php");
change_color_cell_jurpac($vals);
}


ElseIf($data['load_block'] == "show_jurpac_bottom_menu")
{
$vals = $data['data'];
include_once("../components/blocks/show_jurpac_bottom_menu.php");
show_jurpac_bottom_menu($vals);
}

ElseIf($data['load_block'] == "sel_run_act_bottom_jp")
{
$vals = $data['data'];
include_once("../components/blocks/sel_run_act_bottom_jp.php");
sel_run_act_bottom_jp($vals);
}

ElseIf($data['load_block'] == "load_field_ent_pac")
{
$vals = $data['data'];
include_once("../components/blocks/load_field_ent_pac.php");
load_field_ent_pac($vals);
}

ElseIf($data['load_block'] == "recalc_select_end_jurpac")
{
$vals = $data['data'];
include_once("../components/blocks/recalc_select_end_jurpac.php");
recalc_select_end_jurpac($vals);
}


ElseIf($data['load_block'] == "load_availible_times_docs_shed")
{
$vals = $data['data'];
include_once("../components/blocks/load_availible_times_docs_shed.php");
load_availible_times_docs_shed($vals);
}

ElseIf($data['load_block'] == "load_pacs_to_change_pac_jurpac")
{
$vals = $data['data'];
include_once("../components/blocks/load_pacs_to_change_pac_jurpac.php");
load_pacs_to_change_pac_jurpac($vals);
}

ElseIf($data['load_block'] == "navigate_screen_ssetka")
{
$vals = $data['data'];
include_once("../components/blocks/navigate_screen_ssetka.php");
navigate_screen_ssetka($vals);
}

ElseIf($data['load_block'] == "load_msd_calendar")
{
$vals = $data['data'];
include_once("../components/blocks/load_msd_calendar.php");
load_msd_calendar($vals);
}

ElseIf($data['load_block'] == "load_doc_msd")
{
$vals = $data['data'];
include_once("../components/blocks/load_doc_msd.php");
load_doc_msd($vals);
}

ElseIf($data['load_block'] == "load_sp_doc")
{
$vals = $data['data'];
include_once("../components/blocks/load_sp_doc.php");
load_sp_doc($vals);
}

ElseIf($data['load_block'] == "load_cert_doc")
{
$vals = $data['data'];
include_once("../components/blocks/load_cert_doc.php");
load_cert_doc($vals);
}

ElseIf($data['load_block'] == "load_view_cert")
{
$vals = $data['data'];
include_once("../components/blocks/load_view_cert.php");
load_view_cert($vals);
}

ElseIf($data['load_block'] == "delete_cert_doc")
{
$vals = $data['data'];
include_once("../components/blocks/delete_cert_doc.php");
delete_cert_doc($vals);
}

ElseIf($data['load_block'] == "delete_doc")
{
$vals = $data['data'];
include_once("../components/blocks/delete_doc.php");
delete_doc($vals);
}

ElseIf($data['load_block'] == "generate_palite_doc")
{
$vals = $data['data'];
include_once("../components/blocks/generate_palite_doc.php");
generate_palite_doc($vals);
}

ElseIf($data['load_block'] == "load_simple_doc_time")
{
$vals = $data['data'];
include_once("../components/blocks/load_simple_doc_time.php");
load_simple_doc_time($vals);
}

ElseIf($data['load_block'] == "erasing_excess_options_ssetka_default")
{
$vals = $data['data'];
include_once("../components/blocks/erasing_excess_options_ssetka_default.php");
erasing_excess_options_ssetka_default($vals);
}

ElseIf($data['load_block'] == "load_primary_docums_results")
{
$vals = $data['data'];
include_once("../components/blocks/load_primary_docums_results.php");
load_primary_docums_results($vals);
}

ElseIf($data['load_block'] == "load_primary_docums_type_pacs")
{
$vals = $data['data'];
include_once("../components/blocks/load_primary_docums_type_pacs.php");
load_primary_docums_type_pacs($vals);
}

ElseIf($data['load_block'] == "load_names_first_docums")
{
$vals = $data['data'];
include_once("../components/blocks/load_names_first_docums.php");
load_names_first_docums($vals);
}


ElseIf($data['load_block'] == "all_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/blocks/all_dogovor_pmu.php");
all_dogovor_pmu($vals);
}

ElseIf($data['load_block'] == "load_other_lica_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/blocks/load_other_lica_dogovor_pmu.php");
load_other_lica_dogovor_pmu($vals);
}

ElseIf($data['load_block'] == "load_saved_dss")
{
$vals = $data['data'];
include_once("../components/blocks/load_saved_dss.php");
load_saved_dss($vals);
}

ElseIf($data['load_block'] == "load_struct_templ_medcart")
{
$vals = $data['data'];
include_once("../components/blocks/load_struct_templ_medcart.php");
load_struct_templ_medcart($vals);
}

ElseIf($data['load_block'] == "load_razd_templ_medcart")
{
$vals = $data['data'];
include_once("../components/blocks/load_razd_templ_medcart.php");
load_razd_templ_medcart($vals);
}

ElseIf($data['load_block'] == "load_medcart_templ_razdel_self")
{
$vals = $data['data'];
include_once("../components/blocks/load_medcart_templ_razdel_self.php");
load_medcart_templ_razdel_self($vals);
}

ElseIf($data['load_block'] == "load_block_medcart_self")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_medcart_self.php");
load_block_medcart_self($vals);
}

ElseIf($data['load_block'] == "load_block_temple_razd_visit_self")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_temple_razd_visit_self.php");
load_block_temple_razd_visit_self($vals);
}
ElseIf($data['load_block'] == "load_block_act_dw")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_act_dw.php");
load_block_act_dw($vals);
}
ElseIf($data['load_block'] == "load_block_price")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_price.php");
load_block_price($vals);
}
ElseIf($data['load_block'] == "load_block_price_self")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_price_self.php");
load_block_price_self($vals);
}
ElseIf($data['load_block'] == "recalculate_time_work_clinic_preset")
{
$vals = $data['data'];
include_once("../components/blocks/recalculate_time_work_clinic_preset.php");
recalculate_time_work_clinic_preset($vals);
}
ElseIf($data['load_block'] == "load_sp_clients")
{
$vals = $data['data'];
include_once("../components/blocks/load_sp_clients.php");
load_sp_clients($vals);
}
ElseIf($data['load_block'] == "load_block_sp_delete_usluga_from_actdw")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_sp_delete_usluga_from_actdw.php");
load_block_sp_delete_usluga_from_actdw($vals);
}
ElseIf($data['load_block'] == "load_block_act_dw_admin")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_act_dw_admin.php");
load_block_act_dw_admin($vals);
}
ElseIf($data['load_block'] == "load_block_inventar")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_inventar.php");
load_block_inventar($vals);
}
ElseIf($data['load_block'] == "load_types_inventar")
{
$vals = $data['data'];
include_once("../components/blocks/load_types_inventar.php");
load_types_inventar($vals);
}
ElseIf($data['load_block'] == "load_block_position_ds")
{
$vals = $data['data'];
include_once("../components/blocks/load_block_position_ds.php");
load_block_position_ds($vals);
}
ElseIf($data['load_block'] == "change_f_position_ds")
{
$vals = $data['data'];
include_once("../components/blocks/change_f_position_ds.php");
change_f_position_ds($vals);
}
ElseIf($data['load_block'] == "load_ids_edit_self")
{
$vals = $data['data'];
include_once("../components/blocks/load_ids_edit_self.php");
load_ids_edit_self($vals);
}
ElseIf($data['load_block'] == "load_sp_all_types_ids")
{
$vals = $data['data'];
include_once("../components/blocks/load_sp_all_types_ids.php");
load_sp_all_types_ids($vals);
}
ElseIf($data['load_block'] == "load_td_field_work_ids")
{
$vals = $data['data'];
include_once("../components/blocks/load_td_field_work_ids.php");
load_td_field_work_ids($vals);
}
ElseIf($data['load_block'] == "change_num_days_ids")
{
$vals = $data['data'];
include_once("../components/blocks/change_num_days_ids.php");
change_num_days_ids($vals);
}
ElseIf($data['load_block'] == "load_all_clients_otherlica_ids")
{
$vals = $data['data'];
include_once("../components/blocks/load_all_clients_otherlica_ids.php");
load_all_clients_otherlica_ids($vals);
}
ElseIf($data['load_block'] == "change_num_days_plan_treat")
{
$vals = $data['data'];
include_once("../components/blocks/change_num_days_plan_treat.php");
change_num_days_plan_treat($vals);
}
ElseIf($data['load_block'] == "load_self_epikriz")
{
$vals = $data['data'];
include_once("../components/blocks/load_self_epikriz.php");
load_self_epikriz($vals);
}
ElseIf($data['load_block'] == "load_notes_pacs")
{
$vals = $data['data'];
include_once("../components/blocks/load_notes_pacs.php");
load_notes_pacs($vals);
}



}


ElseIf(isset($data['act']))
{

////////////////

If($data['act'] == "checkexit")
{
#$vals = $data['data'];
include_once("../components/functions/checkexit.php");
checkexit();
}

////////////////

ElseIf($data['act'] == "create_superuser")
{
$vals = $data['data'];
include_once("../components/functions/create_superuser.php");
create_superuser($vals);
}
ElseIf($data['act'] == "act_i_read_new_version")
{
$vals = $data['data'];
include_once("../components/functions/act_i_read_new_version.php");
act_i_read_new_version($vals);
}
ElseIf($data['act'] == "author_site")
{
$vals = $data['data'];
include_once("../components/functions/author_site.php");
author_site($vals);
}
ElseIf($data['act'] == "change_settings_ssetka")
{
$vals = $data['data'];
include_once("../components/functions/change_settings_ssetka.php");
change_settings_ssetka($vals);
}
ElseIf($data['act'] == "act_default_ssetka")
{
$vals = $data['data'];
include_once("../components/functions/act_default_ssetka.php");
act_default_ssetka($vals);
}

ElseIf($data['act'] == "add_new_user_dsfree")
{
#$vals = $data['data'];
include_once("../components/functions/add_new_user_dsfree.php");
add_new_user_dsfree();
}

ElseIf($data['act'] == "edit_dsf_users")
{
$vals = $data['data'];
include_once("../components/functions/edit_dsf_users.php");
edit_dsf_users($vals);
}

ElseIf($data['act'] == "exit_dsfree")
{
#$vals = $data['data'];
include_once("../components/functions/exit_dsfree.php");
exit_dsfree();
}

ElseIf($data['act'] == "add_profile_ssetka_user")
{
$vals = $data['data'];
include_once("../components/functions/add_profile_ssetka_user.php");
add_profile_ssetka_user($vals);
}

ElseIf($data['act'] == "delete_ssetka_from_profile")
{
$vals = $data['data'];
include_once("../components/functions/delete_ssetka_from_profile.php");
delete_ssetka_from_profile($vals);
}

ElseIf($data['act'] == "add_tab_ssetka_default")
{
$vals = $data['data'];
include_once("../components/functions/add_tab_ssetka_default.php");
add_tab_ssetka_default($vals);
}

ElseIf($data['act'] == "act_ssetka_default_active")
{
$vals = $data['data'];
include_once("../components/functions/act_ssetka_default_active.php");
act_ssetka_default_active($vals);
}

ElseIf($data['act'] == "act_change_default_param")
{
$vals = $data['data'];
include_once("../components/functions/act_change_default_param.php");
act_change_default_param($vals);
}

ElseIf($data['act'] == "cancel_ent_jp")
{
$vals = $data['data'];
include_once("../components/functions/cancel_ent_jp.php");
cancel_ent_jp($vals);
}

ElseIf($data['act'] == "write_new_pac_ent_jurpac")
{
$vals = $data['data'];
include_once("../components/functions/write_new_pac_ent_jurpac.php");
write_new_pac_ent_jurpac($vals);
}

ElseIf($data['act'] == "writing_new_doc_shed")
{
$vals = $data['data'];
include_once("../components/functions/writing_new_doc_shed.php");
writing_new_doc_shed($vals);
}

ElseIf($data['act'] == "act_change_doc_shed_times")
{
$vals = $data['data'];
include_once("../components/functions/act_change_doc_shed_times.php");
act_change_doc_shed_times($vals);
}

ElseIf($data['act'] == "send_new_period_shed_doc")
{
$vals = $data['data'];
include_once("../components/functions/send_new_period_shed_doc.php");
send_new_period_shed_doc($vals);
}

ElseIf($data['act'] == "act_change_pac_jurpac")
{
$vals = $data['data'];
include_once("../components/functions/act_change_pac_jurpac.php");
act_change_pac_jurpac($vals);
}

ElseIf($data['act'] == "send_new_period_ent_pac")
{
$vals = $data['data'];
include_once("../components/functions/send_new_period_ent_pac.php");
send_new_period_ent_pac($vals);
}

ElseIf($data['act'] == "save_new_msd")
{
$vals = $data['data'];
include_once("../components/functions/save_new_msd.php");
save_new_msd($vals);
}

ElseIf($data['act'] == "add_cert_doc")
{
$vals = $data['data'];
include_once("../components/functions/add_cert_doc.php");
add_cert_doc($vals);
}

ElseIf($data['act'] == "update_cert_doc")
{
$vals = $data['data'];
include_once("../components/functions/update_cert_doc.php");
update_cert_doc($vals);
}

ElseIf($data['act'] == "act_delete_cert_doc")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_cert_doc.php");
act_delete_cert_doc($vals);
}

ElseIf($data['act'] == "act_add_new_doc")
{
$vals = $data['data'];
include_once("../components/functions/act_add_new_doc.php");
act_add_new_doc($vals);
}

ElseIf($data['act'] == "change_fio_doc")
{
$vals = $data['data'];
include_once("../components/functions/change_fio_doc.php");
change_fio_doc($vals);
}

ElseIf($data['act'] == "act_chouse_new_color")
{
$vals = $data['data'];
include_once("../components/functions/act_chouse_new_color.php");
act_chouse_new_color($vals);
}

ElseIf($data['act'] == "act_delete_doc")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_doc.php");
act_delete_doc($vals);
}

ElseIf($data['act'] == "act_permissions_default")
{
$vals = $data['data'];
include_once("../components/functions/act_permissions_default.php");
act_permissions_default($vals);
}

ElseIf($data['act'] == "change_permission")
{
$vals = $data['data'];
include_once("../components/functions/change_permission.php");
change_permission($vals);
}
ElseIf($data['act'] == "edit_info_pacs")
{
$vals = $data['data'];
include_once("../components/functions/edit_info_pacs.php");
edit_info_pacs($vals);
}
ElseIf($data['act'] == "set_pac_sex")
{
$vals = $data['data'];
include_once("../components/functions/set_pac_sex.php");
set_pac_sex($vals);
}
ElseIf($data['act'] == "set_days_bt")
{
$vals = $data['data'];
include_once("../components/functions/set_days_bt.php");
set_days_bt($vals);
}
ElseIf($data['act'] == "act_add_otherlico_pre_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/functions/act_add_otherlico_pre_dogovor_pmu.php");
act_add_otherlico_pre_dogovor_pmu($vals);
}
ElseIf($data['act'] == "act_add_new_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/functions/act_add_new_dogovor_pmu.php");
act_add_new_dogovor_pmu($vals);
}
ElseIf($data['act'] == "act_add_otherlico_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/functions/act_add_otherlico_dogovor_pmu.php");
act_add_otherlico_dogovor_pmu($vals);
}
ElseIf($data['act'] == "change_param_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/functions/change_param_dogovor_pmu.php");
change_param_dogovor_pmu($vals);
}
ElseIf($data['act'] == "act_delete_dogovor_pmu")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_dogovor_pmu.php");
act_delete_dogovor_pmu($vals);
}
ElseIf($data['act'] == "print_primary_docums")
{
$vals = $data['data'];
include_once("../components/functions/print_primary_docums.php");
print_primary_docums($vals);
}
ElseIf($data['act'] == "act_save_new_ds")
{
$vals = $data['data'];
include_once("../components/functions/act_save_new_ds.php");
act_save_new_ds($vals);
}
ElseIf($data['act'] == "act_edit_ds_inner")
{
$vals = $data['data'];
include_once("../components/functions/act_edit_ds_inner.php");
act_edit_ds_inner($vals);
}
ElseIf($data['act'] == "add_new_struct_templ_medcart")
{
$vals = $data['data'];
include_once("../components/functions/add_new_struct_templ_medcart.php");
add_new_struct_templ_medcart($vals);
}
ElseIf($data['act'] == "add_new_razd_templ_medcart")
{
$vals = $data['data'];
include_once("../components/functions/add_new_razd_templ_medcart.php");
add_new_razd_templ_medcart($vals);
}

ElseIf($data['act'] == "act_add_new_temple_to_razdel_medcart")
{
$vals = $data['data'];
include_once("../components/functions/act_add_new_temple_to_razdel_medcart.php");
act_add_new_temple_to_razdel_medcart($vals);
}
ElseIf($data['act'] == "delete_ds")
{
$vals = $data['data'];
include_once("../components/functions/delete_ds.php");
delete_ds($vals);
}
ElseIf($data['act'] == "act_delete_structur_templ_medcart")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_structur_templ_medcart.php");
act_delete_structur_templ_medcart($vals);
}
ElseIf($data['act'] == "act_delete_razdel_templ_medcart")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_razdel_templ_medcart.php");
act_delete_razdel_templ_medcart($vals);
}
ElseIf($data['act'] == "edit_temple_medcart_self_text")
{
$vals = $data['data'];
include_once("../components/functions/edit_temple_medcart_self_text.php");
edit_temple_medcart_self_text($vals);
}
ElseIf($data['act'] == "act_delete_temple_medcart_self_only_text")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_temple_medcart_self_only_text.php");
act_delete_temple_medcart_self_only_text($vals);
}
ElseIf($data['act'] == "act_rename_struct_templ_medcart")
{
$vals = $data['data'];
include_once("../components/functions/act_rename_struct_templ_medcart.php");
act_rename_struct_templ_medcart($vals);
}
ElseIf($data['act'] == "act_rename_razd_templ_medcart")
{
$vals = $data['data'];
include_once("../components/functions/act_rename_razd_templ_medcart.php");
act_rename_razd_templ_medcart($vals);
}
ElseIf($data['act'] == "act_add_new_visit")
{
$vals = $data['data'];
include_once("../components/functions/act_add_new_visit.php");
act_add_new_visit($vals);
}
ElseIf($data['act'] == "act_medcart_self_add_new_razd")
{
$vals = $data['data'];
include_once("../components/functions/act_medcart_self_add_new_razd.php");
act_medcart_self_add_new_razd($vals);
}
ElseIf($data['act'] == "act_save_new_txt_razd_visit")
{
$vals = $data['data'];
include_once("../components/functions/act_save_new_txt_razd_visit.php");
act_save_new_txt_razd_visit($vals);
}
ElseIf($data['act'] == "reload_txt_razd_visit")
{
$vals = $data['data'];
include_once("../components/functions/reload_txt_razd_visit.php");
reload_txt_razd_visit($vals);
}
ElseIf($data['act'] == "act_save_new_param_medcart_self")
{
$vals = $data['data'];
include_once("../components/functions/act_save_new_param_medcart_self.php");
act_save_new_param_medcart_self($vals);
}
ElseIf($data['act'] == "act_sp_medcart")
{
$vals = $data['data'];
include_once("../components/functions/act_sp_medcart.php");
act_sp_medcart($vals);
}
ElseIf($data['act'] == "act_add_new_data_act_dw")
{
$vals = $data['data'];
include_once("../components/functions/act_add_new_data_act_dw.php");
act_add_new_data_act_dw($vals);
}
ElseIf($data['act'] == "act_add_page_price")
{
$vals = $data['data'];
include_once("../components/functions/act_add_page_price.php");
act_add_page_price($vals);
}
ElseIf($data['act'] == "act_modal_page_settings")
{
$vals = $data['data'];
include_once("../components/functions/act_modal_page_settings.php");
act_modal_page_settings($vals);
}
ElseIf($data['act'] == "act_sp_clients")
{
$vals = $data['data'];
include_once("../components/functions/act_sp_clients.php");
act_sp_clients($vals);
}
ElseIf($data['act'] == "act_delete_usluga_from_sp_dw")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_usluga_from_sp_dw.php");
act_delete_usluga_from_sp_dw($vals);
}
ElseIf($data['act'] == "act_block_act_dw_admin")
{
$vals = $data['data'];
include_once("../components/functions/act_block_act_dw_admin.php");
act_block_act_dw_admin($vals);
}
ElseIf($data['act'] == "act_item_to_inventar")
{
$vals = $data['data'];
include_once("../components/functions/act_item_to_inventar.php");
act_item_to_inventar($vals);
}
ElseIf($data['act'] == "act_delete_item_from_inventar")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_item_from_inventar.php");
act_delete_item_from_inventar($vals);
}
ElseIf($data['act'] == "act_rename_mass_type_inventar")
{
$vals = $data['data'];
include_once("../components/functions/act_rename_mass_type_inventar.php");
act_rename_mass_type_inventar($vals);
}
ElseIf($data['act'] == "print_inventar")
{
$vals = $data['data'];
include_once("../components/functions/print_inventar.php");
print_inventar($vals);
}
ElseIf($data['act'] == "act_save_new_position_ds")
{
$vals = $data['data'];
include_once("../components/functions/act_save_new_position_ds.php");
act_save_new_position_ds($vals);
}
ElseIf($data['act'] == "print_medcart")
{
$vals = $data['data'];
include_once("../components/functions/print_medcart.php");
print_medcart($vals);
}
ElseIf($data['act'] == "print_act_dw")
{
$vals = $data['data'];
include_once("../components/functions/print_act_dw.php");
print_act_dw($vals);
}
ElseIf($data['act'] == "act_add_external_medcart_temple")
{
$vals = $data['data'];
include_once("../components/functions/act_add_external_medcart_temple.php");
act_add_external_medcart_temple($vals);
}
ElseIf($data['act'] == "print_template_ds")
{
$vals = $data['data'];
include_once("../components/functions/print_template_ds.php");
print_template_ds($vals);
}
ElseIf($data['act'] == "act_add_new_ids")
{
$vals = $data['data'];
include_once("../components/functions/act_add_new_ids.php");
act_add_new_ids($vals);
}
ElseIf($data['act'] == "act_change_status_ids")
{
$vals = $data['data'];
include_once("../components/functions/act_change_status_ids.php");
act_change_status_ids($vals);
}
ElseIf($data['act'] == "act_rename_ids")
{
$vals = $data['data'];
include_once("../components/functions/act_rename_ids.php");
act_rename_ids($vals);
}
ElseIf($data['act'] == "act_rename_ids_file")
{
$vals = $data['data'];
include_once("../components/functions/act_rename_ids_file.php");
act_rename_ids_file($vals);
}
ElseIf($data['act'] == "act_delete_ids")
{
$vals = $data['data'];
include_once("../components/functions/act_delete_ids.php");
act_delete_ids($vals);
}
ElseIf($data['act'] == "print_ids")
{
$vals = $data['data'];
include_once("../components/functions/print_ids.php");
print_ids($vals);
}
ElseIf($data['act'] == "update_mark_ent")
{
$vals = $data['data'];
include_once("../components/functions/update_mark_ent.php");
update_mark_ent($vals);
}
ElseIf($data['act'] == "update_mark_ent_modal")
{
$vals = $data['data'];
include_once("../components/functions/update_mark_ent_modal.php");
update_mark_ent_modal($vals);
}




}

}
?>
