<?php

function change_color_doc($vals)
{

$screen = $vals['screen'];
$id_pers = $vals['id_pers'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

$row = mysqli_fetch_assoc($query);

$bg_color_gen = $row['bg_color_gen'];
$txt_color_gen = $row['txt_color_gen'];

$bg_color_pac = $row['bg_color_pac'];
$txt_color_pac = $row['txt_color_pac'];



echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"'); load_sp_doc('",$screen,"');\">X</span>

<script>

function generate_palite_doc(type,screen,id_pers)
{

var name_div = 'f_palite_' + type + '_' + screen;



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('generate_palite_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[id_pers]=\" + encodeURIComponent(id_pers));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var cont = document.getElementById(name_div);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


load_simple_doc_time(screen,id_pers);


}
}
}


}


function chouse_new_color(type,id_td_cell_color,rand_color,screen,id_pers)
{

if(type == 'bg_pac')
{

var demo_busy = 'demo_busy_' + screen;
document.getElementById(demo_busy).style.backgroundColor = rand_color;

var class_td_color = 'class_td_color_' + type + '_' + screen;
var theOddOnes = document.getElementsByClassName(class_td_color);

for(var i=0; i<theOddOnes.length; i++)
{
//получение ID из класса
var id_td_cell_color_by_class = theOddOnes[i].id;
document.getElementById(id_td_cell_color_by_class).innerHTML = '';
}

document.getElementById(id_td_cell_color).innerHTML = '✓';

}
else if(type == 'txt_pac')
{

var demo_busy = 'demo_busy_' + screen;
document.getElementById(demo_busy).style.color = rand_color;

var class_td_color = 'class_td_color_' + type + '_' + screen;
var theOddOnes = document.getElementsByClassName(class_td_color);

for(var i=0; i<theOddOnes.length; i++)
{
var id_td_cell_color_by_class = theOddOnes[i].id;
document.getElementById(id_td_cell_color_by_class).innerHTML = '';
}

document.getElementById(id_td_cell_color).innerHTML = '✓';

}

else if(type == 'bg_gen')
{

var class_td_free = 'demo_free_' + screen;
var theOddOnes = document.getElementsByClassName(class_td_free);

for(var i=0; i<theOddOnes.length; i++)
{
var id_td_free = theOddOnes[i].id;
document.getElementById(id_td_free).style.backgroundColor = rand_color;
}

var class_td_free = 'class_td_color_' + type + '_' + screen;
var theOddOnes = document.getElementsByClassName(class_td_free);

for(var i=0; i<theOddOnes.length; i++)
{
var id_td_cell_color_by_class = theOddOnes[i].id;
document.getElementById(id_td_cell_color_by_class).innerHTML = '';
}

document.getElementById(id_td_cell_color).innerHTML = '✓';

}

else if(type == 'txt_gen')
{

var class_td_free = 'demo_free_' + screen;
var theOddOnes = document.getElementsByClassName(class_td_free);

for(var i=0; i<theOddOnes.length; i++)
{
var id_td_free = theOddOnes[i].id;
document.getElementById(id_td_free).style.color = rand_color;
}

var class_td_free = 'class_td_color_' + type + '_' + screen;
var theOddOnes = document.getElementsByClassName(class_td_free);

for(var i=0; i<theOddOnes.length; i++)
{
var id_td_cell_color_by_class = theOddOnes[i].id;
document.getElementById(id_td_cell_color_by_class).innerHTML = '';
}

document.getElementById(id_td_cell_color).innerHTML = '✓';

}


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_chouse_new_color') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[rand_color]=\" + encodeURIComponent(rand_color));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {




}
}
}



}



function load_simple_doc_time(screen,id_pers)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_simple_doc_time') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pers]=\" + encodeURIComponent(id_pers));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_simple_doc_time = 'f_simple_doc_time_' + screen;

var cont = document.getElementById(f_simple_doc_time);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}



}

</script>

<table border = \"1\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; background-color: ; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td height = \"40%\">

<div id = \"f_palite_bg_pac_",$screen,"\" style = \"width: 100%; height: 100%;\"></div>

</td>
<td rowspan = \"4\" width = \"40%\">

<div id = \"f_simple_doc_time_",$screen,"\" style = \"width: 100%; height: 100%;\"></div>

</td>

<td>

<div id = \"f_palite_bg_gen_",$screen,"\" style = \"width: 100%; height: 100%;\"></div>

</td>
</tr>

<tr align = \"center\" height = \"10%\" style = \"background-color: green; color: white; font-weight: bold; cursor: pointer;\">
<td onclick = \"generate_palite_doc('bg_pac','",$screen,"','",$id_pers,"');\">
генерация
</td>
<td onclick = \"generate_palite_doc('bg_gen','",$screen,"','",$id_pers,"');\">
генерация
</td>
</tr>

<tr>
<td>

<div id = \"f_palite_txt_pac_",$screen,"\" style = \"width: 100%; height: 100%;\"></div>

</td>
<td>

<div id = \"f_palite_txt_gen_",$screen,"\" style = \"width: 100%; height: 100%;\"></div>

</td>
</tr>

<tr align = \"center\" height = \"10%\" style = \"background-color: green; color: white; font-weight: bold; cursor: pointer;\">
<td onclick = \"generate_palite_doc('txt_pac','",$screen,"','",$id_pers,"');\">
генерация
</td>
<td onclick = \"generate_palite_doc('txt_gen','",$screen,"','",$id_pers,"');\">
генерация
</td>
</tr>


</table>

<script>
generate_palite_doc('bg_pac','",$screen,"','",$id_pers,"');
generate_palite_doc('bg_gen','",$screen,"','",$id_pers,"');
generate_palite_doc('txt_pac','",$screen,"','",$id_pers,"');
generate_palite_doc('txt_gen','",$screen,"','",$id_pers,"');

load_simple_doc_time('",$screen,"','",$id_pers,"')

</script>

<span id = \"hid_docs_color_",$screen,"\"></span>


";



}

?>
