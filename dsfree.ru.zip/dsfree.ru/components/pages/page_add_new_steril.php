<?php

function page_add_new_steril($vals)
{

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<script>

function get_params_autoclav(type,screen,id_autoclav,second_param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('get_params_autoclav') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[id_autoclav]=\" + encodeURIComponent(id_autoclav) + \"&data[second_param]=\" + encodeURIComponent(second_param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f = 'f_' + type + '_' + screen;

var cont = document.getElementById(f);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function act_but_send_jur_steril(screen,type)
{

var but_send_new_steril_active = 'but_send_new_steril_active_' + screen;
var but_send_new_steril_inactive = 'but_send_new_steril_inactive_' + screen;

if(type == '')
{
document.getElementById(but_send_new_steril_active).style.display = 'none';
document.getElementById(but_send_new_steril_inactive).style.display = 'flex';
}
else{
document.getElementById(but_send_new_steril_active).style.display = 'flex';
document.getElementById(but_send_new_steril_inactive).style.display = 'none';
}



}

function write_new_jur_stril(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

//Изделия
var checkbox_izd = 'checkbox_izd_' + screen;
var clist=document.getElementsByClassName(checkbox_izd);
var arr = [];

for (var i = 0; i < clist.length; ++i)
{
if (clist[i].checked)
{

//выбранный чекбокс
var selected_chbox = clist[i].value;

//связанное с ним количество
var f_count_izd = 'count_izd_' + selected_chbox + '_' + screen;
var e = document.getElementById(f_count_izd);
var value = e.value;
var count_izd = e.options[e.selectedIndex].value;

//связанная с ним упаковка

var  ans_pakage = 'ans_pakage_' + selected_chbox + '_' + screen;
var e = document.getElementById(ans_pakage);
var value = e.value;
var pakage = e.options[e.selectedIndex].value;



arr.push(selected_chbox + '@' + count_izd + '@' + pakage);
}
}


var izd= arr.join('#');
//alert(izd);


//День
var ans_day = 'ans_day_' + screen;
var e = document.getElementById(ans_day);
var value = e.value;
var day = e.options[e.selectedIndex].value;

//Месяц
var ans_month = 'ans_month_' + screen;
var e = document.getElementById(ans_month);
var value = e.value;
var month = e.options[e.selectedIndex].value;

//Год
var ans_year = 'ans_year_' + screen;
var e = document.getElementById(ans_year);
var value = e.value;
var year = e.options[e.selectedIndex].value;


//Начало стерилизации
var ans_time_b = 'ans_time_b_' + screen;
var e = document.getElementById(ans_time_b);
var value = e.value;
var time_b = e.options[e.selectedIndex].text;


//Конец стерилизации
var f_recalc_time_autoclaving = 'f_recalc_time_autoclaving_' + screen;
var time_e = document.getElementById(f_recalc_time_autoclaving).innerHTML;


//Автоклав
var ans_autoclav = 'ans_autoclav_' + screen;
var e = document.getElementById(ans_autoclav);
var value = e.value;
var autoclav = e.options[e.selectedIndex].text;


//Режим
var ans_mode = 'ans_mode_' + screen;
var e = document.getElementById(ans_mode);
var value = e.value;
var mode = e.options[e.selectedIndex].text;


xmlhttp.send(\"act=\" + encodeURIComponent('write_new_jur_stril') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[day]=\" + encodeURIComponent(day) + \"&data[month]=\" + encodeURIComponent(month) + \"&data[year]=\" + encodeURIComponent(year) + \"&data[time_b]=\" + encodeURIComponent(time_b) + \"&data[time_e]=\" + encodeURIComponent(time_e) + \"&data[autoclav]=\" + encodeURIComponent(autoclav) + \"&data[izd]=\" + encodeURIComponent(izd) + \"&data[mode]=\" + encodeURIComponent(mode) + \"&data[pakage]=\" + encodeURIComponent(pakage));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var hidden_f_ads = 'hidden_f_ads_' + screen;

var cont = document.getElementById(hidden_f_ads);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>


<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td colspan = \"2\" align = \"left\" style = \"background-color: black; color: white; font-weight: bold;\">
новая стерилизация
</td>
</tr>

<tr>
<td width = \"40%\">

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"25%\">
<td>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"33%\">
<td align = \"left\" style = \"background-color: grey; color: white;\">
дата стерилизации
</td>
</tr>
<tr>
<td>";

$day_now = date("d");
$month_now = date("m");
$year_now = date("Y");

$hour_now = date("H");
$min_now = date("i");

$hi_now = $hour_now.":".$min_now;

$number_days = cal_days_in_month(CAL_GREGORIAN, $month_now, $year_now);



echo "<select id = \"ans_day_",$screen,"\">";

For($d=1;$d<=$number_days;$d++)
{
echo "<option value = \"",$d,"\"";

If($d == $day_now)
{
echo " selected";
}

echo ">",$d,"</option>";
}

echo "
</select>

";

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);



echo "

<select id = \"ans_month_",$screen,"\">";

Foreach($ar_months_rus as $num_m=>$runame_m)
{

echo "<option";

If($num_m == $month_now)
{
echo " selected";
}

echo " value = \"",$num_m,"\">",$runame_m,"</option>";

}

echo "
</select>

<select id = \"ans_year_",$screen,"\">";


$year_min = $year_now-10;
$year_max = $year_now+10;

For($year_min;$year_min<=$year_max;$year_min++)
{
echo "<option";

If($year_min == $year_now)
{
echo " selected";
}

echo ">",$year_min,"</option>";
}

echo "
</select>

</td>
</tr>
</table>

</td>
</tr>
<tr height = \"25%\">
<td>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"33%\">
<td align = \"left\" style = \"background-color: grey; color: white;\">
время стерилизации
</td>
</tr>
<tr>
<td>

<div id = \"f_time_end_autoclaving_",$screen,"\">нет данных</div> 

</td>
</tr>
</table>

</td>
</tr>
<tr height = \"25%\">
<td>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"33%\">
<td align = \"left\" style = \"background-color: grey; color: white;\">
автоклав
</td>
</tr>
<tr>
<td>

<div id = \"f_autoclav_",$screen,"\"></div>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"33%\">
<td align = \"left\" style = \"background-color: grey; color: white;\">
режим



</td>
</tr>
<tr>
<td>

<div id = \"f_mode_",$screen,"\">
нет данных
</div>

</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
<td>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td>
изделия
</td>

</tr>
<tr>
<td >

<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">";

$sql = "select * from tab_steril_kit order by name_short ASC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "

<table align = \"center\" border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">

";



while($row = mysqli_fetch_assoc($query))
{

$name_short = $row['name_short'];

echo "<tr height = \"25px\">
<td width = \"15%\">

<input value = \"",$name_short,"\" class = \"checkbox_izd_",$screen,"\" type = \"checkbox\"></td><td>Набор №",$name_short,"</td>

<td width = \"15%\">

<select id = \"count_izd_",$name_short,"_",$screen,"\">";

For($o=1;$o<=10;$o++)
{
echo "<option>",$o,"</option>";
}



echo "</select>
</td>

<td >


<select id = \"ans_pakage_",$name_short,"_",$screen,"\">";

$ar_pakage = array("пакет комб","крафт пакет");

Foreach($ar_pakage as $pak)
{
echo "<option>",$pak,"</option>";
}


echo "</select>



</td>

</tr>";

}


echo "</table>";

}



echo "
</div>

</td>
</tr>


</table>

</td>
</tr>

<tr>
<td onclick = \"write_new_jur_stril('",$screen,"');\" colspan = \"2\" style = \"background-color: #008080; color: white; font-weight: bold; cursor: pointer;\">
запись
</td>
</tr>

</table>

<span id = \"hidden_f_ads_",$screen,"\" style = \"display: ;\"></span>

<span id = \"hidden_f_saved_izd_",$screen,"\" style = \"display: ;\"></span>

<script>
get_params_autoclav('autoclav','",$screen,"','','');

</script>

";


}

?>
