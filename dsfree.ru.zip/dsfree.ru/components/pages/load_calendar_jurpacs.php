<?php

function load_calendar_jurpacs($vals)
{


$screen = $vals['screen'];
$date = $vals['date'];

$ar_date = explode("-",$date);
$year = $ar_date[2];
$month = $ar_date[1];


$year_min = $year-5;
$year_max = $year+5;

$ar_rus_month = array("01"=>"январь","02"=>"февраль","03"=>"март","04"=>"апрель","05"=>"май","06"=>"июнь","07"=>"июль","08"=>"август","09"=>"сентябрь","10"=>"октябрь","11"=>"ноябрь","12"=>"декабрь");


echo "
<script>

</script>
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>
<table border = \"0\" width = \"100.5%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: left; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\" align = \"center\">
<td>
<select id = \"choice_data_jurpacs_sel_year_",$screen,"\" onchange = \"calendar_choice_data_self('",$screen,"');\">";

For($year_min;$year_min<=$year_max;$year_min++)
{
echo "<option";

If($year_min == $year)
{
echo " selected";
}

echo " value = \"",$year_min,"\">",$year_min,"</option>";
}



echo "
</select>

</td>
<td>
<select id = \"choice_data_jurpacs_sel_month_",$screen,"\" onchange = \"calendar_choice_data_self('",$screen,"');\">";

Foreach($ar_rus_month as $nm=>$rus)
{

echo "<option";

If($nm == $month)
{
echo " selected";
}

echo " value = \"",$nm,"\">",$rus,"</option>";

}

echo "
</select>
</td>
</tr>
<tr>
<td colspan = \"2\">
<div id = \"f_cal_choice_data_self_",$screen,"\" style = \"width: 100%; height: 100%; background-color: #2E3436;\">
</div>
</td>
</tr>
</table>
<script>
calendar_choice_data_self('",$screen,"');
</script>
";





}

?>
