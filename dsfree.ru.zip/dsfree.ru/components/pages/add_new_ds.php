<?php

function add_new_ds($vals){

#print_r($vals);

$screen = $vals['screen'];
$mode = $vals['mode'];
$id_ds = $vals['id_ds'];

$id_pac = $vals['id_pac'];

$ar_all_classif = array("mmsi"=>"ммси","mkb10"=>"мкб10","mkb11"=>"мкб11","aae"=>"ааэ");

If($mode == "out")
{

include_once("add_new_ds_out.php");
add_new_ds_out($ar_all_classif,$screen,$id_pac);

}
ElseIf($mode == "inner")
{

include_once("edit_ds_inner.php");
edit_ds_inner($ar_all_classif,$screen,$id_ds);

}




}

?>
