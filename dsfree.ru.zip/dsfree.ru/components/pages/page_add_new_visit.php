<?php

function page_add_new_visit($vals)
{

$name_docum = $vals['name_docum'];

If($name_docum == "step1")
{
include_once("../components/pages/page_add_new_visit_step1.php");
page_add_new_visit_step1($vals);
}
ElseIf($name_docum == "step2")
{
include_once("../components/pages/page_add_new_visit_step2.php");
page_add_new_visit_step2($vals);
}

}

?>
