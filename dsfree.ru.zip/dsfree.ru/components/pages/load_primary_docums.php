<?php

function load_primary_docums($vals)
{

$id_pers = $vals['id_pers'];
$screen = $vals['screen'];



If($id_pers == "")
{
//точно не известно посещение, нужна страница поиска пациента


echo "

<script>

function load_primary_docums_results(surname_pac,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_primary_docums_results') + \"&data[surname_pac]=\" + encodeURIComponent(surname_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_primary_docums_results = 'f_load_primary_docums_results_' + screen;

var cont = document.getElementById(f_load_primary_docums_results);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

//


}



</script>

<style>

.class_choice_pac_primary_docum_",$screen,":hover{
background-color: #808080;
}

.class_choice_pac_primary_docum_",$screen,"{
border: 1px dotted #808080;
cursor: pointer;
}

</style>


<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #242424; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
</td>
<td width = \"50%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"7%\">
<td align = \"left\">
<input onkeyup = \"load_primary_docums_results(this.value,'",$screen,"');\" type = \"text\" style = \"width: 98%; height: 95%;\" placeholder = \"фамилия пациента\" value = \"\">
</td>
<td width = \"20%\" align = \"center\" style = \" color: red; font-weight: bold; cursor: pointer;\">
x
</td>
</tr>
<tr >
<td align = \"center\" colspan = \"2\">

<div id = \"f_load_primary_docums_results_",$screen,"\" style = \"width: 100%; height: 100%;\">
</div>

</td>
</tr>
</table>


</td>
<td>
</td>
</tr>
</table>

<script>
load_primary_docums_results('','",$screen,"');
</script>
";



}
Else{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

#print_r($ar_user);

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = (select id_pacs from pacs_ent where id_ent = '$id_pers')";
#echo $sql;

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_pac = $row['id_pac'];
}
Else{
$id_pac = "";
}


echo "<script>choice_pac_primary_docum('",$id_pac,"','",$screen,"');</script>";


}











/*

If($id_pers == "")
{
$surname_pac = "";

}
Else{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

#print_r($ar_user);

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = (select id_pacs from pacs_ent where id_ent = '$id_pers')";
#echo $sql;

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$surname_pac = $row['surname_pac'];



}
Else{

$surname_pac = "";

}


}

*/






}

?>
