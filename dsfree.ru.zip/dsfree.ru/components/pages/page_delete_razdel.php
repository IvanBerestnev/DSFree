<?php

function page_delete_razdel($vals)
{

#print_r($vals);

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];
$id_writed_razd = $vals['id_writed_razd'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td style = \"background-color: #222222;\" colspan = \"2\">
удалить раздел из медицинской записи?
</td>
</tr>
<tr height = \"20%\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" width = \"50%\" style = \"background-color: #FF8080;\">
нет
</td>
<td onclick = \"act_save_new_param_medcart_self('",$id_visit,"','",$id_writed_razd,"','act_delete_razdel','",$screen,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
<span id = \"hidden_delete_razdel_medcart_self_",$screen,"\" style = \"display: ;\"></span>
";

}

?>
