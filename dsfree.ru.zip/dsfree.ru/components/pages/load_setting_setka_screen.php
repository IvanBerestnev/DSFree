<?php

function load_setting()
{

//Получить куки и id-пользователя

If(!isset($_COOKIE['dsf_cookie']))
{
echo "<meta http-equiv=\"refresh\" content=\"0\">";
}
Else{
$cookie = $_COOKIE['dsf_cookie'];
}

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_users where id_user = (select id_user from auths where id_cookie = '$cookie')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$level = $row['level'];
$id_pers = $row['id_user'];
}

//
//Получить список пользователей

$sql = "select * from dsf_users";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while ($row = mysqli_fetch_assoc($query))
{
$ar_users[$row['id_user']]['name_user'] = $row['name_user'];
$ar_users[$row['id_user']]['level'] = $row['level'];
}

}

//

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_setka_screen_profiles where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) == 0)
{
#$row = mysqli_fetch_assoc($query);

$arr = array(
"basic_setka"=>array("simple"=>array("rows"=>"2","cols"=>"2","spacex"=>"10","spacey"=>"20")),
"padding"=>array("a"=>"100","b"=>"150","c"=>"100","d"=>"150"),
"bind_setka"=>""
);

$json_arr = json_encode($arr);
$id_setka = md5(uniqid(rand(),1));

$sql = "insert into tab_setka_screen_profiles values ('$id_setka','$id_pers','$json_arr')";
$query = mysqli_query($connection,$sql);

echo "<script>load_setting_setka_screen();</script>";


}
Else{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['vals'];
$arr = json_decode($json_arr,true);

$type_setka_bd = key($arr['basic_setka']);

}


$a = $arr['padding']['a'];
$b = $arr['padding']['b'];
$c = $arr['padding']['c'];
$d = $arr['padding']['d'];



echo "

<script>

function load_menu_choice_type_setka(param)
{

var select = document.getElementById('id_selected_user');
var id_selected_user = select.options[select.selectedIndex].value;

if(param == '')
{
var str = \"load_block=\" + encodeURIComponent('load_menu_choice_type_setka') + \"&data[id_user]=\" + encodeURIComponent(id_selected_user);
}
else{
if(param !== 'simple')
{
var str = \"load_block=\" + encodeURIComponent('load_menu_choice_type_setka') + \"&data[id_user]=\" + encodeURIComponent(id_selected_user) + \"&data[type_setka]=\" + encodeURIComponent(param);
}
else{
var str = \"load_block=\" + encodeURIComponent('load_menu_choice_type_setka') + \"&data[id_user]=\" + encodeURIComponent(id_selected_user);
}

}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(str);

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_menu_choice_type_setka');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function load_menu_setka_self()
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_menu_setka_self'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_setka_self');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function change_params_setka(value,type)
{

var select = document.getElementById('id_selected_user');
var id_selected_user = select.options[select.selectedIndex].value;

//alert(id_selected_user);

var select = document.getElementById('id_sel_menu_choice_type_setka');
var id_sel_menu_choice_type_setka = select.options[select.selectedIndex].value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('change_params_setka') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[value]=\" + encodeURIComponent(value) + \"&data[id_user]=\" + encodeURIComponent(id_selected_user) + \"&data[name_setka]=\" + encodeURIComponent(id_sel_menu_choice_type_setka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

//f_menu_choice_type_setka
//hidden_div

var cont = document.getElementById('hidden_div');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; \" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"20%\">
<td align = \"center\" width = \"15%\" style = \"background-color: #575757; color: white; font-weight: bold; cursor: pointer;\">

Выбрать профиль

</td>
<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; \" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>
<div id = \"f_menu_choice_type_setka\" style = \"width: 100%; height: 100%;\">

</div>
</td>
<td width = \"20%\" align = \"center\">

<select id = \"id_sel_menu_choice_type_setka\" onchange = \"load_menu_choice_type_setka(this.value);\">";


$ar_types_setka = array("Стандарт"=>"simple","Специальный 1"=>"special_1");

Foreach($ar_types_setka as $k=>$v)
{
echo "<option";

If($v == $type_setka_bd)
{
echo " selected";
}

echo " value = \"",$v,"\">",$k,"</option>"; 

}

echo "</select>

<br><br>

<span style = \"border: 1px solid black; padding-left: 3px; padding-right: 3px; cursor: pointer;\">
применить
</span>

</td>
</tr>

</table>

</td>
<td align = \"center\" width = \"15%\" style = \"background-color: #575757;\">";

If($level == "3")
{

echo "<b style = \"color: white;\">Пользователь</b><br>
<select id = \"id_selected_user\" onchange = \"load_menu_choice_type_setka();\">";

Foreach($ar_users as $id_user=>$ar_vals)
{
$name_user = $ar_vals['name_user'];


echo "<option";
If($id_user == $id_pers)
{
echo " selected";
}
echo " value = \"",$id_user,"\">",$name_user,"</option>";
}

echo "</select>";

}



echo "</td>
</tr>
<tr height = \"10%\" style = \"background-color: #575757;\">
<td colspan = \"3\" align = \"center\" style = \"background-color: #575757; color: white; font-weight: bold;\">

<input onkeyup = \"change_params_setka(this.value,'a');\" size = \"2\" value = \"",$a,"\"> px

</td>
</tr>
<tr align = \"center\" >
<td style = \"background-color: #575757; color: white; font-weight: bold;\">

<input onkeyup = \"change_params_setka(this.value,'b');\" size = \"2\" value = \"",$b,"\"> px

</td>
<td>
<div id = \"f_setka_self\" style = \"width: 100%; height: 100%;\">

</div>
</td>
<td style = \"background-color: #575757; color: white; font-weight: bold;\">

<input onkeyup = \"change_params_setka(this.value,'c');\" size = \"2\" value = \"",$c,"\"> px

</td>
</tr>
<tr style = \"background-color: #575757; color: white; font-weight: bold;\" height = \"10%\">
<td colspan = \"3\" align = \"center\">

<input onkeyup = \"change_params_setka(this.value,'d');\" size = \"2\" value = \"",$d,"\"> px

</td>
</tr>

</table>
<div id = \"hidden_div\" style = \"display: none;\"></div>
<script>load_menu_choice_type_setka('');</script>
";


}

?>
