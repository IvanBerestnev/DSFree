<?php

function load_medcart_self($vals)
{

#print_r($vals);
$id_visit = $vals['param'];
$screen = $vals['screen'];

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pac = $row['id_pac'];
$ds = $row['ds'];
$date_time = $row['date_time'];
$fio_doc = $row['fio_doc'];

If($fio_doc == "")
{
$fio_doc_view = "врач не выбран";
}
Else{
$fio_doc_view = $fio_doc;
}


}

echo "

<script>

function load_block_medcart_self(id_visit,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_medcart_self') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_visit]=\" + encodeURIComponent(id_visit));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_medcart_self = 'f_load_medcart_self_' + screen;

var cont = document.getElementById(f_load_medcart_self);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function medcart_self_table_no_any_inf_hidden(screen)
{

var medcart_self_table_no_any_inf = 'medcart_self_table_no_any_inf_' + screen;
document.getElementById(medcart_self_table_no_any_inf).style.display = 'none';

}



function page_medcart_self_add_new_razd(screen,id_visit)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_medcart_self_add_new_razd') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_visit]=\" + encodeURIComponent(id_visit));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '45%';
document.getElementById(modal).style.height = '15%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function act_medcart_self_add_new_razd(screen,id_visit)
{

var page_medcart_self_add_new_razd_inp = 'page_medcart_self_add_new_razd_inp_' + screen;
var text = document.getElementById(page_medcart_self_add_new_razd_inp).value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_medcart_self_add_new_razd') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[text]=\" + encodeURIComponent(text));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_medcart_self = 'f_load_medcart_self_' + screen;

var cont = document.getElementById(f_load_medcart_self);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function save_new_txt_razd_visit(id_visit,id_writed_razd,screen)
{

var textarea = 'textarea_' + id_writed_razd + '_' + screen;
var text = document.getElementById(textarea).value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_save_new_txt_razd_visit') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_writed_razd]=\" + encodeURIComponent(id_writed_razd) + \"&data[text]=\" + encodeURIComponent(text) + \"&data[id_visit]=\" + encodeURIComponent(id_visit));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

}
}
}


}

function reload_txt_razd_visit(id_visit,id_writed_razd,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('reload_txt_razd_visit') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_writed_razd]=\" + encodeURIComponent(id_writed_razd) + \"&data[id_visit]=\" + encodeURIComponent(id_visit));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var textarea = 'textarea_' + id_writed_razd + '_' + screen;

var cont = document.getElementById(textarea);
cont.value = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}

function load_page_temple_razd_visit(id_visit,id_writed_razd,screen,id_struct,id_razd,id_bd_ds_temple)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_page_temple_razd_visit') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[id_writed_razd]=\" + encodeURIComponent(id_writed_razd) + \"&data[id_struct]=\" + encodeURIComponent(id_struct) + \"&data[id_razd]=\" + encodeURIComponent(id_razd) + \"&data[id_bd_ds_temple]=\" + encodeURIComponent(id_bd_ds_temple));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '65%';
document.getElementById(modal).style.height = '35%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function insert_temple_to_textarea(id_writed_razd,screen,id_selftemple)
{

var f_saved_templ_text = 'f_saved_templ_text_' + id_selftemple + '_' + screen;
var new_txt = document.getElementById(f_saved_templ_text).innerHTML;

var textarea = 'textarea_' + id_writed_razd + '_' + screen;
document.getElementById(textarea).value = new_txt;

var fon_modal = 'fon_modal_' + screen;
close_mw(fon_modal);

}

function load_page_edit_param_medcart_self(id_visit,id_writed_razd,page,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_page_edit_param_medcart_self') + \"&data[page]=\" + encodeURIComponent(page) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[id_writed_razd]=\" + encodeURIComponent(id_writed_razd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '35%';
document.getElementById(modal).style.height = '15%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

function act_save_new_param_medcart_self(id_visit,id_writed_razd,name,screen)
{

if(name == 'act_rename_razd')
{
var txt = 'new_txt_' + id_writed_razd + '_' + screen;
var changed_txt = document.getElementById(txt).value;
}
else if(name == 'datatime_razdel_medcart_self')
{

var sel_hour = 'hour_razdel_medcart_self_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_hour);
var hour = sel.options[sel.selectedIndex].value;

var sel_min = 'min_razdel_medcart_self_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_min);
var min = sel.options[sel.selectedIndex].value;

var sel_sec = 'sec_razdel_medcart_self_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_sec);
var sec = sel.options[sel.selectedIndex].value;


var sel_day = 'day_razdel_medcart_self_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_day);
var day = sel.options[sel.selectedIndex].value;


var sel_month = 'month_razdel_medcart_self_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_month);
var month_to_write = sel.options[sel.selectedIndex].value;
var month_to_view = sel.options[sel.selectedIndex].text;

var sel_year = 'year_razdel_medcart_self_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_year);
var year = sel.options[sel.selectedIndex].value;

var changed_txt = year + '-' + month_to_write + '-' + day + ' ' + hour + ':' + min + ':' + sec;
var view_txt = year + '-' + month_to_view + '-' + day + ' ' + hour + ':' + min + ':' + sec;
}
else if(name == 'act_delete_visit')
{
var changed_txt = '';
}
else if(name == 'act_delete_razdel')
{
var changed_txt = '';

}
else if(name == 'act_ds_rename_medcart_self')
{
var inp_new_ds_medcart_self = 'inp_new_ds_medcart_self_' + screen;
var changed_txt = document.getElementById(inp_new_ds_medcart_self).value;

}
else if(name == 'act_set_doc_medcart_self')
{

var changed_txt = '';

}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_save_new_param_medcart_self') + \"&data[id_writed_razd]=\" + encodeURIComponent(id_writed_razd) + \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[new_txt]=\" + encodeURIComponent(changed_txt) + \"&data[name]=\" + encodeURIComponent(name) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

if(name == 'act_rename_razd')
{
var hidden_rename_razdel_medcart_self = 'hidden_rename_razdel_medcart_self_' + screen;
var cont = document.getElementById(hidden_rename_razdel_medcart_self);
}
else if(name == 'datatime_razdel_medcart_self')
{
var hidden_datatime_razdel_medcart_self = 'hidden_datatime_razdel_medcart_self_' + screen;
var cont = document.getElementById(hidden_datatime_razdel_medcart_self);

}
else if(name == 'act_delete_visit')
{
var hidden_rename_razdel_medcart_self = 'hidden_rename_razdel_medcart_self_' + screen;
var cont = document.getElementById(hidden_rename_razdel_medcart_self);

}
else if(name == 'act_delete_razdel')
{
var hidden_delete_razdel_medcart_self = 'hidden_delete_razdel_medcart_self_' + screen;
var cont = document.getElementById(hidden_delete_razdel_medcart_self);

}
else if(name == 'act_ds_rename_medcart_self')
{
var hidden_edit_ds_self_medcart = 'hidden_edit_ds_self_medcart_' + screen;
var cont = document.getElementById(hidden_edit_ds_self_medcart);
}
else if(name == 'act_set_doc_medcart_self')
{
var hidden_open_choice_doc_medcart_self = 'hidden_open_choice_doc_medcart_self_' + screen;
var cont = document.getElementById(hidden_open_choice_doc_medcart_self);
}

cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}

</script>

<style>

textarea:focus, input:focus{
outline: none;
}

</style>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\">
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"20%\" style = \"cursor:pointer;\" class = \"but_back_to_sp_first_docs_",$screen,"\">

&#10096;
</td>
<td>
Медицинская карта
</td>
</tr>
</table>

</td>

<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Петровский
</td>
<td width = \"20%\" onclick=\"load_primary_docums('','",$screen,"');\">
Х
</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td >
Текущая запись
</td>
<td width = \"20%\" onclick=\"edit_first_docum('medcart_general','",$id_pac,"','",$screen,"');\">
Х
</td>
</tr>
</table>

</td>
</tr>
</table>

</td>

</tr>
</table>

</td>
</tr>
<tr>
<td>


<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"20px\" style = \"background-color: black;\">
</td>
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20\" style = \"background-color: black;\">
<td>
</td>
</tr>

<tr height = \"70px\">
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td id = \"medcart_self_td_datetime_",$id_visit,"_",$screen,"\" onclick = \"load_page_edit_param_medcart_self('",$id_visit,"','','datatime_razdel','",$screen,"');\" width = \"60%\" style = \"background-color: #1A5FB4;\">

";

$ar_date_time = explode(" ",$date_time);
$date = $ar_date_time['0'];
$time = $ar_date_time['1'];

$ar_date = explode("-",$date);
$year = $ar_date[0];
$month = $ar_date[1];
$day = $ar_date[2];

$rus_month = $ar_months_rus[$month];

$new_date = $day." ".$rus_month." ".$year;
$new_dt_txt = $new_date. " ".$time;
echo $new_dt_txt;


echo "

</td>
<td style = \"background-color: black; cursor: default;\">

</td>
</tr>
</table>

</td>
<td width = \"40%\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"background-color: #8080FF;\" width = \"25%\">
акт вр
</td>
<td style = \"background-color: #8A969C;\" width = \"25%\">
эпикриз
</td>
<td style = \"background-color: #F5C211; color: black;\" width = \"25%\">
гарантия
</td>

<td onclick = \"load_page_edit_param_medcart_self('",$id_visit,"','','delete_visit','",$screen,"');\" style = \"background-color: red;\">
Х
</td>
</tr>
</table>

</td>

</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: default;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"70%\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\">
<td width = \"10%\">
DS
</td>
<td onclick = \"load_page_edit_param_medcart_self('",$id_visit,"','','ds_rename','",$screen,"');\" align = \"left\" style = \"background-color: #3A3A3A; cursor: pointer;\">
<span id = \"span_ds_medcart_self_",$screen,"\">
",$ds,"
</span>
</td>
</tr>
</table>

</td>
<td style = \"background-color: #3A3A3A;\">



</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>

<tr>
<td>

<div id = \"f_load_medcart_self_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y:scroll; background-color: #191919; cursor: default;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
</td>
</tr>
<tr height = \"1%\">
<td>
<img width=\"50\" height=\"50\" src=\"pics/loading.gif\" alt=\"Подождите...\">
</td>
</tr>
<tr>
<td>
</td>
</tr>
</table>

</div>

</td>
</tr>

<tr height = \"40px\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"page_medcart_self_add_new_razd('",$screen,"','",$id_visit,"');\" width = \"33%\" style = \"background-color: #008080;\">

+ раздел

</td>
<td style = \"background-color: #8A969C;\" width = \"33%\">
печать
</td>

<td onclick = \"load_page_edit_param_medcart_self('",$id_visit,"','','open_choice_doc_medcart_self','",$screen,"');\">

<span id = \"span_fio_doc_medcart_self_",$screen,"\">

",$fio_doc_view,"
</span>

</td>
</tr>
</table>

</td>
</tr>

</table>


</td>
<td width = \"20px\" style = \"background-color: black;\">
</td>
</tr>
</table>

</td>
</tr>
</table>

<script>load_block_medcart_self('",$id_visit,"','",$screen,"');</script>

";

}


?>
