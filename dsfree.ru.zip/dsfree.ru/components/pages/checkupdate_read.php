<?php

function checkupdate_read()
{

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from history_version where id_hv = 'd93daa3f2cc305110f723e5f4ba8584c' and showed = ''";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$ar = mysqli_fetch_assoc($query);

$txt = $ar['txt'];


echo $txt;


die();
}



}

?>
