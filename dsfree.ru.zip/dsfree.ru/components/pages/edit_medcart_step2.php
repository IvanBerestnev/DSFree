<?php

function edit_medcart_step2($vals)
{

$name_docum = $vals['name_docum'];
$param = $vals['param'];
$ar_param = explode("@",$param);

$id_ds = $ar_param['0'];
$id_pac = $ar_param['1'];
$screen = $vals['screen'];

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss where id_ds = '$id_ds'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
while($row = mysqli_fetch_assoc($query))
{
$name_ds = $row['name_ds'];
}
}

echo "

<style>
.but_back_to_sp_first_docs_",$screen,":hover{
color: green;
}

.but_back_to_spdss_templ_medcart_",$screen,":hover{
color: #FF8080;
}
</style>


<script>

function load_struct_templ_medcart(screen,id_ds,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_struct_templ_medcart') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_struct_templ_medcart = 'f_load_struct_templ_medcart_' + screen;

var cont = document.getElementById(f_load_struct_templ_medcart);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function add_new_struct_templ_medcart(screen,id_ds)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_struct_templ_medcart') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_struct_templ_medcart = 'f_load_struct_templ_medcart_' + screen;

var cont = document.getElementById(f_load_struct_templ_medcart);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function page_delete_struct_templ_medcart(id_tm,id_ds_income,id_str_templ,id_pac,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_delete_struct_templ_medcart') + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '20%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}




}
}
}


}


function act_delete_structur_templ_medcart(screen,id_tm,id_ds_income,id_str_templ,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_structur_templ_medcart') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_struct_templ_medcart = 'f_load_struct_templ_medcart_' + screen;

var cont = document.getElementById(f_load_struct_templ_medcart);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function act_rename_struct_templ_medcart(new_name,id_tm,id_ds_income,id_str_templ,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_rename_struct_templ_medcart') + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[new_name]=\" + encodeURIComponent(new_name));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

}
}
}

}

</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td class = \"but_back_to_sp_first_docs_",$screen,"\" onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" style = \"cursor: pointer;\" width = \"20%\">

&#10096;

</td>
<td>
Медицинская карта (ред. диагнозы и шаблоны)
</td>
</tr>
</table>


</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\" align = \"right\">
",$name_ds,"
</td>
<td class = \"but_back_to_spdss_templ_medcart_",$screen,"\" onclick = \"edit_first_docum('edit_medcart_step1','",$id_pac,"','",$screen,"');\" style = \"cursor: pointer;\">
Х
</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"background-color: #2E3336;\" width = \"25%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"45%\">
<td>

</td>
</tr>
<tr height = \"10%\">
<td onclick = \"add_new_struct_templ_medcart('",$screen,"','",$id_ds,"');\" style = \"background-color: #3A3A3A; cursor: pointer;\">
Добавить структурный<br>шаблон
</td>
</tr>
<tr height = \"45%\">
<td>

</td>
</tr>

</table>


</td>
<td style = \"background-color: #22272B;\" width = \"50%\">

<div id = \"f_load_struct_templ_medcart_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
</td>
</tr>
<tr height = \"1%\">
<td>
<img width=\"50\" height=\"50\" src=\"pics/loading.gif\" alt=\"Подождите...\">
</td>
</tr>
<tr>
<td>
</td>
</tr>
</table>

</div>

</td>
<td style = \"background-color: #2E3336;\">

</td>
</tr>
</table>

</td>
</tr>
</table>
<script>
load_struct_templ_medcart('",$screen,"','",$id_ds,"','",$id_pac,"');
</script>
";


}

?>
