<?php

function rename_price($vals)
{

$screen = $vals['screen'];
$param = $vals['param'];
$id_price = $vals['id_price'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$name_price = $row['name_price'];
}

echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>
<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"35%\" style=\"background-color: #22272B; font-weight: bold;\">
<td>
укажите новое название прайса
</td>
</tr>

<tr style = \"background-color: #22272B;\">
<td>

<input id = \"input_rename_new_price_",$screen,"\" style = \"width: 70%; height: 65%;\" value = \"",$name_price,"\">
</td>
</tr>

<tr height = \"25%\" style = \"cursor: pointer; font-weight: bold;\">

<td onclick=\"act_add_page_price('act_rename_new_price','",$screen,"','','",$id_price,"');\" style = \"background-color: #008080;\">
сохранить
</td>
</tr>
</table>
<span id = \"hidden_rename_new_price_",$screen,"\"></span>
";

}


?>
