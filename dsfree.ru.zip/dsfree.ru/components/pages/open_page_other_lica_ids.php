<?php

function open_page_other_lica_ids($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_pac = $vals['id_pac'];

echo "

<script>

function load_all_clients_otherlica_ids(screen,surname_pac,id_pac_income)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_all_clients_otherlica_ids') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[surname_pac]=\" + encodeURIComponent(surname_pac) + \"&data[id_pac_income]=\" + encodeURIComponent(id_pac_income));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_all_clients_otherlica_ids = 'f_load_all_clients_otherlica_ids_' + screen;

var cont = document.getElementById(f_load_all_clients_otherlica_ids);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

calculate_bg_ids_pacs_other_lica(screen);

}
}
}

}

function erase_input(screen)
{

var id_inp_surname_all_clients_otherlica_ids = 'id_inp_surname_all_clients_otherlica_ids_' + screen;
document.getElementById(id_inp_surname_all_clients_otherlica_ids).value = '';

//var hidden_selected_id_pacs = 'hidden_selected_id_pacs_' + screen;
//document.getElementById(hidden_selected_id_pacs).innerHTML = '';

calculate_bg_ids_pacs_other_lica(screen);


}

function choice_pac_other_lica_ids(id_pac,screen)
{

var hidden_selected_id_pacs = 'hidden_selected_id_pacs_' + screen;
var val_selected_id_pacs = document.getElementById(hidden_selected_id_pacs).innerHTML;

if(val_selected_id_pacs == '')
{
document.getElementById(hidden_selected_id_pacs).innerHTML = id_pac;
}
else{

var ar_str = val_selected_id_pacs.split('@');

if(ar_str.length == '1')
{
var first_elem_str = ar_str[0];

if(first_elem_str == id_pac)
{
document.getElementById(hidden_selected_id_pacs).innerHTML = '';
}
else{
document.getElementById(hidden_selected_id_pacs).innerHTML = val_selected_id_pacs + '@' + id_pac;
}


}
else{

var first_elem_str = ar_str[0];
var second_elem_str = ar_str[1];

if(second_elem_str == id_pac)
{

document.getElementById(hidden_selected_id_pacs).innerHTML = first_elem_str;

}
else if(first_elem_str == id_pac)
{

document.getElementById(hidden_selected_id_pacs).innerHTML =  second_elem_str;

}
else{


var new_str = second_elem_str  + '@' + id_pac;

document.getElementById(hidden_selected_id_pacs).innerHTML = new_str;
}


}

}

calculate_bg_ids_pacs_other_lica(screen);

check_otherlica_button(screen);

}


function calculate_bg_ids_pacs_other_lica(screen)
{

var class_ids_pacs_other_lica = 'class_ids_pacs_other_lica_' + screen;
var elements = document.getElementsByClassName(class_ids_pacs_other_lica);
let i;

for (i = 0; i < elements.length; i++) {

  if (elements[i] instanceof HTMLElement) {
    elements[i].style.backgroundColor = \"#22272B\";
  }

}

var hidden_selected_id_pacs = 'hidden_selected_id_pacs_' + screen;
var pacs_str = document.getElementById(hidden_selected_id_pacs).innerHTML;

if(pacs_str !== '')
{

//alert('1111');

var ar_pacs_str = pacs_str.split('@');

}
else{



var hidden_id_other_lica = 'hidden_id_other_lica_' + screen;
var pacs_str = document.getElementById(hidden_id_other_lica).innerHTML;
document.getElementById(hidden_selected_id_pacs).innerHTML = pacs_str;


////
//document.getElementById(hidden_id_other_lica).innerHTML = '';
//var but_check_otherlica_button = 'but_check_otherlica_button_' + screen;
//document.getElementById(but_check_otherlica_button).style.backgroundColor = 'white';
//document.getElementById(but_check_otherlica_button).style.color = '#3A3A3A';

////


var ar_pacs_str = pacs_str.split('@');



}

let x;
for (x = 0; x < ar_pacs_str.length; x++) {
var ids_pacs_other_lica = 'ids_pacs_other_lica_' + ar_pacs_str[x] + '_' + screen;

var areaOption = document.getElementById(ids_pacs_other_lica);
if (areaOption) {
document.getElementById(ids_pacs_other_lica).style.backgroundColor = \"#1A5FB4\";
}


}





}





</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>


<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\" style = \"background-color: #22272B;\">
<td colspan = \"2\">
можно сообщить о состоянии здоровья (до 2 человек)
</td>
</tr>

<tr height = \"10%\" style = \"background-color: #22272B;\">
<td width = \"66%\" align = \"right\">
<input id = \"id_inp_surname_all_clients_otherlica_ids_",$screen,"\" onkeyup = \"load_all_clients_otherlica_ids('",$screen,"',this.value,'",$id_pac,"');\" style = \"width: 70%; height: 70%; font-weight: bold; background: transparent; border: none; border-bottom: 1px solid grey; color: white; font-size: 16px;\" placeholder = \"поиск по фамилии\">
</td>

<td align = \"center\">
<span onclick = \"load_all_clients_otherlica_ids('",$screen,"','','",$id_pac,"'); erase_input('",$screen,"');\" style = \"width: 75%; height: 70%; display: flex; align-items: center; justify-content: center; background-color: #FF8080; cursor: pointer;\">
X
</span>
</td>

</tr>

<tr style = \"background-color: #2E3436;\">
<td colspan = \"2\" style = \"padding: 10px;\">

<div id = \"f_load_all_clients_otherlica_ids_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y:scroll;\"></div>

</td>
</tr>



</table>



<script>
load_all_clients_otherlica_ids('",$screen,"','','",$id_pac,"');

</script>

";

}

?>
