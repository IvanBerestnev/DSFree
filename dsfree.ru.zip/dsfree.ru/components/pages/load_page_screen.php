<?php

function load_page_screen($vals)
{

#print_r($vals);
$screen = $vals['screen'];
$name_page = $vals['name_page'];
$param = $vals['param'];

If($name_page == "jur_pacs")
{

$date_now = date("d-m-Y");
$belong = "";
include_once("jurnal_pacs.php");
jurnal_pacs($screen,$date_now,$belong);


}
ElseIf($name_page == "mass_doc_shed")
{

#print_r($vals);
include_once("mass_doc_shed.php");
mass_doc_shed($vals);

}
ElseIf($name_page == "sp_docs")
{

#print_r($vals);
include_once("sp_docs.php");
sp_docs($vals);

}
ElseIf($name_page == "sp_docs_readonly")
{
include_once("sp_docs_readonly.php");
sp_docs_readonly($vals);
}
ElseIf($name_page == "primary_docums")
{
include_once("primary_docums.php");
primary_docums($vals);
}
ElseIf($name_page == "price")
{
include_once("price.php");
price($vals);
}

ElseIf($name_page == "sp_clients")
{
include_once("sp_clients.php");
sp_clients($vals);
#price($vals);
}

ElseIf($name_page == "inventar")
{
include_once("inventar.php");
inventar($vals);
#price($vals);
}


ElseIf($name_page == "notes_pacs")
{
include_once("notes_pacs.php");
notes_pacs($vals);
#price($vals);
}

ElseIf($name_page == "archive_sp_docs")
{
include_once("archive_sp_docs.php");
archive_sp_docs($vals);
#price($vals);
}


}

?>
