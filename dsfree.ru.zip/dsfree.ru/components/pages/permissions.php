<?php

function permissions()
{

//

$ar_levels = array("3"=>"Суперпользователь","2"=>"Администратор","1"=>"Врач","0"=>"Медсестра");

$ar_yes_no = array("1"=>array("name"=>"включено","bgcolor"=>"green","txt_color"=>"white"),"0"=>array("name"=>"отключено","bgcolor"=>"red","txt_color"=>"white"));

$ar_de = array("read_write"=>"чтение запись","read"=>"только чтение","disable"=>"отключено");

/*

*/



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");





$sql = "select * from tab_permissions where id_permission = '1'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);

$ar_permissions = $row['permissions'];

$ar = json_decode($ar_permissions,true);

}

#print_r($ar);


echo "

<script>

function permissions_default()
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('permissions_default') + \"&data[id_permission]=\" + encodeURIComponent('1'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


document.getElementById('fon_modal_gen_settings').style.display = 'block';
document.getElementById('modal_gen_settings').style.width = '30%';
document.getElementById('modal_gen_settings').style.height = '20%';


var cont = document.getElementById('modal_gen_settings');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function change_permission(id_permission,eng_base_key,eng_cont_name,code_users,level_self)
{

var id_td = eng_cont_name + '_' + code_users;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('change_permission') + \"&data[id_permission]=\" + encodeURIComponent(id_permission) + \"&data[eng_base_key]=\" + encodeURIComponent(eng_base_key) + \"&data[eng_cont_name]=\" + encodeURIComponent(eng_cont_name) + \"&data[code_users]=\" + encodeURIComponent(code_users) + \"&data[level_self]=\" + encodeURIComponent(level_self));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var areaOption = document.getElementById(id_td);
if (areaOption) {

var cont = document.getElementById(id_td);
cont.innerHTML = xmlhttp.responseText;
var result = xmlhttp.responseText;

if(result == '0')
{
document.getElementById(id_td).style.backgroundColor = 'red';
document.getElementById(id_td).innerHTML = 'отключено';
}
else if(result == '1')
{
document.getElementById(id_td).style.backgroundColor = 'green';
document.getElementById(id_td).innerHTML = 'включено';
}

}
else{


var cont = document.getElementById('f_hid_permission');
cont.innerHTML = xmlhttp.responseText;

}


}
}
}


}


</script>

<div style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2F3436;\">

<table border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; font-weight: bold; background-color: #404040; text-align: center; border: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"60px\">
<td width = \"35%\">

<button onclick = \"permissions_default();\">Восстановить настройки по умолчанию</button>


</td>

<td>Суперпользователь</td>
<td>Администратор</td>
<td>Врач</td>
<td>Медсестра</td>
</tr>";

Foreach($ar as $eng_base_key=>$ar_values)
{



$rus_base_key = $ar_values['name'];

echo "<tr style = \"background-color: #555753;\" height = \"30px\"><td colspan = \"5\">",$rus_base_key,"</td></tr>";

If(isset($ar_values['content']))
{

$ar_content = $ar_values['content'];


Foreach($ar_content as $eng_cont_name=>$ar_cont)
{

$rus_cont_name = $ar_cont['name'];

$ar_levels = $ar_cont['levels'];

echo "
<tr height = \"30px\">
<td>
",$rus_cont_name,"
</td>";

Foreach($ar_levels as $code_users=>$level_self)
{

If($level_self == "0" or $level_self == "1")
{

$name_rus = $ar_yes_no[$level_self]['name'];
$bgcolor = $ar_yes_no[$level_self]['bgcolor'];
$txt_color = $ar_yes_no[$level_self]['txt_color'];

$id_td = $eng_cont_name."_".$code_users;

echo "<td onclick = \"change_permission('1','",$eng_base_key,"','",$eng_cont_name,"','",$code_users,"','');\" id = \"",$id_td,"\" style = \"background-color: ",$bgcolor,"; color: ",$txt_color,"\">",$name_rus,"</td>";


}
Else{

$availible = $ar_cont['availible'];

echo "
<td>
<select onchange = \"change_permission('1','",$eng_base_key,"','",$eng_cont_name,"','",$code_users,"',this.value);\">
";

Foreach($availible as $k=>$v)
{
echo "<option";

If($v == $level_self)
{
echo " selected";
}

echo " value = \"",$v,"\">",$ar_de[$v],"</option>";
}




echo "
</select>
</td>
";

}


}

echo "
</tr>
";


}

}
Else{

echo "<td height = \"30px\">все функции</td>";

$levels = $ar_values['levels'];
$availible = $ar_values['availible'];

Foreach($levels as $code_users=>$level_self)
{

//$level_self

echo "<td>

<select onchange = \"change_permission('1','",$eng_base_key,"','','",$code_users,"',this.value);\">
";

Foreach($availible as $k=>$v)
{
echo "<option";

If($v == $level_self)
{
echo " selected";
}

echo " value = \"",$v,"\">",$ar_de[$v],"</option>";
}

echo "</select></td>";

}

}

}

echo "</table>

</div>
</div>

</div>


<div style = \"display: block;\" id = \"f_hid_permission\"></div>

";


}

?>
