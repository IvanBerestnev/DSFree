<?php

function rename_razdel_medcart_self($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];
$id_writed_razd = $vals['id_writed_razd'];

#rename_razdel

echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$txt_treat = $row['txt_treat'];

$ar_txt_treat = json_decode($txt_treat,true);
$name_razd = $ar_txt_treat[$id_writed_razd]['name'];

}


echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #22272B;\">
<td>
Изменить название раздела
</td>
</tr>
<tr style = \"background-color: #222222;\">
<td>
<input id = \"new_txt_",$id_writed_razd,"_",$screen,"\" style = \"width: 100%; height: 50px; font-weight: bold; font-size: 18px;\" value = \"",$name_razd,"\">
</td>
</tr>
<tr style = \"background-color: #008080; cursor: pointer;\" height = \"25%\">
<td align = \"center\" onclick = \"act_save_new_param_medcart_self('",$id_visit,"','",$id_writed_razd,"','act_rename_razd','",$screen,"');\">
сохранить
</td>
</tr>
</table>
<span id = \"hidden_rename_razdel_medcart_self_",$screen,"\" style = \"display: none;\"></span>

";


}

?>
