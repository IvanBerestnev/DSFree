<?php

function edit_sp_medcart($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];
$type = $vals['type'];

If($type == "data_time")
{
include_once("edit_sp_medcart_date_time.php");
edit_sp_medcart_date_time($vals);
}
ElseIf($type == "dogovor_pmu")
{
include_once("edit_sp_medcart_dogovor_pmu.php");
edit_sp_medcart_dogovor_pmu($vals);
}
ElseIf($type == "ds")
{
include_once("edit_sp_medcart_ds.php");
edit_sp_medcart_ds($vals);
}
ElseIf($type == "delete_visit")
{
include_once("edit_sp_medcart_delete_visit.php");
edit_sp_medcart_delete_visit($vals);
}



}

?>
