<?php

function load_modal_page_settings($vals)
{

#print_r($vals);
$name = $vals['name'];

If($name == "page_reset_dsfree_default_mode0")
{

include_once("../components/pages/page_reset_dsfree_default_mode0.php");
page_reset_dsfree_default_mode0();



}

}

?>
