<?php

function open_page_act_dw($vals)
{


#print_r($vals);
$screen = $vals['screen'];
$id_visit = $vals['id_visit'];

echo "

<script>

function load_block_act_dw(id_visit,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_act_dw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_block_act_dw = 'f_load_block_act_dw_' + screen;

var cont = document.getElementById(f_load_block_act_dw);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

function open_page_add_act_dw(id_visit,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_page_add_act_dw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '35%';
document.getElementById(modal_first).style.height = '30%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

function act_add_new_data_act_dw(id_visit,screen,name_act,param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_new_data_act_dw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_act]=\" + encodeURIComponent(name_act) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_block_act_dw = 'f_load_block_act_dw_' + screen;

var cont = document.getElementById(f_load_block_act_dw);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"background-color: #3A3A3A;\">
<td>
Акт выполненных работ
</td>
</tr>
<tr style = \"background-color: #22272B;\">
<td>
<div id = \"f_load_block_act_dw_",$screen,"\" style = \"width: 100%; height: 100%;\">
</div>
</td>
</tr>
</table>

<script>
load_block_act_dw('",$id_visit,"','",$screen,"');
</script>

";

}

?>
