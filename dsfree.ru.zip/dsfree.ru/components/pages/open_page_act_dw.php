<?php

function open_page_act_dw($vals)
{


#print_r($vals);
$screen = $vals['screen'];
$id_visit = $vals['id_visit'];

echo "

<script>

function load_block_act_dw(id_visit,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_act_dw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_block_act_dw = 'f_load_block_act_dw_' + screen;

var cont = document.getElementById(f_load_block_act_dw);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

function open_page_add_act_dw(param,screen,name_page)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_page_add_act_dw')+ \"&data[param]=\" + encodeURIComponent(param) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_page]=\" + encodeURIComponent(name_page));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

if(name_page == 'select_price')
{
var x = '35%';
var y = '30%';
}
else if(name_page == 'add_new_usl')
{
var x = '30%';
var y = '40%';
}
else if(name_page == 'page_delete_usluga_from_actdw')
{
var x = '30%';
var y = '40%';
}
else if(name_page == 'delete_act_dw')
{
var x = '25%';
var y = '20%';
}
else if(name_page == 'erase_act_dw')
{
var x = '25%';
var y = '20%';
}
else if(name_page == 'page_general_discont_act_dw')
{
var x = '30%';
var y = '40%';
}
else if(name_page == 'page_delete_concrt_usluga_from_actdw')
{
var x = '25%';
var y = '20%';
}

document.getElementById(modal_first).style.width = x;
document.getElementById(modal_first).style.height = y;

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

function act_add_new_data_act_dw(id_visit,screen,name_act,param)
{

if(name_act == 'act_add_new_uslugi_act_dw')
{
var id_span_default_cost_uslugi = 'id_span_default_cost_uslugi_' + screen;
var default_cost_uslugi = document.getElementById(id_span_default_cost_uslugi).innerHTML;

var id_count_add_new_usl = 'id_count_add_new_usl_' + screen;
var count_add_new_usl = document.getElementById(id_count_add_new_usl).innerHTML;

var id_inp_cost_add_new_usl = 'id_inp_cost_add_new_usl_' + screen;
var new_cost_uslugi = document.getElementById(id_inp_cost_add_new_usl).value;

var id_div_name_add_new_usl = 'id_div_name_add_new_usl_' + screen;
var name_add_new_usl = document.getElementById(id_div_name_add_new_usl).innerHTML;

var param = name_add_new_usl + '@' + count_add_new_usl + '@' + new_cost_uslugi + '@' + default_cost_uslugi;

}

else if(name_act == 'update_gen_discont')
{
var td_skidka_general_discont_act_dw = 'td_skidka_general_discont_act_dw_' + screen;
var param = document.getElementById(td_skidka_general_discont_act_dw).innerHTML;
}




var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_new_data_act_dw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_act]=\" + encodeURIComponent(name_act) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_block_act_dw = 'f_load_block_act_dw_' + screen;

var cont = document.getElementById(f_load_block_act_dw);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}





</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"background-color: black;\">
<td>
Акт выполненных работ
</td>
</tr>
<tr style = \"background-color: #22272B;\">
<td>
<div id = \"f_load_block_act_dw_",$screen,"\" style = \"width: 100%; height: 100%; display: ;\">
</div>
</td>
</tr>
</table>

<script>
load_block_act_dw('",$id_visit,"','",$screen,"');
</script>

";

}

?>
