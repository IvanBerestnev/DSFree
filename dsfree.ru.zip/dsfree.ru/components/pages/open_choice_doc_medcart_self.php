<?php

function open_choice_doc_medcart_self($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

#print_r($vals);

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center ; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #22272B;\">
<td>
выбор врача
</td>
</tr>
<tr>
<td>
<div style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #222222;\">";

$sql = "select * from tab_personal where type = 'doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"act_save_new_param_medcart_self('",$id_visit,"','','act_set_doc_medcart_self','",$screen,"');\" style = \"cursor: pointer;\">сбросить запись о лечащем враче</td>
</tr>
";

while($row = mysqli_fetch_assoc($query))
{

$surname_pers = $row['surname_pers'];
$name_pers = $row['name_pers'];
$patronymic_pers = $row['patronymic_pers'];

$fio_pers = $surname_pers." ".$name_pers." ".$patronymic_pers;

echo "<tr><td onclick = \"act_save_new_param_medcart_self('",$id_visit,"','",$fio_pers,"','act_set_doc_medcart_self','",$screen,"');\" style = \"cursor: pointer;\">",$fio_pers,"</td></tr>";

}

echo "</table>";

}

echo "

</div>
</td>
</tr>

</table>
<span id = \"hidden_open_choice_doc_medcart_self_",$screen,"\" style = \"display: none;\"></span>
";



}

?>
