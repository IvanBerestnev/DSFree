<?php

function page_delete_temple_medcart_self_only_text($vals)
{

$id_ds_income = $vals['id_ds_income'];
$id_tm = $vals['id_tm'];
$id_str_templ = $vals['id_str_templ'];
$screen = $vals['screen'];
$id_shabl = $vals['id_shabl'];
$id_razd = $vals['id_razd'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>



<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #3A3A3A; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
<b style = \"color: #FF8080;\">Внимание</b>

<br><br>
Удалить этот шаблон?
</td>
</tr>
<tr height = \"25%\" align = \"center\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_first_",$screen,"');\" style = \"background-color: #FF8080; \" width = \"50%\">
нет
</td>
<td onclick = \"act_delete_temple_medcart_self_only_text('",$id_tm,"','",$id_ds_income,"','",$id_razd,"','",$id_str_templ,"','",$id_shabl,"','",$screen,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>


";


}

?>
