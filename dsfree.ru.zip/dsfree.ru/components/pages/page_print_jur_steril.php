<?php

function page_print_jur_steril($vals)
{

$screen = $vals['screen'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"1\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: black; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\" style = \"background-color: black; color: white;\">
<td align = \"left\">
печать журнала стерилизации
</td>
</tr>
<tr>
<td>

<table border = \"1\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: black; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td colspan = \"3\">
Укажите диапазон дат
</td>
</tr>
<tr>
<td>
123
</td>
<td width = \"40px\">
до
</td>
<td>
321
</td>
</tr>

<tr height = \"15%\">
<td onclick = \"print_jur_steril('",$screen,"');\" colspan = \"3\" style = \"background-color: #008080; color: white; cursor: pointer;\">
Распечатать
</td>
</tr>

</table>


</td>
</tr>
</table>

";

}

?>
