<?php

function edit_usluga_price($vals)
{

$id_price = $vals['id_price'];
$screen = $vals['screen'];
$id_usl = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$txt_price = $row['txt_price'];

$ar_new = json_decode($txt_price,true);
$name_usl = $ar_new[$id_usl]['name'];
$cost_usl = $ar_new[$id_usl]['cost'];



}


echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #22272B;\">
<td align = \"left\" colspan = \"2\">
редактировать услугу
</td>
</tr>
<tr height = \"20%\" style = \"background-color: #222222;\">
<td width = \"80%\">
название
</td>
<td>
цена
</td>
</tr>
<tr style = \"background-color: #222222;\">
<td>
<input id = \"id_inp_name_edit_usluga_",$screen,"\" style = \"width: 90%; height: 40%;\" value = \"",$name_usl,"\">
</td>
<td>
<input id = \"id_inp_cena_edit_usluga_",$screen,"\" style = \"width: 80%; height: 40%;\" value = \"",$cost_usl,"\">
</td>
</tr>
<tr height = \"20%\" style = \"background-color: #008080;\">
<td style = \"cursor: pointer\" onclick = \"act_add_page_price('act_edit_usluga_price','",$screen,"','",$id_usl,"','",$id_price,"');\" colspan = \"2\">
сохранить
</td>
</tr>
</table>
<span style = \"display: hidden;\" id = \"hidden_edit_usluga_price_",$screen,"\"></span>
";

}

?>
