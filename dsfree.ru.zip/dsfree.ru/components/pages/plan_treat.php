<?php

function plan_treat($id_pac,$screen)
{

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$surname_pac = $row['surname_pac'];

$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];
}




echo "

<script>

function change_num_days_plan_treat(screen,type,val)
{

if(type == 'month')
{
var old_type = 'year';

var year_create_plan_treat = 'year_create_plan_treat_' + screen;
var e = document.getElementById(year_create_plan_treat);
var value = e.value;
var old_val = e.options[e.selectedIndex].value;

}
else if(type == 'year')
{
var old_type = 'month';

var month_create_plan_treat = 'month_create_plan_treat_' + screen;
var e = document.getElementById(month_create_plan_treat);
var value = e.value;
var old_val = e.options[e.selectedIndex].value;

}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('change_num_days_plan_treat') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[val]=\" + encodeURIComponent(val) + \"&data[old_type]=\" + encodeURIComponent(old_type) + \"&data[old_val]=\" + encodeURIComponent(old_val));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var span_day_plan_treat = 'span_day_plan_treat_' + screen;

var cont = document.getElementById(span_day_plan_treat);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"25%\" style = \"cursor: pointer;\">
&#10096;
</td>
<td>
План лечения
</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
";

echo $surname_pac," ",$name_pac," ",$patronymic_pac;

echo "
</td>
<td style = \"cursor: pointer;\" width = \"25%\">
X
</td>
</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
<tr style = \"background-color: #22272B;\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3336; \" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>

Дата составления плана лечения<br><br>";



$day_now = date("j");
$month_now = date("n");
$year_now = date("Y");

$q_days = cal_days_in_month(CAL_GREGORIAN, $month_now, $year_now);

echo "<span id = \"span_day_plan_treat_",$screen,"\">";

echo "<select id = \"day_create_plan_treat_",$screen,"\">";


For($i=1;$i<=$q_days;$i++)
{

$dn = date("d", mktime(0, 0, 0, 1, $i, 1970));

echo "<option";

If($i == $day_now)
{
echo " selected";
}

echo " value = \"",$dn,"\">",$dn,"</option>";

}




echo "
</select>


</span>

";



echo "<select id = \"month_create_plan_treat_",$screen,"\" onchange = \"change_num_days_plan_treat('",$screen,"','month',this.value);\" style = \"text-align: center;\">";


Foreach($ar_months_rus as $m=>$nm)
{

echo "

<option";

If($m == $month_now )
{

echo " selected";
}

echo " value = \"",$m,"\">",$nm,"</option>

";

}

echo "</select>";




//<input size = \"4\" value = \"",$year_now,"\">

$year_now_min = $year_now-15;
$year_now_max = $year_now+15;

echo " <select id = \"year_create_plan_treat_",$screen,"\" onchange = \"change_num_days_plan_treat('",$screen,"','year',this.value);\" style = \"text-align: center;\">";

For($year_now_min;$year_now_min<=$year_now_max;$year_now_min++)
{
echo "<option";

If($year_now_min == $year_now)
{
echo " selected";
}

echo " value = \"",$year_now_min,"\">",$year_now_min,"</option>";
}

echo "

</select>


</td>
</tr>
</table>

</td>
<td style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div style = \"width: 100%; height: 100%; overflow-y: scroll; \">

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">

";

$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac' order by data_write ASC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_dogovor = $row['id_dogovor'];
$data_dogovor = $row['data_dogovor'];

$ar_data_dogovor = explode("-",$data_dogovor);
$day = $ar_data_dogovor[2];
$month = $ar_data_dogovor[1];
$year = $ar_data_dogovor[0];

echo "
<tr onclick = \"print_primary_docums('plan_treat','",$id_dogovor,"','",$screen,"');\" style = \"background-color: #2E3336; border: 1px solid black; cursor: pointer;\" height = \"100px\"><td>Договор № ",$id_dogovor," от \"",$day,"\" ",$ar_months_rus[$month]," ",$year," г.</td></tr>
<tr style = \"background-color: #22272B;\" height = \"20px\"><td></td></tr>
";

}


}
Else{

echo "<tr><td>Нет </td></tr>";

}

echo "

</table>

</div>

</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>

</table>

";




}


?>
