<?php

function load_settings($vals)
{


#print_r($vals);die();
#$json_arr = json_encode($arr);
#print_r($json_arr);
#die();

$setting = $vals['setting'];
$val = $vals['val'];


If($setting == "screen_setka_myprofile_show")
{
include_once("../components/pages/screen_setka_myprofile_show.php");
screen_setka_myprofile_show();
}
ElseIf($setting == "screen_setka_myprofile_add")
{
include_once("../components/pages/screen_setka_myprofile_add.php");
screen_setka_myprofile_add($val);
}
ElseIf($setting == "users_dsfree")
{
include_once("../components/pages/users_dsfree.php");
users_dsfree();
}
ElseIf($setting == "permissions")
{
include_once("../components/pages/permissions.php");
permissions();
}
ElseIf($setting == "settings")
{
include_once("../components/pages/settings.php");
settings();
}


#ElseIf($setting == "jur"){include_once("../components/pages/jurnal_pacs.php");jurnal_pacs();}



}

?>
