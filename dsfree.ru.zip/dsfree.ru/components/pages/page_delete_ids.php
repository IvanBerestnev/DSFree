<?php

function page_delete_ids($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$type = $vals['type'];
$id = $vals['param'];


echo "

<script>

function act_delete_ids(screen,id,type)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_ids') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id]=\" + encodeURIComponent(id) + \"&data[type]=\" + encodeURIComponent(type));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var hidden_page_delete_ids = 'hidden_page_delete_ids_' + screen;

var cont = document.getElementById(hidden_page_delete_ids);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3336; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
Удалить ИДС ?
</td>
</tr>
<tr height = \"25%\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" width = \"50%\" style = \"background-color: #FF8080;\">
нет
</td>

<td onclick = \"act_delete_ids('",$screen,"','",$id,"','",$type,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
<div style = \"display: ;\" id = \"hidden_page_delete_ids_",$screen,"\"></div>
";



}


?>
