<?php

function load_page_edit_param_medcart_self($vals)
{

#print_r($vals);

$page = $vals['page'];

If($page == "rename_razdel")
{
include_once("rename_razdel_medcart_self.php");
rename_razdel_medcart_self($vals);
}
ElseIf($page == "datatime_razdel")
{
include_once("datatime_razdel_medcart_self.php");
datatime_razdel_medcart_self($vals);
}
ElseIf($page == "delete_visit")
{
include_once("page_delete_visit.php");
page_delete_visit($vals);
}
ElseIf($page == "delete_razdel")
{
include_once("page_delete_razdel.php");
page_delete_razdel($vals);
}
ElseIf($page == "ds_rename")
{
include_once("ds_rename_medcart_self.php");
ds_rename_medcart_self($vals);
}
ElseIf($page == "open_choice_doc_medcart_self")
{
include_once("open_choice_doc_medcart_self.php");
open_choice_doc_medcart_self($vals);
}


}

?>
