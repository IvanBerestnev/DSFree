<?php

function jur_uf_control($vals)
{

#print_r($vals);


$screen = $vals['screen'];


echo "

<script>

function load_jur_uf_control(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_jur_uf_control = 'f_jur_uf_control_' + screen;

var cont = document.getElementById(f_jur_uf_control);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}


function open_page_add_write_jur_uf_control(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_page_add_write_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '35%';
document.getElementById(modal).style.height = '50%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function page_print_jur_uf_control(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_print_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '35%';
document.getElementById(modal).style.height = '50%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function print_jur_pso(screen)
{

//var id_form_print_medcart_id_visit = 'id_form_print_medcart_id_visit_' + screen;
//document.getElementById(id_form_print_medcart_id_visit).value = id_visit;

//var id_form_print_medcart_locat_ds = 'id_form_print_medcart_locat_ds_' + screen;
//document.getElementById(id_form_print_medcart_locat_ds).value = locat_ds;

var form_print_jur_pso = 'form_print_jur_pso_' + screen;
document.getElementById(form_print_jur_pso).submit();

}

</script>

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: grey;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"4%\">
<td style = \"background-color: black; color:white; font-weight: bold;\" align = \"center\">
Журнал контроля уф бактерицидной установки

<span onclick = \"trunc_screen('",$screen,"');\" class = \"but_trunc_screen\">X</span>

<span onclick = \"open_settings_screen('jurnal_uf_control','",$screen,"');\" style = \"cursor: pointer; padding-left: 20px; padding-right: 20px; float: right; margin-right: 10px; border-radius: 15px; background-color: blue;\">&#9881;</span>

</td>
</tr>

<tr height = \"8%\" style = \"background-color: #3A3A3A; color: white; font-weight: bold;\">
<td align = \"right\">

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr >
<td align = \"center\">

отображать последние 

<select>
<option>30</option>
<option>60</option>
<option>90</option>
</select>

записей

</td>

<td align = \"center\">

<span onclick = \"open_page_add_write_jur_uf_control('",$screen,"');\" style = \"padding-right: 10px; padding-left: 10px; padding-top: 5px; padding-bottom: 5px; background-color: #008080; cursor: pointer; font-weight: bold;\">
заполнить
</span>

</td>

<td align = \"right\">

<span onclick = \"page_print_jur_uf_control('",$screen,"');\" style = \"background-color: #1A5FB4; font-weight: bold; padding-left: 10px; padding-right: 10px; margin-right: 10px; cursor: pointer;\">
Печать
</span>

</td>
</tr>
</table>



</td>
</tr>

<tr height = \"8%\" style = \"background-color: #8A969C; color: white; font-weight: bold; border-bottom: 1px solid #3A3A3A;\">
<td align = \"center\">

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #8A969C; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>

<td width = \"40px\"></td>

<td>
дата
</td>
<td>
условия<br>обеззараживания
</td>
<td>
объект<br>обеззараживания
</td>
<td>
вид<br>микроорганизма
</td>
<td>
режим<br>облучения
</td>
<td>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #8A969C; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
время
</td>
</tr>
<tr>
<td>
вкл
</td>
<td>
выкл
</td>
</tr>
</table>

</td>
<td>
длительность
</td>

<td width = \"11px\">

</td>

</tr>


</table>


</td>
</tr>

<tr>
<td style = \"\">

<div id = \"f_jur_uf_control_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; scrollbar-width: thin;\">
</div>


</td>
</tr>



</table>

<form id = \"form_print_jur_pso_",$screen,"\" action = \"../handle/handle.html\" method = \"post\" target=\"_self\" style = \"display: none;\">
<input type = \"hidden\" name = \"act\" value = \"print_jur_pso\">
<input type = \"hidden\" id = \"id_form_print_jur_pso_date_begin_",$screen,"\" name = \"data[date_begin]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_jur_pso_date_end_",$screen,"\" name = \"data[date_end]\" value = \"\">
</form>

<script>
load_jur_uf_control('",$screen,"');
</script>

";


}

?>
