<?php

function edit_medcart_step3($vals)
{

$name_docum = $vals['name_docum'];
$ds_and_id_str_templ = $vals['param'];
$screen = $vals['screen'];

#print_r($vals);
$ar_ds_and_id_str_templ = explode("@",$ds_and_id_str_templ);

$ds_income = $ar_ds_and_id_str_templ[0];
$id_str_templ = $ar_ds_and_id_str_templ[1];
$id_tm = $ar_ds_and_id_str_templ[2];
$id_pac = $ar_ds_and_id_str_templ[3];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss where id_ds = '$ds_income'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
while($row = mysqli_fetch_assoc($query))
{
$name_ds = $row['name_ds'];
}
}


echo "

<script>

function load_razd_templ_medcart(screen,id_ds,id_str_templ,id_tm)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_razd_templ_medcart') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_razd_templ_medcart = 'f_load_razd_templ_medcart_' + screen;

var cont = document.getElementById(f_load_razd_templ_medcart);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function add_new_razd_templ_medcart(screen,id_ds,id_str_templ,id_tm)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_razd_templ_medcart') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_razd_templ_medcart = 'f_load_razd_templ_medcart_' + screen;

var cont = document.getElementById(f_load_razd_templ_medcart);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


function edit_medcart_templ_razdel_self(screen,id_ds_income,id_str_templ,id_tm,id_razd)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('edit_medcart_templ_razdel_self') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_razd]=\" + encodeURIComponent(id_razd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '60%';
document.getElementById(modal).style.height = '40%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


function page_delete_razdel_templ_medcart(id_tm,id_ds_income,id_str_templ,screen,id_razd)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_delete_razdel_templ_medcart') + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_razd]=\" + encodeURIComponent(id_razd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '20%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function act_delete_razdel_templ_medcart(screen,id_tm,id_ds_income,id_str_templ,id_razd)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_razdel_templ_medcart') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_razd]=\" + encodeURIComponent(id_razd) + \"&data[id_tm]=\" + encodeURIComponent(id_tm));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_razd_templ_medcart = 'f_load_razd_templ_medcart_' + screen;

var cont = document.getElementById(f_load_razd_templ_medcart);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function act_rename_razd_templ_medcart(new_name,id_tm,id_ds_income,id_str_templ,screen,id_razd)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_rename_razd_templ_medcart') + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[new_name]=\" + encodeURIComponent(new_name) + \"&data[id_razd]=\" + encodeURIComponent(id_razd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

}
}
}

}

function load_block_position_ds(screen,id_ds_income,id_str_templ,id_tm)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_position_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_position_ds = 'f_position_ds_' + screen;

var cont = document.getElementById(f_position_ds);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function modal_edit_position_ds(screen,id_ds_income,id_str_templ,id_tm)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('modal_edit_position_ds') + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '35%';
document.getElementById(modal).style.height = '35%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>

<style>
.but_back_to_sp_first_docs_",$screen,":hover{
color: green;
}

.but_back_to_spdss_templ_medcart_",$screen,":hover{
color: #FF8080;
}

.but_back_to_struc_templ_medcart_",$screen,":hover{
color: #FF8080;
}

</style>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td class = \"but_back_to_sp_first_docs_",$screen,"\" onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"20%\">

&#10096;

</td>
<td>
Медицинская карта (ред. диагнозы и шаблоны)
</td>
</tr>
</table>


</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\" align = \"center\">
",$name_ds,"
</td>
<td onclick = \"edit_first_docum('edit_medcart_step1','",$id_pac,"','",$screen,"');\" class = \"but_back_to_spdss_templ_medcart_",$screen,"\" style = \"cursor: pointer;\">
Х
</td>
</tr>
</table>

</td>
<td width = \"10%\">

&#10140;

</td>
<td width = \"45%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\" align = \"center\">
Структурный шаблон
</td>
<td class = \"but_back_to_struc_templ_medcart_",$screen,"\" style = \"cursor: pointer;\" onclick=\"edit_first_docum('edit_medcart_step2','",$ds_income,"@",$id_str_templ,"@",$id_tm,"@",$id_pac,"','",$screen,"');\">
Х
</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"background-color: #2E3336;\" width = \"25%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"45%\">
<td>

</td>
</tr>
<tr height = \"10%\">
<td onclick = \"add_new_razd_templ_medcart('",$screen,"','",$ds_income,"','",$id_str_templ,"','",$id_tm,"');\" style = \"background-color: #3A3A3A; cursor: pointer;\">
Добавить раздел шаблона
</td>
</tr>
<tr height = \"45%\">
<td>

</td>
</tr>

</table>


</td>
<td style = \"background-color: #22272B;\" width = \"50%\">

<div id = \"f_load_razd_templ_medcart_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">
</div>

</td>
<td style = \"background-color: #2E3336;\">

<div id = \"f_position_ds_",$screen,"\" style = \"width: 100%; height: 100%;\"></div>



</td>
</tr>
</table>

</td>
</tr>
</table>
<script>
load_razd_templ_medcart('",$screen,"','",$ds_income,"','",$id_str_templ,"','",$id_tm,"');
load_block_position_ds('",$screen,"','",$ds_income,"','",$id_str_templ,"','",$id_tm,"');
</script>
";


}

?>
