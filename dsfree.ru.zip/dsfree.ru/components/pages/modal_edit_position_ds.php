<?php

function modal_edit_position_ds($vals)
{


#print_r($vals);

$screen = $vals['screen'];
$id_ds_income = $vals['id_ds_income'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];
$ar_decoded = json_decode($text,true);
#print_r($ar_decoded);

$ar_razd = $ar_decoded[$id_ds_income][$id_str_templ]['cont'];

$selected_position_ds_after_razd = $ar_decoded[$id_ds_income][$id_str_templ]['locat_ds'];

If(!empty($ar_razd))
{


echo "

<script>

function act_save_new_position_ds(screen,id_tm,id_ds_income,id_str_templ)
{

var id_sel_position_ds = 'id_sel_position_ds_' + screen;
var select = document.getElementById(id_sel_position_ds);
var position_ds = select.options[select.selectedIndex].value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_save_new_position_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[position_ds]=\" + encodeURIComponent(position_ds));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hidden_modal_edit_position_ds = 'hidden_modal_edit_position_ds_' + screen;

var cont = document.getElementById(hidden_modal_edit_position_ds);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"33%\" style = \"background-color: #3A3A3A;\">
<td>
Расположить диагноз в карте после раздела
</td>
</tr>
<tr style = \"background-color: #2E3336;\">
<td>

<select id = \"id_sel_position_ds_",$screen,"\" style = \"text-align: center;\">
<option value = \"\">выберете</option>
";

Foreach($ar_razd as $id_razd=>$ar_valls)
{
$name_razd = $ar_valls['name'];
echo "<option";

If($name_razd == $selected_position_ds_after_razd)
{
echo " selected";
}

echo " value = \"",$name_razd,"\">",$name_razd,"</option>";
}

echo "
</select>

</td>
</tr>
<tr height = \"20%\" style = \"background-color: #008080; cursor: pointer;\">
<td onclick = \"act_save_new_position_ds('",$screen,"','",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"');\">

сохранить

</td>
</tr>
</table>
<span style = \"display: none;\" id = \"hidden_modal_edit_position_ds_",$screen,"\"></span>
";


}
Else{


echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\">
<td>
нет доступных разделов
</td>
</tr>
</table>


";


}

#print_r($ar_razd);



}





}

?>
