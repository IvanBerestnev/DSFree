<?php

function modal_edit_position_ds($vals)
{


#print_r($vals);

$screen = $vals['screen'];
$id_ds_income = $vals['id_ds_income'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];
$text = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_decoded = json_decode($text,true);
#print_r($ar_decoded);

$ar_razd = $ar_decoded[$id_ds_income][$id_str_templ]['cont'];

$selected_position_preds_after_razd = $ar_decoded[$id_ds_income][$id_str_templ]['locat_preds'];
$selected_position_ds_after_razd = $ar_decoded[$id_ds_income][$id_str_templ]['locat_ds'];


Foreach($ar_razd as $id_razd=>$ar_valls)
{
$name_razd = $ar_valls['name'];
$ar_razds[$name_razd] = $name_razd;
}

If(!empty($ar_razds))
{

$ar_razd_preds_add['first_position'] = "Первая позиция";
$ar_razd_preds_add['disabled'] = "Отключен";

$ar_razd_preds = array_merge($ar_razd_preds_add, $ar_razds);

#print_r($ar_razd_preds);


If($selected_position_preds_after_razd == "disabled")
{
$ar_razd_ds_add['first_position'] = "Первая позиция";
}
Else{
$ar_razd_ds_add['after_preds'] = "После предварительного диагноза";
}

$ar_razd_ds_add['disabled'] = "Отключен";

$ar_razd_ds = array_merge($ar_razd_ds_add, $ar_razds);


echo "

<script>

function act_save_new_position_ds(screen,id_tm,id_ds_income,id_str_templ)
{

var id_sel_position_predvards = 'id_sel_position_predvards_' + screen;
var select = document.getElementById(id_sel_position_predvards);
var position_preds = select.options[select.selectedIndex].value;

var id_sel_position_ds = 'id_sel_position_ds_' + screen;
var select = document.getElementById(id_sel_position_ds);
var position_ds = select.options[select.selectedIndex].value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_save_new_position_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[position_ds]=\" + encodeURIComponent(position_ds) + \"&data[position_preds]=\" + encodeURIComponent(position_preds));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hidden_modal_edit_position_ds = 'hidden_modal_edit_position_ds_' + screen;

var cont = document.getElementById(hidden_modal_edit_position_ds);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}


function change_f_position_ds(param,screen,id_tm,id_ds_income,id_str_templ)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('change_f_position_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[position_preds]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_position_ds = 'f_position_ds_' + screen;

var cont = document.getElementById(f_position_ds);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}




}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"33%\" style = \"background-color: #3A3A3A;\">
<td>
Позиция предварительного диагноза в карте после
</td>
<td>
Позиция диагноза в карте после
</td>


</tr>
<tr style = \"background-color: #2E3336;\">
<td>

<select onchange = \"change_f_position_ds(this.value,'",$screen,"','",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"');\" id = \"id_sel_position_predvards_",$screen,"\" style = \"text-align: center; width: 75%;\">";



Foreach($ar_razd_preds as $key=>$val)
{
echo "<option";

If($key == $selected_position_preds_after_razd)
{
echo " selected";
}

echo " value = \"",$key,"\">",$val,"</option>";
}



echo "
</select>

</td>

<td width = \"50%\">

<div id = \"f_position_ds_",$screen,"\">

<select id = \"id_sel_position_ds_",$screen,"\" style = \"text-align: center; width: 75%;\">";

Foreach($ar_razd_ds as $key=>$val)
{
echo "<option";

If($key == $selected_position_ds_after_razd)
{
echo " selected";
}

echo " value = \"",$key,"\">",$val,"</option>";
}

echo "
</select>

</div>

</td>

</tr>
<tr height = \"20%\" style = \"background-color: #008080; cursor: pointer;\">
<td colspan = \"2\" onclick = \"act_save_new_position_ds('",$screen,"','",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"');\">

сохранить

</td>
</tr>
</table>
<span style = \"display: ;\" id = \"hidden_modal_edit_position_ds_",$screen,"\"></span>
";


}
Else{


echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\">
<td>
нет доступных разделов
</td>
</tr>
</table>


";


}

#print_r($ar_razd);



}





}

?>
