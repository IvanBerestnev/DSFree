<?php

function delete_usluga_price($vals)
{

#print_r($vals);
$id_price = $vals['id_price'];
$screen = $vals['screen'];
$id_usl = $vals['param'];



echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #22272B;\">
<td colspan = \"2\">
удалить услугу из прайса?
</td>
</tr>
<tr height = \"20%\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_first_",$screen,"');\" width = \"50%\" style = \"background-color: #FF8080;\">
нет
</td>
<td onclick = \"act_add_page_price('act_delete_usluga_price','",$screen,"','",$id_usl,"','",$id_price,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
<span style = \"display: hidden;\" id = \"hidden_delete_usluga_price_",$screen,"\"></span>
";


}

?>
