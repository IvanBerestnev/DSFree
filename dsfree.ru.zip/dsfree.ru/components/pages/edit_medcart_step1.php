<?php

function edit_medcart_step1($vals)
{

$name_docum = $vals['name_docum'];
$id_pac = $vals['param'];
$screen = $vals['screen'];

#print_r($vals);

echo "

<script>

function load_saved_dss(screen,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_saved_dss') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_saved_dss = 'f_load_saved_dss_' + screen;

var cont = document.getElementById(f_load_saved_dss);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function open_add_new_ds(screen,mode,id_ds)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('add_new_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[mode]=\" + encodeURIComponent(mode) + \"&data[id_ds]=\" + encodeURIComponent(id_ds));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '20%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function page_delete_ds(screen,id_ds)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_delete_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '20%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}


function delete_ds(screen,id_ds)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('delete_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_saved_dss = 'f_load_saved_dss_' + screen;

var cont = document.getElementById(f_load_saved_dss);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}


function modal_page_import_new_template(screen,param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('modal_page_import_new_template') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '50%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function print_template_ds(screen,id_ds)
{

var id_form_print_template_ds_id_ds = 'id_form_print_template_ds_id_ds_' + screen;
document.getElementById(id_form_print_template_ds_id_ds).value = id_ds;

var form_print_template_ds = 'form_print_template_ds_' + screen;
document.getElementById(form_print_template_ds).submit();


}

</script>

<style>
.but_back_to_sp_first_docs_",$screen,":hover{
color: green;
}
</style>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td class = \"but_back_to_sp_first_docs_",$screen,"\" onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"20%\" style = \"cursor: pointer;\">

&#10096;

</td>
<td>
Медицинская карта<br>(ред. диагнозы и шаблоны)
</td>
</tr>
</table>


</td>
<td>
</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"background-color: #2E3336;\" width = \"25%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"45%\">
<td>

</td>
</tr>
<tr height = \"10%\">
<td onclick = \"open_add_new_ds('",$screen,"','out','');\" style = \"background-color: #3A3A3A; cursor: pointer;\">
Новый диагноз
</td>
</tr>
<tr height = \"45%\">
<td>

</td>
</tr>

</table>


</td>
<td style = \"background-color: #22272B;\" width = \"50%\">

<div id = \"f_load_saved_dss_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
</td>
</tr>
<tr height = \"1%\">
<td>
<img width=\"50\" height=\"50\" src=\"pics/loading.gif\" alt=\"Подождите...\">
</td>
</tr>
<tr>
<td>
</td>
</tr>
</table>

</div>

</td>
<td style = \"background-color: #2E3336;\">
<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"45%\">
<td>

</td>
</tr>
<tr height = \"10%\">
<td onclick = \"modal_page_import_new_template('",$screen,"','');\" style = \"background-color: #3A3A3A; cursor: pointer;\">
Импорт шаблонов
</td>
</tr>
<tr height = \"45%\">
<td>

</td>
</tr>

</table>
</td>
</tr>
</table>

</td>
</tr>
</table>

<form id = \"form_print_template_ds_",$screen,"\" action = \"../handle/handle.html\" method = \"post\" target=\"_self\" style = \"display: none;\">
<input type = \"hidden\" name = \"act\" value = \"print_template_ds\">
<input type = \"hidden\" id = \"id_form_print_template_ds_id_ds_",$screen,"\" name = \"data[id_ds]\" value = \"\">
</form>


<script>
load_saved_dss('",$screen,"','",$id_pac,"');
</script>
";


}

?>
