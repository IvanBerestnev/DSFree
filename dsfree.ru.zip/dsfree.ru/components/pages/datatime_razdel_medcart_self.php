<?php

function datatime_razdel_medcart_self($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];


$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$date_time = $row['date_time'];

$ar_date_time = explode(" ",$date_time);
$date = $ar_date_time[0];
$time = $ar_date_time[1];

$ar_date = explode("-",$date);
$year = $ar_date[0];
$month = $ar_date[1];
$day = $ar_date[2];

$ar_time = explode(":",$time);
$hour = $ar_time[0];
$min = $ar_time[1];
$sec = $ar_time[2];


}

echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #22272B\">
<td >
время приема
</td>
</tr>
<tr style = \"background-color: #222222\">
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">
время
</td>
<td>
дата
</td>

</tr>
<tr>
<td>
<select id = \"hour_razdel_medcart_self_",$id_visit,"_",$screen,"\">
";

For($i=0;$i<=23;$i++)
{

$h = date("H", mktime($i, 0, 0, 1, 1, 1970));

echo "<option value = \"",$h,"\"";

If($i == $hour)
{
echo " selected";
}

echo ">",$h,"</option>";
}

echo "
</select> : 
<select id = \"min_razdel_medcart_self_",$id_visit,"_",$screen,"\">
";

For($i=0;$i<=59;$i++)
{

$mi = date("i", mktime(0, $i, 0, 1, 1, 1970));

echo "<option value = \"",$mi,"\"";

If($mi == $min)
{
echo " selected";
}

echo ">",$mi,"</option>";
}




echo "
</select> : 
<select id = \"sec_razdel_medcart_self_",$id_visit,"_",$screen,"\">
";

For($i=0;$i<=59;$i++)
{

$si = date("s", mktime(0, 0, $i, 1, 1, 1970));

echo "<option value = \"",$si,"\"";

If($si == $sec)
{
echo " selected";
}

echo ">",$si,"</option>";
}

echo "
</select> 

</td>
<td>

<select id = \"day_razdel_medcart_self_",$id_visit,"_",$screen,"\">
";

For($i=1;$i<=31;$i++)
{

$d = date("d", mktime(0, 0, 0, 1, $i, 1970));

echo "<option value = \"",$d,"\">",$d,"</option>";
}

echo "
</select> 
 - 
<select id = \"month_razdel_medcart_self_",$id_visit,"_",$screen,"\">
";

For($i=1;$i<=12;$i++)
{

$m = date("m", mktime(0, 0, 0, $i, 1, 1970));

echo "<option value = \"",$m,"\"";

If($m == $month)
{
echo " selected";
}

echo ">",$ar_months_rus[$m],"</option>";
}

echo "
</select> 
 - 
<select id = \"year_razdel_medcart_self_",$id_visit,"_",$screen,"\">
";

For($i=2018;$i<=2026;$i++)
{
echo "<option value = \"",$i,"\"";

If($i == $year)
{
echo " selected";
}

echo ">",$i,"</option>";
}

echo "
</select> 

</td>
</tr>
</table>

</td>
</tr>
<tr onclick = \"act_save_new_param_medcart_self('",$id_visit,"','','datatime_razdel_medcart_self','",$screen,"');\" style = \"background-color: #008080;\">
<td>
сохранить
</td>
</tr>
</table>
<span id = \"hidden_datatime_razdel_medcart_self_",$screen,"\" style = \"display: none;\"></span>
";



}


?>
