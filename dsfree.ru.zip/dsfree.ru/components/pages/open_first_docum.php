<?php

function open_first_docum($vals)
{

#print_r($vals);

$name_docum = $vals['name_docum'];
$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

If($name_docum == "dogovor_pmu")
{
include_once("../components/pages/dogovor_pmu_page.php");
dogovor_pmu_page($id_pac,$screen);
}
ElseIf($name_docum == "act_dw_admin")
{
include_once("../components/pages/act_dw_admin.php");
act_dw_admin($id_pac,$screen);
}
ElseIf($name_docum == "anketa_zd")
{
include_once("../components/pages/anketa_zd.php");
anketa_zd($id_pac,$screen);
}
ElseIf($name_docum == "work_ids")
{
include_once("../components/pages/work_ids.php");
work_ids($id_pac,$screen);
}



}

?>
