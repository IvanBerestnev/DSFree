<?php

function open_first_docum($vals)
{

#print_r($vals);

$name_docum = $vals['name_docum'];
$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

If($name_docum == "dogovor_pmu")
{

include_once("../components/pages/dogovor_pmu_page.php");
dogovor_pmu_page($id_pac,$screen);


}





}

?>
