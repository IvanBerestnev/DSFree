<?php

function edit_sp_medcart_delete_visit($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];

#print_r($vals);

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td style = \"background-color: #222222;\" colspan = \"2\">
удалить запись из медкарты?
</td>
</tr>
<tr height = \"20%\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" width = \"50%\" style = \"background-color: #FF8080;\">
нет
</td>
<td onclick = \"act_sp_medcart('",$id_visit,"','",$screen,"','act_delete_visit_medcart_sp');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
<span id = \"hidden_delete_visit_sp_medcart_self_",$screen,"\" style = \"display: ;\"></span>
";



}

?>
