<?php

function edit_first_docum($vals)
{

$name_docum = $vals['name_docum'];

If($name_docum == "edit_medcart_step1")
{
include_once("../components/pages/edit_medcart_step1.php");
edit_medcart_step1($vals);
}
ElseIf($name_docum == "edit_medcart_step2")
{
include_once("../components/pages/edit_medcart_step2.php");
edit_medcart_step2($vals);
}
ElseIf($name_docum == "edit_medcart_step3")
{
include_once("../components/pages/edit_medcart_step3.php");
edit_medcart_step3($vals);
}
ElseIf($name_docum == "medcart_general")
{
include_once("../components/pages/medcart_general.php");
medcart_general($vals);
}
ElseIf($name_docum == "load_medcart_self")
{
include_once("../components/pages/load_medcart_self.php");
load_medcart_self($vals);
}
ElseIf($name_docum == "edit_ids")
{
include_once("../components/pages/edit_ids.php");
edit_ids($vals);
}





}

?>
