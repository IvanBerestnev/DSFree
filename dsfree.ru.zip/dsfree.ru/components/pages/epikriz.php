<?php

function epikriz($id_pac,$screen)
{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$surname_pac = $row['surname_pac'];
}




echo "

<script>

function load_self_epikriz(screen,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_self_epikriz') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_epikriz = 'f_epikriz_' + screen;

var cont = document.getElementById(f_epikriz);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"25%\" style = \"cursor: pointer;\">
&#10096;
</td>
<td>
Эпикриз
</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
",$surname_pac,"
</td>
<td style = \"cursor: pointer;\" width = \"25%\">
X
</td>
</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
<tr style = \"background-color: #22272B;\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3336; \" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>

Резерв для параметров<br>поиска медицинских записей




</td>
</tr>
</table>

</td>
<td style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div id = \"f_epikriz_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; \">

</div>

</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>

</table>

<script>

load_self_epikriz('",$screen,"','",$id_pac,"');

</script>

";



}

?>
