<?php

function page_change_status_ids($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$type_ids = $vals['param'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_misc_sets where id = 'id_avail_ids_work'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$val = $row['val'];
$ar_avail_types = json_decode($val,true);

}

}
Else{

$ar_avail_types = array("general"=>"1","terap"=>"1","ortoped"=>"1","chirurg"=>"1","ortodont"=>"1","detstvo"=>"1");

}


echo "

<script>

function act_change_status_ids(screen,type_ids)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_change_status_ids') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type_ids]=\" + encodeURIComponent(type_ids) );

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var page_change_status_ids = 'page_change_status_ids_' + screen;

var cont = document.getElementById(page_change_status_ids);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}

}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3336; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"60%\">
<td>

Статус отображения в рабочем режиме:

</td>
</tr>
<tr style = \"cursor: pointer;\">
";

$status = $ar_avail_types[$type_ids];

If($status == "1")
{
$bg = "#008080";
$text = "отображается";
}
Else{
$bg = "#FF8080";
$text = "не отображается";
}

echo "

<td onclick = \"act_change_status_ids('",$screen,"','",$type_ids,"');\" width = \"50%\" style = \"background-color: ",$bg,";\">
",$text,"
</td>

</tr>
</table>

<div style = \"display: none;\" id = \"page_change_status_ids_",$screen,"\"></div>

";



}


?>
