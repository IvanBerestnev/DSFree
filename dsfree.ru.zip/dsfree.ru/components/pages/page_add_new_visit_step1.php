<?php

function page_add_new_visit_step1($vals)
{

#print_r($vals);

$id_pac = $vals['param'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$ar_dss[$row['id_ds']] = $row['name_ds'];

}

}

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; cursor: default;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #3A3A3A;\">
<td align = \"center\">
новая запись медицинской карты. этап 1 (из 2)
</td>
</tr>
<tr style = \"background-color: #2E3336;\" height = \"35%\">


<td>
<span onclick=\"edit_first_docum('edit_medcart_step1','",$id_pac,"','",$screen,"'); close_mw('fon_modal_",$screen,"');\" style = \"border: 1px solid grey; margin-left: 5px; padding-left: 15px; padding-right: 15px; cursor: pointer;\">Новый диагноз</span>
</td>
</tr>
<tr style = \"background-color: #2E3336;\">
<td align = \"center\" valign = \"middle\" >



<select onchange = \"page_add_new_visit('",$screen,"',this.value,'step2');\" style = \"text-align: center;\">
<option disabled selected>выберете диагноз</option>";

Foreach($ar_dss as $id_dss=>$name_ds)
{

echo "<option value = \"",$id_pac,"@",$id_dss,"\">",$name_ds,"</option>";

}

echo "

</select>

</td>
</tr>
</table>


";

}

?>
