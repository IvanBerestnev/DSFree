<?php

function page_lock()
{
	
echo "
<table border = \"1\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; font-weight: bold; background-color: grey;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
У Вас недостаточно прав на просмотр содержимого
</td>
</tr>
</table>
";

#die();
$signal = "stop";
return $signal;
	
	
}

?>
