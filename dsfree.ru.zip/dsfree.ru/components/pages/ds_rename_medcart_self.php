<?php

function ds_rename_medcart_self($vals)
{

#print_r($vals);

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$name_ds = $row['ds'];
}


echo "
<style>

.tr_dog_edit_sp_medcart_ds_",$screen,":hover{
background-color: #008080;

}

</style>
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #22272B\">
<td>
коррекция диагноза
</td>
</tr>
<tr style = \"background-color: #222222\">

<td>
<input id = \"inp_new_ds_medcart_self_",$screen,"\" style = \"width: 95%; height: 40px;\" value = \"",$name_ds,"\">


</td>
</tr>
<tr height = \"25%\" style = \"background-color: #008080; cursor: pointer;\">
<td onclick = \"act_save_new_param_medcart_self('",$id_visit,"','','act_ds_rename_medcart_self','",$screen,"');\">
сохранить
</td>
</tr>
</table>
<span id = \"hidden_edit_ds_self_medcart_",$screen,"\" style = \"display: none;\"></span>
";


}

?>
