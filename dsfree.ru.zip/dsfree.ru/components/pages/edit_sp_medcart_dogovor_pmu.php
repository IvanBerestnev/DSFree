<?php

function edit_sp_medcart_dogovor_pmu($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];
$type = $vals['type'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_pac = $row['id_pac'];
}

echo "
<style>

.tr_dog_edit_sp_medcart_dogovor_pmu_",$screen,":hover{
background-color: #8080FF;

}

</style>
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\" style = \"background-color: #22272B\">
<td>
договор
</td>
</tr>
<tr style = \"background-color: #222222\">

<td>

<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">
<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
";

$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_dog = $row['id_dogovor'];
$data_dogovor = $row['data_dogovor'];

echo "<tr onclick = \"act_sp_medcart('",$id_visit,"@",$id_dog,"','",$screen,"','act_use_new_dogovor_medcart_sp');\" class = \"tr_dog_edit_sp_medcart_dogovor_pmu_",$screen,"\" height = \"60px\" style = \"cursor: pointer;\"><td>№ ",$id_dog," от ",$data_dogovor,"</td></tr>";
}


}

echo "
</table>
</div>

</td>
</tr>
<tr height = \"20%\" style = \"background-color: #008080; cursor: pointer;\">
<td>
сохранить
</td>
</tr>
</table>
<span id = \"hidden_edit_sp_medcart_dogovor_pmu_",$screen,"\"></span>
";


}

?>
