<?php

function show_modal_general_setting()
{

include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();
$level_cookie = $ar_vals['level_cookie'];

#$id_user_cookie = $ar_vals['id_user_cookie'];
#$name_user_cookie= $ar_vals['name_user_cookie'];


echo "

<script>

function load_settings(param,val)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_settings') + \"&data[setting]=\" + encodeURIComponent(param) + \"&data[val]=\" + encodeURIComponent(val));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('id_f_gen_settings');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal');\">X</span>

<div style = \"display: flex; flex-direction: column; height: 100%;\">

<div style = \"text-align: center; background-color: #1A3B97; font-weight: bold; color: white; padding: 5px; \">
Настройки
</div>

<div class=\"cm-e-menu\">
<ul>
<li class=\"topmenu\">
<a>Интерфейс</a>
<ul class=\"submenu\">
<li><a>сетка экрана</a>

<ul class=\"submenu\">
<li onclick = \"load_settings('screen_setka_myprofile_show','');\"><a>Профили отображения</a></li>

<li onclick = \"load_settings('screen_setka_myprofile_add','');\"><a>Добавить в профиль</a></li>
</ul>

</li>

</ul>
</li>";


/*

<li class=\"topmenu\" onclick = \"load_settings('license_clinic','');\">
<a>Клиника</a>

<ul class=\"submenu\">
<li><a>Лицензия</a>
</li>
</ul>

</li>

*/


echo "




<li class=\"topmenu\">
<a>Система</a>
<ul class=\"submenu\">
<li onclick = \"load_settings('users_dsfree','');\"><a>Аккаунты DSFree</a></li>
<li onclick = \"load_settings('permissions','');\"><a>Права доступа</a></li>
<li onclick = \"load_settings('settings','');\"><a>Настройки</a></li>
<li><a>Резервная копия</a>

<ul class=\"submenu\">
<li onclick = \"load_settings('backup_create','');\"><a>Создать</a></li>
<li onclick = \"load_settings('backup_restore','');\"><a>Восстановить</a></li>
</ul>


</li>


</ul>
</li>


</ul>
</div>

<div id = \"id_f_gen_settings\" style = \"flex-grow: 3; background-color: white;\">




</div>

<div id = \"fon_modal_gen_settings\" style = \"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); right: 0; bottom: 0; left: 0; margin: auto; position: fixed; z-index: 4000;\">
<div id = \"modal_gen_settings\" style = \"display: block; position: fixed; top: 0%; right: 0; bottom: 0; left: 0; margin: auto; background: white;\"></div>
</div>

</div>



<script>
load_settings('screen_setka_myprofile_show','');
</script>

";


}

?>
