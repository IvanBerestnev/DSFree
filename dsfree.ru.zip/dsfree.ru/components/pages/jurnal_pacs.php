<?php

function jurnal_pacs($x,$date_now,$belong)
{


	
////////////////////

include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();
$level_cookie = $ar_vals['level_cookie'];
$int_level_cookie = (int)$level_cookie;

////////////////////

include_once("../components/blocks/check_permissions.php");
$permission = check_permissions($int_level_cookie,"jur_pacs","show_jur");
////////////////////

If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
}


echo "

<script>



</script>




<span id = \"main_loaded_page_jur_pacs\" class = \"main_loaded_page\" style = \"display: none;\">opened</span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30px\" style = \"background-color: black; color: white; font-weight: bold;\">
<td>

Журнал записи пациентов




";

If($belong !== "y")
{
echo "<span onclick = \"trunc_screen('",$x,"');\" class = \"but_trunc_screen\">X</span>";
}

echo "

<span onclick = \"open_settings_screen('jurnal_pacs','",$x,"');\" style = \"cursor: pointer; padding-left: 20px; padding-right: 20px; float: right; margin-right: 10px; border-radius: 15px; background-color: blue;\">&#9881;</span>

</td>
</tr>
<tr>
<td style = \"position: relative; color: white;\">

<div id = \"id_f_self_jurpacs_",$x,"\" style = \"color: white; width: 100%; height: 100%;\"></div>


</td>
</tr>

<tr height = \"120px\" style = \"background-color: #202020;\">
<td align = \"center\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center;  border: 1px dotted #1C1C1C;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"110px\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; color: white; cursor: pointer; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td class = \"class_td_navigate\"  onclick = \"get_data('now','",$x,"');\" colspan = \"2\">сегодня</td>
</tr>
<tr height= \"45%\">
<td align = \"center\" class = \"class_td_navigate\" onclick = \"get_data('back','",$x,"');\" style = \"font-size: 30px; font-weight: bold;\">
&#9665;

</td>

<td align = \"center\" class = \"class_td_navigate\" onclick = \"get_data('next','",$x,"');\" style = \"font-size: 30px; font-weight: bold;\">
&#9655;

</td>

</tr>
<tr>
<td class = \"class_td_navigate\"  colspan = \"2\" onclick = \"load_calendar_jurpacs('",$x,"');\">
на дату

<div id = \"f_dir_date_",$x,"\" style = \"display: none;\">",$date_now,"</div>

</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td width = \"35%\">
<div id = \"f_ctrl_jurpacs_dunit_",$x,"\"></div>
</td>
<td rowspan = \"2\">
<div id = \"f_ctrl_jurpacs_doc_",$x,"\" style = \"width: 100%; height: 100%; overflow-y:scroll;\"></div>
</td>
</tr>
<tr>
<td>
<div id = \"f_ctrl_jurpacs_c_days_",$x,"\"></div>
</td>
</tr>
</table>


</td>


<td width = \"35%\">

<div id = \"jurpac_bottom_menu_",$x,"\" style = \"width: 100%; height: 100%;\"></div>

<div style = \"display: none;\" id = \"id_",$x,"_cell_jurpac_selected_id\"></div>
<div style = \"display: none;\" id = \"id_",$x,"_cell_jurpac_selected_color\"></div>


</td>
</tr>
</table>


</td>
</tr>
</table>



</td>
</tr>

</table>

<span style = \"display: ;\" id = \"hidden_jurnal_pacs_",$x,"\"></span>



<script>

load_ctrl_jurpacs('dunit','",$x,"');
load_ctrl_jurpacs('c_days','",$x,"');
load_ctrl_jurpacs('doc','",$x,"');
load_jurpacs('",$x,"');

</script>
";


}

?>
