<?php

function add_new_price($vals)
{

#print_r($vals);

$screen = $vals['screen'];


echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>
<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"35%\" style=\"background-color: #22272B; font-weight: bold;\">
<td>
укажите название нового прайса
</td>
</tr>

<tr style = \"background-color: #22272B;\">
<td>
<input id = \"input_add_new_price_",$screen,"\" style = \"width: 70%; height: 65%;\">
</td>
</tr>

<tr height = \"25%\" style = \"cursor: pointer; font-weight: bold;\">

<td onclick=\"act_add_page_price('act_add_new_price','",$screen,"','','');\" style = \"background-color: #008080;\">
сохранить
</td>
</tr>
</table>
<span id = \"hidden_add_new_price_",$screen,"\"></span>
";



}

?>
