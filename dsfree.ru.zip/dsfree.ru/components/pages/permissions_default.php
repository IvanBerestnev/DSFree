<?php

function permissions_default($vals)
{

#print_r($vals);

$id_permission = $vals['id_permission'];


echo "

<script>

function act_permissions_default(id_permission)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_permissions_default') + \"&data[id_permission]=\" + encodeURIComponent(id_permission));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


document.getElementById('fon_modal_gen_settings').style.display = 'block';
document.getElementById('modal_gen_settings').style.width = '30%';
document.getElementById('modal_gen_settings').style.height = '20%';


var cont = document.getElementById('modal_gen_settings');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_gen_settings');\">X</span>

<table border = \"0\" width = \"100.5%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\" style = \"background-color: #555753; color: white;\">

Восстановить настройки прав доступа по умолчанию?

</td>
</tr>
<tr height = \"25%\" style = \"cursor: pointer;\">
<td onclick = \"act_permissions_default('",$id_permission,"');\" style = \"background-color: green; color: white; font-weight: bold;\" width = \"50%\">
Да
</td>
<td style = \"background-color: #DF9087; color: white; font-weight: bold;\">
Нет
</td>
</tr>
</table>

";

}

?>

