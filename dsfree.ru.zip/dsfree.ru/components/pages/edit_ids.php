<?php

function edit_ids($vals)
{

#print_r($vals);

$param = $vals['param'];
$screen = $vals['screen'];

echo "

<script>

function load_sp_all_types_ids(screen)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sp_all_types_ids') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_sp_all_types_ids = 'f_load_sp_all_types_ids_' + screen;

var cont = document.getElementById(f_load_sp_all_types_ids);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}

function load_ids_edit_self(screen,type)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_ids_edit_self') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_ids_edit_self = 'f_load_ids_edit_self_' + screen;

var cont = document.getElementById(f_load_ids_edit_self);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function open_modal_ids_edit_self(screen,name_page,type,param)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_modal_ids_edit_self') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

if(name_page == 'page_add_ids')
{
var w = '35%';
var h = '35%';
}
else if(name_page == 'page_rename_ids')
{
var w = '35%';
var h = '25%';
}
else if(name_page == 'page_rename_ids_file')
{
var w = '35%';
var h = '25%';
}
else if(name_page == 'page_delete_ids')
{
var w = '30%';
var h = '20%';
}
else if(name_page == 'page_change_status_ids')
{
var w = '30%';
var h = '20%';
}

document.getElementById(modal).style.width = w;
document.getElementById(modal).style.height = h;

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"background-color: #3A3A3A;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"font-weight: bold;\">
<td onclick=\"choice_pac_primary_docum('",$param,"','",$screen,"');\" width = \"33%\" style = \"cursor: pointer;\">
&#10096;
</td>
<td>
Информированное добровольное согласие (редакт.)
</td>
</tr>
</table>


</td>
<td>
</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"padding: 10px;\" id = \"f_load_sp_all_types_ids_",$screen,"\">

";




echo "


</td>
<td>

<div id = \"f_load_ids_edit_self_",$screen,"\" style = \"height: 100%; width: 100%; \">


</div>

</td>
</tr>
</table>


</td>
</tr>
</table>

<script>
load_sp_all_types_ids('",$screen,"');
load_ids_edit_self('",$screen,"','general');
</script>


";




}

?>
