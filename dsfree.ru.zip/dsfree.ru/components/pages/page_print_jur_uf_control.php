<?php

function page_print_jur_uf_control($vals)
{

print_r($vals);

}

?>
