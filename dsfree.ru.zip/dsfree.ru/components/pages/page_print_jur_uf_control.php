<?php

function page_print_jur_uf_control($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$page = $vals['page'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

If($page == "")
{
echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td colspan = \"3\" align = \"left\" style = \"padding-left: 10px; background-color: black; color: white;\">
печать журнала
</td>
</tr>

<tr height = \"15%\">
<td colspan = \"3\" align = \"left\">


";

$sql = "select * from tab_misc_sets where id = '5'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['val'];
$arr = json_decode($json_arr,true);

Foreach($arr as $id_room=>$ar_valls)
{

$name_room = $ar_valls['char']['name'];

$ar_ufs = $ar_valls['ufs'];

Foreach($ar_ufs as $id_ufs=>$ar_val)
{
$place = $ar_val['place'];
$ar_all_ufs[$id_ufs] = $name_room."-".$place;

}


}

echo "<select id = \"sel_id_uf_device_",$screen,"\" style = \"float: right;\">
<option selected value = \"\">выберете уф-облучатель</option>";

Foreach($ar_all_ufs as $id_uf=>$namef_uf)
{
echo "<option value = \"",$id_uf,"\">",$namef_uf,"</option>";
}

echo "</select>";

}



//<option value = \"111\">лампа 1</option>
//<option value = \"222\">В отсутствии людей</option>

echo "
</select>

</td>
</tr>


<tr style = \"cursor: pointer;\">
<td onclick = \"page_print_jur_uf_control('",$screen,"','cover1');\">

обложка 1

</td>
<td onclick = \"page_print_jur_uf_control('",$screen,"','cover2');\">

обложка 2

</td>
<td onclick = \"page_print_jur_uf_control('",$screen,"','table');\">

таблица

</td>
</tr>
</table>

";

}
Else{



$id_uf_device = $vals['id_uf_device'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td align = \"left\" style = \"padding-left: 10px; background-color: black; color: white;\">
печать журнала
</td>
</tr>
<tr height = \"15%\">
<td onclick = \"page_print_jur_uf_control('",$screen,"','');\" align = \"left\" style = \"padding-left: 10px;\">

назад

</td>
</tr>
<tr>
<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>


<select id = \"sel_month_begin_page_preprint_jur_uf_control_",$screen,"\">";

$ar_months_rus = array(
"01"=>"январь",
"02"=>"февраль",
"03"=>"март",
"04"=>"апрель",
"05"=>"май",
"06"=>"июнь",
"07"=>"июль",
"08"=>"август",
"09"=>"сентябрь",
"10"=>"октябрь",
"11"=>"ноябрь",
"12"=>"декабрь"
);

$month_now = date("m");
$year_now = date("Y");

#$month_now = 01;
#$year_now = 2023;

$mon_sel = date("m",mktime(0,0,0,$month_now-1,1,$year_now));
$year_sel = date("Y",mktime(0,0,0,$month_now-1,1,$year_now));


Foreach($ar_months_rus as $km=>$nm)
{

echo "<option";

If($km == $mon_sel)
{
echo " selected";
}

echo " value = \"",$km,"\">",$nm,"</option>";

}

echo "


</select>


<select id = \"sel_year_begin_page_preprint_jur_uf_control_",$screen,"\">";

$year_now = date("Y");
$year_past = $year_now-5;
$year_last = $year_now+5;

For($year_past;$year_past<=$year_last;$year_past++)
{
echo "<option";

If($year_past == $year_sel)
{
echo " selected";
}

echo ">",$year_past,"</option>";
}

echo "</select>

</td>



<td>


<select id = \"sel_month_end_page_preprint_jur_uf_control_",$screen,"\">";

$month_now = date("m");
$year_now = date("Y");


Foreach($ar_months_rus as $km=>$nm)
{

echo "<option";

If($km == $month_now)
{
echo " selected";
}

echo " value = \"",$km,"\">",$nm,"</option>";

}

echo "


</select>


<select id = \"sel_year_end_page_preprint_jur_uf_control_",$screen,"\">";

$year_now = date("Y");
$year_past = $year_now-5;
$year_last = $year_now+5;

For($year_past;$year_past<=$year_last;$year_past++)
{
echo "<option";

If($year_past == $year_now)
{
echo " selected";
}

echo ">",$year_past,"</option>";
}

echo "</select>

</td>

</tr>
</table>

</td>
</tr>
<tr onclick = \"print_jur_uf_control('",$screen,"','",$page,"','",$id_uf_device,"');\" height = \"15%\" style = \"background-color: #008080; color: white;\">
<td>
отправка
</td>
</tr>
</table>

<span id = \"hidden_id_uf_device_preprint_jur_uf_control_",$screen,"\">",$id_uf_device,"</span>

";

}


}

?>

