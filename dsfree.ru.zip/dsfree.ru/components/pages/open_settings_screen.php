<?php

function open_settings_screen($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$name_page = $vals['name_page'];


If($name_page == "jurnal_pacs")
{
echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"'); \">X</span>

<script>


function load_sets_jurnal_pacs(screen,name_page)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sets_jurnal_pacs') + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var id_f_jurnal_pacs = 'id_f_jurnal_pacs_' + screen;

var cont = document.getElementById(id_f_jurnal_pacs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30px\" style = \"background-color: black; color: white; font-weight: bold;\">
<td>
Параметры журнала записи
</td>
</tr>
<tr>
<td>

<div style = \"display: flex; flex-direction: column; height: 100%; text-align: left;\">

<div class=\"cm-e-menu\" style = \"padding-top: 4px; padding-bottom: 4px;\">
<ul>

<li class=\"topmenu\">
<a>Подсказка</a>

<ul class=\"submenu\">
<li onclick = \"load_sets_jurnal_pacs('",$screen,"','orientation_tips');\"><a>Ориентация</a></li>
<li ><a>Содержание</a></li>
</ul>

</li>

<li class=\"topmenu\">
<a>
Элементы
</a>

<ul class=\"submenu\">
<li ><a>День дата</a></li>
<li onclick = \"load_sets_jurnal_pacs('",$screen,"','panel_control');\"><a>Панель управления</a></li>
</ul>

</li>

</ul>
</div>




<div id = \"id_f_jurnal_pacs_",$screen,"\" style = \"flex-grow: 3; \">



</div>


</td>

</tr>

</table>

<script>
load_sets_jurnal_pacs('",$screen,"','orientation_tips');
</script>

";

}
ElseIf($name_page == "jurnal_steril")
{
echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"'); \">X</span>


<script>


function load_sets_jurnal_steril(screen,name_page)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sets_jurnal_steril') + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var id_f_jurnal_steril = 'id_f_jurnal_steril_' + screen;

var cont = document.getElementById(id_f_jurnal_steril);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}



</script>


<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30px\" style = \"background-color: black; color: white; font-weight: bold;\">
<td>
Параметры журнала стерилизации
</td>
</tr>
<tr>
<td>

<div style = \"display: flex; flex-direction: column; height: 100%; text-align: left;\">

<div class=\"cm-e-menu\" style = \"padding-top: 4px; padding-bottom: 4px;\">
<ul>

<li class=\"topmenu\">
<a onclick = \"load_sets_jurnal_steril('",$screen,"','steril_kits');\">Наборы</a>
</li>


<li class=\"topmenu\">
<a onclick = \"load_sets_jurnal_steril('",$screen,"','autoclav');\">Автоклав</a>
</li>


</ul>
</div>




<div id = \"id_f_jurnal_steril_",$screen,"\" style = \"flex-grow: 3; \">



</div>


</td>

</tr>

</table>

<script>
load_sets_jurnal_steril('",$screen,"','steril_kits');
</script>

";




}
ElseIf($name_page == "jurnal_pso")
{
echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"'); \">X</span>


<script>


function load_sets_jurnal_pso(screen,name_page)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sets_jurnal_pso') + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var id_f_jurnal_pso = 'id_f_jurnal_pso_' + screen;

var cont = document.getElementById(id_f_jurnal_pso);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}



</script>


<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30px\" style = \"background-color: black; color: white; font-weight: bold;\">
<td>
Параметры журнала ПСО
</td>
</tr>
<tr>
<td>

<div style = \"display: flex; flex-direction: column; height: 100%; text-align: left;\">

<div class=\"cm-e-menu\" style = \"padding-top: 4px; padding-bottom: 4px;\">
<ul>

<li class=\"topmenu\">
<a onclick = \"load_sets_jurnal_pso('",$screen,"','azopiram');\">азопирам</a>
</li>


<li class=\"topmenu\">
<a onclick = \"load_sets_jurnal_pso('",$screen,"','method');\">метод</a>
</li>


</ul>
</div>




<div id = \"id_f_jurnal_pso_",$screen,"\" style = \"flex-grow: 3; \">



</div>


</td>

</tr>

</table>

<script>
load_sets_jurnal_pso('",$screen,"','azopiram');
</script>

";




}
ElseIf($name_page == "jurnal_uf_control")
{
echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"'); \">X</span>


<script>


function load_sets_jurnal_uf_control(screen,name_page)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sets_jurnal_uf_control') + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var id_f_jurnal_uf_control = 'id_f_jurnal_uf_control_' + screen;

var cont = document.getElementById(id_f_jurnal_uf_control);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}



</script>


<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30px\" style = \"background-color: black; color: white; font-weight: bold;\">
<td>
Параметры журнала УФ
</td>
</tr>
<tr>
<td>

<div style = \"display: flex; flex-direction: column; height: 100%; text-align: left;\">

<div class=\"cm-e-menu\" style = \"padding-top: 4px; padding-bottom: 4px;\">
<ul>

<li class=\"topmenu\">
<a onclick = \"load_sets_jurnal_uf_control('",$screen,"','rooms');\">Помещения</a>
</li>


</ul>
</div>




<div id = \"id_f_jurnal_uf_control_",$screen,"\" style = \"flex-grow: 3; \">



</div>


</td>

</tr>

</table>

<script>
load_sets_jurnal_uf_control('",$screen,"','rooms');
</script>

";




}




}

?>
