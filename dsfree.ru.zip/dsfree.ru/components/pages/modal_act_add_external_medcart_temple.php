<?php

function modal_act_add_external_medcart_temple($vals)
{


#print_r($vals);

$screen = $vals['screen'];
$id_ds = $vals['id_ds'];
$name_funct = $vals['name_funct'];

$id_pac = $vals['id_pac'];


include_once("../components/blocks/templates/".$name_funct.".php");
$ar = $name_funct();

$avail_ds = $ar['avail_ds'];

$name_ds = $avail_ds[$id_ds];


echo "<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\" height = \"25%\">
Добавить шаблон данного диагноза в базу?
</td>
</tr>
<tr>
<td colspan = \"2\">

<input id = \"id_add_external_medcart_temple_",$screen,"\" style = \"width: 95%; height: 70%; background: transparent; border: none; border-bottom: 1px solid grey; color: white; font-size: 18px; font-weight: bold;\" value = \"",$name_ds,"\">

</td>
</tr>
<tr height = \"25%\">
<td onclick=\"close_mw('fon_modal_first_",$screen,"');\" style = \"background-color: #FF8080; cursor: pointer;\" width = \"50%\">
нет
</td>
<td onclick = \"act_add_external_medcart_temple('",$screen,"','",$id_ds,"','",$name_funct,"','",$id_pac,"');\" style = \"background-color: #008080; cursor: pointer;\">
да
</td>
</tr>
</table>
<span id = \"hidden_modal_act_add_external_medcart_temple_",$screen,"\"></span>
";



}

?>
