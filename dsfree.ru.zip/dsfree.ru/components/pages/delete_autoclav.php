<?php

function delete_autoclav($vals)
{

$screen = $vals['screen'];
$id = $vals['id'];


echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"65%\">
<td colspan = \"2\">
удалить этот автоклав?
</td>
</tr>
<tr>
<td onclick=\"close_mw('fon_modal_first_",$screen,"');\" style = \"background-color: #FF8080;\">
нет
</td>
<td onclick = \"act_delete_autoclav('",$id,"','",$screen,"');\" style = \"background-color: #008080;\">
да
</td>

</tr>

</table>

";



}

?>
