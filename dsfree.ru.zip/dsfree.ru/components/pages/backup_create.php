<?php

function backup_create()
{

echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\" align = \"center\">

<div style = \"border: 0px solid grey; width: 60%; height: 40%; background-color: #2E3436; display: table;\">


<span style=\"vertical-align: middle; display: table-cell; font-weight: bold; cursor: pointer;\">

Снять резервную копию данных DSFree

</span>




</div>

</td>
<td align = \"center\">

<div style = \"border: 0px solid grey; width: 60%; height: 40%; background-color: #2E3436; display: table; cursor: pointer;\">


<span style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">

Снять резервную копию пользователей DSFree

</span>




</div>

</td>

</tr>
</table>
";


}

?>
