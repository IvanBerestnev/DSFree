<?php

function page_delete_price($vals)
{

$screen = $vals['screen'];
$param = $vals['param'];
$id_price = $vals['id_price'];


echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>
<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style=\"background-color: #22272B; font-weight: bold;\">
<td colspan = \"2\">
удалить прайс?
</td>
</tr>
<tr height = \"35%\" style = \"cursor: pointer; font-weight: bold;\">
<td onclick=\"close_mw('fon_modal_first_",$screen,"');\" style = \"background-color: #FF8080;\" width = \"50%\">
нет
</td>
<td onclick=\"act_add_page_price('act_delete_price','",$screen,"','','",$id_price,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
<span id = \"hidden_page_delete_price_",$screen,"\"></span>
";


}


?>
