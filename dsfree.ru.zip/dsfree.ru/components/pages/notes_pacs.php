<?php

function notes_pacs($vals)
{

#print_r($vals);

$screen = $vals['screen'];

echo "

<script>

function load_notes_pacs(surname,screen)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_notes_pacs') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[surname]=\" + encodeURIComponent(surname));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_notes_pacs = 'f_notes_pacs_' + screen;

var cont = document.getElementById(f_notes_pacs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

function erase_inp_notes_pacs(screen)
{
var inp_surname_notes_pacs = 'inp_surname_notes_pacs_' + screen;
document.getElementById(inp_surname_notes_pacs).value = '';
}

function open_modal_mark_ent(screen,id_pac)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_modal_mark_ent') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '40%';
document.getElementById(modal).style.height = '40%';

var cont = document.getElementById(modal);

cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<style>

.tr_load_notes_pacs_",$screen,":hover{
background-color: #808080;
}

</style>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"3%\" style = \"background-color: black;\">
<td>
Заметки о приеме пациента

<span onclick=\"trunc_screen('",$screen,"');\" class=\"but_trunc_screen\">X</span>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"background-color: #242424;\">

</td>
<td style = \"background-color: #2E3436;\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #22272B;\" height = \"10%\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"66%\" align = \"left\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\" style = \" \">


<input id = \"inp_surname_notes_pacs_",$screen,"\" onkeyup = \"load_notes_pacs(this.value,'",$screen,"');\" style = \"width:100%;  vertical-align: middle; display: table-cell; font-weight: bold; height: 70%; background: transparent; border: none; border-bottom: 1px solid grey; color: white; font-size: 15px; font-weight: bold;\" placeholder = \"поиск по фамилии\">


</td>
<td align = \"center\">

<div style=\"background-color: #FF8080; cursor: pointer; height: 55%; width: 65%; display: table; text-align: center;\">
<span onclick = \"load_notes_pacs('','",$screen,"'); erase_inp_notes_pacs('",$screen,"');\" style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">х</span>
</div>

</td>
</tr>
</table>






</td>
<td>

<select disabled>
<option>пол</option>
</select>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<div id = \"f_notes_pacs_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">
</div>

</td>
</tr>
</table>

</td>
<td width = \"25%\" style = \"background-color: #242424;\">

</td>
</tr>
</table>

</td>
</tr>
</table>

<script>
load_notes_pacs('','",$screen,"')
</script>


";


}


?>
