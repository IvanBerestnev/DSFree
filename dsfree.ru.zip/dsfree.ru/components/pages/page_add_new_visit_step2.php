<?php

function page_add_new_visit_step2($vals)
{

#print_r($vals);

$param = $vals['param'];
$screen = $vals['screen'];

$ar_param = explode("@",$param);
$id_pac = $ar_param[0];
$id_dss = $ar_param[1];

#echo $id_dss;

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss where id_ds = '$id_dss'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$name_ds = $row['name_ds'];
}

$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$text = $row['text'];
$ar_decoded = json_decode($text,true);

If(key($ar_decoded) == $id_dss)
{

$ar_selected_ds = $ar_decoded[$id_dss];

Foreach($ar_selected_ds as $id_struct=>$ar_valls)
{
$name_struct = $ar_valls['name'];
$ar_new[$id_struct] = $name_struct;
}

}
Else{
continue;
}

}

}




echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #3A3A3A;\">
<td align = \"center\">
новая запись медицинской карты. этап 2 (из 2)
</td>
</tr>

<tr style = \"background-color: #2E3336;\" height = \"35%\">
<td align = \"center\">
выбран диагноз: ",$name_ds,"
</td>
</tr>
<tr style = \"background-color: #2E3336;\">
<td align = \"center\" valign = \"top\">

выберете структурный шаблон
<br>

<select onchange = \"act_add_new_visit('",$screen,"',this.value);\" style = \"text-align: center;\">
<option disabled selected>-</option>
";

If(isset($ar_new))
{

Foreach($ar_new as $id_str=>$name_str)
{
echo "<option value = \"",$id_pac,"@",$id_dss,"@",$id_str,"\">",$name_str,"</option>";
}

}
Else{
echo "<option value = \"",$id_pac,"@",$id_dss,"@\">продолжить без шаблона</option>";

}


echo "
</select>

</td>
</tr>
</table>


";


}

?>
