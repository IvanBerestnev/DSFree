<?php

function sp_docs_readonly($screen,$belong)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



echo "

<table border = \"0\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; font-weight: bold; background-color: #2F3436; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"3%\" align = \"center\" style = \"background-color: black; color: white;\">
<td>
Список врачей (только чтение)";

If($belong !== "y")
{
echo "<span onclick = \"trunc_screen('",$screen,"');\" class = \"but_trunc_screen\">X</span>";
}

echo "
</td>
</tr>
<tr>
<td>
<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">
";

$sql = "select * from tab_personal where type = 'doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];

$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];

$bg_color_gen = $row['bg_color_gen'];



echo "

<table border = \"1\" height = \"150px\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; font-weight: bold; background-color: #404040; margin-top: 10px;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"60%\">
<td>

<table border = \"1\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; font-weight: bold; background-color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td>
",$surname_pers,"
</td>
<td>
",$name_pers,"
</td>
<td>
",$patronymic_pers,"
</td>
</tr>
</table>

</td>
<td rowspan = \"2\">
<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">";


$sql = "select * from tab_docs_cert where id_doc = '$id_pers'";
$query_cert = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query_cert) !== 0)
{

echo "<table border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; font-weight: bold; background-color: #404040; border: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row_cert = mysqli_fetch_assoc($query_cert))
{

$name_cert = $row_cert['name_cert'];
$date_cert = $row_cert['date_cert'];

If($name_cert == "")
{
$name_cert = "пусто";
}

echo "


<tr height = \"50px\" align = \"center\">
<td>",
$name_cert
,"</td>
<td>до 
",$date_cert,"
</td>
</tr>


";

}

echo "</table>";

}

echo "
</div>
</td>
</tr>
<tr style = \"background-color: ",$bg_color_gen,";\">
<td>

</td>
</tr>
</table>


";


}

}



echo "</td>
</tr>
</table>

";


}

?>
