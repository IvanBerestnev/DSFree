<?php

function add_new_ds_out($ar_all_classif,$screen,$id_pac)
{

echo "

<script>

function act_save_new_ds(screen,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

var new_ds = 'new_ds_' + screen;
var ds = document.getElementById(new_ds).value;

var classif_ds = 'classif_ds_' + screen;

var e = document.getElementById(classif_ds);
var value = e.value;
var classif = e.options[e.selectedIndex].value;


xmlhttp.send(\"act=\" + encodeURIComponent('act_save_new_ds') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[ds]=\" + encodeURIComponent(ds) + \"&data[classif]=\" + encodeURIComponent(classif) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_hidden_act_save_new_ds = 'f_hidden_act_save_new_ds_' + screen;

var cont = document.getElementById(f_hidden_act_save_new_ds);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; font-weight: bold; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td align = \"left\" style = \"background-color: #3A3A3A; padding-left: 20px;\">
добавить диагноз
</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; font-weight: bold; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"60%\">
<input id = \"new_ds_",$screen,"\" style = \"width: 80%; height: 30%;\">
</td>
<td>
<select id = \"classif_ds_",$screen,"\" style = \"width: 80%; height: 30%; text-align: center;\">
<option disabled selected>классификация</option>";

Foreach($ar_all_classif as $kc=>$vc)
{

echo "<option value = \"",$kc,"\">",$vc,"</option>";

}

echo "
</select>
</td>
</tr>
</table>

</td>
</tr>
<tr onclick = \"act_save_new_ds('",$screen,"','",$id_pac,"');\" height = \"20%\" style = \"background-color: #008080; cursor: pointer;\">
<td>
сохранить
</td>
</tr>
</table>

<span style = \"display: none;\" id = \"f_hidden_act_save_new_ds_",$screen,"\"></span>";


}

?>
