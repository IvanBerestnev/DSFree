<?php

function dogovor_pmu_page($id_pac,$screen)
{


include_once("../components/blocks/get_info_pac_by_id_pac.php");
$info_pac = get_info_pac_by_id_pac($id_pac);
$surname_pac = $info_pac['surname_pac'];
$name_pac = $info_pac['name_pac'];
$patronymic_pac = $info_pac['patronymic_pac'];


echo "

<script>


function all_dogovor_pmu(id_pac,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('all_dogovor_pmu') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_all_dogovor_pmu = 'f_all_dogovor_pmu_' + screen;

var cont = document.getElementById(f_all_dogovor_pmu);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}



function change_opt_new_dogovor_pmu(type,val,screen)
{



if(type == 'age_pac')
{

if(val == 'do18')
{


var new_var = 'age_pac_do18_opt_dog_pmu_' + screen;
var old_var = 'age_pac_posle18_opt_dog_pmu_' + screen;

document.getElementById(new_var).style.backgroundColor = '#008080';
document.getElementById(new_var).style.color = 'white';


document.getElementById(old_var).style.backgroundColor = '#C0C0C0';
document.getElementById(old_var).style.color = 'black';


var hid_val_selected_age_dog_pmu = 'hid_val_selected_age_dog_pmu_' + screen;
document.getElementById(hid_val_selected_age_dog_pmu).innerHTML = 'do18';



}
else if(val == 'posle18')
{

var new_var = 'age_pac_do18_opt_dog_pmu_' + screen;
var old_var = 'age_pac_posle18_opt_dog_pmu_' + screen;

document.getElementById(new_var).style.backgroundColor = '#C0C0C0';
document.getElementById(new_var).style.color = 'black';


document.getElementById(old_var).style.backgroundColor = '#008080';
document.getElementById(old_var).style.color = 'white';

var hid_val_selected_age_dog_pmu = 'hid_val_selected_age_dog_pmu_' + screen;
document.getElementById(hid_val_selected_age_dog_pmu).innerHTML = 'posle18';

}
}
}


function open_page_other_lica_dogovor_pmu(id_pac,screen,id_dog,mode)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_page_other_lica_dogovor_pmu') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[mode]=\" + encodeURIComponent(mode) + \"&data[id_dog]=\" + encodeURIComponent(id_dog));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '60%';
document.getElementById(modal).style.height = '50%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}

function change_val_selected_whopaid_dog_pmu(screen,val)
{

var hid_val_selected_whopaid_dog_pmu = 'hid_val_selected_whopaid_dog_pmu_' + screen;
document.getElementById(hid_val_selected_whopaid_dog_pmu).innerHTML = val;

}

function act_add_new_dogovor_pmu(screen,id_pac)
{

var hid_val_selected_age_dog_pmu = 'hid_val_selected_age_dog_pmu_' + screen;
var selected_age_dog_pmu = document.getElementById(hid_val_selected_age_dog_pmu).innerHTML;

var hid_val_selected_whopaid_dog_pmu = 'hid_val_selected_whopaid_dog_pmu_' + screen;
var selected_whopaid_dog_pmu = document.getElementById(hid_val_selected_whopaid_dog_pmu).innerHTML;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_new_dogovor_pmu') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[selected_age_dog_pmu]=\" + encodeURIComponent(selected_age_dog_pmu) + \"&data[selected_whopaid_dog_pmu]=\" + encodeURIComponent(selected_whopaid_dog_pmu) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_all_dogovor_pmu = 'f_all_dogovor_pmu_' + screen;

var cont = document.getElementById(f_all_dogovor_pmu);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}


function act_add_otherlico_dogovor_pmu(id_pac,id_other_lico,id_dog,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_otherlico_dogovor_pmu') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_other_lico]=\" + encodeURIComponent(id_other_lico) + \"&data[id_dog]=\" + encodeURIComponent(id_dog));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_all_dogovor_pmu = 'f_all_dogovor_pmu_' + screen;

var cont = document.getElementById(f_all_dogovor_pmu);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function change_param_dogovor_pmu(id_dog,type,val,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('change_param_dogovor_pmu') + \"&data[id_dog]=\" + encodeURIComponent(id_dog) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[val]=\" + encodeURIComponent(val));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



}
}
}

}


function act_delete_dogovor_pmu(id_dog,screen,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_dogovor_pmu') + \"&data[id_dog]=\" + encodeURIComponent(id_dog) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_all_dogovor_pmu = 'f_all_dogovor_pmu_' + screen;

var cont = document.getElementById(f_all_dogovor_pmu);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}

}


function choice_id_doc_dog(screen,val,id_dog)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('choice_id_doc_dog') + \"&data[val]=\" + encodeURIComponent(val) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_dog]=\" + encodeURIComponent(id_dog));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

}
}
}


}

function delete_doc_from_dogovor(id_dog,screen)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('delete_doc_from_dogovor') + \"&data[id_dog]=\" + encodeURIComponent(id_dog) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hid_dogovor_pmu_page = 'hid_dogovor_pmu_page_' + screen;

var cont = document.getElementById(hid_dogovor_pmu_page);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}




}

</script>

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\">
<td>

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #3A3A3A;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"20%\" style = \"cursor: pointer;\" onclick = \"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\">
&#10096;

</td>
<td>
Договор платных медицинских услуг
</td>
</tr>
</table>


</td>
<td>

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>";

echo $surname_pac," ",$name_pac," ",$patronymic_pac;

echo "</td>
<td onclick = \"load_primary_docums('','",$screen,"');\" width = \"20%\" style = \"cursor: pointer;\">
X
</td>
</tr>
</table>


</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"background-color: #2E3336;\">

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<table border = \"0\" align = \"center\" height = \"40%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td colspan = \"2\">
Возраст пациента
</td>
</tr>
<tr style = \"cursor: pointer;\">
<td id = \"age_pac_do18_opt_dog_pmu_",$screen,"\" onclick = \"change_opt_new_dogovor_pmu('age_pac','do18','",$screen,"');\" width = \"50%\" style = \"background-color: #C0C0C0; color: black;\">
до 18
</td>
<td id = \"age_pac_posle18_opt_dog_pmu_",$screen,"\" onclick = \"change_opt_new_dogovor_pmu('age_pac','posle18','",$screen,"');\" width = \"50%\" style = \"background-color: #008080; color: white;\">
18 и выше
</td>
</tr>
</table>


</td>
</tr>
<tr>
<td>


<table border = \"0\" align = \"center\" height = \"40%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td>
Оплачивает
</td>
</tr>
<tr style = \"cursor: pointer;\">
<td>

<div id = \"f_chousen_self_",$screen,"\" style = \"display: block; width: 100%; height: 100%;\">
<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"open_page_other_lica_dogovor_pmu('",$id_pac,"','",$screen,"','','out');\" width = \"50%\" style = \"background-color: #C0C0C0; color: black;\">
3е лицо
</td>
<td width = \"50%\" style = \"background-color: #008080; color: white;\">
сам
</td>
</tr>
</table>
</div>


<div id = \"f_chousen_other_lico_",$screen,"\" style = \"display: none; width: 100%; height: 100%;\"></div>


</td>
</tr>
</table>


</td>
</tr>
<tr height = \"50%\">
<td>

<table border = \"0\" align = \"center\" height = \"25%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer; background-color: #3A3A3A;\" cellpadding=\"0\" cellspacing= \"0\">
<tr onclick = \"act_add_new_dogovor_pmu('",$screen,"','",$id_pac,"');\">
<td>
Создать договор
</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
<td style = \"background-color: #22272B;\">

<div id = \"f_all_dogovor_pmu_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\"></div>

</td>
</tr>
</table>



</td>
</tr>
</table>

<span style = \"display: none;\" id = \"hid_val_selected_age_dog_pmu_",$screen,"\">posle18</span>
<span style = \"display: none;\" id = \"hid_val_selected_whopaid_dog_pmu_",$screen,"\">self</span>

<span style = \"display: none;\" id = \"hid_dogovor_pmu_page_",$screen,"\"></span>


<script>
all_dogovor_pmu('",$id_pac,"','",$screen,"');
</script>

";



}


?>
