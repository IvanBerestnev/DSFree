<?php

function add_new_usluga($vals)
{

#print_r($vals);

$id_price = $vals['id_price'];
$screen = $vals['screen'];

echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #22272B;\">
<td align = \"left\" colspan = \"2\">
добавить новую услугу
</td>
</tr>
<tr height = \"20%\" style = \"background-color: #222222;\">
<td width = \"80%\">
название
</td>
<td>
цена
</td>
</tr>
<tr style = \"background-color: #222222;\">
<td>
<input id = \"id_inp_name_new_usluga_",$screen,"\" style = \"width: 90%; height: 40%;\">
</td>
<td>
<input id = \"id_inp_cena_new_usluga_",$screen,"\" style = \"width: 80%; height: 40%;\">
</td>
</tr>
<tr height = \"20%\" style = \"background-color: #008080;\">
<td style = \"cursor: pointer\" onclick = \"act_add_page_price('act_save_new_usluga','",$screen,"','','",$id_price,"');\" colspan = \"2\">
сохранить
</td>
</tr>
</table>
<span style = \"display: hidden;\" id = \"hidden_act_add_new_usluga_",$screen,"\"></span>
";

}

?>
