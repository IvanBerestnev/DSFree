<?php

function mass_doc_shed($vals)
{



include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();
$level_cookie = $ar_vals['level_cookie'];
$int_level_cookie = (int)$level_cookie;

include_once("../components/blocks/check_permissions.php");
$permission = check_permissions($int_level_cookie,"mass_doc_shed","");

If($permission == "disable")
{
include_once("../components/pages/page_lock.php");
$signal = page_lock();

If($signal == "stop")
{
return false;
}
}




#print_r($vals);
$screen = $vals['screen'];

If(isset($vals['belong']))
{
$belong = $vals['belong'];
}
Else{
$belong = "";
}

$ar_rus_month = array("01"=>"январь","02"=>"февраль","03"=>"март","04"=>"апрель","05"=>"май","06"=>"июнь","07"=>"июль","08"=>"август","09"=>"сентябрь","10"=>"октябрь","11"=>"ноябрь","12"=>"декабрь");
$month_now = date("m");
$year_now = date("Y");
$year_pre = $year_now-5;
$year_nxt = $year_now+5;

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_personal where type = 'doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$id_pers = $row['id_pers'];
$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];

If($surname_pers == "")
{
echo "<script>close_mw('fon_modal_",$screen,"');load_page_screen('sp_docs','",$screen,"');</script>";die();
}

$ar_pers[$id_pers]['name_pers'] = $name_pers;
$ar_pers[$id_pers]['surname_pers'] = $surname_pers;
$ar_pers[$id_pers]['patronymic_pers'] = $patronymic_pers;

}

//


echo "

<span id = \"main_loaded_page_mass_doc_shed\" class = \"main_loaded_page\" style = \"display: none;\">opened</span>

<script>

function load_msd_calendar(screen,type,val)
{

if(type !== 'month')
{
//пол-е месяца
var sel_msd_calendar_month = 'sel_msd_calendar_month_' + screen;
var x = document.getElementById(sel_msd_calendar_month);
var month = x.options[x.selectedIndex].value;
}
else{
var month = val;
}


if(type !== 'year')
{

//пол-е года
var sel_msd_calendar_year = 'sel_msd_calendar_year_' + screen;
var x = document.getElementById(sel_msd_calendar_year);
var year = x.options[x.selectedIndex].value;

}
else{
var year = val;
}


if(type !== 'unit')
{

//пол-е установки
var sel_msd_calendar_unit = 'sel_msd_calendar_unit_' + screen;
var x = document.getElementById(sel_msd_calendar_unit);
var unit = x.options[x.selectedIndex].value;

}
else{
var unit = val;
}


if(type !== 'type')
{

//пол-е типа календаря
var sel_msd_calendar_type = 'sel_msd_calendar_type_' + screen;
var x = document.getElementById(sel_msd_calendar_type);
var type = x.options[x.selectedIndex].value;



}
else{

var type = val;

//очистка сохраненных дней
//alert('123');
var span_chousen_day_msd_cal = 'span_chousen_day_msd_cal_' + screen;
document.getElementById(span_chousen_day_msd_cal).innerHTML = '';

}


check_button_send_msd(screen);


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_msd_calendar') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[month]=\" + encodeURIComponent(month) + \"&data[year]=\" + encodeURIComponent(year) + \"&data[unit]=\" + encodeURIComponent(unit) + \"&data[type]=\" + encodeURIComponent(type));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_msd_calendar = 'f_msd_calendar_' + screen;

var cont = document.getElementById(f_msd_calendar);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}



function chouse_day_msd_cal(day,screen,act)
{

if(act == 'save')
{

var id_chousen_day_msd_call = 'id_chousen_day_msd_call_' + screen + '_' + day;
document.getElementById(id_chousen_day_msd_call).style.display = 'flex';

var id_chouse_day_msd_call = 'id_chouse_day_msd_call_' + screen + '_' + day;
document.getElementById(id_chouse_day_msd_call).style.display = 'none';

//добавление в скрытый спан выбранного дня

var span_chousen_day_msd_cal = 'span_chousen_day_msd_cal_' + screen;
var pre_chousen_day_msd_cal = document.getElementById(span_chousen_day_msd_cal).innerHTML;

if(pre_chousen_day_msd_cal == '')
{
document.getElementById(span_chousen_day_msd_cal).innerHTML = day;
}
else{
var chousen_day_msd_cal = pre_chousen_day_msd_cal + ',' + day;
document.getElementById(span_chousen_day_msd_cal).innerHTML = chousen_day_msd_cal;
}




}
else if(act == 'cancel')
{

var id_chousen_day_msd_call = 'id_chousen_day_msd_call_' + screen + '_' + day;
document.getElementById(id_chousen_day_msd_call).style.display = 'none';

var id_chouse_day_msd_call = 'id_chouse_day_msd_call_' + screen + '_' + day;
document.getElementById(id_chouse_day_msd_call).style.display = 'flex';

//удаление дней из скрытого спана

var span_chousen_day_msd_cal = 'span_chousen_day_msd_cal_' + screen;
var pre_chousen_day_msd_cal = document.getElementById(span_chousen_day_msd_cal).innerHTML;

var arr = pre_chousen_day_msd_cal.split(',');

var new_arr = [];

var length = arr.length;

for (var i = 0; i < length; i++) {

var saved_day = arr[i];

if(saved_day !== day)
{
new_arr.push(saved_day);
}


}


//alert(new_arr);

var str_new_arr = new_arr.join(',');

//alert(str_new_arr);

document.getElementById(span_chousen_day_msd_cal).innerHTML = str_new_arr;


}

check_button_send_msd(screen);

}

function load_doc_msd(screen,id_pers,act)
{







if(act == 'save')
{


var id_sp_doc_msd_active = 'id_sp_doc_msd_active_' + screen + '_' + id_pers;
document.getElementById(id_sp_doc_msd_active).style.display = 'none';

var id_sp_doc_msd_inactive = 'id_sp_doc_msd_inactive_' + screen + '_' + id_pers;
document.getElementById(id_sp_doc_msd_inactive).style.display = 'flex';

//////////////


var span_chousen_doc_msd = 'span_chousen_doc_msd_' + screen;

//добавление в скрытый спан выбранного врача
var pre_chousen_doc_msd = document.getElementById(span_chousen_doc_msd).innerHTML;

if(pre_chousen_doc_msd == '')
{
document.getElementById(span_chousen_doc_msd).innerHTML = id_pers;
}
else{
var chousen_doc_msd = pre_chousen_doc_msd + ',' + id_pers;
document.getElementById(span_chousen_doc_msd).innerHTML = chousen_doc_msd;
}




}
else if(act == 'delete')
{

var id_sp_doc_msd_active = 'id_sp_doc_msd_active_' + screen + '_' + id_pers;
document.getElementById(id_sp_doc_msd_active).style.display = 'flex';

var id_sp_doc_msd_inactive = 'id_sp_doc_msd_inactive_' + screen + '_' + id_pers;
document.getElementById(id_sp_doc_msd_inactive).style.display = 'none';

/////////////////////////
//удаление врачей из скрытого спана

var span_chousen_doc_msd = 'span_chousen_doc_msd_' + screen;
var pre_chousen_doc_msd = document.getElementById(span_chousen_doc_msd).innerHTML;

var arr = pre_chousen_doc_msd.split(',');

var new_arr = [];

var length = arr.length;

for (var i = 0; i < length; i++) {

var saved_id_docs = arr[i];

if(saved_id_docs !== id_pers)
{
new_arr.push(saved_id_docs);
}


}


//alert(new_arr);

var str_new_arr = new_arr.join(',');

//alert(str_new_arr);

document.getElementById(span_chousen_doc_msd).innerHTML = str_new_arr;


}

var chousen_doc_msd = document.getElementById(span_chousen_doc_msd).innerHTML;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_doc_msd') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pers]=\" + encodeURIComponent(chousen_doc_msd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_doc_msd = 'f_doc_msd_' + screen;

var cont = document.getElementById(f_doc_msd);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

check_button_send_msd(screen);

}

function save_new_msd(screen)
{


var new_ar = new Array();

var class_sel_already_choiced_doc_msd = 'class_sel_already_choiced_doc_msd_' + screen;
var theOddOnes = document.getElementsByClassName(class_sel_already_choiced_doc_msd);


for(var i=0; i<theOddOnes.length; i++)
{

//получение ID из класса
var id_sel_already_choiced_doc_msd_circle = theOddOnes[i].id;

//получение выбранных значений селекта у перечисляемых в цикле
var x = document.getElementById(id_sel_already_choiced_doc_msd_circle);
var val_already_choiced_doc_msd_circle = x.options[x.selectedIndex].value;

//получение времен
var id_ntime = 'id_ntime_' + screen + '_' + i;
var val_ntime = document.getElementById(id_ntime).innerText;

var str_snd = val_already_choiced_doc_msd_circle + '#' + val_ntime;
new_ar.push(str_snd);

}

var str_new_ar = new_ar.join('@');
//alert(str_new_ar);

//выбранные дни

var span_chousen_day_msd_cal = 'span_chousen_day_msd_cal_' + screen;
var chousen_day_msd_cal = document.getElementById(span_chousen_day_msd_cal).innerHTML;

//месяц

var sel_msd_calendar_month = 'sel_msd_calendar_month_' + screen;
var x = document.getElementById(sel_msd_calendar_month);
var month = x.options[x.selectedIndex].value;

//год

var sel_msd_calendar_year = 'sel_msd_calendar_year_' + screen;
var x = document.getElementById(sel_msd_calendar_year);
var year = x.options[x.selectedIndex].value;

//установка

var sel_msd_calendar_unit = 'sel_msd_calendar_unit_' + screen;
var x = document.getElementById(sel_msd_calendar_unit);
var unit = x.options[x.selectedIndex].value;


////


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('save_new_msd') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[msd_dtime]=\" + encodeURIComponent(str_new_ar) + \"&data[month]=\" + encodeURIComponent(month) + \"&data[year]=\" + encodeURIComponent(year) + \"&data[unit]=\" + encodeURIComponent(unit) + \"&data[days]=\" + encodeURIComponent(chousen_day_msd_cal));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var id_f_page_default_ssetka = 'id_f_page_default_ssetka_' + screen;

var cont = document.getElementById(id_f_page_default_ssetka);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}




}

function check_button_send_msd(screen)
{

var span_chousen_day_msd_cal = 'span_chousen_day_msd_cal_' + screen;
var chousen_day_msd_cal = document.getElementById(span_chousen_day_msd_cal).innerHTML;

var span_chousen_doc_msd = 'span_chousen_doc_msd_' + screen;
var chousen_doc_msd = document.getElementById(span_chousen_doc_msd).innerHTML;


if(chousen_day_msd_cal !== '' && chousen_doc_msd !== '')
{
document.getElementById('but_save_inactive_msd').style.display = 'none';
document.getElementById('but_save_active_msd').style.display = 'flex';
}
else{
document.getElementById('but_save_inactive_msd').style.display = 'flex';
document.getElementById('but_save_active_msd').style.display = 'none';
}

}

</script>

<style>

::-webkit-scrollbar {
    width: 15px;
background-color: #1C1C1C;
}
 
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 

    border-radius: 10px;
}
 
::-webkit-scrollbar-thumb {
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 


}

.class_sp_doc_msd_active{

display: flex;
align-items: center;
justify-content: center;

height: 120px;
background-color: #303030; cursor: pointer; font-weight: bold; padding-left: 5px;
text-align: center;


border-bottom: 1px dashed DimGrey;
}


.class_sp_doc_msd_inactive{

display: flex;
align-items: center;
justify-content: center;

height: 120px;
background-color: #0E0E0E;
cursor: pointer; font-weight: bold; padding-left: 5px;
text-align: center;
color: LawnGreen;

border-bottom: 1px dotted DimGrey;

}



</style>
<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30px\" style = \"background-color: black; color: white; font-weight: bold; cursor: default;\">
<td colspan = \"3\" align = \"center\">
Массовое расписание врачей

";

If($belong !== "y")
{
echo "<span onclick = \"trunc_screen('",$screen,"');\" class = \"but_trunc_screen\">X</span>";
}

echo "

</td>
</tr>
<tr>
<td width = \"10%\">
<div class = \"\" style = \"height: 100%; width: 100%; overflow-y: scroll; \">

<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; background-color: #555753; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
";

Foreach($ar_pers as $id_pers=>$ar_vals)
{

$name_pers = $ar_vals['name_pers'];
$surname_pers = $ar_vals['surname_pers'];
$patronymic_pers = $ar_vals['patronymic_pers'];





echo "
<tr>
<td  >
<div id = \"id_sp_doc_msd_active_",$screen,"_",$id_pers,"\" class = \"class_sp_doc_msd_active\" onclick = \"load_doc_msd('",$screen,"','",$id_pers,"','save');\">",$surname_pers,"<br>",$name_pers,"<br>",$patronymic_pers,"</div>

<div id = \"id_sp_doc_msd_inactive_",$screen,"_",$id_pers,"\" class = \"class_sp_doc_msd_inactive\" onclick = \"load_doc_msd('",$screen,"','",$id_pers,"','delete');\" style = \"display: none;\">",$surname_pers,"<br>",$name_pers,"<br>",$patronymic_pers,"</div>

</td></tr>
";



}

echo "

</table>

</div>

</td>
<td>

<div style = \"width: 100%; height: 100%; overflow-y: scroll;\" id = \"f_doc_msd_",$screen,"\"></div>

</td>
<td width = \"20%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-right: 1px solid #222222; border-collapse: collapse; background-color: #555753; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\" height = \"10%\">
<td width = \"30%\">

<select style = \"font-weight: bold;\" onchange = \"load_msd_calendar('",$screen,"','month',this.value);\" id = \"sel_msd_calendar_month_",$screen,"\">
";

Foreach($ar_rus_month as $k=>$m)
{

echo "<option value = \"",$k,"\"";
If($k == $month_now)
{
echo " selected";
}
echo ">",$m,"</option>";
}


echo "
</select>

</td>
<td width = \"30%\">

<select style = \"font-weight: bold;\" onchange = \"load_msd_calendar('",$screen,"','year',this.value);\" id = \"sel_msd_calendar_year_",$screen,"\">
";

For($year_pre;$year_pre<=$year_nxt;$year_pre++)
{

echo "<option";
If($year_pre == $year_now)
{
echo " selected";
}
echo " value = \"",$year_pre,"\">",$year_pre,"</option>";

}

echo "

</select>
</td>

<td>


<select style = \"font-weight: bold;\" onchange = \"load_msd_calendar('",$screen,"','unit',this.value);\" id = \"sel_msd_calendar_unit_",$screen,"\">
<option value = \"1\">1 уст-ка</option>
<option value = \"2\">2 уст-ка</option>
</select>


</td>

</tr>
<tr>
<td colspan = \"3\">
<div style = \"width: 100%; height: 100%; \" id = \"f_msd_calendar_",$screen,"\"></div>
</td>
</tr>
<tr height = \"20%\">
<td colspan = \"3\" align = \"center\">

<select style = \"font-weight: bold;\" onchange = \"load_msd_calendar('",$screen,"','type',this.value);\" id = \"sel_msd_calendar_type_",$screen,"\">
<option value = \"only_freetime\">Только дни без расписания врачей</option>
<option value = \"only_wout_pacs\">Дни без записи пациентов</option>
</select>

</td>
</tr>


<tr height = \"10%\">
<td align = \"center\" colspan = \"3\" style = \"\">
<span id = \"but_save_inactive_msd\" style = \"display: none; align-items: center; justify-content: center; height: 100%; background-color: c3c3c3; color: white; font-weight: bold; cursor: default;\">Сохранить</span>
<span id = \"but_save_active_msd\" onclick = \"save_new_msd('",$screen,"');\" style = \"display: flex; align-items: center; justify-content: center; height: 100%; background-color: green; color: white; font-weight: bold; cursor: pointer;\">Сохранить</span>
</td>
</tr>
</table>

</td>

</tr>
</table>

<span style = \"display: none;\" id = \"span_chousen_day_msd_cal_",$screen,"\"></span>
<span style = \"display: none;\" id = \"span_chousen_doc_msd_",$screen,"\"></span>

<script>
load_msd_calendar('",$screen,"');check_button_send_msd('",$screen,"');
</script>

";

}
Else{

echo "<script>close_mw('fon_modal_",$screen,"');load_page_screen('sp_docs','",$screen,"');</script>";die();

}



}

?>
