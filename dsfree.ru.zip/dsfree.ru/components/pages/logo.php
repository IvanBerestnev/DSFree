<?php

function logo($txt_messg)
{


//Есть ли суперпользователь?
include_once("../components/functions/checkissetsuperuser.php");
checkissetsuperuser();

//Поиск информационных куки

If(isset($_COOKIE['dsf_cookie_inf']))
{
$dsf_cookie_inf = $_COOKIE['dsf_cookie_inf'];
include_once("../components/blocks/txt_messgs.php");
$ext_ar = txt_messgs($dsf_cookie_inf);
$messg = $ext_ar['txt'];
$w = $ext_ar['w'];
$h = $ext_ar['h'];
$trigger_show_cookie_inf = "<script>show_txt_modal('".$messg."','".$w."','".$h."');</script>";
}
Else{
$trigger_show_cookie_inf = "";
}



echo "
<meta charset=\"utf-8\">
<title>DSFree - Авторизация</title>
<meta name=\"keywords\" content=\"Полностью бесплатная программа для стоматологических клиник Dental Soft Free (DSFree)\">
<meta NAME=\"description\" CONTENT=\"Бесплатная программа для стоматологии, \">

<script>

function getXmlHttp() {
var xmlhttp;
try {
xmlhttp = new ActiveXObject(\"Msxml2.XMLHTTP\");
} catch (e) {
try {
xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");
} catch (E) {
xmlhttp = false;
}
}
if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
xmlhttp = new XMLHttpRequest();
}
return xmlhttp;
}

function author_site()
{

var name_auth = document.getElementById('auth_name').value;
var pass_auth = document.getElementById('auth_pass').value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('author_site') + \"&data[name_auth]=\" + encodeURIComponent(name_auth) + \"&data[pass_auth]=\" + encodeURIComponent(pass_auth));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('run');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function close_mw(fon)
{
document.getElementById(fon).style.display = 'none';
}


function show_txt_modal(txt,w,h)
{

document.getElementById('fon_modal_start').style.display = \"block\";
document.getElementById('modal_start').style.width = w;
document.getElementById('modal_start').style.height = h;
document.getElementById('modal_start').innerHTML = txt;

}



</script>

<style>

body{font-family: Arial;}

.close {

		background: #CC0000;
		color: #FFFFFF;
		line-height: 25px;

		position: absolute;
		right: -12px;
		text-align: center;
		top: -10px;
		width: 24px;
		text-decoration: none;
		font-weight: bold;
		
		
		
		-moz-box-shadow: 1px 1px 3px #000;
		-webkit-box-shadow: 1px 1px 3px #000;
		box-shadow: 1px 1px 3px #000;



	}

	.close:hover { background: #FF2424; cursor: pointer;}
	.close:active { background: black; }

table{cursor: default;}

input:-webkit-autofill {color: #ffffff !important;}
body{background-color: grey;}
#enter{border: 1px dotted #C3C3C3; padding-top: 32%; padding-bottom: 32%;font-family: Arial;}

@keyframes show{
0%{
 transform: scale(0) rotate(-45deg);
}
100% {
 transform: scale(1) rotate(0deg);
}
}

</style>

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: grey;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"\">

<table align = \"center\" border = \"0\" width = \"1100\" height = \"600\" style = \"border-collapse: collapse; table-layout: fixed; background-color: white; transition: 1s; animation: show 0.3s 1; animation-fill-mode: forwards;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\">
<td colspan = \"2\" style = \"background-color: #D3D7CF;\">
<div id = \"dq\" style = \"width: 80%; height: 100%; background-color: #EF2929; float: left; color: white; font-weight: bold; font-family: Arial; padding-left: 5px;  position: relative;\">
<div style = \"position: absolute; top: 33%; \">
Авторизация
</div>
</div>
<div style = \"width: 15%; height: 100%; background-color: #204A87; float: right;\"></div>
</td>
</tr>

<tr height = \"5%\">
<td colspan = \"2\" style = \"background-color: #D3D7CF; \"></td>
</tr>

<tr height = \"50%\">
<td style = \"font-size: 30px; font-family: Arial; position: relative;\" align = \"center\">

<div style = \" position: absolute; top: 5%; left: 3%; width: 100%; height: 50%; \"><div style = \"position: absolute; background-color:red; width:60px; height:60px; border: 4px solid #FF7878; outline: 1px solid black;\"></div><div style = \"position: absolute; left: 30px; top: 30px; background-color:blue; width:60px; height:60px; border: 4px solid #6B60FF; outline: 1px solid black;\"></div>
</div>

<span style = \"font-weight: bold;  font-size: 37px;\"> DSFree v2.0</span>


</td>
<td align = \"center\">


<table border = \"0\" width = \"90%\" height = \"40%\" style = \"border-collapse: collapse; table-layout: fixed; border: 1px dotted #D3D7CF;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">

<input type=\"text\" id = \"auth_name\" placeholder = \"имя\" >

</td>
<td onclick = \"author_site();\" rowspan = \"2\" style = \" cursor: pointer; font-size: 19px; border: 1px dotted #D3D7CF; font-family: Arial;\" width = \"30%\" align = \"center\">


вход


</td>
</tr>
<tr>
<td align = \"center\">

<input type = \"password\" id = \"auth_pass\" placeholder = \"пароль\" autocomplete=\"false\">

</td>
</tr>
</table>


</td>
</tr>
<tr height = \"15%\">
<td colspan = \"2\" style = \"font-size: 19px;  font-family: Arial; font-style: italic; color: black; padding-right: 30px; background-color: #D3D7CF; \" align = \"right\">
Навсегда свободное ПО


</td>
</tr>
<tr height = \"5%\">
<td colspan = \"2\" style = \"background-color: #D3D7CF; \">
<div style = \"width: 80%; height: 100%; background-color: #204A87; float: left;\">
<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"right\">

<button style = \"margin-right: 20px; display: none;\">
Политика использования
</button>

<button style = \"margin-right: 20px; display: none; \">
Видеоинструкция
</button>


<button style = \"margin-right: 20px; display: none; \">
Пожертвовать
</button>


</td>
</tr>
</table>
</div>
<div style = \"width: 15%; height: 100%; background-color: #EF2929; float: right;\"></div>
</td>
</tr>


</table>


<span id = \"run\" style = \"display: none;\"></span>

</td>
</tr>
</table>

";

echo "
<div id = \"fon_modal_start\" style = \"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); right: 0; bottom: 0; left: 0; margin: auto; position: fixed;\">
<div id = \"modal_start\" style = \"display: block; position: fixed; top: 0%; right: 0; bottom: 0; left: 0; margin: auto; background: white;\"></div>
</div>";

echo $trigger_show_cookie_inf;
//Проверка окна с сообщением.

#die();



}

?>
