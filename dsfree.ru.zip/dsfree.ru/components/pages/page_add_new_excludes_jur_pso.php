<?php

function page_add_new_excludes_jur_pso($vals)
{

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

echo "

<script>

function add_new_excludes_jur_pso(screen)
{

var class_radio_excludes = 'class_radio_excludes_' + screen;

var x = document.getElementsByClassName(class_radio_excludes);
  var rate_value;
  for(var i = 0; i < x.length; i++){
      if(x[i].checked){
          var new_exclude = x[i].value;
      }
  }

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_excludes_jur_pso') + \"&data[new_exclude]=\" + encodeURIComponent(new_exclude) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hidden_f_page_add_new_excludes_jur_pso = 'hidden_f_page_add_new_excludes_jur_pso_' + screen;
var cont = document.getElementById(hidden_f_page_add_new_excludes_jur_pso);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #2E3436; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td style = \"background-color: black;\">
добавить
</td>
</tr>
<tr>
<td>
<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">





";

$sql = "select * from tab_steril_kit order by cast(name_short as unsigned) ASC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table align = \"center\" border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #2E3436; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{


$id = $row['id'];
$name_short = $row['name_short'];
$items = $row['items'];

$ar_items[$id]['name_short'] = $name_short;
$ar_items[$id]['items'] = $items;

echo "

<tr align = \"center\" height = \"30px\">
<td width = \"30px\">
<input class = \"class_radio_excludes_",$screen,"\" type = \"radio\" name = \"radio_excludes_",$screen,"\" value = \"",$name_short,"\">
</td>
<td>Набор №
",$name_short,"
</td>
</tr>
";

}

echo "</table>";

}

echo "
</div>
</td>
</tr>
<tr height = \"20%\" style = \"background-color: #008080; cursor: pointer;\">
<td onclick = \"add_new_excludes_jur_pso('",$screen,"');\" align = \"center\">
ОК
</td>
</tr>

</table>

<span id = \"hidden_f_page_add_new_excludes_jur_pso_",$screen,"\" style = \"display: none;\"></span>

";

}

?>
