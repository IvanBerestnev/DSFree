<?php

function open_page_add_write_jur_uf_control($vals)
{

#print_r($vals);

$screen = $vals['screen'];

echo "

<script>

function load_add_write_jur_uf_control(screen,step)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

if(step == 'step1')
{
var str_send = \"load_block=\" + encodeURIComponent('load_add_write_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[step]=\" + encodeURIComponent(step);
}
else if(step == 'step2')
{

var sel_uf_id_device = 'sel_uf_id_device_' + screen;
var e = document.getElementById(sel_uf_id_device);
var value = e.value;
var id_uf_device = e.options[e.selectedIndex].value;

var sel_usl_dezinf = 'sel_usl_dezinf_' + screen;
var e = document.getElementById(sel_usl_dezinf);
var value = e.value;
var usl_dezinf = e.options[e.selectedIndex].value;

var sel_obj_dezinf = 'sel_obj_dezinf_' + screen;
var e = document.getElementById(sel_obj_dezinf);
var value = e.value;
var obj_dezinf = e.options[e.selectedIndex].value;

var sel_vid_microb = 'sel_vid_microb_' + screen;
var e = document.getElementById(sel_vid_microb);
var value = e.value;
var vid_microb = e.options[e.selectedIndex].value;

var sel_exposure_mode = 'sel_exposure_mode_' + screen;
var e = document.getElementById(sel_exposure_mode);
var value = e.value;
var exposure_mode = e.options[e.selectedIndex].value;


var str_send = \"load_block=\" + encodeURIComponent('load_add_write_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[step]=\" + encodeURIComponent(step) + \"&data[id_uf_device]=\" + encodeURIComponent(id_uf_device) + \"&data[usl_dezinf]=\" + encodeURIComponent(usl_dezinf) + \"&data[obj_dezinf]=\" + encodeURIComponent(obj_dezinf) + \"&data[vid_microb]=\" + encodeURIComponent(vid_microb) + \"&data[exposure_mode]=\" + encodeURIComponent(exposure_mode);
}
else if(step == 'step3')
{

var f_id_uf_device = 'f_id_uf_device_' + screen;
var id_uf_device = document.getElementById(f_id_uf_device).innerHTML;

var f_usl_dezinf = 'f_usl_dezinf_' + screen;
var usl_dezinf = document.getElementById(f_usl_dezinf).innerHTML;

var f_obj_dezinf = 'f_obj_dezinf_' + screen;
var obj_dezinf = document.getElementById(f_obj_dezinf).innerHTML;

var f_vid_microb = 'f_vid_microb_' + screen;
var vid_microb = document.getElementById(f_vid_microb).innerHTML;

var f_exposure_mode = 'f_exposure_mode_' + screen;
var exposure_mode = document.getElementById(f_exposure_mode).innerHTML;



var sel_tbeg_jur_uf_control = 'sel_tbeg_jur_uf_control_' + screen;
var e = document.getElementById(sel_tbeg_jur_uf_control);
var value = e.value;
var tbeg_jur_uf_control = e.options[e.selectedIndex].value;


var sel_tend_jur_uf_control = 'sel_tend_jur_uf_control_' + screen;
var e = document.getElementById(sel_tend_jur_uf_control);
var value = e.value;
var tend_jur_uf_control = e.options[e.selectedIndex].value;



var str_send = \"load_block=\" + encodeURIComponent('load_add_write_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[step]=\" + encodeURIComponent(step) + \"&data[id_uf_device]=\" + encodeURIComponent(id_uf_device) + \"&data[usl_dezinf]=\" + encodeURIComponent(usl_dezinf) + \"&data[obj_dezinf]=\" + encodeURIComponent(obj_dezinf) + \"&data[vid_microb]=\" + encodeURIComponent(vid_microb) + \"&data[exposure_mode]=\" + encodeURIComponent(exposure_mode) + \"&data[tbeg_jur_uf_control]=\" + encodeURIComponent(tbeg_jur_uf_control) + \"&data[tend_jur_uf_control]=\" + encodeURIComponent(tend_jur_uf_control);
}
else if(step == 'step4')
{


//Получение выбранных дней
var days_calendar_uf_control = 'days_calendar_uf_control_' + screen;
var clist=document.getElementsByClassName(days_calendar_uf_control);
var arr = [];

for (var i = 0; i < clist.length; ++i)
{
if (clist[i].checked)
{
var selected_chbox = clist[i].value;
arr.push(selected_chbox);
}
}

var days= arr.join('#');
//alert(days);

//Получение месяца и года
var sel_month_jur_uf_control = 'sel_month_jur_uf_control_' + screen;
var e = document.getElementById(sel_month_jur_uf_control);
var value = e.value;
var month_jur_uf_control = e.options[e.selectedIndex].value;

var sel_year_jur_uf_control = 'sel_year_jur_uf_control_' + screen;
var e = document.getElementById(sel_year_jur_uf_control);
var value = e.value;
var year_jur_uf_control = e.options[e.selectedIndex].value;

//Получение остального

var f_id_uf_device = 'f_id_uf_device_' + screen;
var id_uf_device = document.getElementById(f_id_uf_device).innerHTML;

var f_usl_dezinf = 'f_usl_dezinf_' + screen;
var usl_dezinf = document.getElementById(f_usl_dezinf).innerHTML;

var f_obj_dezinf = 'f_obj_dezinf_' + screen;
var obj_dezinf = document.getElementById(f_obj_dezinf).innerHTML;

var f_vid_microb = 'f_vid_microb_' + screen;
var vid_microb = document.getElementById(f_vid_microb).innerHTML;

var f_exposure_mode = 'f_exposure_mode_' + screen;
var exposure_mode = document.getElementById(f_exposure_mode).innerHTML;

var f_tbeg_jur_uf_control = 'f_tbeg_jur_uf_control_' + screen;
var tbeg_jur_uf_control = document.getElementById(f_tbeg_jur_uf_control).innerHTML;

var f_tend_jur_uf_control = 'f_tend_jur_uf_control_' + screen;
var tend_jur_uf_control = document.getElementById(f_tend_jur_uf_control).innerHTML;


var str_send = \"act=\" + encodeURIComponent('add_write_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[step]=\" + encodeURIComponent(step) + \"&data[id_uf_device]=\" + encodeURIComponent(id_uf_device) + \"&data[usl_dezinf]=\" + encodeURIComponent(usl_dezinf) + \"&data[obj_dezinf]=\" + encodeURIComponent(obj_dezinf) + \"&data[vid_microb]=\" + encodeURIComponent(vid_microb) + \"&data[exposure_mode]=\" + encodeURIComponent(exposure_mode) + \"&data[tbeg_jur_uf_control]=\" + encodeURIComponent(tbeg_jur_uf_control) + \"&data[tend_jur_uf_control]=\" + encodeURIComponent(tend_jur_uf_control) + \"&data[days]=\" + encodeURIComponent(days) + \"&data[month_jur_uf_control]=\" + encodeURIComponent(month_jur_uf_control) + \"&data[year_jur_uf_control]=\" + encodeURIComponent(year_jur_uf_control);


}


xmlhttp.send(str_send);

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

if(step == 'step4')
{
var hidden_add_write_jur_uf_control = 'hidden_add_write_jur_uf_control_' + screen;

var cont = document.getElementById(hidden_add_write_jur_uf_control);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
else{

var f_page_add_write_jur_uf_control = 'f_page_add_write_jur_uf_control_' + screen;
var cont = document.getElementById(f_page_add_write_jur_uf_control);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}



}
}
}


}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td align = \"left\" style = \"background-color: black; color:white; font-weight: bold;\" align = \"center\">
добавить запись

</td>
</tr>

<tr>

<td>

<div id = \"f_page_add_write_jur_uf_control_",$screen,"\" style = \"width: 100%; height: 100%;\">
</div>

</td>

</tr>

</table>

<span id = \"hidden_add_write_jur_uf_control_",$screen,"\" style = \"display: ;\"></span>

<script>
load_add_write_jur_uf_control('",$screen,"','step1');
</script>

";

}

?>
