<?php

function sp_clients($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_pac = $vals['param'];


echo "

<script>

function load_sp_clients(screen,surname,sex,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sp_clients') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[surname]=\" + encodeURIComponent(surname) + \"&data[sex]=\" + encodeURIComponent(sex) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_sp_clients = 'f_sp_clients_' + screen;

var cont = document.getElementById(f_sp_clients);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function open_modal_load_sp_clients(name_page,id_pac,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_modal_load_sp_clients') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


if(name_page == 'info_pac')
{
var x = '55%';
var y = '75%';
}
else if(name_page == 'page_del_client')
{

var x = '45%';
var y = '35%';

}

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = x;
document.getElementById(modal).style.height = y;

var cont = document.getElementById(modal);

cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}

function act_sp_clients(name_act,id_pac,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_sp_clients') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_act]=\" + encodeURIComponent(name_act) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

if(name_act == 'act_del_client')
{

var hidden_page_del_client = 'hidden_page_del_client_' + screen;
var cont = document.getElementById(hidden_page_del_client);
}

if(name_act == 'add_new_client')
{

var hidden_sp_clients = 'hidden_sp_clients_' + screen;
var cont = document.getElementById(hidden_sp_clients);
}



cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function erase_inp_search_bysurname(screen)
{

var id_inp_sp_clients_search_pac_by_surname = 'id_inp_sp_clients_search_pac_by_surname_' + screen;
document.getElementById(id_inp_sp_clients_search_pac_by_surname).value = '';
}

</script>



<style>

.inp_sp_clients_search_pac_by_surname_",$screen,"{
width: 85%;
height: 70%;
 background: transparent;
 border: none;
    border-bottom: 1px solid grey;
color: white;
font-size: 18px;
font-weight: bold;
}

.inp_sp_clients_search_pac_by_surname_",$screen,":focus{
outline:none;

}

.inp_sp_clients_search_pac_by_surname_",$screen,"::-webkit-input-placeholder {font-size:15px;}

select:focus{
outline:none;

}


.td_self_load_sp_clients_",$screen,":hover{

background-color: grey;

}


</style>



<span id = \"main_loaded_page_sp_clients\"></span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #242424; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"3%\">
<td align = \"center\" style = \"background-color: black; color: white; font-weight: bold;\">
Список клиентов

<span onclick=\"trunc_screen('",$screen,"');\" class=\"but_trunc_screen\">X</span>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #242424; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\">
</td>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #242424; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\" style = \"background-color: #22272B;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"20%\">

<div style=\"background-color: #008080; cursor: pointer; height: 75%; width: 75%; display: table; text-align: center;\">
<span onclick = \"act_sp_clients('add_new_client','','",$screen,"');\" style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">+</span>
</div>

</td>
<td align = \"center\">

<input id = \"id_inp_sp_clients_search_pac_by_surname_",$screen,"\" onkeyup = \"load_sp_clients('",$screen,"',this.value,'','');\" class = \"inp_sp_clients_search_pac_by_surname_",$screen,"\" placeholder = \"поиск по фамилии\">

</td>
<td width = \"20%\" align = \"center\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #242424; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"50%\">

<div style=\"background-color: #FF8080; cursor: pointer; height: 55%; width: 55%; display: table; text-align: center;\">
<span onclick=\"load_sp_clients('",$screen,"','','',''); erase_inp_search_bysurname('",$screen,"');\" style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">х</span>
</div>

</td>
<td>

<select disabled>
<option value = \"\">пол</option>
<option value = \"m\">муж</option>
<option value = \"w\">жен</option>
</select>

</td>
</tr>
</table>



</td>
</tr>
</table>


</td>
</tr>
<tr>
<td>

<div id = \"f_sp_clients_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2E3436;\">
</div>


</td>
</tr>
</table>


</td>
<td width = \"25%\">
</td>
</tr>
</table>

</td>
</tr>
</table>

<span style = \"display: none;\" id = \"hidden_sp_clients_",$screen,"\"></span>

<script>
load_sp_clients('",$screen,"','','','",$id_pac,"');
</script>

";


}


?>
