<?php

function open_page_other_lica_dogovor_pmu($vals)
{

$id_pac = $vals['id_pac'];
$screen = $vals['screen'];
$id_dog = $vals['id_dog'];
$mode = $vals['mode'];

echo "

<script>

function load_other_lica_dogovor_pmu(id_pac,screen,id_dog,mode)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_other_lica_dogovor_pmu') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_dog]=\" + encodeURIComponent(id_dog) + \"&data[mode]=\" + encodeURIComponent(mode));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_open_page_other_lica_dogovor_pmu = 'f_open_page_other_lica_dogovor_pmu_' + screen;

var cont = document.getElementById(f_open_page_other_lica_dogovor_pmu);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function act_add_otherlico_pre_dogovor_pmu(id_pac,id_other_lico,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_otherlico_pre_dogovor_pmu') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[id_other_lico]=\" + encodeURIComponent(id_other_lico) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_chousen_self = 'f_chousen_self_' + '",$screen,"';
document.getElementById(f_chousen_self).style.display = 'none';

var f_chousen_other_lico = 'f_chousen_other_lico_' + '",$screen,"';
document.getElementById(f_chousen_other_lico).style.display = 'block';


var cont = document.getElementById(f_chousen_other_lico);
cont.innerHTML = xmlhttp.responseText;

//изменить скрытый див на кто будет платить
change_val_selected_whopaid_dog_pmu('",$screen,"',id_other_lico);


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function reset_who_paid(screen)
{

var f_chousen_self = 'f_chousen_self_' + screen;
document.getElementById(f_chousen_self).style.display = 'block';

var f_chousen_other_lico = 'f_chousen_other_lico_' + screen;
document.getElementById(f_chousen_other_lico).style.display = 'none';

}




</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td>

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #22272B; color: white;\">
<td width = \"50%\" >
Выберете 3-е лицо пациента
</td>
<td>
<input style = \"width: 80%; height: 50%;\" placeholder = \"поиск по фамилии\">
</td>
</tr>
</table>

</td>
</tr>

<tr style = \"background-color: #222222; color: white;\">
<td>
<div id = \"f_open_page_other_lica_dogovor_pmu_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">
</div>
</td>
</tr>



</table>

<div id = \"f_hidden_open_page_other_lica_dogovor_pmu_",$screen,"\" style = \"display: none;\"></div>

<script>

load_other_lica_dogovor_pmu('",$id_pac,"','",$screen,"','",$id_dog,"','",$mode,"');

</script>

";




}

?>
