<?php

function page_add_ids($vals)
{

#print_r($vals);

$screen = $vals['screen'];


$ar_all_types = array("general"=>"Общий раздел","terap"=>"Терапевтическая стоматология","ortoped"=>"Ортопедическая стоматология","chirurg"=>"Хирургическая стоматология","ortodont"=>"Ортодонтия","detstvo"=>"Детская стоматология");


echo "

<script>

function act_add_new_ids(screen)
{

var id_sel_all_types_ids = 'id_sel_all_types_ids_' + screen;
var sel = document.getElementById(id_sel_all_types_ids);
var value_sel_type= sel.options[sel.selectedIndex].value;

var id_name_file_new_ids = 'id_name_file_new_ids_' + screen;
var name_file_new_ids = document.getElementById(id_name_file_new_ids).value;

var id_name_new_ids = 'id_name_new_ids_' + screen;
var name_new_ids = document.getElementById(id_name_new_ids).value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_new_ids') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[new_type]=\" + encodeURIComponent(value_sel_type) + \"&data[name_file_new_ids]=\" + encodeURIComponent(name_file_new_ids) + \"&data[name_new_ids]=\" + encodeURIComponent(name_new_ids));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


load_ids_edit_self(screen,value_sel_type);
var fon_modal = 'fon_modal_' + screen;
close_mw(fon_modal);

}
}
}

}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3336; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td colspan = \"2\">
Новый ИДС
</td>
</tr>
<tr height = \"15%\">
<td width = \"50%\">
<select id = \"id_sel_all_types_ids_",$screen,"\" style = \"height: 80%; width: 80%; text-align: center;\">
<option value = \"\" disabled selected>раздел ИДС</option>";

Foreach($ar_all_types as $name=>$rname)
{

echo "
<option value = \"",$name,"\">",$rname,"</option>
";

}

echo "
</select>
</td>
<td >
<input id = \"id_name_file_new_ids_",$screen,"\" placeholder = \"имя файла\" style = \"height: 80%; width: 80%;\">
</td>
</tr>
<tr height = \"20%\">
<td colspan = \"2\">
<input id = \"id_name_new_ids_",$screen,"\" placeholder = \"название ИДС\" style = \"height: 80%; width: 80%;\">
</td>
</tr>
<tr>
<td colspan = \"2\">
поместите документ в папку /var/www/html/dsfree.ru/components/download
</td>
</tr>
<tr height = \"20%\">
<td onclick = \"act_add_new_ids('",$screen,"');\" colspan = \"2\" style = \"background-color: #008080; cursor: pointer;\">
добавить
</td>
</tr>
</table>

";

}


?>
