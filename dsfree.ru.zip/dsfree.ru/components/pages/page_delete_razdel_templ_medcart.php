<?php

function page_delete_razdel_templ_medcart($vals)
{

#print_r($vals);

$id_ds_income = $vals['id_ds_income'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];
$id_razd = $vals['id_razd'];
$screen = $vals['screen'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #3A3A3A; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
<b style = \"color: #FF8080;\">Внимание</b>

<br><br>

Вы действительно хотите удалить данный раздел? <br>
Учтите, что его удаление повлечет за собой удаление цепочки связанных с ним шаблонов.
<br>
<br>
Продолжить?

</td>
</tr>
<tr height = \"20%\" align = \"center\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" style = \"background-color: #FF8080; \" width = \"50%\">
нет
</td>
<td onclick = \"act_delete_razdel_templ_medcart('",$screen,"','",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"','",$id_razd,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>

</table>
";

}

?>
