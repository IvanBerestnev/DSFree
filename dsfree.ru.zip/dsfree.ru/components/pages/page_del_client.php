<?php

function page_del_client($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_pac = $vals['id_pac'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #555753; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
Внимание.<br><br>Удаление пациента повлечет за собой удаление о нем всех записей, в том числе и медицинских.<br>
Пожалуйста, убедитесь, что вся информация была распечатана и больше не требуется хранить ее в программе.
<br>
<br>
Продолжить?
</td>
</tr>
<tr align = \"center\" height = \"20%\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" style = \"background-color: #FF8080;\" width = \"50%\">
нет
</td>
<td onclick = \"act_sp_clients('act_del_client','",$id_pac,"','",$screen,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
<span style = \"display: none;\" id = \"hidden_page_del_client_",$screen,"\"></span>
";


}


?>
