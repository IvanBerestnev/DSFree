<?php

function jur_steril($vals)
{

#print_r($vals);
#$x = $va
$screen = $vals['screen'];

echo "

<script>

function load_jur_steril(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_jur_steril') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_jur_steril = 'f_jur_steril_' + screen;

var cont = document.getElementById(f_jur_steril);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

function page_add_new_steril(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_add_new_steril') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '60%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function page_print_jur_steril(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_print_jur_steril') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '35%';
document.getElementById(modal).style.height = '30%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function print_jur_steril(screen)
{

//var id_form_print_medcart_id_visit = 'id_form_print_medcart_id_visit_' + screen;
//document.getElementById(id_form_print_medcart_id_visit).value = id_visit;

//var id_form_print_medcart_locat_ds = 'id_form_print_medcart_locat_ds_' + screen;
//document.getElementById(id_form_print_medcart_locat_ds).value = locat_ds;

var form_print_jur_steril = 'form_print_jur_steril_' + screen;
document.getElementById(form_print_jur_steril).submit();

}

</script>

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: grey;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"4%\">
<td style = \"background-color: black; color:white; font-weight: bold;\" align = \"center\">
Журнал стерилизации

<span onclick = \"trunc_screen('",$screen,"');\" class = \"but_trunc_screen\">X</span>

<span onclick = \"open_settings_screen('jurnal_steril','",$screen,"');\" style = \"cursor: pointer; padding-left: 20px; padding-right: 20px; float: right; margin-right: 10px; border-radius: 15px; background-color: blue;\">&#9881;</span>

</td>
</tr>

<tr height = \"8%\" style = \"background-color: #3A3A3A; color: white; font-weight: bold;\">
<td align = \"right\">

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr >
<td align = \"center\">

отображать последние 

<select>
<option>30</option>
<option>60</option>
<option>90</option>
</select>

записей

</td>
<td align = \"right\">

<span onclick = \"page_print_jur_steril('",$screen,"');\" style = \"background-color: #1A5FB4; font-weight: bold; padding-left: 10px; padding-right: 10px; margin-right: 10px; cursor: pointer;\">
Печать
</span>

</td>
</tr>
</table>



</td>
</tr>

<tr height = \"8%\" style = \"background-color: #8A969C; color: white; font-weight: bold; border-bottom: 1px solid #3A3A3A;\">
<td align = \"center\">

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #8A969C; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>

<td width = \"40px\">

</td>

<td>
дата
</td>
<td>
стерилизатор
</td>
<td>
наименование
</td>
<td>
кол-во
</td>
<td>
упаковка
</td>
<td>
начало стер
</td>
<td>
конец стер
</td>
<td>
давление
</td>
<td>
температура
</td>

<td width = \"11px\">

</td>

</tr>


</table>


</td>
</tr>

<tr>
<td style = \"\">

<div id = \"f_jur_steril_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; scrollbar-width: thin;\">
</div>


</td>
</tr>

<tr onclick = \"page_add_new_steril('",$screen,"');\" height = \"5%\" style = \"background-color: #008080; color: white; font-weight: bold; cursor: pointer;\">
<td align = \"center\">

Добавить запись

</td>
</tr>

</table>

<form id = \"form_print_jur_steril_",$screen,"\" action = \"../handle/handle.html\" method = \"post\" target=\"_self\" style = \"display: none;\">
<input type = \"hidden\" name = \"act\" value = \"print_jur_steril\">
<input type = \"hidden\" id = \"id_form_print_jur_steril_date_begin_",$screen,"\" name = \"data[date_begin]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_jur_steril_date_end_",$screen,"\" name = \"data[date_end]\" value = \"\">
</form>

<script>
load_jur_steril('",$screen,"');
</script>

";

}

?>
