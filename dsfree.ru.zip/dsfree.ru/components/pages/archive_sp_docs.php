<?php

function archive_sp_docs($vals)
{

$screen = $vals['screen'];

echo "

<script>

function load_archive_sp_docs(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_archive_sp_docs') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_archive_sp_docs = 'f_archive_sp_docs_' + screen;

var cont = document.getElementById(f_archive_sp_docs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

function act_restore_doc(id_pers,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_restore_doc') + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_archive_sp_docs = 'f_archive_sp_docs_' + screen;

var cont = document.getElementById(f_archive_sp_docs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"3%\" style = \"background-color: black; color: white; font-weight: bold; text-align: center; cursor: default;\">
<td>
Архивный список врачей

<span onclick = \"trunc_screen('",$screen,"');\" class = \"but_trunc_screen\">X</span>

</td>
</tr>

<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"30%\" style = \"background-color: #22272B\">
</td>
<td>

<div id = \"f_archive_sp_docs_",$screen,"\" style = \"height: 100%; width: 100%; overflow-y: scroll; \"></div>

</td>
<td width = \"30%\" style = \"background-color: #22272B\"> 
</td>
</tr>
</table>

</td>
</tr>

</table>

<div id=\"fon_modal_",$screen,"\" style=\"display: none; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); inset: 0px; margin: auto; position: absolute; z-index: 2000;\">
<div id=\"modal_",$screen,"\" style=\"display: block; width: 60%; height: 50%; position: absolute; inset: 0px; margin: auto; background: white; transition: all 1s ease 0s; animation: 0.3s ease 0s 1 normal forwards running show;\">

</div>
</div>

<script>
load_archive_sp_docs('",$screen,"');
</script>


";


}

?>
