<?php

function page_rename_ids_file($vals)
{

$screen = $vals['screen'];
$type = $vals['type'];
$id = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_ids where id = '$id'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$name_file = $row['name_file'];

}


echo "

<script>

function act_rename_ids_file(screen,id,type)
{

var inp_rename_ids_file = 'inp_rename_ids_file_' + screen;
var new_name_file = document.getElementById(inp_rename_ids_file).value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_rename_ids_file') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id]=\" + encodeURIComponent(id) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[new_name_file]=\" + encodeURIComponent(new_name_file));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var hidden_page_rename_ids_file = 'hidden_page_rename_ids_file_' + screen;

var cont = document.getElementById(hidden_page_rename_ids_file);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3336; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"25%\">
<td>
Новое название файла ИДС
</td>
</tr>
<tr>
<td>
<input id = \"inp_rename_ids_file_",$screen,"\" style = \"width: 80%; height: 35%;\" value = \"",$name_file,"\">
</td>
</tr>
<tr onclick = \"act_rename_ids_file('",$screen,"','",$id,"','",$type,"');\" height = \"25%\" style = \"background-color: #008080;\">
<td>
Сохранить
</td>
</tr>
</table>
<div style = \"display: none;\" id = \"hidden_page_rename_ids_file_",$screen,"\"></div>
";


}


?>
