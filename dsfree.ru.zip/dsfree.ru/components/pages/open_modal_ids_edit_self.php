<?php

function open_modal_ids_edit_self($vals)
{

$name_page = $vals['name_page'];

If($name_page == "page_add_ids")
{
include_once("page_add_ids.php");
page_add_ids($vals);
}
ElseIf($name_page == "page_rename_ids")
{
include_once("page_rename_ids.php");
page_rename_ids($vals);
}
ElseIf($name_page == "page_rename_ids_file")
{
include_once("page_rename_ids_file.php");
page_rename_ids_file($vals);
}
ElseIf($name_page == "page_delete_ids")
{
include_once("page_delete_ids.php");
page_delete_ids($vals);
}
ElseIf($name_page == "page_change_status_ids")
{
include_once("page_change_status_ids.php");
page_change_status_ids($vals);
}





}


?>
