<?php

function edit_medcart_templ_razdel_self($vals)
{

#print_r($vals);

$id_ds_income = $vals['id_ds'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];
$id_razd = $vals['id_razd'];
$screen = $vals['screen'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];

#echo $text;die();

#$json = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_decoded = json_decode($text,true);

$name_razdel = $ar_decoded[$id_ds_income][$id_str_templ]['cont'][$id_razd]['name'];

}




echo "

<script>

function load_medcart_templ_razdel_self(screen,id_ds,id_str_templ,id_tm,id_razd)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_medcart_templ_razdel_self') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_razd]=\" + encodeURIComponent(id_razd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_medcart_templ_razdel_self = 'f_load_medcart_templ_razdel_self_' + screen;

var cont = document.getElementById(f_load_medcart_templ_razdel_self);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function act_add_new_temple_to_razdel_medcart(screen,id_ds,id_str_templ,id_tm,id_razd)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_new_temple_to_razdel_medcart') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_razd]=\" + encodeURIComponent(id_razd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_medcart_templ_razdel_self = 'f_load_medcart_templ_razdel_self_' + screen;

var cont = document.getElementById(f_load_medcart_templ_razdel_self);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


function edit_temple_medcart_self_only_text(text,id_tm,id_ds_income,id_razd,id_str_templ,id_shabl,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('edit_temple_medcart_self_text') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_razd]=\" + encodeURIComponent(id_razd) + \"&data[id_shabl]=\" + encodeURIComponent(id_shabl) + \"&data[text]=\" + encodeURIComponent(text));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



}
}
}


}

function page_delete_temple_medcart_self_only_text(id_tm,id_ds_income,id_razd,id_str_templ,id_shabl,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_delete_temple_medcart_self_only_text') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_razd]=\" + encodeURIComponent(id_razd) + \"&data[id_shabl]=\" + encodeURIComponent(id_shabl));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '35%';
document.getElementById(modal_first).style.height = '10%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function act_delete_temple_medcart_self_only_text(id_tm,id_ds_income,id_razd,id_str_templ,id_shabl,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_temple_medcart_self_only_text') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds_income]=\" + encodeURIComponent(id_ds_income) + \"&data[id_str_templ]=\" + encodeURIComponent(id_str_templ) + \"&data[id_tm]=\" + encodeURIComponent(id_tm) + \"&data[id_razd]=\" + encodeURIComponent(id_razd) + \"&data[id_shabl]=\" + encodeURIComponent(id_shabl));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '35%';
document.getElementById(modal_first).style.height = '10%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}



</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td style = \"background-color: #22272B;\" align = \"left\">
Раздел \"",$name_razdel,"\"
</td>
</tr>
<tr style = \"background-color: #2E3336;\">
<td>
<div id = \"f_load_medcart_templ_razdel_self_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">
</div>
</td>
</tr>
<tr onclick = \"act_add_new_temple_to_razdel_medcart('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"','",$id_razd,"');\" height = \"10%\" style = \"background-color: #008080; cursor: pointer;\">
<td>
Добавить шаблон
</td>
</tr>
</table>
<script>
load_medcart_templ_razdel_self('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"','",$id_razd,"');
</script>


";

}

?>
