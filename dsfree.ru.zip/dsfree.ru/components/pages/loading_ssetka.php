<?php

function loading_ssetka($vals)
{

#print_r($vals);


If(isset($_COOKIE['dsf_cookie']))
{
$cookie = $_COOKIE['dsf_cookie'];	
}
Else{

echo "<script>exit_dsfree();</script>";



}

#$id_used_ssetka = $vals['id_used_ssetka'];

$date_now = date("d-m-Y");

#echo $date_now;

#$id_used_ssetka = "aea8977411ea821c8539246aa6ccdda8";
$id_used_ssetka = $vals['id_used_ssetka'];

include_once("../components/functions/get_tab_ssetka_default.php");
$ar_ssetka_default = get_tab_ssetka_default($id_used_ssetka);

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


include_once("../components/pages/page_default_ssetka.php");
include_once("../components/pages/jurnal_pacs.php");
include_once("../components/pages/mass_doc_shed.php");
include_once("../components/pages/sp_docs.php");


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_users where id_user = (select id_user from auths where id_cookie = '$cookie')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$level = $row['level'];
$id_pers = $row['id_user'];
}


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_used_ssetka where id_used_ssetka = '$id_used_ssetka'";

#echo $sql;die();

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['vals'];
$arr = json_decode($json_arr,true);

#print_r($arr);

$key = key($arr);

}
Else{

die();

}



#print_r($arr);die();

echo "
<style>
input{
text-align: center;
}
</style>
";

If($key == "simple")
{

$a = $arr['simple']['padding']['a'];
$b = $arr['simple']['padding']['b'];
$cr = $arr['simple']['padding']['c'];
$d = $arr['simple']['padding']['d'];


$rows = $arr['simple']['params']['rows'];
$cols = $arr['simple']['params']['cols'];
$spacex = $arr['simple']['params']['spacex'];
$spacey = $arr['simple']['params']['spacey'];

$c_height = 100/$rows;
#echo $c_height;


echo "

<script>





function load_ctrl_jurpacs(param,screen)
{

//alert('123');

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_ctrl_jurpacs') + \"&data[param]=\" + encodeURIComponent(param) + \"&data[id_used_ssetka]=\" + encodeURIComponent('",$id_used_ssetka,"') + \"&data[screen]=\" + encodeURIComponent(screen));


xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var load_ctrl_jurpacs = 'f_ctrl_jurpacs_'+param+'_'+screen;
var cont = document.getElementById(load_ctrl_jurpacs);
cont.innerHTML = xmlhttp.responseText;



var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}



function ctrl_jurpacs_doc_review(id_pers,screen,act)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('ctrl_jurpacs_doc_review') + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[act]=\" + encodeURIComponent(act));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

//load_jurpacs(screen);

var f_ctrl_jurpacs_doc = 'f_ctrl_jurpacs_doc_'+screen;
var cont = document.getElementById(f_ctrl_jurpacs_doc);

var return_review = xmlhttp.responseText;


if(return_review == 'bg')
{
//alert(return_review);

change_bg_choiced_pers(screen,id_pers);

return false;
}
else{

cont.innerHTML = xmlhttp.responseText;

}



var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


/////////контрольная панель выбора врача

function ctrl_jurpacs_spdocs_review(id_used_ssetka,id_pers,screen,act)
{


if(act == 'tochoice')
{

var f_ctrl_id_pers = 'f_ctrl_id_pers_' + screen;
document.getElementById(f_ctrl_id_pers).innerHTML = id_pers;
load_jurpacs(screen);

}
else if(act == 'close')
{

var f_ctrl_id_pers = 'f_ctrl_id_pers_' + screen;
document.getElementById(f_ctrl_id_pers).innerHTML = 'all';
load_jurpacs(screen);

}




var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('ctrl_jurpacs_spdocs_review') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[act]=\" + encodeURIComponent(act) + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var f_ctrl_jurpacs_doc = 'f_ctrl_jurpacs_doc_'+screen;
var cont = document.getElementById(f_ctrl_jurpacs_doc);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}



}


//////////

function load_jurpacs(screen)
{



var sel_dunit  = 'sel_dunit_' + screen;
var selector_dunit = document.getElementById(sel_dunit);

if(selector_dunit)
{
var dunit = selector_dunit[selector_dunit.selectedIndex].value;

}
else{
var span_dunit = 'span_dunit_' + screen;
var dunit_obj = document.getElementById(span_dunit);

if(dunit_obj)
{
var dunit = document.getElementById(span_dunit).innerHTML;
}
else{
var dunit = '';
}

}


var sel_c_days  = 'sel_c_days_' + screen;
var selector_c_days = document.getElementById(sel_c_days);

if(selector_c_days)
{
var c_days = selector_c_days[selector_c_days.selectedIndex].value;
}
else{
var span_c_days = 'span_c_days_' + screen;
var span_c_days_obj = document.getElementById(span_c_days);

if(span_c_days_obj)
{
var c_days = document.getElementById(span_c_days).innerHTML;
}
else{
var c_days = '';
}

}


var f_dir_date = 'f_dir_date_'+screen;
var date = document.getElementById(f_dir_date).innerHTML;


var f_ctrl_id_pers = 'f_ctrl_id_pers_' + screen;
var id_pers_obj = document.getElementById(f_ctrl_id_pers);

if(id_pers_obj)
{
var id_pers = document.getElementById(f_ctrl_id_pers).innerHTML;

if(id_pers == '')
{
id_pers = 'all';
}

}
else{
var id_pers = '';
//alert(id_pers);
}



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

var str = \"load_block=\" + encodeURIComponent('load_jurpacs') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_used_ssetka]=\" + encodeURIComponent('",$id_used_ssetka,"') + \"&data[dunit]=\" + encodeURIComponent(dunit) + \"&data[c_days]=\" + encodeURIComponent(c_days) + \"&data[date]=\" + encodeURIComponent(date) + \"&data[id_pers]=\" + encodeURIComponent(id_pers);

//alert(str);

xmlhttp.send(str);

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var id_f_self_jurpacs = 'id_f_self_jurpacs_' + screen;
var cont = document.getElementById(id_f_self_jurpacs);
cont.innerHTML = xmlhttp.responseText;


//попытка замены цвета при перемещении

var id_screen_cell_jurpac_selected_id = 'id_' + screen + '_cell_jurpac_selected_id';
var id_screen_cell_jurpac_selected_color = 'id_' + screen + '_cell_jurpac_selected_color';

var cell_selected_id = document.getElementById(id_screen_cell_jurpac_selected_id).innerHTML;
var cell_selected_returned_color = document.getElementById(id_screen_cell_jurpac_selected_color).innerHTML;

if(cell_selected_id !== '')
{

var areaOption = document.getElementById(cell_selected_id);
if(areaOption)
{
// element exists
document.getElementById(cell_selected_id).style.backgroundColor = cell_selected_returned_color;
document.getElementById(cell_selected_id).style.textDecoration = 'underline';
document.getElementById(cell_selected_id).style.border = '1px dashed white';

}
else
{
// element doesn't exist


}




}


//


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}




}

//движок по дате

function get_data(direct,screen)
{

var f_dir_date = 'f_dir_date_'+screen;
var dir_date = document.getElementById(f_dir_date).innerHTML;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('get_data') + \"&data[direct]=\" + encodeURIComponent(direct) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[dir_date]=\" + encodeURIComponent(dir_date));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var cont = document.getElementById(f_dir_date);
cont.innerHTML = xmlhttp.responseText;

//alert(cont.innerHTML);

var return_date = cont.innerHTML;

load_jurpacs(screen);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function close_choice_pers(screen)
{

var f_ctrl_id_pers = 'f_ctrl_id_pers_' + screen;
var f_ctrl_id_pers_obj = document.getElementById(f_ctrl_id_pers);

if(f_ctrl_id_pers_obj)
{
document.getElementById(f_ctrl_id_pers).innerHTML = '';
}

load_ctrl_jurpacs('doc',screen);
load_jurpacs(screen);

}




function change_bg_choiced_pers(screen,id_pers)
{

//alert('333');

var class_ctrl_doc = 'class_ctrl_doc_' + screen;

const collection = document.getElementsByClassName(class_ctrl_doc);
for (let i = 0; i < collection.length; i++) {
  collection[i].style.backgroundColor = '#2E3436';
}

id_bg_doc = 'id_ctrl_doc_' + screen + '_' + id_pers;
document.getElementById(id_bg_doc).style.backgroundColor = 'blue';

var f_ctrl_id_pers = 'f_ctrl_id_pers_' + screen;
var f_ctrl_id_pers_obj = document.getElementById(f_ctrl_id_pers);

if(f_ctrl_id_pers_obj)
{
document.getElementById(f_ctrl_id_pers).innerHTML = id_pers;
}

load_jurpacs(screen);

}


function load_calendar_jurpacs(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


var f_dir_date = 'f_dir_date_' + screen;
var dir_date = document.getElementById(f_dir_date).innerHTML;

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_calendar_jurpacs') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[date]=\" + encodeURIComponent(dir_date));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
var modal = 'modal_' + screen;

document.getElementById(fon_modal).style.display = 'block';
document.getElementById(modal).style.width = '300px';
document.getElementById(modal).style.height = '300px';


var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function calendar_choice_data_self(screen)
{



var choice_data_jurpacs_sel_year = 'choice_data_jurpacs_sel_year_' + screen;
var selector_year = document.getElementById(choice_data_jurpacs_sel_year);
var year = selector_year[selector_year.selectedIndex].value;

var choice_data_jurpacs_sel_month = 'choice_data_jurpacs_sel_month_' + screen;
var selector_month = document.getElementById(choice_data_jurpacs_sel_month);
var month = selector_month[selector_month.selectedIndex].value;



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('calendar_choice_data_self') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[year]=\" + encodeURIComponent(year) + \"&data[month]=\" + encodeURIComponent(month));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_cal_choice_data_self = 'f_cal_choice_data_self_' + screen;

var cont = document.getElementById(f_cal_choice_data_self);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function send_date_from_cal_to_jurpacs(date,screen)
{

var f_dir_date = 'f_dir_date_'+screen;
document.getElementById(f_dir_date).innerHTML = date;

var fon_modal = 'fon_modal_' + screen;

document.getElementById(fon_modal).style.display = 'none';

load_jurpacs(screen);




}


function change_color_cell_jurpac(id_cell,type,screen,color,id_doc,unit,id_shedule)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('change_color_cell_jurpac') + \"&data[color]=\" + encodeURIComponent(color));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var class_jurpac_cell = 'class_jurpac_cell_' + screen;
var theOddOnes = document.getElementsByClassName(class_jurpac_cell);

for(var i=0; i<theOddOnes.length; i++)
{
//alert(theOddOnes[i].innerHTML);

var id_showed = theOddOnes[i].id;

var id_cell_jp_old = id_showed + '_old';
var old_color = document.getElementById(id_cell_jp_old).innerHTML;
document.getElementById(id_showed).style.backgroundColor = old_color;
document.getElementById(id_showed).style.textDecoration = 'none';
document.getElementById(id_showed).style.border = '0px';
}

var color_returned = xmlhttp.responseText;
document.getElementById(id_cell).style.backgroundColor = color_returned;
document.getElementById(id_cell).style.textDecoration = 'underline';
document.getElementById(id_cell).style.border = '1px dashed white';

var id_screen_cell_jurpac_selected_id = 'id_' + screen + '_cell_jurpac_selected_id';
var id_screen_cell_jurpac_selected_color = 'id_' + screen + '_cell_jurpac_selected_color';

document.getElementById(id_screen_cell_jurpac_selected_id).innerHTML = id_cell;
document.getElementById(id_screen_cell_jurpac_selected_color).innerHTML = color_returned;


show_jurpac_bottom_menu(type,screen,id_cell,id_doc,unit,id_shedule);


}
}
}



}



function show_jurpac_bottom_menu(type,screen,id_cell,id_doc,unit,id_shedule)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('show_jurpac_bottom_menu') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[id_cell]=\" + encodeURIComponent(id_cell) + \"&data[id_doc]=\" + encodeURIComponent(id_doc) + \"&data[unit]=\" + encodeURIComponent(unit) + \"&data[id_shedule]=\" + encodeURIComponent(id_shedule));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var jurpac_bottom_menu = 'jurpac_bottom_menu_' + screen;
var cont = document.getElementById(jurpac_bottom_menu);

cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

function reload_jurpacs_cell_colors(screen)
{

var class_jurpac_cell = 'class_jurpac_cell_' + screen;
var theOddOnes = document.getElementsByClassName(class_jurpac_cell);

for(var i=0; i<theOddOnes.length; i++)
{
//alert(theOddOnes[i].innerHTML);

var id_showed = theOddOnes[i].id;

var id_cell_jp_old = id_showed + '_old';
var old_color = document.getElementById(id_cell_jp_old).innerHTML;
document.getElementById(id_showed).style.backgroundColor = old_color;
document.getElementById(id_showed).style.textDecoration = 'none';
document.getElementById(id_showed).style.border = '0px';
}


var jurpac_bottom_menu = 'jurpac_bottom_menu_' + screen;
document.getElementById(jurpac_bottom_menu).innerHTML = '';


var id_screen_cell_jurpac_selected_id = 'id_' + screen + '_cell_jurpac_selected_id';
var id_screen_cell_jurpac_selected_color = 'id_' + screen + '_cell_jurpac_selected_color';

document.getElementById(id_screen_cell_jurpac_selected_id).innerHTML = '';
document.getElementById(id_screen_cell_jurpac_selected_color).innerHTML = '';


}


function sel_run_act_bottom_jp(act,screen,param)
{

if(act == 'primary_docums')
{
load_page_screen('primary_docums',screen,param);

}
else{

var fon_modal = 'fon_modal_' + screen;
var modal = 'modal_' + screen;

document.getElementById(fon_modal).style.display = 'block';

if(act == 'cancel_ent')
{
var w = '300px';
var h = '100px';
}
else if(act == 'write_pac_ent_into_shedule')
{
var w = '700px';
var h = '400px';
}
else if(act == 'write_doc_shed')
{
var w = '500px';
var h = '250px';
}
else if(act == 'change_doc_shed_times')
{
var w = '700px';
var h = '250px';
}
else if(act == 'correct_shed_time_doc')
{
var w = '700px';
var h = '250px';
}
else if(act == 'del_period_shed_time_doc')
{
var w = '450px';
var h = '150px';
}
else if(act == 'change_pac_jurpac')
{
var w = '800px';
var h = '450px';
}
else if(act == 'corr_time_ent_pac')
{
var w = '800px';
var h = '250px';
}
else if(act == 'info_pac')
{
var w = '800px';
var h = '450px';
}



document.getElementById(modal).style.width = w;
document.getElementById(modal).style.height = h;
document.getElementById(modal).innerHTML = '';

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('sel_run_act_bottom_jp') + \"&data[act]=\" + encodeURIComponent(act) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var id_sel_run_act_bottom_jp = 'id_sel_run_act_bottom_jp_' + screen;
document.getElementById(id_sel_run_act_bottom_jp).selectedIndex = 0;



var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

}


function load_availible_times_docs_shed(id_selected_pers,screen,param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_availible_times_docs_shed') + \"&data[id_selected_pers]=\" + encodeURIComponent(id_selected_pers) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_load_availible_times_docs_shed = 'f_load_availible_times_docs_shed_' + screen;
var cont = document.getElementById(f_load_availible_times_docs_shed);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


</script>

<style>

.ctrl_doc_line:hover{

border: 1px solid white;

}

.class_td_navigate:hover{

color: red;
background-color: #1A1A1A;

}

</style>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"",$a,"\">
<td colspan = \"3\" align = \"center\"></td>
<tr>
<td width = \"",$d,"\" align = \"center\"></td>
<td>
";

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; \" cellpadding=\"0\" cellspacing= \"0\">";

$x=1;

For($r=1;$r<=$rows;$r++)
{
echo "<tr>";



For($c=1;$c<=$cols;$c++)
{
echo "<td height = \"",$c_height,"%\" align = \"right\" style = \"background-color: grey; position: relative;\">
<div id=\"fon_modal_",$x,"\" style=\"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); top: 0; right: 0; bottom: 0; left: 0; margin: auto; position: absolute; z-index: 2000;\">
<div id=\"modal_",$x,"\" style=\"display: block; width: 100px; height: 100px; position: absolute; top: 0; right: 0; bottom: 0; left: 0; margin: auto; background: white; transition: 1s; animation: show 0.3s 1; animation-fill-mode: forwards;\"></div>
</div>

<div id=\"fon_modal_first_",$x,"\" style=\"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); top: 0; right: 0; bottom: 0; left: 0; margin: auto; position: absolute; z-index: 3000;\">
<div id=\"modal_first_",$x,"\" style=\"display: block; width: 100px; height: 100px; position: absolute; top: 0; right: 0; bottom: 0; left: 0; margin: auto; background: white; transition: 1s; animation: show 0.3s 1; animation-fill-mode: forwards;\">
</div>
</div>

";

If(isset($ar_ssetka_default[$x]))
{
$name_func = $ar_ssetka_default[$x];

If($name_func == "jurnal_pacs")
{
#$date_now = date("d-m-Y");
$belong = "y";
jurnal_pacs($x,$date_now,$belong);
}
ElseIf($name_func == "mass_doc_shed")
{
#$date_now = date("d-m-Y");
$vals['screen'] = $x;
$vals['belong'] = "y";
mass_doc_shed($vals);
}
ElseIf($name_func == "sp_docs")
{
#$date_now = date("d-m-Y");
$vals['screen'] = $x;
$vals['belong'] = "y";
sp_docs($vals);
}

}
Else{
//default страница
page_default_ssetka($x);
}


echo "</td>";


If($spacey !== "0")
{
If($c < $cols)
{
echo "<td width = \"",$spacex,"\"></td>";
}
}

$x++;
}

echo "</tr>";

If($spacex !== "0")
{
If($r < $rows)
{
echo "<tr height = \"",$spacey,"\"><td align = \"center\" colspan = \"",$cols,"\"></td></tr>";
}

}
}

echo "</table>

</td>
<td width = \"",$b,"\" align = \"center\">



</td>
</tr>
<tr height = \"",$cr,"\">
<td colspan = \"3\" align = \"center\">



</td>
</tr>
</table>

";

}
ElseIf($key == "special")
{

$a = $arr['special']['padding']['a'];
$d = $arr['special']['padding']['d'];

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td colspan = \"3\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','a',this.value);\" size = \"3\" value = \"",$a,"\" style = \"text-align: center;\">
</td>
<tr>

<td width = \"5%\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','d',this.value);\" size = \"3\" value = \"",$d,"\" style = \"text-align: center;\">

</td>
<td style = \"color: white;\">
";

$count_tr = count($arr['special']['params']);
$name_special = $arr['special']['name'];
$working_cells = $arr['special']['working_cells'];

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">";

$g=1;
$h=1;

For($c=0;$c<$count_tr;$c++)
{

$height = $arr['special']['params'][$c]['height'];
$cells = $arr['special']['params'][$c]['cells'];

If(isset($arr['special']['params'][$c]['x']))
{
$x = $arr['special']['params'][$c]['x'];
}

echo "<tr height = \"",$height,"\"><td >";
echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; color: white;\" cellpadding=\"0\" cellspacing= \"0\"><tr>";

For($td_c=0;$td_c<=$cells;$td_c++)
{

If(isset($x[$td_c]))
{
$v = $x[$td_c];
$width = " width=\"".$v."\"";
}
Else{
$width = "";
}


If(in_array($g,$working_cells))
{

echo "<td",$width," style= \"background-color: grey; font-weight: bold; color: white;\">

шир.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"#",$td_c,"',this.value);\" size = \"2\" value = \"",$v,"\">

";

echo "<select style = \"text-align: center;\">
<option selected>выбрать</option>
";

Foreach($ar_triggers as $k=>$t)
{
echo "<option value = \"",$t,"\">",$k,"</option>";
}

echo "</select>";

If($td_c == "0")
{
echo "<span style = \"float: left;\">выс.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"*",$td_c,"',this.value);\" size = \"2\" value = \"",$height,"\"></span>";
}

echo "</td>";

$h++;
}
Else{

echo "<td",$width," >";

If(!empty($x))
{
echo " шир.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"#",$td_c,"',this.value);\" size = \"2\" value = \"",$v,"\">";
}
Else{
echo " выс.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"*",$td_c,"',this.value);\" size = \"2\" value = \"",$height,"\">";
}

//

echo "</td>";

}




$g++;
}

echo "</tr></table>";
echo "</td></tr>";

$height = "";
$cells = "";
$x = array();

}

echo "</table>";

$b = $arr['special']['padding']['b'];
$c = $arr['special']['padding']['c'];

echo "

</td>
<td width = \"5%\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','b',this.value);\" size = \"3\" value = \"",$b,"\" style = \"text-align: center;\">

</td>
</tr>
<tr height = \"10%\">
<td colspan = \"3\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','c',this.value);\" size = \"3\" value = \"",$c,"\" style = \"text-align: center;\">

</td>
</tr>
</table>


";

}





}

?>
