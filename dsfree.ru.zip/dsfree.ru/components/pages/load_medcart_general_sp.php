<?php

function load_medcart_general_sp($vals)
{

$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$id_dog = $row['id_dogovor'];
$data_dog = $row['data_dogovor'];
$ar_dog_data[$id_dog] = $data_dog;
}

}

$sql = "select * from pacs_visits where id_pac = '$id_pac' order by date_time DESC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; margin-top: 10px; \" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_visit = $row['id_visit'];
$id_dogovor = $row['id_dogovor'];
$date_time = $row['date_time'];
$ds = $row['ds'];

$dog_data = $ar_dog_data[$id_dogovor ];

$fio_doc = $row['fio_doc'];

If($fio_doc == "")
{
$fio_doc_view = "врач не выбран";
}
Else{
$fio_doc_view = "вр. ".$fio_doc;
}

echo "


<tr style = \"border-left: 1px solid black;\">
<td>

<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr >
<td width = \"50%\" height = \"35px\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"edit_first_docum('load_medcart_self','",$id_visit,"','",$screen,"');\" width = \"20%\" style = \"background-color: #008080; \"> 
открыть
</td>
<td onclick = \"edit_first_docum('load_medcart_self','",$id_visit,"','",$screen,"');\" width = \"20%\" style = \"background-color: #1A5FB4; \"> 
печать
</td>
<td style = \"background-color: #3A3A3A;\" onclick = \"edit_sp_medcart('",$id_visit,"','",$screen,"','data_time');\">
<span id = \"span_date_time_sp_medcart_",$screen,"\">";

$ar_date_time = explode(" ",$date_time);
$date = $ar_date_time['0'];
$time = $ar_date_time['1'];

$ar_date = explode("-",$date);
$year = $ar_date[0];
$month = $ar_date[1];
$day = $ar_date[2];

$rus_month = $ar_months_rus[$month];

$new_date = $day." ".$rus_month." ".$year;
$new_dt_txt = $new_date. " ".$time;
echo $new_dt_txt;

echo "</span>
</td>
</tr>
</table>

</td>
<td width = \"50%\" height = \"35px\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"open_page_act_dw('",$id_visit,"','",$screen,"');\" style = \"background-color: #8080FF;\" width = \"25%\">
акт вр
</td>
<td style = \"background-color: #8A969C;\" width = \"25%\">
эпикриз
</td>
<td style = \"background-color: #F5C211; color: black;\" width = \"25%\">
гарантия
</td>

<td onclick = \"edit_sp_medcart('",$id_visit,"','",$screen,"','delete_visit');\" style = \"background-color: #FF8080;\">
Х
</td>
</tr>
</table>

</td>
</tr>
</table>

</td>

<tr >

<td onclick = \"edit_sp_medcart('",$id_visit,"','",$screen,"','dogovor_pmu');\" height = \"30px\" style = \"background-color: #2E3336; border-left: 1px solid black; cursor: pointer;\">
№ договора <span id = \"span_id_dog_medcart_sp_",$screen,"\">",$id_dogovor," от ",$dog_data,"</span>
</td>
</tr>

<tr >

<td  height = \"30px\" style = \"border-left: 1px solid black; \">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; border-bottom: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #2E3336; \">
<td onclick = \"edit_sp_medcart('",$id_visit,"','",$screen,"','ds');\" width = \"70%\" style = \"overflow-x: hidden; cursor: pointer;\">

DS: <span id = \"span_ds_sp_medcart_",$id_visit,"_",$screen,"\">",$ds,"</span>

</td>
<td>
",$fio_doc_view,"
</td>
</tr>
</table>

</td>
</tr>

<tr height = \"30px\">
<td>
</td>
</tr>


";


}

echo "</table>";


}
Else{

echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
Нет записей в медкарте
</td>
</tr>
</table>
";


}


}

?>
