<?php

function open_modal_mark_ent($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_pac = $vals['id_pac'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<script>


function update_mark_ent_modal(screen,val,id_ent)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('update_mark_ent_modal') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[val]=\" + encodeURIComponent(val) + \"&data[id_ent]=\" + encodeURIComponent(id_ent));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


}
}
}

}

</script>


<style>

.textarea_open_modal_mark_ent_",$screen,":focus, input:focus{
outline: none;
}

</style>



<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td align = \"left\" style = \"background-color: black; padding-left: 5px;\">
Заметки
</td>
</tr>
<tr>
<td>
<div style = \"height: 100%; width: 100%; overflow-y: scroll;\">
";

$sql = "select * from pacs_ent where mark_ent != '' and id_pacs = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_ent = $row['id_ent'];
$mark_ent = $row['mark_ent'];

$begin = $row['begin'];
$ar_begin = explode(" ",$begin);
$date = $ar_begin[0];

echo "
<tr height = \"10px\">
<td align = \"left\">

<span style = \"background-color: green; padding-left: 20px; padding-right: 20px;\">
",$date,"
</span>



</td>
</tr>
<tr style = \"background-color: #2E3436; cursor: pointer;\">
<td height = \"60px\">

<textarea onkeyup = \"update_mark_ent_modal('",$screen,"',this.value,'",$id_ent,"');\" class = \"textarea_open_modal_mark_ent_",$screen,"\" style = \"width: 100%; height: 100%; font-size: 18px; padding: 5px;\">",$mark_ent,"</textarea>

</td>
</tr>
<tr height = \"10px\">
<td>

</td>
</tr>
";

}


echo "</table>";



}
Else{

echo "пусто";

}


echo "

</div>
</td>
</tr>
</table>";

}


?>
