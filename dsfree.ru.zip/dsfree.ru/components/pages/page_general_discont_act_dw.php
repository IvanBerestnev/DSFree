<?php

function page_general_discont_act_dw($vals)
{

#print_r($vals);
$id_visit = $vals['param'];
$screen = $vals['screen'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$works = $row['works'];
$discont = $row['discont'];

If($discont == "")
{
$discont = "0";
}

$ar_works = json_decode($works,true);

Foreach($ar_works as $id_dw=>$ar_valls)
{

$full_cost = $ar_valls['full_cost'];

$ar_full_cost = explode(";",$full_cost);

Foreach($ar_full_cost as $cost_no)
{

$ar_cost_no = explode("-",$cost_no);
$n_cost = $ar_cost_no[0];
$o_cost = $ar_cost_no[1];

$ar_general_stoimost[] = $n_cost;


}

}

$summ = array_sum($ar_general_stoimost);
$part = ($summ*$discont)/100;
$summ_itog = $summ-$part;

}

echo "

<script>

function change_discont_general_discont_act_dw(act,screen)
{

var td_skidka_general_discont_act_dw = 'td_skidka_general_discont_act_dw_' + screen;
var skidka_general_discont_act_dw = document.getElementById(td_skidka_general_discont_act_dw).innerHTML;

if(act == 'minus')
{
if(skidka_general_discont_act_dw > 0)
{
skidka_general_discont_act_dw--;
}


}
else if(act == 'plus')
{
if(skidka_general_discont_act_dw <100)
{
skidka_general_discont_act_dw++;
}

}

document.getElementById(td_skidka_general_discont_act_dw).innerHTML = skidka_general_discont_act_dw;

recalculate_general_discont_act_dw(screen,skidka_general_discont_act_dw);

}

function recalculate_general_discont_act_dw(screen,skidka_general_discont_act_dw)
{

var span_general_discont_act_dw = 'span_general_discont_act_dw_' + screen;
var general_discont_act_dw = document.getElementById(span_general_discont_act_dw).innerHTML;


var span_itog_general_discont_act_dw = 'span_itog_general_discont_act_dw_' + screen;




var part = (general_discont_act_dw*skidka_general_discont_act_dw)/100;
var calc_summ = general_discont_act_dw-part;

document.getElementById(span_itog_general_discont_act_dw).innerHTML = calc_summ;

}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td colspan = \"2\" style = \"background-color: #3A3A3A;\">
общая скидка на лечение
</td>
</tr>
<tr>
<td width = \"50%\" style = \"padding: 5px;\">

<table border = \"1\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: ;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"25%\">
<td>
стоимость
</td>
</tr>
<tr>
<td>
<span id = \"span_general_discont_act_dw_",$screen,"\">",$summ,"</span> р.
</td>
</tr>
</table>

</td>



<td style = \"padding: 5px;\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: ;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"25%\" style = \"border: 1px solid grey;\">
<td colspan = \"3\">
скидка
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td width = \"33%\" align = \"center\">

<div style=\"background-color: #FF8080; cursor: pointer; height: 35%; width: 65%; display: table; text-align: center;\">
<span onclick = \"change_discont_general_discont_act_dw('minus','",$screen,"');\" style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">
–	
</span>
</div>

</td>
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: ;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td id = \"td_skidka_general_discont_act_dw_",$screen,"\" align = \"right\">
",$discont,"
</td>
<td align = \"left\">
%
</td>
</tr>
</table>


</td>
<td width = \"33%\" align = \"center\">

<div style=\"background-color: green; cursor: pointer; height: 35%; width: 65%; display: table; text-align: center;\">
<span onclick = \"change_discont_general_discont_act_dw('plus','",$screen,"');\" style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">
+
</span>
</div>

</td>
</tr>
</table>

</td>

</tr>
<tr>
<td height = \"30%\" colspan = \"3\" style = \"padding: 5px;\">

<table border = \"1\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: ;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td colspan = \"2\" align = \"left\">
стоимость со скидкой
</td>
</tr>
<tr>
<td>
<span id = \"span_itog_general_discont_act_dw_",$screen,"\">",$summ_itog,"</span> р.
</td>
<td onclick = \"act_add_new_data_act_dw('",$id_visit,"','",$screen,"','update_gen_discont','');\" width = \"25%\" style = \"background-color: #008080; cursor: pointer;\">
внести
</td>

</tr>
</table>

</td>
</tr>
</table>

";


}

?>
