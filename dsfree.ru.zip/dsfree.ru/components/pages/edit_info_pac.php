<?php

function edit_info_pac($vals)
{



#print_r($vals);

$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");





include_once("../components/blocks/get_info_pac_by_id_pac.php");
$ar_pac = get_info_pac_by_id_pac($id_pac);


$ar_months_rus = array("01"=>"январь","02"=>"февраль","03"=>"март","04"=>"апрель","05"=>"май","06"=>"июнь","07"=>"июль","08"=>"август","09"=>"сентябрь","10"=>"октябрь","11"=>"ноябрь","12"=>"декабрь");
$ar_sex_pac = array("w"=>"жен","m"=>"муж");

include_once("../components/functions/tab_abr.php");
$ar_abr = tab_abr();

$ar_atd = $ar_abr['atd'];
$ar_uds = $ar_abr['uds'];
$ar_tz = $ar_abr['tz'];

echo "

<script>

function edit_info_pacs(id_pac,name,val)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('edit_info_pacs') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[name]=\" + encodeURIComponent(name) + \"&data[val]=\" + encodeURIComponent(val));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


if(name == 'name_pac' || name == 'patronymic_pac')
{
set_pac_sex(id_pac);
}
else if(name == 'birth_pac_month' || name == 'birth_pac_year')
{

set_days_bt(id_pac);

}

//var id_f_page_default_ssetka = 'id_f_page_default_ssetka_' + screen;

var cont = document.getElementById('info_pac_hid_span');
cont.innerHTML = xmlhttp.responseText;


//var elements = cont.getElementsByTagName('script');
//var len = elements.length;
//for (var i = 0; i < len; i++) {
//eval.call(window, elements[i].innerHTML);  
//}

}
}
}


}

function set_pac_sex(id_pac)
{


//Получить имя и отчество
var name_pac = document.getElementById('infopac_name_pac').value;
var patronymic_pac = document.getElementById('infopac_patronymic_pac').value;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('set_pac_sex') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[name_pac]=\" + encodeURIComponent(name_pac) + \"&data[patronymic_pac]=\" + encodeURIComponent(patronymic_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var sex_pac_answer = xmlhttp.responseText;


if(sex_pac_answer !== '')
{
document.getElementById('sel_pac_sex').value = sex_pac_answer;
edit_info_pacs(id_pac,'sex_pac',sex_pac_answer);

}
else{
document.getElementById('sel_pac_sex').value = sex_pac_answer;
edit_info_pacs(id_pac,'sex_pac','');

}


//alert(sex_pac);

//var cont = document.getElementById('info_pac_hid_span');
//cont.innerHTML = xmlhttp.responseText;


//var elements = cont.getElementsByTagName('script');
//var len = elements.length;
//for (var i = 0; i < len; i++) {
//eval.call(window, elements[i].innerHTML);  
//}

}
}
}






}

function set_days_bt(id_pac)
{

//Получить месяц и год
var e = document.getElementById('sel_birth_pac_month');
var sel_month = e.value;
var sel_year = document.getElementById('sel_birth_pac_year').value;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('set_days_bt') + \"&data[month]=\" + encodeURIComponent(sel_month) + \"&data[year]=\" + encodeURIComponent(sel_year) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


//info_pac_hid_span

var cont = document.getElementById('span_sel_birth_pac_day');
cont.innerHTML = xmlhttp.responseText;


//var elements = cont.getElementsByTagName('script');
//var len = elements.length;
//for (var i = 0; i < len; i++) {
//eval.call(window, elements[i].innerHTML);  
//}

}
}
}


//sel_birth_pac_day



}

</script>

<style>

input{
width: 95%;
height: 70%;
 background: transparent;
 border: none;
    border-bottom: 1px solid grey;
color: white;
font-size: 18px;
font-weight: bold;
}

input:focus{
outline:none;

}

input::-webkit-input-placeholder {font-size:15px;}

select:focus{
outline:none;

}


</style>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"'); load_sp_clients('",$screen,"','','','');\">X</span>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #242424;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\" style = \"background-color: black; color: white; font-weight: bold;\">
<td >
Информация о пациенте
</td>
</tr>
<tr height = \"30%\">
<td align = \"center\">

<table border = \"0\" width = \"99%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"font-size: 13px; border: 0px; background-color: #242424;\">
<td>
установочные данные
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"25%\">
<input onkeyup = \"edit_info_pacs('",$id_pac,"','surname_pac',this.value); \" placeholder = \"фамилия\" value = \"",$ar_pac['surname_pac'],"\">
</td>
<td width = \"25%\">
<input id = \"infopac_name_pac\" onkeyup = \"edit_info_pacs('",$id_pac,"','name_pac',this.value);\" placeholder = \"имя\" value = \"",$ar_pac['name_pac'],"\">
</td>
<td width = \"25%\">
<input id = \"infopac_patronymic_pac\" onkeyup = \"edit_info_pacs('",$id_pac,"','patronymic_pac',this.value);\" placeholder = \"отчество\" value = \"",$ar_pac['patronymic_pac'],"\">
</td>
<td>

<select id = \"sel_pac_sex\" onchange = \"edit_info_pacs('",$id_pac,"','sex_pac',this.value);\" style = \"background-color: #2E3436; color: white;\">
<option value = \"\">пол</option>
";

Foreach($ar_sex_pac as $ss=>$srus)
{
echo "<option";

If($ss == $ar_pac['sex_pac'])
{
echo " selected";

}

echo " value = \"",$ss,"\">",$srus,"</option>";

}

echo "
</select>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"35%\">

<span id = \"span_sel_birth_pac_day\">

";

If($ar_pac['birth_pac_day'] !== "")
{

$birth_pac_day = $ar_pac['birth_pac_day'];
$birth_pac_month = $ar_pac['birth_pac_month'];
$birth_pac_year = $ar_pac['birth_pac_year'];

If($birth_pac_month !== "" and $birth_pac_year !== "")
{



$number = cal_days_in_month(CAL_GREGORIAN, $birth_pac_month, $birth_pac_year);

echo "

<select id = \"sel_birth_pac_day\" onchange = \"edit_info_pacs('",$id_pac,"','birth_pac_day',this.value);\" style = \"width: 25%; background-color: #2E3436; color: white;\">
<option value = \"\">день</option>";

For($i=1;$i<=$number;$i++)
{

echo "<option";

If($i == $ar_pac['birth_pac_day'])
{
echo " selected";
}

echo " value = \"",$i,"\">",$i,"</option>";

}

echo "
</select>

";

}
Else{

echo "

<script>
set_days_bt('",$id_pac,"');
</script>

";

}


}
Else{

echo "

<script>
set_days_bt('",$id_pac,"');
</script>

";


}

echo "





</span>

<select id = \"sel_birth_pac_month\" onchange = \"edit_info_pacs('",$id_pac,"','birth_pac_month',this.value);\" style = \"  background-color: #2E3436; color: white;\">
<option value = \"\">месяц</option>
";

Foreach($ar_months_rus as $nm=>$rusm)
{

echo "<option";

If($nm == $ar_pac['birth_pac_month'])
{
echo " selected";
}

echo " value = \"",$nm,"\">",$rusm,"</option>";

}

echo "
</select>

<input id = \"sel_birth_pac_year\" onkeyup = \"edit_info_pacs('",$id_pac,"','birth_pac_year',this.value);\" style = \"width: 33%;\" placeholder = \"год рож-я\" value = \"",$ar_pac['birth_pac_year'],"\">

</td>


<td width = \"20%\">
<input onchange = \"edit_info_pacs('",$id_pac,"','phone',this.value);\" placeholder = \"телефон\" value = \"",$ar_pac['phone'],"\">
</td>
<td>

<input onchange = \"edit_info_pacs('",$id_pac,"','email',this.value);\" placeholder = \"электронная почта и тд\" value = \"",$ar_pac['email'],"\">

</td>
<td width = \"20%\">

<input onchange = \"edit_info_pacs('",$id_pac,"','deyatel',this.value);\" placeholder = \"род деятельности\" value = \"",$ar_pac['deyatel'],"\">

</td>

</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
</table>


</td>
</tr>
<tr height = \"30%\">
<td align = \"center\">

<table border = \"0\" width = \"99%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"font-size: 13px; border: 0px; background-color: #242424;\">
<td>
адрес
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"15%\">

<input onkeyup = \"edit_info_pacs('",$id_pac,"','country_pac',this.value);\" placeholder = \"страна\" value = \"",$ar_pac['country_pac'],"\">

</td>
<td width = \"25%\">
<input onkeyup = \"edit_info_pacs('",$id_pac,"','obl_pac',this.value);\" placeholder = \"регион\" value = \"",$ar_pac['obl_pac'],"\">
</td>
<td width = \"25%\">


<select onchange = \"edit_info_pacs('",$id_pac,"','type_atd_pac',this.value);\" style = \"background-color: #2E3436; color: white;\">
<option value = \"\">тип АТД</option>
";

Foreach($ar_atd as $satd=>$fatd)
{
echo "<option";

If($satd == $ar_pac['type_atd_pac'])
{
echo " selected";
}

echo " value = \"",$satd,"\">",$fatd,"</option>";
}

echo "
</select>


</td>
<td>

<input onkeyup = \"edit_info_pacs('",$id_pac,"','city_pac',this.value);\" placeholder = \"название АТД\" value = \"",$ar_pac['city_pac'],"\">

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"15%\">

<select onchange = \"edit_info_pacs('",$id_pac,"','type_street_pac',this.value);\" style = \"background-color: #2E3436; color: white;\">
<option value = \"\">тип УДС</option>
";

Foreach($ar_uds as $suds=>$fuds)
{
echo "<option";

If($suds == $ar_pac['type_street_pac'])
{
echo " selected";
}

echo " value = \"",$suds,"\">",$fuds,"</option>";
}

echo "
</select>

</td>
<td width = \"20%\">

<input onkeyup = \"edit_info_pacs('",$id_pac,"','street_pac',this.value);\" placeholder = \"название УДС\" value = \"",$ar_pac['street_pac'],"\">

</td>
<td width = \"15%\">

<select onchange = \"edit_info_pacs('",$id_pac,"','type_house_pac',this.value);\" style = \"background-color: #2E3436; color: white;\">
<option value = \"\">тип здания</option>
";

Foreach($ar_tz as $stz=>$ftz)
{
echo "<option";

If($stz == $ar_pac['type_house_pac'])
{
echo " selected";
}

echo " value = \"",$stz,"\">",$ftz,"</option>";
}

echo "
</select>

</td>

<td width = \"15%\">

<input onkeyup = \"edit_info_pacs('",$id_pac,"','house_pac',this.value);\" placeholder = \"номер здания\" value = \"",$ar_pac['house_pac'],"\">

</td>

<td width = \"10%\">

<input onkeyup = \"edit_info_pacs('",$id_pac,"','flat_pac',this.value);\" placeholder = \"квартира\" value = \"",$ar_pac['flat_pac'],"\">

</td>

</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
</table>


</td>
</tr>
<tr height = \"17%\">
<td align = \"center\">

<table border = \"0\" width = \"99%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"font-size: 13px; border: 0px; background-color: #242424;\">
<td>
документ и его сведения
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td align = \"center\">
<input onkeyup = \"edit_info_pacs('",$id_pac,"','docum',this.value);\" placeholder = \"название документа и его данные\" value = \"",$ar_pac['docum'],"\">
</td>
</tr>
</table>

</td>
</tr>

</table>
<span style = \"display: none;\" id = \"info_pac_hid_span\"></span>



";











}

?>
