<?php

function screen_setka_myprofile_show()
{


include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();

$id_user_cookie = $ar_vals['id_user_cookie'];
$name_user_cookie= $ar_vals['name_user_cookie'];
$level_cookie = $ar_vals['level_cookie'];


If($level_cookie == "3")
{
//3 уровень доступа. Суперпользователь. Нужен список других пользователей для управления их сеткой

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select id_user, name_user from dsf_users order by level DESC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while ($row = mysqli_fetch_assoc($query))
{
$id_user = $row['id_user'];
$name_user = $row['name_user'];

$ar_users[$id_user] = $name_user;
}
}

}
Else{
$ar_users = array();
}




echo "
<script>
function load_menu_choice_type_setka(id_user)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_menu_choice_type_setka') + \"&data[id_user]=\" + encodeURIComponent(id_user));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('id_f_menu_choice_ssetka');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function load_menu_ctlr_type_setka(id_used_ssetka)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_menu_ctlr_type_setka') + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('id_f_menu_ctrl_ssetka');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function load_menu_setka_self(id_used_ssetka)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_menu_setka_self') + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('id_f_menu_setka_self');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function change_settings_ssetka(id_used_ssetka,type,value)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

var areaOption = document.getElementById('id_but_reset_ssetka');

if (areaOption) {

var stat_but = document.getElementById('id_but_reset_ssetka').style.display;
if(stat_but == 'none')
{
document.getElementById('id_but_reset_ssetka').style.display = \"block\";

}

}

xmlhttp.send(\"act=\" + encodeURIComponent('change_settings_ssetka') + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[value]=\" + encodeURIComponent(value));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('invis_div');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function act_default_ssetka(id_used_ssetka)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_default_ssetka') + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('invis_div');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function delete_ssetka_from_profile(id_used_ssetka)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('delete_ssetka_from_profile') + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('invis_div');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function add_tab_ssetka_default(param,id_used_ssetka,number_cell)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_tab_ssetka_default') + \"&data[param]=\" + encodeURIComponent(param) + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka) + \"&data[number_cell]=\" + encodeURIComponent(number_cell));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('invis_div');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}

function erasing_excess_options_ssetka_default(param,number_cell,id_used_ssetka)
{

//наш выбранный селект
var our_sel_add_tab_ssetka_default = 'sel_add_tab_ssetka_default_' + number_cell;

//Получим класс и переберем его
var theOddOnes = document.getElementsByClassName('sel_add_tab_ssetka_default');

var arr_screen_unsed = [];

for(var i=0; i<theOddOnes.length; i++)
{

//alert(i);

//получение ID из класса
var sel_add_tab_ssetka_default = theOddOnes[i].id;

//получение номера экрана
var myarr = sel_add_tab_ssetka_default.split('sel_add_tab_ssetka_default_');
var screen = myarr[1];

if(our_sel_add_tab_ssetka_default == sel_add_tab_ssetka_default)
{
//alert('да');


}
else{
//alert('нет');

arr_screen_unsed.push(screen);

}

}

var str_screen_unused = arr_screen_unsed.join(',');


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('erasing_excess_options_ssetka_default') + \"&data[screen]=\" + encodeURIComponent(str_screen_unused) + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var answer_fsrv = xmlhttp.responseText;
//alert(answer_fsrv);

var ar_answer_fsrv = answer_fsrv.split('@');

for(var x=0; x<ar_answer_fsrv.length; x++)
{

var scr_sel = ar_answer_fsrv[x];

//alert(pre_answer_fsrv);

var ar_scr_sel = scr_sel.split('#');
var new_scr = ar_scr_sel[0];
var new_sel = ar_scr_sel[1];
//alert(new_sel);

var span_sel_add_tab_ssetka_default = 'span_sel_add_tab_ssetka_default_' + new_scr;

document.getElementById(span_sel_add_tab_ssetka_default).innerHTML = new_sel;


}


//var cont = document.getElementById('span_answer_from_srv_ssetka_default');
//cont.innerHTML = xmlhttp.responseText;

//var elements = cont.getElementsByTagName('script');
//var len = elements.length;
//for (var i = 0; i < len; i++) {
//eval.call(window, elements[i].innerHTML);  
//}


}
}
}



}

function show_button_rp_edit_default_ssetka(act,id_ssetka_default,id_used_ssetka,number_cell)
{

if(act == 'show')
{
var but_edit_default = 'but_edit_default_' + id_used_ssetka + '_' + number_cell;
document.getElementById(but_edit_default).style.display = 'inline';
}
else if(act == 'hidden')
{

var but_edit_default = 'but_edit_default_' + id_used_ssetka + '_' + number_cell;
document.getElementById(but_edit_default).style.display = 'none';

}

}



function open_page_edit_default_ssetka(id_used_ssetka,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_page_edit_default_ssetka') + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


document.getElementById('fon_modal_add').style.display = 'block';
document.getElementById('modal_add').style.width = '400px';
document.getElementById('modal_add').style.height = '450px';

var cont = document.getElementById('modal_add');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}




}



</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\">
<td>";

If(!empty($ar_users))
{
echo "<select onchange = \"load_menu_choice_type_setka(this.value);\" id = \"id_sel_users\">";

Foreach($ar_users as $id=>$name)
{
echo "<option value = \"",$id,"\">",$name,"</option>";
}

echo "</select>";
}

echo "</td>
<td width = \"65%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #575757;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"40%\">
<td>
<div id = \"id_f_menu_choice_ssetka\" style = \"width: 100%; height: 100%;\"></div>
</td>
</tr>
<tr>
<td>

<div id = \"id_f_menu_ctrl_ssetka\" style = \"width: 100%; height: 100%; background-color: #575757;\"></div>

</td>
</tr>
</table>

</td>
<td>
</td>
</tr>
<tr>
<td colspan = \"3\">

<div id = \"id_f_menu_setka_self\" style = \"width: 100%; height: 100%;\"></div>

</td>
</tr>
</table>
<div id = \"invis_div\" style = \"display: none;\"></div>

<div id=\"fon_modal_add\" style=\"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); right: 0; bottom: 0; left: 0; margin: auto; position: fixed; z-index: 2000;\">
<div id=\"modal_add\" style=\"display: block; position: fixed; top: 0%; right: 0; bottom: 0; left: 0; margin: auto; background: white; transition: 1s; animation: show 0.3s 1; animation-fill-mode: forwards;\">
</div>
</div>

<script>
load_menu_choice_type_setka('",$id_user_cookie,"');
</script>
";



}

?>
