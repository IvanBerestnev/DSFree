<?php

function act_dw_admin($id_pac,$screen)
{

#print_r($id_pac);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$surname_pac = $row['surname_pac'];
}

echo "

<script>

function load_block_act_dw_admin(id_pac,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_act_dw_admin') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_act_dw_admin = 'f_act_dw_admin_' + screen;

var cont = document.getElementById(f_act_dw_admin);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"background-color: #3A3A3A;\">
<td >

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"20%\" style = \"cursor:pointer;\" class = \"but_back_to_sp_first_docs_",$screen,"\">

&#10096;

</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\" >
Акт выполненных работ
</td>
<td onclick=\"open_first_docum('act_dw_admin','",$id_pac,"','",$screen,"');\" style = \"cursor: pointer; background-color: #8080FF;\">

&#10227;

</td>
</tr>
</table>


</td>
</tr>
</table>

</td>
<td>


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\">
",$surname_pac,"
</td>
<td onclick = \"load_primary_docums('','",$screen,"');\" style = \"cursor: pointer;\">
X
</td>
</tr>
</table>


</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"30%\" style = \"border-right: 1px solid black;\">
</td>
<td>
<div id = \"f_act_dw_admin_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #22272B;\">
</div>
</td>
<td width = \"30%\" style = \"\">
</td>
</tr>
</table>

</td>
</tr>
</table>

<script>
load_block_act_dw_admin('",$id_pac,"','",$screen,"');
</script>
";

}

?>
