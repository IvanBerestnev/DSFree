<?php

function price($vals)
{

$screen = $vals['screen'];

#print_r($vals);

echo "

<script>

function load_block_price(id_price,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_price') + \"&data[id_price]=\" + encodeURIComponent(id_price) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_price = 'f_price_' + screen;

var cont = document.getElementById(f_price);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function load_add_page_price(name,screen,param,id_price)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_add_page_price')+ \"&data[name]=\" + encodeURIComponent(name) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param) + \"&data[id_price]=\" + encodeURIComponent(id_price));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

if(name == 'delete_price')
{
var x = '30%';
var y = '10%';
}
else if(name == 'add_new_price')
{
var x = '30%';
var y = '15%';
}
else if(name == 'rename_price')
{
var x = '30%';
var y = '15%';
}
else if(name == 'add_new_usluga')
{
var x = '40%';
var y = '15%';
}
else if(name == 'delete_usluga_price')
{
var x = '40%';
var y = '15%';
}
else if(name == 'edit_usluga_price')
{
var x = '40%';
var y = '15%';
}


document.getElementById(modal_first).style.width = x;
document.getElementById(modal_first).style.height = y;

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


function act_add_page_price(name,screen,param,id_price)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

if(name == 'act_add_new_price')
{
var input_add_new_price = 'input_add_new_price_' + screen;
var param = document.getElementById(input_add_new_price).value;
}
else if(name == 'act_rename_new_price')
{
var input_rename_new_price = 'input_rename_new_price_' + screen;
var param = document.getElementById(input_rename_new_price).value;
}
else if(name == 'act_save_new_usluga')
{
var id_inp_name_new_usluga = 'id_inp_name_new_usluga_' + screen;
var name_new_usluga = document.getElementById(id_inp_name_new_usluga).value;

var id_inp_cena_new_usluga = 'id_inp_cena_new_usluga_' + screen;
var cena_new_usluga = document.getElementById(id_inp_cena_new_usluga).value;

var param = name_new_usluga + '@' + cena_new_usluga;
}
else if(name == 'act_edit_usluga_price')
{

var id_usl = param;

var id_inp_name_edit_usluga = 'id_inp_name_edit_usluga_' + screen;
var name_new_usluga = document.getElementById(id_inp_name_edit_usluga).value;

var id_inp_cena_edit_usluga = 'id_inp_cena_edit_usluga_' + screen;
var cena_new_usluga = document.getElementById(id_inp_cena_edit_usluga).value;

var param = id_usl + '@' + name_new_usluga + '@' + cena_new_usluga;

}




xmlhttp.send(\"act=\" + encodeURIComponent('act_add_page_price')+ \"&data[name]=\" + encodeURIComponent(name) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param) + \"&data[id_price]=\" + encodeURIComponent(id_price));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

if(name == 'act_delete_price')
{
var hidden_page_delete_price = 'hidden_page_delete_price_' + screen;
var cont = document.getElementById(hidden_page_delete_price);
}
else if(name == 'act_add_new_price')
{
var hidden_add_new_price = 'hidden_add_new_price_' + screen;
var cont = document.getElementById(hidden_add_new_price);
}
else if(name == 'act_rename_new_price')
{
var hidden_rename_new_price = 'hidden_rename_new_price_' + screen;
var cont = document.getElementById(hidden_rename_new_price);
}
else if(name == 'act_save_new_usluga')
{
var hidden_act_add_new_usluga = 'hidden_act_add_new_usluga_' + screen;
var cont = document.getElementById(hidden_act_add_new_usluga);
}
else if(name == 'act_delete_usluga_price')
{
var hidden_delete_usluga_price = 'hidden_delete_usluga_price_' + screen;
var cont = document.getElementById(hidden_delete_usluga_price);
}
else if(name == 'act_edit_usluga_price')
{
var hidden_edit_usluga_price = 'hidden_edit_usluga_price_' + screen;
var cont = document.getElementById(hidden_edit_usluga_price);
}



cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


function load_block_price_self(id_price,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_price_self') + \"&data[id_price]=\" + encodeURIComponent(id_price) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_load_block_price_self = 'f_load_block_price_self_' + screen;

var cont = document.getElementById(f_load_block_price_self);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style=\"background-color: black; font-weight: bold;\">
<td height = \"3%\">
прайс

<span onclick=\"trunc_screen('",$screen,"');\" class=\"but_trunc_screen\">X</span>

</td>
</tr>
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"background-color: #242424;\">
</td>
<td>
<div id = \"f_price_",$screen,"\" style = \"width: 100%; height: 100%; background-color: #2E3436; font-weight: bold;\">
</div>
</td>
<td width = \"25%\" style = \"background-color: #242424;\">
</td>
</tr>
</table>


</td>
</tr>
</table>

<script>
load_block_price('','",$screen,"');
</script>

";


}

?>
