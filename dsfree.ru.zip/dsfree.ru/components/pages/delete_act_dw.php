<?php

function delete_act_dw($vals)
{

$id_visit = $vals['param'];
$screen = $vals['screen'];

echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>
<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
Удалить данный акт выполненных работ?
</td>
</tr>
<tr height = \"20%\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_first_",$screen,"');\" width = \"50%\" style = \"background-color: #FF8080;\">
нет
</td>
<td onclick = \"act_add_new_data_act_dw('",$id_visit,"','",$screen,"','act_delete_act_dw','');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
";

}

?>
