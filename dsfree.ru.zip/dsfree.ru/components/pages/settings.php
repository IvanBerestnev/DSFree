<?php

function settings()
{

echo "

<script>

function load_modal_page_settings(name,param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_modal_page_settings') + \"&data[name]=\" + encodeURIComponent(name) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_settings';
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_settings';

document.getElementById(modal).style.width = '35%';
document.getElementById(modal).style.height = '25%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function act_modal_page_settings(name,param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_modal_page_settings') + \"&data[name]=\" + encodeURIComponent(name) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


if(name == 'act_reset_dsfree_default_mode0')
{
var f_span = 'hidden_page_reset_dsfree_default_mode0';
}


var cont = document.getElementById(f_span);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}

</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #3A3A3A;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #3A3A3A;\" cellpadding=\"0\" cellspacing= \"0\">
<tr >
<td height = \"200px\" width = \"50%\" align = \"center\">

<table border = \"0\" align = \"center\" width = \"95%\" height = \"90%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #3A3A3A;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: #22272B;\">
<td>
Настройки разработчика
</td>
</tr>
<tr>
<td style = \"background-color: #2E3336;\">
<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50px\" style = \"background-color: #8A969C; cursor: pointer;\">
<td onclick = \"load_modal_page_settings('page_reset_dsfree_default_mode0','');\">
Удалить все данные. Привести программу изначальный вид.
</td>
</tr>
<tr height = \"15px\">
<td>
</td>
</tr>
<tr height = \"50px\" style = \"background-color: #8A969C; cursor: pointer;\">
<td>
Удалить все пользовательские данные. Оставить пользователей.
</td>
</tr>
<tr height = \"15px\">
<td>
</td>
</tr>
</table>

</div>

</td>
</tr>
</table>

</td>
<td>
</td>
</tr>
<tr height = \"200px\">
<td>
</td>
<td>
</td>
</tr>
<tr height = \"200px\">
<td>
</td>
<td>
</td>
</tr>

</table>

</div>

</td>
</tr>
</table>

<div id = \"fon_modal_settings\" style = \"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); right: 0; bottom: 0; left: 0; margin: auto; position: fixed; z-index: 2000;  \">
<div id = \"modal_settings\" style = \"display: block; position: fixed; top: 0%; right: 0; bottom: 0; left: 0; margin: auto; background: white; transition: 1s; animation: show 0.3s 1; animation-fill-mode: forwards;\"></div>
</div>

";


}

?>
