<?php

function page_delete_ds($vals)
{
	
#print_r($vals);

$screen = $vals['screen'];
$id_ds = $vals['id_ds'];
$id_pac = $vals['id_pac'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #3A3A3A; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
<b style = \"color: #FF8080;\">Внимание</b>

<br>
<br>

Удаление диагноза повлечет за собой удаление всей<br>соответствующей цепочки профилей и разделов шаблона.





<br><br>
Продолжить?
</td>
</tr>
<tr height = \"20%\" align = \"center\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" style = \"background-color: #FF8080; \" width = \"50%\">
нет
</td>
<td onclick = \"delete_ds('",$screen,"','",$id_ds,"','",$id_pac,"');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>

";



}

?>
