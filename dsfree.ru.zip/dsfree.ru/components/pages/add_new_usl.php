<?php

function add_new_usl($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$param = $vals['param'];

$ar_param = explode("@",$param);
$id_price = $ar_param['0'];
$id_usl = $ar_param['1'];
$id_visit = $ar_param['2'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$txt_price = $row['txt_price'];
$ar_txt_price = json_decode($txt_price,true);


$name = $ar_txt_price[$id_usl]['name'];
$cost = $ar_txt_price[$id_usl]['cost'];
}

echo "

<script>

function change_count_uslugi(screen,act)
{

var id_count_add_new_usl = 'id_count_add_new_usl_' + screen;
var count_add_new_usl = document.getElementById(id_count_add_new_usl).innerHTML;

if(act == 'minus')
{

if(count_add_new_usl >= 2)
{
var count_add_new_usl = count_add_new_usl-1;
document.getElementById(id_count_add_new_usl).innerHTML = count_add_new_usl;
}

}
else if(act == 'plus')
{
var count_add_new_usl = Number(count_add_new_usl) + 1;
document.getElementById(id_count_add_new_usl).innerHTML = count_add_new_usl;
}

calculate_itog_cena_new_uslugi(screen)
}

function calculate_itog_cena_new_uslugi(screen)
{

var id_count_add_new_usl = 'id_count_add_new_usl_' + screen;
var count_add_new_usl = document.getElementById(id_count_add_new_usl).innerHTML;

var id_inp_cost_add_new_usl = 'id_inp_cost_add_new_usl_' + screen;
var cost_add_new_usl = document.getElementById(id_inp_cost_add_new_usl).value;

var itog_cena_new_uslugi = count_add_new_usl*cost_add_new_usl;

var id_td_itog_cena_new_uslugi = 'id_td_itog_cena_new_uslugi_' + screen;
document.getElementById(id_td_itog_cena_new_uslugi).innerHTML = itog_cena_new_uslugi + ' р.';

}

</script>

<style>

.inp_cost_add_new_usl_",$screen,"{
width: 85%;
height: 60%;
 background: transparent;
 border: none;
    border-bottom: 1px solid grey;
color: white;
font-size: 18px;
font-weight: bold;

}

.inp_cost_add_new_usl_",$screen,":focus{
outline:none;
}


</style>

<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td colspan = \"3\" style = \"background-color: #3A3A3A;\">
Стоимость услуги
</td>
</tr>
<tr height = \"25%\">
<td colspan = \"3\" style = \"padding: 5px;\">
<div id = \"id_div_name_add_new_usl_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; text-align: left; border: 1px solid grey;\">",$name,"</div>
</td>

</tr>

<tr>
<td width = \"45%\" align = \"center\" style = \"padding: 5px;\">

<table border = \"1\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td align = \"left\">
цена
</td>
</tr>
<tr>
<td>

<input onkeyup = \"calculate_itog_cena_new_uslugi('",$screen,"');\" id = \"id_inp_cost_add_new_usl_",$screen,"\" class = \"inp_cost_add_new_usl_",$screen,"\" value = \"",$cost,"\" placeholder = \"цена услуги\">


</td>
</tr>
</table>

</td>
<td align = \"left\" style = \"padding: 5px;\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td>

</td>
</tr>
<tr>
<tr>
<td align = \"left\">
р.
</td>
</tr>
</table>


</td>
<td  width = \"33%\" align = \"center\" style = \"padding: 5px;\">

<table border = \"0\"  width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B; border: 1px solid grey;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td colspan = \"3\" align = \"left\" style = \"border-bottom: 1px solid grey;\">
количество
</td>
</tr>
<tr>
<td width = \"33%\" align = \"center\" >

<div onclick = \"change_count_uslugi('",$screen,"','minus');\" style=\"background-color: #FF8080; cursor: pointer; height: 35%; width: 65%; display: table; text-align: center;\">
<span style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">
&ndash;	
</span>
</div>

</td>
<td id = \"id_count_add_new_usl_",$screen,"\" width = \"33%\" align = \"center\">1</td>
<td align = \"center\">

<div onclick = \"change_count_uslugi('",$screen,"','plus');\" style=\"background-color: green; cursor: pointer; height: 35%; width: 65%; display: table; text-align: center;\">
<span style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">
+
</span>
</div>

</td>
</tr>
</table>

</td>

</tr>

<tr height = \"25%\">
<td colspan = \"3\" style = \"background-color: ; padding: 5px;\">

<table border = \"1\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td colspan = \"2\" align = \"left\">
стоимость
</td>
</tr>
<tr>
<td id = \"id_td_itog_cena_new_uslugi_",$screen,"\">
",$cost," р.
</td>
<td onclick = \"act_add_new_data_act_dw('",$id_visit,"','",$screen,"','act_add_new_uslugi_act_dw','');\" width = \"25%\" style = \"background-color: #008080; cursor: pointer;\">
внести
</td>
</tr>
</table>

</td>
</tr>


</table>

<span style = \"display: none;\" id = \"id_span_default_cost_uslugi_",$screen,"\">",$cost,"</span>

";


//act_add_new_data_act_dw(id_visit,screen,name_act,param)


}

?>
