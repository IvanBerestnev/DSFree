<?php

function page_delete_usluga_from_actdw($vals)
{

#print_r($vals);

$param = $vals['param'];
$screen = $vals['screen'];

$ar_param = explode("@",$param);

$id_visit = $ar_param[0];
$id_dw = $ar_param[1];




echo "

<script>

function load_block_sp_delete_usluga_from_actdw(id_visit,id_dw,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_sp_delete_usluga_from_actdw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_dw]=\" + encodeURIComponent(id_dw));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_sp_delete_usluga_from_actdw = 'f_sp_delete_usluga_from_actdw_' + screen;

var cont = document.getElementById(f_sp_delete_usluga_from_actdw);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function act_delete_usluga_from_sp_dw(no_cost,id_visit,id_dw,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_usluga_from_sp_dw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_dw]=\" + encodeURIComponent(id_dw) + \"&data[no_cost]=\" + encodeURIComponent(no_cost));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hidden_page_delete_usluga_from_actdw = 'hidden_page_delete_usluga_from_actdw_' + screen;

var cont = document.getElementById(hidden_page_delete_usluga_from_actdw);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
<div id = \"f_sp_delete_usluga_from_actdw_",$screen,"\" style = \"height: 100%; width: 100%; overflow-y: scroll; background-color: #1D1D1D;\"></div>
</td>
</tr>
</table>
<span id = \"hidden_page_delete_usluga_from_actdw_",$screen,"\"></span>

<script>
load_block_sp_delete_usluga_from_actdw('",$id_visit,"','",$id_dw,"','",$screen,"');
</script>
";


}

?>
