<?php

function modal_page_inventar($vals)
{

#print_r($vals);

$name_page = $vals['name_page'];
$screen = $vals['screen'];
$param = $vals['param'];

If($name_page == "page_delete_item")
{

echo "

<script>

function act_delete_item_from_inventar(screen,id_item)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_item_from_inventar') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_item]=\" + encodeURIComponent(id_item));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var hidden_page_delete_item = 'hidden_page_delete_item_' + screen;

var cont = document.getElementById(hidden_page_delete_item);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"1\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
удалить из инвентаря?
</td>
</tr>
<tr height = \"30%\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" width = \"50%\" style = \"background-color: #FF8080; cursor: pointer;\">
нет
</td>
<td onclick = \"act_delete_item_from_inventar('",$screen,"','",$param,"');\" style = \"background-color: #008080; cursor: pointer;\">
да
</td>
</tr>
</table>
<span id = \"hidden_page_delete_item_",$screen,"\" style = \"display: none;\"></span>
";

die;
}
ElseIf($name_page == "open_modal_edit_type_inventar")
{

If($param !== "")
{

If($param == "empty_type_inventar_notusedname")
{
$name = "раздел без имени";
$param = "";
}
Else{
$name = $param;
}



echo "

<script>

function act_rename_mass_type_inventar(screen)
{

var id_inp_rename_mass_type_inventar = 'id_inp_rename_mass_type_inventar_' + screen;
var new_name = document.getElementById(id_inp_rename_mass_type_inventar).value;

var hidden_old_name_type_inventar = 'hidden_old_name_type_inventar_' + screen;
var old_name = document.getElementById(hidden_old_name_type_inventar).innerHTML;

if(new_name == old_name)
{
var fon_modal = 'fon_modal_' + screen;
close_mw(fon_modal);
return false;
}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_rename_mass_type_inventar') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[new_name]=\" + encodeURIComponent(new_name) + \"&data[old_name]=\" + encodeURIComponent(old_name));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var hidden_open_modal_edit_type_inventar = 'hidden_open_modal_edit_type_inventar_' + screen;

var cont = document.getElementById(hidden_open_modal_edit_type_inventar);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"20%\">
<td align = \"left\" style = \"background-color: black;\" colspan = \"2\">
Редактировать раздел
</td>
</tr>

<tr height = \"25%\">
<td>
",$name,"
</td>
<td onclick = \"modal_page_inventar('",$screen,"','open_modal_edit_type_inventar','');\" width = \"15%\" style = \"border: 1px solid grey; background-color: #FF8080; cursor: pointer;\">
х
</td>
</tr>
<tr>
<td colspan = \"2\">
<input id = \"id_inp_rename_mass_type_inventar_",$screen,"\" placeholder = \"новое имя раздела\">
</td>

</tr>
<tr height = \"25%\">
<td onclick = \"act_rename_mass_type_inventar('",$screen,"');\" colspan = \"2\" style = \"background-color: #008080; cursor: pointer;\">
принять
</td>

</tr>
</table>
<span id = \"hidden_open_modal_edit_type_inventar_",$screen,"\"></span>
<span id = \"hidden_old_name_type_inventar_",$screen,"\">",$param,"</span>

";

}
Else{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select distinct(type) from limit_list";
$query = mysqli_query($connection,$sql);


echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"20%\">
<td align = \"left\" style = \"background-color: black;\">
Редактировать раздел
</td>
</tr>

<tr>
<td>

";

If(mysqli_num_rows($query) !== 0)
{
echo "<select onclick = \"modal_page_inventar('",$screen,"','open_modal_edit_type_inventar',this.value);\" >
<option value = \"\">выберете категорию</option>
<option value = \"empty_type_inventar_notusedname\">раздел без имени</option>
";
while($row = mysqli_fetch_assoc($query))
{
$type = $row['type'];

echo "<option value=\"",$type,"\">",$type,"</option>";

}

echo "</select>";


}

echo "
</select>

</td>
</tr>
</table>

";

}

die;
}
ElseIf($name_page == "modal_print_items_inventar")
{

If($param == "")
{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select distinct(type) from limit_list";
$query = mysqli_query($connection,$sql);

echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\" style = \"background-color: black;\">
<td>
Выберете раздел для печати 
</td>
</tr>
<tr>
<td>";

If(mysqli_num_rows($query) !== 0)
{
echo "<select onchange = \"modal_page_inventar('",$screen,"','modal_print_items_inventar',this.value);\" id = \"sel_choice_type_load_block_inventar_",$screen,"\">
<option disabled selected>выберете категорию</option>
<option value = \"all_types\">все категории</option>
";
while($row = mysqli_fetch_assoc($query))
{
$type = $row['type'];

echo "<option value=\"",$type,"\">",$type,"</option>";

}

echo "</select>";


}

echo "
</td>
</tr>
</table>

";


}
Else{

If($param == "all_types")
{
$param = "";
$name_param = "Все категории";
}
Else{
$name_param = $param;
}


echo "

<script>

function show_days_prosrok(param,screen)
{

var id_td_hidden_but_print_inventar = 'id_td_hidden_but_print_inventar_' + screen;
document.getElementById(id_td_hidden_but_print_inventar).style.display = 'table-row';

if(param == 'print_prosrok')
{
var id_span_kolich_days_prosrok = 'id_span_kolich_days_prosrok_' + screen;
document.getElementById(id_span_kolich_days_prosrok).style.display = 'inline-block';
}

else if(param == 'print_all')
{
var id_span_kolich_days_prosrok = 'id_span_kolich_days_prosrok_' + screen;
document.getElementById(id_span_kolich_days_prosrok).style.display = 'none';
}



}


function print_inventar(screen)
{

var id_sel_is_prosrok = 'id_sel_is_prosrok_' + screen;
var selector = document.getElementById(id_sel_is_prosrok);
var val_is_prosrok = selector[selector.selectedIndex].value;

var id_sel_kolich_days_prosrok = 'id_sel_kolich_days_prosrok_' + screen;
var selector = document.getElementById(id_sel_kolich_days_prosrok);
var val_kolich_days_prosrok = selector[selector.selectedIndex].value;

var param = val_is_prosrok + '@' + val_kolich_days_prosrok;

var inp_is_prosrok = 'inp_is_prosrok_' + screen;
document.getElementById(inp_is_prosrok).value = param;


var form_print_inventar = 'form_print_inventar_' + screen;
document.getElementById(form_print_inventar).submit();

}

</script>


<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\" style = \"background-color: black;\">
<td>
Выбран раздел <span style = \"color: gold;\">\"",$name_param,"\"</span>
</td>
</tr>
<tr height = \"40%\">
<td>
<select id = \"id_sel_is_prosrok_",$screen,"\" onchange = \"show_days_prosrok(this.value,'",$screen,"');\" style = \"font-weight: bold; text-align: center;\">
<option disabled selected>выберете</option>
<option value = \"print_all\">Печать всего</option>
<option value = \"print_prosrok\">Печать только просрочки</option>
</select>
 
<span id = \"id_span_kolich_days_prosrok_",$screen,"\" style = \"display: none;\">
кол-во дней
<select id = \"id_sel_kolich_days_prosrok_",$screen,"\">
";

For($i=0;$i<=120;$i++)
{
echo "<option value = \"",$i,"\">",$i,"</option>";
}

echo "
</select>
</span>

</td>
</tr>

<tr id = \"id_td_hidden_but_print_inventar_",$screen,"\" style = \"display: none;\" height = \"20%\">
<td onclick = \"print_inventar('",$screen,"');\" style = \"background-color: #008080; cursor: pointer;\">
печать
</td>
</tr>
</table>

<form id = \"form_print_inventar_",$screen,"\" action = \"../handle/handle.html\" method = \"post\" target=\"_self\" style = \"display: none;\">
<input type = \"hidden\" name = \"act\" value = \"print_inventar\">
<input type = \"hidden\" id = \"inp_type_",$screen,"\" name = \"data[type]\" value = \"",$param,"\">
<input type = \"hidden\" id = \"inp_is_prosrok_",$screen,"\" name = \"data[is_prosrok]\" value = \"\">
</form>

";


}


die;
}




include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


If($name_page == "page_add_new_item")
{
$but_act = "act_item_to_inventar('".$screen."','');";

$type_bd = "";
$name = "";
$limit = "";
$comment = "";

$day_now = date('d');
$month_now = date('m');
$year_now = date('Y');

$zagol = "Добавить";


}
ElseIf($name_page == "page_edit_item")
{
$but_act = "act_item_to_inventar('".$screen."','".$param."');";

$sql = "select * from limit_list where id = '$param'";

$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);

$type_bd = $row['type'];
$name = $row['name'];
$limit = $row['limit'];
$comment = $row['comment'];

$ar_limit = explode("-",$limit);
$day_now = $ar_limit[2];
$month_now = $ar_limit[1];
$year_now = $ar_limit[0];

}

$zagol = "Редактировать";

}





$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);


echo "

<script>

function act_item_to_inventar(screen,param)
{

var txtarea_name_item_inventar = 'txtarea_name_item_inventar_' + screen;
var name_item_inventar = document.getElementById(txtarea_name_item_inventar).value;

var inp_type_item_inventar = 'inp_type_item_inventar_' + screen;
var types_item_inventar = document.getElementById(inp_type_item_inventar).value;

var sel_day_limit_item_inventar = 'sel_day_limit_item_inventar_' + screen;
var selector = document.getElementById(sel_day_limit_item_inventar);
var day_limit = selector[selector.selectedIndex].value;

var sel_month_limit_item_inventar = 'sel_month_limit_item_inventar_' + screen;
var selector = document.getElementById(sel_month_limit_item_inventar);
var month_limit = selector[selector.selectedIndex].value;

var sel_year_limit_item_inventar = 'sel_year_limit_item_inventar_' + screen;
var selector = document.getElementById(sel_year_limit_item_inventar);
var year_limit = selector[selector.selectedIndex].value;

var limit_data = year_limit + '-' + month_limit + '-' + day_limit;

var txtarea_comment_item_inventar = 'txtarea_comment_item_inventar_' + screen;
var comment_item_inventar = document.getElementById(txtarea_comment_item_inventar).value;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_item_to_inventar') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_item_inventar]=\" + encodeURIComponent(name_item_inventar) + \"&data[types_item_inventar]=\" + encodeURIComponent(types_item_inventar) + \"&data[limit_data]=\" + encodeURIComponent(limit_data) + \"&data[comment_item_inventar]=\" + encodeURIComponent(comment_item_inventar) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var hidden_modal_page_inventar = 'hidden_modal_page_inventar_' + screen;

var cont = document.getElementById(hidden_modal_page_inventar);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>

<style>

textarea:focus, input:focus{
outline: none;
font-weight: bold;
}

</style>

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td colspan = \"2\" align = \"left\" style = \"padding-left: 5px; padding-right: 5px; background-color: 121212;\">
",$zagol,"
</td>
</tr>
<tr>
<td height = \"30%\" colspan = \"2\" align = \"center\" style = \"padding: 5px;\">

<table border = \"1\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td align = \"left\">
название
</td>
</tr>
<tr>
<td>
<textarea id = \"txtarea_name_item_inventar_",$screen,"\" style = \"width: 100%; height: 100%; background-color: grey; color: white; font-weight: bold;\">",$name,"</textarea>
</td>
</tr>
</table>

</td>
</tr>
<tr>
<td align = \"center\" style = \"padding: 5px;\">

<table border = \"1\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td align = \"left\">
раздел
</td>
</tr>
<tr>
<td>

<input list=\"sp_types_item_inventar_",$screen,"\" id=\"inp_type_item_inventar_",$screen,"\" style = \"width: 100%;\" value = \"",$type_bd,"\">

<datalist id=\"sp_types_item_inventar_",$screen,"\">";

#$sql = "update limit_list set type = REPLACE(type,'drug','лекарства')";
#$sql = "update limit_list set type = REPLACE(type,'reg','лицензионный список')";
#$query = mysqli_query($connection,$sql);

$sql = "select distinct(type) from limit_list";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$type = $row['type'];

echo "<option value=\"",$type,"\">";

}


}


echo "
</datalist>


</td>
</tr>
</table>

</td>
<td width = \"55%\" align = \"center\" style = \"padding: 5px;\">


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold; border: 1px solid grey;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td align = \"right\" colspan = \"3\" style = \"border-bottom: 1px solid grey;\">
срок годности
</td>
</tr>
<tr>
<td width = \"30%\">

<select id = \"sel_day_limit_item_inventar_",$screen,"\">
";



For($i=1;$i<=31;$i++)
{
$md = date('d',mktime(0,0,0,1,$i,1970));
echo "<option";

If($day_now == $md)
{
echo " selected";
}

echo " value = \"",$md,"\">",$md,"</option>";
}

echo "
</select>

</td>
<td>
<select id = \"sel_month_limit_item_inventar_",$screen,"\">
";



Foreach($ar_months_rus as $key=>$val)
{
echo "<option";

If($key == $month_now)
{
echo " selected";
}

echo " value = \"",$key,"\">",$val,"</option>";
}

echo "
</select>
</td>
<td width = \"30%\">
<select id = \"sel_year_limit_item_inventar_",$screen,"\">";

$my = date('Y');
$min_my = $my-10;
$max_my = $my+10;

For($min_my;$min_my<=$max_my;$min_my++)
{
echo "<option";
If($min_my==$year_now)
{
echo " selected";
}
echo ">",$min_my,"</option>";
}

echo "

</select>
</td>

</tr>
</table>


</td>
</tr>
<tr height = \"30%\">
<td colspan = \"2\" style = \"padding: 5px;\">

<table border = \"1\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td align = \"left\">
комментарий
</td>
</tr>
<tr>
<td>
<textarea id = \"txtarea_comment_item_inventar_",$screen,"\" style = \"width: 100%; height: 100%; background-color: grey; color: white; font-weight: bold;\">",$comment,"</textarea>
</td>
</tr>
</table>

</td>
</tr>
<tr height = \"15%\">
<td onclick = \"",$but_act,"\" colspan = \"2\" style = \"background-color: #008080;\">
принять
</td>
</tr>
</table>
<span id = \"hidden_modal_page_inventar_",$screen,"\"></span>
";


}

?>
