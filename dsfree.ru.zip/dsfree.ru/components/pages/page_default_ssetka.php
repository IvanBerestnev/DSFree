<?php

function page_default_ssetka($x)
{


echo "



<div style = \"display: flex; flex-direction: column; height: 100%; text-align: left;\">

<div class=\"cm-e-menu\" style = \"padding-top: 4px; padding-bottom: 4px;\">
<ul>



<li class=\"topmenu\">


<a>Журналы</a>

<ul class=\"submenu\">

<li onclick = \"load_page_screen('jur_pacs','",$x,"');\">
<a>
Журнал записи пациентов
</a>
</li>

<li><a>Сестринские журналы</a>

<ul class=\"submenu\">
<li><a>Журнал 1</a></li>
<li><a>Журнал 2</a></li>
</ul>

</li>

</ul>




<li class=\"topmenu\">
<a>
Клиенты
</a>

<ul class=\"submenu\">

<li onclick = \"load_page_screen('sp_clients','",$x,"','');\"><a>Список клиентов</a></li>

<li >

<a>документация</a>

<ul class=\"submenu\">

<li onclick = \"load_page_screen('primary_docums','",$x,"','');\"><a>первичная</a></li>
<li onclick = \"load_page_screen('price','",$x,"','');\"><a>прайс</a></li>

</ul>

</li>



</ul>






</li>

<li class=\"topmenu\">

<a>Персонал</a>

<ul class=\"submenu\">
<li onclick = \"load_page_screen('mass_doc_shed','",$x,"');\"><a>Массовое расписание врачей</a></li>
<li onclick = \"load_page_screen('sp_docs','",$x,"');\"><a>Список врачей</a></li>
</ul>

</li>




<li onclick = \"load_page_screen('inventar','",$x,"','');\" class=\"topmenu\">

<a>Инвентарь</a>


</li>


</ul>
</div>

<div id = \"id_f_page_default_ssetka_",$x,"\" style = \"flex-grow: 3; background-color: grey;\">

</div>

</div>



";


}

?>
