<?php

function primary_docums($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_pac = $vals['param'];


echo "
<script>

function load_primary_docums(id_pers,screen)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_primary_docums') + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_main_primary_docums = 'f_main_primary_docums_' + screen;

var cont = document.getElementById(f_main_primary_docums);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

function choice_pac_primary_docum(id_pac,screen)
{

//alert(id_pac);

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('choice_pac_primary_docum') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_main_primary_docums = 'f_main_primary_docums_' + screen;

var cont = document.getElementById(f_main_primary_docums);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function print_primary_docums(name,param,screen)
{

var name_print_primary_docums = 'name_print_primary_docums_' + screen;
var param_print_primary_docums = 'param_print_primary_docums_' + screen;

document.getElementById(name_print_primary_docums).value = name;

if(name == 'plan_treat')
{

var day_create_plan_treat = 'day_create_plan_treat_' + screen;
var e = document.getElementById(day_create_plan_treat);
var value = e.value;
var day_plan_treat = e.options[e.selectedIndex].value;


var month_create_plan_treat = 'month_create_plan_treat_' + screen;
var e = document.getElementById(month_create_plan_treat);
var value = e.value;
var month_plan_treat = e.options[e.selectedIndex].value;


var year_create_plan_treat = 'year_create_plan_treat_' + screen;
var e = document.getElementById(year_create_plan_treat);
var value = e.value;
var year_plan_treat = e.options[e.selectedIndex].value;

var date_plan_treat = day_plan_treat + '-' + month_plan_treat + '-' + year_plan_treat;

var val = param + '@' + date_plan_treat;
var param = val;
}
else if(name == 'anketa_zd')
{

var select_day_az = 'select_day_az_' + screen;
var e = document.getElementById(select_day_az);
var value = e.value;
var day_az = e.options[e.selectedIndex].value;


var select_month_az = 'select_month_az_' + screen;
var e = document.getElementById(select_month_az);
var value = e.value;
var month_az = e.options[e.selectedIndex].value;


var select_year_az = 'select_year_az_' + screen;
var e = document.getElementById(select_year_az);
var value = e.value;
var year_az = e.options[e.selectedIndex].value;

var date_az = day_az + '-' + month_az + '-' + year_az;

var val = param + '@' + date_az;
var param = val;


}



document.getElementById(param_print_primary_docums).value = param;

var print_primary_docums = 'print_primary_docums_' + screen;

document.getElementById(print_primary_docums).submit();

}


</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #242424; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: black; font-weight: bold;\" align = \"center\" height = \"3%\">
<td>
Первичная документация

<span onclick=\"trunc_screen('",$screen,"');\" class=\"but_trunc_screen\">X</span>

</td>
</tr>
<tr>
<td>

<div id = \"f_main_primary_docums_",$screen,"\" style = \"width: 100%; height: 100%;\"><div>

</td>
</tr>
</table>


<form id = \"print_primary_docums_",$screen,"\" action = \"../handle/handle.html\" method = \"post\" target=\"_self\" style = \"display: none;\">
<input type = \"hidden\" name = \"act\" value = \"print_primary_docums\">
<input type = \"hidden\" id = \"name_print_primary_docums_",$screen,"\" name = \"data[name]\" value = \"\">
<input type = \"hidden\" id = \"param_print_primary_docums_",$screen,"\" name = \"data[param]\" value = \"\">
</form>

";



If($id_pac !== "")
{


#echo "123123123";

echo "

<script>
load_primary_docums('",$id_pac,"','",$screen,"');
</script>

";



}
Else{

//вызывается из главного меню
	
#echo "123123123";

echo "<script>load_primary_docums('','",$screen,"');</script>";

}


}

?>
