<?php

function primary_docums($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_pac = $vals['param'];


echo "
<script>

function load_primary_docums(id_pers,screen)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_primary_docums') + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_main_primary_docums = 'f_main_primary_docums_' + screen;

var cont = document.getElementById(f_main_primary_docums);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

function choice_pac_primary_docum(id_pac,screen)
{

//alert(id_pac);

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('choice_pac_primary_docum') + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_main_primary_docums = 'f_main_primary_docums_' + screen;

var cont = document.getElementById(f_main_primary_docums);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function print_primary_docums(name,param,screen)
{

var name_print_primary_docums = 'name_print_primary_docums_' + screen;
var param_print_primary_docums = 'param_print_primary_docums_' + screen;

document.getElementById(name_print_primary_docums).value = name;
document.getElementById(param_print_primary_docums).value = param;

var print_primary_docums = 'print_primary_docums_' + screen;

document.getElementById(print_primary_docums).submit();

}


</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #242424; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: black; font-weight: bold;\" align = \"center\" height = \"3%\">
<td>
Первичная документация

<span onclick=\"trunc_screen('",$screen,"');\" class=\"but_trunc_screen\">X</span>

</td>
</tr>
<tr>
<td>

<div id = \"f_main_primary_docums_",$screen,"\" style = \"width: 100%; height: 100%;\"><div>

</td>
</tr>
</table>


<form id = \"print_primary_docums_",$screen,"\" action = \"../handle/handle.html\" method = \"post\" target=\"_self\" style = \"display: none;\">
<input type = \"hidden\" name = \"act\" value = \"print_primary_docums\">
<input type = \"hidden\" id = \"name_print_primary_docums_",$screen,"\" name = \"data[name]\" value = \"\">
<input type = \"hidden\" id = \"param_print_primary_docums_",$screen,"\" name = \"data[param]\" value = \"\">
</form>

";



If($id_pac !== "")
{


#echo "123123123";

echo "

<script>
load_primary_docums('",$id_pac,"','",$screen,"');
</script>

";



}
Else{

//вызывается из главного меню
	
#echo "123123123";

echo "<script>load_primary_docums('','",$screen,"');</script>";

}


}

?>
