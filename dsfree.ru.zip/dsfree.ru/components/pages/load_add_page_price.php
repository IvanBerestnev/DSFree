<?php

function load_add_page_price($vals)
{


#print_r($vals);

$name = $vals['name'];

If($name == "delete_price")
{
include_once("page_delete_price.php");
page_delete_price($vals);
}
ElseIf($name == "add_new_price")
{
include_once("add_new_price.php");
add_new_price($vals);
}
ElseIf($name == "rename_price")
{
include_once("rename_price.php");
rename_price($vals);
}
ElseIf($name == "add_new_usluga")
{
include_once("add_new_usluga.php");
add_new_usluga($vals);
}
ElseIf($name == "delete_usluga_price")
{
include_once("delete_usluga_price.php");
delete_usluga_price($vals);
}
ElseIf($name == "edit_usluga_price")
{
include_once("edit_usluga_price.php");
edit_usluga_price($vals);
}




}

?>
