<?php

function load_page_temple_razd_visit($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];
$id_writed_razd = $vals['id_writed_razd'];


echo "

<script>

function load_block_temple_razd_visit_self(id_ds,id_struct,id_razd,screen,id_writed_razd)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_temple_razd_visit_self') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[id_struct]=\" + encodeURIComponent(id_struct) + \"&data[id_razd]=\" + encodeURIComponent(id_razd) + \"&data[id_writed_razd]=\" + encodeURIComponent(id_writed_razd));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_load_page_temple_razd_visit_self = 'f_load_page_temple_razd_visit_self_' + screen;

var cont = document.getElementById(f_load_page_temple_razd_visit_self);

cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}




}

</script>


<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

";

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

//получить все шаблоны

#$sql = "select * from tab_templ_medcart where id_visit = '$id_visit'";
#$query = mysqli_query($connection,$sql);

$id_ds_writed_invisited_to_js = "";
$id_struct_writed_invisited_to_js = "";
$id_razd_intemple_to_js = "";

//далее

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$txt_treat = $row['txt_treat'];

$ar_txt_treat = json_decode($txt_treat,true);

$str_templ = $ar_txt_treat[$id_writed_razd]['templ'];

$ar_templ = explode("@",$str_templ);

If(isset($ar_templ[0]))
{
$id_struct_writed_invisited = $ar_templ[0];
}
Else{
$id_struct_writed_invisited = "";
}

If(isset($ar_templ[1]))
{
$id_razd_writed_invisited = $ar_templ[1];
}
Else{
$id_razd_writed_invisited = "";
}

If(isset($ar_templ[2]))
{
$id_ds_writed_invisited = $ar_templ[2];
}
Else{
$id_ds_writed_invisited = "";
}








$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while ($row = mysqli_fetch_assoc($query))
{
$text = $row['text'];

$text = preg_replace('/[[:cntrl:]]/', '', $text);
$ar_text = json_decode($text,true);

If(isset($ar_text[$id_ds_writed_invisited]))
{

$id_ds_writed_invisited_to_js = $id_ds_writed_invisited;
$ar_all_struct = $ar_text[$id_ds_writed_invisited];

Foreach($ar_all_struct as $id_struct_intemple=>$ar_valls_struct)
{


If($id_struct_writed_invisited == $id_struct_intemple)
{

$name_struct_intemple = $ar_valls_struct['name'];
$ar_razd_intemple = $ar_valls_struct['cont'];
$id_struct_writed_invisited_to_js = $id_struct_writed_invisited;

Foreach($ar_razd_intemple as $id_razd_intemple=>$ar_valls_razd)
{

If($id_razd_writed_invisited == $id_razd_intemple)
{

$name_razd_intemple = $ar_valls_razd['name'];
$ar_selftempl_intemple = $ar_valls_razd['cont'];
$id_razd_intemple_to_js = $id_razd_intemple;


}


}

}


}

}


}

}



#$id_struct_writed_invisited = $ar_templ[0];
#$id_razd_writed_invisited = $ar_templ[1];
#$id_ds_writed_invisited = $ar_templ[2];

#//load_block_temple_razd_visit_self(id_ds,id_struct,id_razd,'",$screen,"');

echo "
<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\" style = \"background-color: #22272B;\">
<td>
использование шаблонов
</td>
</tr>
<tr>
<td>
<div id = \"f_load_page_temple_razd_visit_self_",$screen,"\" style = \"width: 100%; height: 100%; cursor: default; background-color: #222222;\">
</div>
</td>
</tr>
</table>

<script>

load_block_temple_razd_visit_self('",$id_ds_writed_invisited_to_js,"','",$id_struct_writed_invisited_to_js,"','",$id_razd_intemple_to_js,"','",$screen,"','",$id_writed_razd,"');

</script>

";




}



#$id_ds_writed_invisited_to_js = "";
#$id_struct_writed_invisited_to_js = "";
#$id_razd_intemple_to_js = "";








}







?>
