<?php

function work_ids($id_pac,$screen)
{

$ar_types = array("general"=>"Общий раздел","terap"=>"Терапевтическая стоматология","ortoped"=>"Ортопедическая стоматология","chirurg"=>"Хирургическая стоматология","ortodont"=>"Ортодонтия","detstvo"=>"Детская стоматология");

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_misc_sets where id = 'id_avail_ids_work'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$val = $row['val'];

$ar_avail_ids_work = json_decode($val,true);

}
Else{
$ar_avail_ids_work = array("general"=>"1","terap"=>"1","ortoped"=>"1","chirurg"=>"1","ortodont"=>"1","detstvo"=>"1");
}

echo "

<script>

function load_td_field_work_ids(screen,num_field,type)
{

var num_field_underline = num_field-1;

var under_line = 'under_line_' + num_field_underline + '_' + screen;
var className = document.getElementsByClassName(under_line);
for(var index=0;index < className.length;index++){
className[index].style.display = 'none';
}


var id_under_line = 'under_line_' + num_field_underline + '_' + type + '_' + screen;
document.getElementById(id_under_line).style.display = 'inline';




var id_pac_selected = '';



if(num_field == '2')
{

var id_3_td_field_work_ids = 'id_3_td_field_work_ids_' + screen;
document.getElementById(id_3_td_field_work_ids).innerHTML = '';

var id_4_td_field_work_ids = 'id_4_td_field_work_ids_' + screen;
document.getElementById(id_4_td_field_work_ids).innerHTML = '';

var hidden_id_ids_selected = 'hidden_id_ids_selected_' + screen;
document.getElementById(hidden_id_ids_selected).innerHTML = '';

var hidden_id_dogovor_selected = 'hidden_id_dogovor_selected_' + screen;
document.getElementById(hidden_id_dogovor_selected).innerHTML = '';


}

if(num_field == '3')
{
var hidden_id_ids_selected = 'hidden_id_ids_selected_' + screen;
document.getElementById(hidden_id_ids_selected).innerHTML = type;

var hidden_id_pac_selected = 'hidden_id_pac_selected_' + screen;
var id_pac_selected = document.getElementById(hidden_id_pac_selected).innerHTML;

var id_4_td_field_work_ids = 'id_4_td_field_work_ids_' + screen;
document.getElementById(id_4_td_field_work_ids).innerHTML = '';

var hidden_id_dogovor_selected = 'hidden_id_dogovor_selected_' + screen;
document.getElementById(hidden_id_dogovor_selected).innerHTML = '';

}

if(num_field == '4')
{
var hidden_id_dogovor_selected = 'hidden_id_dogovor_selected_' + screen;
document.getElementById(hidden_id_dogovor_selected).innerHTML = type;

}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_td_field_work_ids') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[num_field]=\" + encodeURIComponent(num_field) + \"&data[id_pac_selected]=\" + encodeURIComponent(id_pac_selected));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var id_td_field_work_ids = 'id_' + num_field + '_td_field_work_ids_' + screen;

var cont = document.getElementById(id_td_field_work_ids);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"background-color: #3A3A3A;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"font-weight: bold;\">
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"33%\" style = \"cursor: pointer;\">
&#10096;
</td>
<td>
Информированное добровольное согласие
</td>
</tr>
</table>


</td>
<td>
</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"padding: 10px;\" >

<div style = \"width: 100%; height: 100%; overflow-y: scroll; \">


<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3436; \" cellpadding=\"0\" cellspacing= \"0\">";

Foreach($ar_types as $name=>$rname)
{

If($ar_avail_ids_work[$name] == "0")
{
continue;
}

echo "

<tr >
<td style = \"padding: 10px;\" height = \"120px\">

<div onclick = \"load_td_field_work_ids('",$screen,"','2','",$name,"');\" style = \"height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B; cursor: pointer; font-weight: bold; position: relative;\">

",$rname,"

<span id = \"under_line_1_",$name,"_",$screen,"\" class = \"under_line_1_",$screen,"\" style = \"position: absolute; width: 100%; height: 5px; bottom: 0px; border: 1px solid #008080; background-color: #008080; display: none;\"></span>

</div>


</td>
</tr>

";

}

echo "</table>

</div>

</td>
<td  width = \"25%\" style = \"padding: 10px; \">
<div id = \"id_2_td_field_work_ids_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2E3436; \">

</div>

</td>

<td  width = \"50%\" style = \"padding: 10px; \">


<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr >
<td height = \"50%\">

<div id = \"id_3_td_field_work_ids_",$screen,"\" style = \"width: 100%; height: 100%; \">
3
</div>

</td>
</tr>
<tr>
<td>

<div id = \"id_4_td_field_work_ids_",$screen,"\" style = \"width: 100%; height: 100%; \">
4
</div>


</td>
</tr>
</table>







</td>

</tr>
</table>


</td>
</tr>
</table>

<script>
load_td_field_work_ids('",$screen,"','2','general');
</script>

<span style = \"display: none;\" id = \"hidden_id_ids_selected_",$screen,"\"></span>
<span style = \"display: none;\" id = \"hidden_id_pac_selected_",$screen,"\">",$id_pac,"</span>
<span style = \"display: none;\" id = \"hidden_id_dogovor_selected_",$screen,"\"></span>

";





}


?>
