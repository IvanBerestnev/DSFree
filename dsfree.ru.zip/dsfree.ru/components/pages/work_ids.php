<?php

function work_ids($id_pac,$screen)
{

$ar_types = array("general"=>"Общий раздел","terap"=>"Терапевтическая стоматология","ortoped"=>"Ортопедическая стоматология","chirurg"=>"Хирургическая стоматология","ortodont"=>"Ортодонтия","detstvo"=>"Детская стоматология");

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];

$fio_pac = $surname_pac." ".$name_pac." ".$patronymic_pac;

}



$sql = "select * from tab_misc_sets where id = 'id_avail_ids_work'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$val = $row['val'];

$ar_avail_ids_work = json_decode($val,true);

}
Else{
$ar_avail_ids_work = array("general"=>"1","terap"=>"1","ortoped"=>"1","chirurg"=>"1","ortodont"=>"1","detstvo"=>"1");
}

echo "

<script>

function load_td_field_work_ids(screen,num_field,type)
{

var num_field_underline = num_field-1;

var under_line = 'under_line_' + num_field_underline + '_' + screen;
var className = document.getElementsByClassName(under_line);
for(var index=0;index < className.length;index++){
className[index].style.display = 'none';
}


var id_under_line = 'under_line_' + num_field_underline + '_' + type + '_' + screen;
document.getElementById(id_under_line).style.display = 'inline';




var id_pac_selected = '';



if(num_field == '2')
{

var id_3_td_field_work_ids = 'id_3_td_field_work_ids_' + screen;
document.getElementById(id_3_td_field_work_ids).innerHTML = '';

var id_4_td_field_work_ids = 'id_4_td_field_work_ids_' + screen;
document.getElementById(id_4_td_field_work_ids).innerHTML = '';

var id_5_td_field_work_ids = 'id_5_td_field_work_ids_' + screen;
document.getElementById(id_5_td_field_work_ids).innerHTML = '';

var hidden_id_ids_selected = 'hidden_id_ids_selected_' + screen;
document.getElementById(hidden_id_ids_selected).innerHTML = '';

var hidden_id_dogovor_selected = 'hidden_id_dogovor_selected_' + screen;
document.getElementById(hidden_id_dogovor_selected).innerHTML = '';

var hidden_id_pac_selected = 'hidden_id_pac_selected_' + screen;
var id_pac_selected = document.getElementById(hidden_id_pac_selected).innerHTML;


}

if(num_field == '3')
{
var hidden_id_ids_selected = 'hidden_id_ids_selected_' + screen;
document.getElementById(hidden_id_ids_selected).innerHTML = type;

var hidden_id_pac_selected = 'hidden_id_pac_selected_' + screen;
var id_pac_selected = document.getElementById(hidden_id_pac_selected).innerHTML;


var id_4_td_field_work_ids = 'id_4_td_field_work_ids_' + screen;
document.getElementById(id_4_td_field_work_ids).innerHTML = '';

var hidden_id_dogovor_selected = 'hidden_id_dogovor_selected_' + screen;
document.getElementById(hidden_id_dogovor_selected).innerHTML = '';

var id_5_td_field_work_ids = 'id_5_td_field_work_ids_' + screen;
document.getElementById(id_5_td_field_work_ids).innerHTML = '';



}

if(num_field == '4')
{

var id_4_td_field_work_ids = 'id_4_td_field_work_ids_' + screen;
document.getElementById(id_4_td_field_work_ids).innerHTML = '';


var id_5_td_field_work_ids = 'id_5_td_field_work_ids_' + screen;
document.getElementById(id_5_td_field_work_ids).innerHTML = '';

var hidden_id_pac_selected = 'hidden_id_pac_selected_' + screen;
var id_pac_selected = document.getElementById(hidden_id_pac_selected).innerHTML;

var hidden_id_doc_selected = 'hidden_id_doc_selected_' + screen;
document.getElementById(hidden_id_doc_selected).innerHTML = type;


var sel_cert_doc_ids = 'sel_cert_doc_ids_' + type + '_' + screen;
var selector = document.getElementById(sel_cert_doc_ids);
var cert_doc_ids = selector[selector.selectedIndex].value;


var hidden_id_cert_doc = 'hidden_id_cert_doc_' + screen;
document.getElementById(hidden_id_cert_doc).innerHTML = cert_doc_ids;


}

if(num_field == '5')
{

var hidden_id_pac_selected = 'hidden_id_pac_selected_' + screen;
var id_pac_selected = document.getElementById(hidden_id_pac_selected).innerHTML;

var hidden_id_dogovor_selected = 'hidden_id_dogovor_selected_' + screen;
document.getElementById(hidden_id_dogovor_selected).innerHTML = type;

}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_td_field_work_ids') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[num_field]=\" + encodeURIComponent(num_field) + \"&data[id_pac_selected]=\" + encodeURIComponent(id_pac_selected));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var id_td_field_work_ids = 'id_' + num_field + '_td_field_work_ids_' + screen;

var cont = document.getElementById(id_td_field_work_ids);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}

function print_ids(screen)
{

///id_ids
var hidden_id_ids_selected = 'hidden_id_ids_selected_' + screen;
var val_id_ids_selected = document.getElementById(hidden_id_ids_selected).innerHTML;

var id_form_print_ids_id_ids = 'id_form_print_ids_id_ids_' + screen;
document.getElementById(id_form_print_ids_id_ids).value = val_id_ids_selected;

//id_pac

var hidden_id_pac_selected = 'hidden_id_pac_selected_' + screen;
var val_id_pac_selected = document.getElementById(hidden_id_pac_selected).innerHTML;

var id_form_print_ids_id_pac = 'id_form_print_ids_id_pac_' + screen;
document.getElementById(id_form_print_ids_id_pac).value = val_id_pac_selected;

//id_dogovor

var hidden_id_dogovor_selected = 'hidden_id_dogovor_selected_' + screen;
var val_id_dogovor_selected = document.getElementById(hidden_id_dogovor_selected).innerHTML;

var id_form_print_ids_id_dogovor = 'id_form_print_ids_id_dogovor_' + screen;
document.getElementById(id_form_print_ids_id_dogovor).value = val_id_dogovor_selected;

//id_doc

var hidden_id_doc_selected = 'hidden_id_doc_selected_' + screen;
var val_id_doc_selected = document.getElementById(hidden_id_doc_selected).innerHTML;

var id_form_print_ids_id_doc = 'id_form_print_ids_id_doc_' + screen;
document.getElementById(id_form_print_ids_id_doc).value = val_id_doc_selected;

//cert_doc

var hidden_id_cert_doc = 'hidden_id_cert_doc_' + screen;
var cert_doc_ids = document.getElementById(hidden_id_cert_doc).innerHTML;

var id_form_print_ids_cert_doc = 'id_form_print_ids_cert_doc_' + screen;
document.getElementById(id_form_print_ids_cert_doc).value = cert_doc_ids;

//ids_selected_otherlica
var hidden_selected_id_pacs = 'hidden_selected_id_pacs_' + screen;
var ids_other_lica = document.getElementById(hidden_selected_id_pacs).innerHTML;


var id_form_print_ids_other_lica = 'id_form_print_ids_other_lica_' + screen;
document.getElementById(id_form_print_ids_other_lica).value = ids_other_lica;


///добавляем дату

///день
var sel_day_ids = 'sel_day_ids_' + screen;
var e = document.getElementById(sel_day_ids);
var val_day_ids = e.options[e.selectedIndex].value;

var id_form_print_ids_day_ids = 'id_form_print_ids_day_ids_' + screen;
document.getElementById(id_form_print_ids_day_ids).value = val_day_ids;


///месяц
var sel_month_ids = 'sel_month_ids_' + screen;
var selector = document.getElementById(sel_month_ids);
var val_month_ids = selector[selector.selectedIndex].value;

var id_form_print_ids_month_ids = 'id_form_print_ids_month_ids_' + screen;
document.getElementById(id_form_print_ids_month_ids).value = val_month_ids;


///год
var sel_year_ids = 'sel_year_ids_' + screen;
var selector = document.getElementById(sel_year_ids);
var val_year_ids = selector[selector.selectedIndex].value;

var id_form_print_ids_year_ids = 'id_form_print_ids_year_ids_' + screen;
document.getElementById(id_form_print_ids_year_ids).value = val_year_ids;



var form_print_ids = 'form_print_ids_' + screen;
document.getElementById(form_print_ids).submit();

}


function open_page_other_lica_ids(screen,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_page_other_lica_ids') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '45%';
document.getElementById(modal).style.height = '65%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}



function check_otherlica_button(screen)
{

var hidden_selected_id_pacs = 'hidden_selected_id_pacs_' + screen;
var selected_id_other_lica = document.getElementById(hidden_selected_id_pacs).innerHTML;



if(selected_id_other_lica !== '')
{

var but_check_otherlica_button = 'but_check_otherlica_button_' + screen;
document.getElementById(but_check_otherlica_button).style.backgroundColor = '#008080';
document.getElementById(but_check_otherlica_button).style.color = 'white';

}
else{

var but_check_otherlica_button = 'but_check_otherlica_button_' + screen;
document.getElementById(but_check_otherlica_button).style.backgroundColor = 'white';
document.getElementById(but_check_otherlica_button).style.color = '#3A3A3A';


}

}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"background-color: #3A3A3A;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"font-weight: bold;\">
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"33%\" style = \"cursor: pointer;\">
&#10096;
</td>
<td>
Информированное добровольное согласие
</td>
</tr>
</table>


</td>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr  style = \"font-weight: bold;\">
<td>
",$fio_pac,"
</td>

<td onclick = \"open_page_other_lica_ids('",$screen,"','",$id_pac,"');\" style = \"cursor: pointer;\">
<span id = \"but_check_otherlica_button_",$screen,"\" style = \"border: 1px solid grey; background-color: white; color: #3A3A3A;\">
представители
</span>
</td>

<td onclick=\"load_primary_docums('','",$screen,"');\" style = \"cursor: pointer;\" width = \"33%\">
X
</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"padding: 10px;\" >

<div style = \"width: 100%; height: 100%; overflow-y: scroll; \">


<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3436; \" cellpadding=\"0\" cellspacing= \"0\">";

Foreach($ar_types as $name=>$rname)
{

If($ar_avail_ids_work[$name] == "0")
{
continue;
}

echo "

<tr >
<td style = \"padding: 10px;\" height = \"120px\">

<div onclick = \"load_td_field_work_ids('",$screen,"','2','",$name,"');\" style = \"height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B; cursor: pointer; font-weight: bold; position: relative;\">

",$rname,"

<span id = \"under_line_1_",$name,"_",$screen,"\" class = \"under_line_1_",$screen,"\" style = \"position: absolute; width: 100%; height: 5px; bottom: 0px; border: 1px solid #008080; background-color: #008080; display: none;\"></span>

</div>


</td>
</tr>

";

}

echo "</table>

</div>

</td>
<td  width = \"25%\" style = \"padding: 10px; \">
<div id = \"id_2_td_field_work_ids_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2E3436; \">

</div>

</td>

<td  width = \"50%\" style = \"padding: 10px; \">


<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr >
<td height = \"33%\">

<div id = \"id_3_td_field_work_ids_",$screen,"\" style = \"width: 100%; height: 100%; \">

</div>

</td>
</tr>
<tr>
<td height = \"33%\">

<div id = \"id_4_td_field_work_ids_",$screen,"\" style = \"width: 100%; height: 100%; \">

</div>


</td>
</tr>

<tr>
<td>

<div id = \"id_5_td_field_work_ids_",$screen,"\" style = \"width: 100%; height: 100%; \">

</div>


</td>
</tr>

</table>







</td>

</tr>
</table>


</td>
</tr>
</table>

<script>
load_td_field_work_ids('",$screen,"','2','general');
</script>


<div style = \"color: white; display: none;\" id = \"hidden_selected_id_pacs_",$screen,"\"></div>


<span style = \"display: none;\" id = \"hidden_id_ids_selected_",$screen,"\"></span>
<span style = \"display: none;\" id = \"hidden_id_pac_selected_",$screen,"\">",$id_pac,"</span>
<span style = \"display: none;\" id = \"hidden_id_dogovor_selected_",$screen,"\"></span>
<span style = \"display: none;\" id = \"hidden_id_doc_selected_",$screen,"\"></span>
<span style = \"display: none;\" id = \"hidden_id_cert_doc_",$screen,"\"></span>
<span style = \"display: none;\" id = \"hidden_id_other_lica_",$screen,"\"></span>



<form id = \"form_print_ids_",$screen,"\" action = \"../handle/handle.html\" method = \"post\" target=\"_self\" style = \"display: none;\">
<input type = \"hidden\" name = \"act\" value = \"print_ids\">
<input type = \"hidden\" id = \"id_form_print_ids_id_ids_",$screen,"\" name = \"data[id_ids]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_ids_id_pac_",$screen,"\" name = \"data[id_pac]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_ids_id_dogovor_",$screen,"\" name = \"data[id_dogovor]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_ids_id_doc_",$screen,"\" name = \"data[id_doc]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_ids_cert_doc_",$screen,"\" name = \"data[cert_doc]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_ids_other_lica_",$screen,"\" name = \"data[id_other_lica]\" value = \"\">

<input type = \"hidden\" id = \"id_form_print_ids_day_ids_",$screen,"\" name = \"data[day]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_ids_month_ids_",$screen,"\" name = \"data[month]\" value = \"\">
<input type = \"hidden\" id = \"id_form_print_ids_year_ids_",$screen,"\" name = \"data[year]\" value = \"\">


</form>


";





}


?>
