<?php

function page_reset_dsfree_default_mode0()
{

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_settings');\">X</span>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
Продолжение приведет к удалению всех данных, включая аккаунты пользователей.<br>Произойдет выброс на начальную страницу.<br>Продолжить?
</td>
</tr>
<tr height = \"20%\">
<td onclick=\"close_mw('fon_modal_settings');\" width = \"50%\" style = \"background-color: #FF8080;\">
нет
</td>
<td onclick = \"act_modal_page_settings('act_reset_dsfree_default_mode0','');\" style = \"background-color: #008080;\">
да
</td>
</tr>
</table>
<span id = \"hidden_page_reset_dsfree_default_mode0\" style = \"display: none;\"></span>
";

}

?>
