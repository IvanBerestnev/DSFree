<?php

function choice_pac_primary_docum($vals)
{

#print_r($vals);
$id_pac = $vals['id_pac'];
$screen = $vals['screen'];


include_once("../components/blocks/get_info_pac_by_id_pac.php");
$info_pac = get_info_pac_by_id_pac($id_pac);
$surname_pac = $info_pac['surname_pac'];


echo "

<script>


function load_names_first_docums(type,mode,screen,id_pac)
{

if(type == '')
{
var type_names_first_docums = 'type_names_first_docums_' + screen;
var e = document.getElementById(type_names_first_docums);
var value = e.value;
var selected_type = e.options[e.selectedIndex].value;
}
else{
var selected_type = type;
}


if(mode == '')
{
var mode_names_first_docums = 'mode_names_first_docums_' + screen;
var e = document.getElementById(mode_names_first_docums);
var value = e.value;
var selected_mode = e.options[e.selectedIndex].value;
}
else{
var selected_mode = mode;
}


if(id_pac == null)
{
var id_pac = '';
}


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_names_first_docums') + \"&data[type]=\" + encodeURIComponent(selected_type) + \"&data[mode]=\" + encodeURIComponent(selected_mode) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_names_first_docums = 'f_load_names_first_docums_' + screen;

var cont = document.getElementById(f_load_names_first_docums);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}





</script>



<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: left;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"background-color: #8A969C; color: white; font-weight: bold;\">
<td colspan = \"2\" align = \"right\"><b>",$surname_pac,"</b>
<span onclick = \"load_primary_docums('','",$screen,"');\" style = \"padding-left: 15px; padding-right: 15px; color: LightSalmon; cursor: pointer; background-color: #808080;\">X</span>
</td>
</tr>
<tr>
<td width = \"25%\" style = \"background-color: #2E3336;\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td align = \"center\">

<table border = \"0\" width = \"70%\" height = \"10%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td>

<select onchange = \"load_names_first_docums(this.value,'','",$screen,"','",$id_pac,"');\" id = \"type_names_first_docums_",$screen,"\" style = \"text-align: center;\">
<option value = \"single\">отдельные</option>
<option value = \"multiple\">пакет</option>
</select>

</td>
</tr>
</table>


</td>
</tr>
<tr>
<td align = \"center\">


<table border = \"0\" width = \"70%\" height = \"10%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td>
режим
</td>
</tr>
<tr>
<td>

<select id = \"mode_names_first_docums_",$screen,"\" onchange = \"load_names_first_docums('',this.value,'",$screen,"','",$id_pac,"');\" style = \"text-align: center;\">
<option value = \"work\">рабочий</option>
<option value = \"edit\">редактирование</option>
</select>

</td>
</tr>
</table>




</td>
</tr>
</table>


</td>
<td align = \"center\" style = \"background-color: #22272B\">


<div id = \"f_load_names_first_docums_",$screen,"\" style = \"overflow-y: scroll; height: 100%; width: 100%; color: white;\">



</div>

</td>
</tr>
</table>



<script>
load_names_first_docums('single','work','",$screen,"','",$id_pac,"');
</script>

";


}

?>
