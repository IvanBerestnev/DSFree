<?php

function modal_block_act_dw_admin($vals)
{

$screen = $vals['screen'];
$id_act_dw = $vals['id_act_dw'];
$param = $vals['param'];

echo "

<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\" onclick = \"\">
Подтвердить оплату пациентом акта?
</td>
</tr>
<tr height = \"30%\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" style = \"background-color: #FF8080; color: white; cursor: pointer;\" width = \"50%\">
нет
</td>
<td onclick = \"act_block_act_dw_admin('admin_accept_pay_pacient','",$id_act_dw,"','",$screen,"');\" style = \"background-color: #008080; color: white; cursor: pointer;\">
да
</td>
</tr>
</table>

";

}

?>
