<?php

function anketa_zd($id_pac,$screen)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];

$name_pac_short = mb_substr($name_pac, 0, 1,'UTF8');
$patronymic_pac_short = mb_substr($patronymic_pac, 0, 1,'UTF8');

}


$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);



echo "

<script>

function recalc_days_in_months_az(screen)
{


///получение выбранного месяца
var select_month_az = 'select_month_az_' + screen;
var e = document.getElementById(select_month_az);
var value = e.value;
var month = e.options[e.selectedIndex].value;

///получение выбранного года
var select_year_az = 'select_year_az_' + screen;
var e = document.getElementById(select_year_az);
var value = e.value;
var year = e.options[e.selectedIndex].value;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('recalc_days_in_months_az') + \"&data[year]=\" + encodeURIComponent(year) + \"&data[month]=\" + encodeURIComponent(month) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_select_day_az = 'f_select_day_az_' + screen;

var cont = document.getElementById(f_select_day_az);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function load_default_data_az(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_default_data_az') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_full_data_az = 'f_full_data_az_' + screen;

var cont = document.getElementById(f_full_data_az);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"25%\" style = \"cursor: pointer;\">
&#10096;
</td>
<td>
Анкета о здоровье
</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
",$surname_pac," ",$name_pac," ",$patronymic_pac,"
</td>
<td style = \"cursor: pointer;\" width = \"25%\">
X
</td>
</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
<tr style = \"background-color: #22272B;\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3336; \" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>

<div style = \"border: 1px dotted grey; padding-top: 30px; padding-bottom: 30px; margin-right: 5px; margin-left: 5px;\">

Дата составления анкеты<br><br>

<span id = \"f_full_data_az_",$screen,"\"></span>

<span onclick = \"load_default_data_az('",$screen,"');\" style = \"border: 1px dotted grey; padding-left: 15px; padding-right: 15px; cursor: pointer;\">текущая дата</span>

</td>
</tr>
</table>

</td>
<td style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div style = \"width: 100%; height: 100%; overflow-y: scroll; \">

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">

";

$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac' order by data_write ASC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_dogovor = $row['id_dogovor'];
$data_dogovor = $row['data_dogovor'];

$ar_data_dogovor = explode("-",$data_dogovor);
$day = $ar_data_dogovor[2];
$month = $ar_data_dogovor[1];
$year = $ar_data_dogovor[0];

echo "
<tr onclick = \"print_primary_docums('anketa_zd','",$id_dogovor,"','",$screen,"');\" style = \"background-color: #2E3336; border: 1px solid black; cursor: pointer;\" height = \"100px\">
<td>Договор № <span style = \"background-color: white; color: black;\"> ",$id_dogovor," </span> от \"",$day,"\" ",$ar_months_rus[$month]," ",$year," г. </td></tr>
<tr style = \"background-color: #22272B;\" height = \"20px\"><td></td></tr>
";

}


}
Else{

echo "<tr><td>Нет </td></tr>";

}

echo "

</table>

</div>

</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>

</table>

<script>

load_default_data_az('",$screen,"');

</script>

";






}

?>
