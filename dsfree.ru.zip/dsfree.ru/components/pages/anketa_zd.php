<?php

function anketa_zd($id_pac,$screen)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);


$surname_pac = $row['surname_pac'];

}


echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"25%\" style = \"cursor: pointer;\">
&#10096;
</td>
<td>
Анкета о здоровье
</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
",$surname_pac,"
</td>
<td style = \"cursor: pointer;\" width = \"25%\">
X
</td>
</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
<tr style = \"background-color: #22272B;\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3336; \" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>

Дата составления анкеты<br><br>

<select>
<option>1</option>
</select>

<select>
<option>мая</option>
</select>

<select>
<option>2023</option>
</select>


</td>
</tr>
</table>

</td>
<td style = \"padding: 10px;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div style = \"width: 100%; height: 100%; overflow-y: scroll; \">

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">

";

$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac' order by data_write ASC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_dogovor = $row['id_dogovor'];
$data_dogovor = $row['data_dogovor'];

echo "
<tr onclick = \"print_primary_docums('anketa_zd','",$id_dogovor,"','",$screen,"');\" style = \"background-color: #2E3336; border: 1px solid black; cursor: pointer;\" height = \"100px\"><td>Договор № ",$id_dogovor," от ",$data_dogovor,"</td></tr>
<tr style = \"background-color: #22272B;\" height = \"20px\"><td></td></tr>
";

}


}
Else{

echo "<tr><td>Нет </td></tr>";

}

echo "

</table>

</div>

</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>

</table>

";






}

?>
