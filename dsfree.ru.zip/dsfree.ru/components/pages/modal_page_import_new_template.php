<?php

function modal_page_import_new_template($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$param = $vals['param'];
$id_pac = $vals['id_pac'];

echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

If($param == "")
{

echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td>
Выберете внешний шаблон
</td>
<tr>
<td valign = \"top\">
<div style = \"overflow-y: scroll; width: 100%; height: 100%;\">

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">

";

$dir = "../components/blocks/templates";
$scanned_directory = array_diff(scandir($dir), array('..', '.'));

Foreach($scanned_directory as $full_file)
{

include_once("../components/blocks/templates/".$full_file."");
$ar_full_file = explode(".",$full_file);
$name_file = $ar_full_file[0];
$temp_ar = $name_file();
$name = $temp_ar['name'];
$comment = $temp_ar['comment'];


echo "<tr onclick = \"modal_page_import_new_template('",$screen,"','",$full_file,"','",$id_pac,"');\"><td style = \"padding: 10px; cursor: pointer;\">";

echo $name;

echo "</td></tr>
<tr><td style = \"padding: 10px; cursor: default; color: gold;\">",

$comment

,"
</td></tr>

<tr>
<td height = \"height: 5px;\" style = \"background-color: #22272B;\">
 &nbsp; 
</td>
</tr>
";

}


echo "

</table>

</div>
</td>
</tr>
</table>

";

}
Else{

include_once("../components/blocks/templates/".$param."");

$ar_param = explode(".",$param);
$name_funct = $ar_param[0];
$temp = $name_funct();

$name = $temp['name'];
$avail_ds = $temp['avail_ds'];

echo "

<script>

function modal_act_add_external_medcart_temple(screen,id_ds,name_funct,id_pac)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('modal_act_add_external_medcart_temple') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[name_funct]=\" + encodeURIComponent(name_funct) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '45%';
document.getElementById(modal_first).style.height = '20%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function act_add_external_medcart_temple(screen,id_ds,name_funct,id_pac)
{

var id_add_external_medcart_temple = 'id_add_external_medcart_temple_' + screen;
var name_add_external_medcart_temple = document.getElementById(id_add_external_medcart_temple).value;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_external_medcart_temple') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ds]=\" + encodeURIComponent(id_ds) + \"&data[name_funct]=\" + encodeURIComponent(name_funct) + \"&data[name_ds]=\" + encodeURIComponent(name_add_external_medcart_temple));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hidden_modal_act_add_external_medcart_temple = 'hidden_modal_act_add_external_medcart_temple_' + screen;

var cont = document.getElementById(hidden_modal_act_add_external_medcart_temple);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}




</script>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td>
",$name,"
</td>
<tr>
<td valign = \"top\">
<div style = \"overflow-y: scroll; width: 100%; height: 100%;\">

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">

";


Foreach($avail_ds as $id_ds=>$name_ds)
{

echo "<tr onclick = \"modal_act_add_external_medcart_temple('",$screen,"','",$id_ds,"','",$name_funct,"','",$id_pac,"')\"><td style = \"padding: 10px; cursor: pointer;\">";

echo $name_ds;

echo "</td></tr>


<tr>
<td height = \"height: 5px;\" style = \"background-color: #22272B;\">
 &nbsp; 
</td>
</tr>
";

}


echo "

</table>

</div>
</td>
</tr>
</table>

";


}


}

?>
