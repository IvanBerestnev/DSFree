<?php

function select_price($vals)
{

$screen = $vals['screen'];
$id_visit = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_first_",$screen,"');\">X</span>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td style = \"background-color: #3A3A3A;\">
Выберете прайс
</td>
</tr>
<tr>
<td>
<div style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2E3336;\">";

$sql = "select * from price";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{
$id_price = $row['id_price'];
$name_price = $row['name_price'];

echo "<tr onclick = \"act_add_new_data_act_dw('",$id_visit,"','",$screen,"','new_act_dw','",$id_price,"');\" height = \"50px\" style = \"background-color: #808080; cursor: pointer;\"><td>",$name_price,"</td></tr><tr height = \"15px\"><td></td></tr>";


}

echo "</table>";

}


echo "
</div>
</td>
</tr>
</table>
";


}

?>
