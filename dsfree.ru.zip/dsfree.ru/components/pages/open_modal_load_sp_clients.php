<?php

function open_modal_load_sp_clients($vals)
{


#print_r($vals);

$name_page = $vals['name_page'];

If($name_page == "info_pac")
{

include_once("edit_info_pac.php");
edit_info_pac($vals);

}
ElseIf($name_page == "page_del_client")
{

include_once("page_del_client.php");
page_del_client($vals);

}


}

?>
