<?php

function page_medcart_self_add_new_razd($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];

echo "
<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>

<table border = \"0\" height =\"100%\" width = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #22272B;\">
<td height = \"20%\">
новый раздел
</td>
</tr>
<tr style = \"background-color: #222222;\">
<td>
<input id = \"page_medcart_self_add_new_razd_inp_",$screen,"\" placeholder = \"имя нового раздела\" style = \"width: 80%; height: 60%;font-weight: bold;\">
</td>
</tr>
<tr height = \"25%\" style = \"background-color: #008080; cursor:pointer;\">
<td onclick = \"act_medcart_self_add_new_razd('",$screen,"','",$id_visit,"');\">
продолжить
</td>
</tr>
</table>

";

}


?>
