<?php

function medcart_general($vals)
{

#print_r($vals);

$id_pac = $vals['param'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$surname_pac = $row['surname_pac'];
}


echo "
<script>
function page_add_new_visit(screen,param,name_docum)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_add_new_visit')+ \"&data[name_docum]=\" + encodeURIComponent(name_docum) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '20%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function load_medcart_general_sp(screen,id_pac)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_medcart_general_sp') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pac]=\" + encodeURIComponent(id_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_medcart_general = 'f_medcart_general_' + screen;

var cont = document.getElementById(f_medcart_general);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function act_add_new_visit(screen,param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_new_visit') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_medcart_general = 'f_medcart_general_' + screen;

var cont = document.getElementById(f_medcart_general);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

function edit_sp_medcart(id_visit,screen,type)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('edit_sp_medcart')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

if(type == 'data_time')
{
document.getElementById(modal).style.width = '45%';
document.getElementById(modal).style.height = '15%';
}
else if(type == 'dogovor_pmu')
{
document.getElementById(modal).style.width = '40%';
document.getElementById(modal).style.height = '35%';
}
else if(type == 'ds')
{
document.getElementById(modal).style.width = '45%';
document.getElementById(modal).style.height = '15%';
}
else if(type == 'delete_visit')
{
document.getElementById(modal).style.width = '25%';
document.getElementById(modal).style.height = '10%';
}


var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function act_sp_medcart(param,screen,name)
{

if(name == 'act_edit_sp_medcart_ds')
{

var inp_new_ds_medcart_sp = 'inp_new_ds_medcart_sp_' + screen;
var new_ds = document.getElementById(inp_new_ds_medcart_sp).value;
var merge = param + '@' + new_ds;
var param = merge;

}
else if(name == 'act_use_new_datatime_medcart_sp')
{

var id_visit = param;

var sel_hour = 'hour_razdel_medcart_sp_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_hour);
var hour = sel.options[sel.selectedIndex].value;

var sel_min = 'min_razdel_medcart_sp_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_min);
var min = sel.options[sel.selectedIndex].value;

var sel_sec = 'sec_razdel_medcart_sp_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_sec);
var sec = sel.options[sel.selectedIndex].value;


var sel_day = 'day_razdel_medcart_sp_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_day);
var day = sel.options[sel.selectedIndex].value;


var sel_month = 'month_razdel_medcart_sp_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_month);
var month_to_write = sel.options[sel.selectedIndex].value;
var month_to_view = sel.options[sel.selectedIndex].text;

var sel_year = 'year_razdel_medcart_sp_' + id_visit + '_' + screen;
var sel = document.getElementById(sel_year);
var year = sel.options[sel.selectedIndex].value;

var datetime = year + '-' + month_to_write + '-' + day + ' ' + hour + ':' + min + ':' + sec;
var id_visit = param;
var param = id_visit + '@' + datetime;

}


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_sp_medcart')+ \"&data[name]=\" + encodeURIComponent(name) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

if(name == 'act_delete_visit_medcart_sp')
{
var hidden_delete_visit_sp_medcart_self = 'hidden_delete_visit_sp_medcart_self_' + screen;
var cont = document.getElementById(hidden_delete_visit_sp_medcart_self);
}
else if(name == 'act_edit_sp_medcart_ds')
{
var hidden_edit_ds_sp_medcart = 'hidden_edit_ds_sp_medcart_' + screen;
var cont = document.getElementById(hidden_edit_ds_sp_medcart);
}
else if(name == 'act_use_new_dogovor_medcart_sp')
{
var hidden_edit_sp_medcart_dogovor_pmu = 'hidden_edit_sp_medcart_dogovor_pmu_' + screen;
var cont = document.getElementById(hidden_edit_sp_medcart_dogovor_pmu);
}
else if(name == 'act_use_new_datatime_medcart_sp')
{

var hidden_edit_sp_medcart_date_time = 'hidden_edit_sp_medcart_date_time_' + screen;
var cont = document.getElementById(hidden_edit_sp_medcart_date_time);
}

cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}



function open_page_act_dw(id_visit,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_page_act_dw')+ \"&data[id_visit]=\" + encodeURIComponent(id_visit) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '55%';
document.getElementById(modal).style.height = '60%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

</script>

<style>
.but_back_to_sp_first_docs_",$screen,":hover{
color: green;
}
</style>



<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #3A3A3A;\" height = \"5%\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick=\"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" width = \"20%\" style = \"cursor:pointer;\" class = \"but_back_to_sp_first_docs_",$screen,"\">

&#10096;

</td>
<td>

Медицинская карта. Оглавление.

</td>
</tr>
</table>

</td>
<td>


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\">
",$surname_pac,"
</td>
<td onclick = \"load_primary_docums('','",$screen,"');\" style = \"cursor: pointer;\">
X
</td>
</tr>
</table>


</td>
</tr>
</table>

</td>
</tr>
<tr style = \"background-color: #3A3A3A;\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"background-color: #2E3336;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color:#22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td align = \"center\">

<table border = \"0\" align = \"center\" width = \"95%\" height = \"90%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border: 1px solid black; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"25%\">
<td>
сортировка
</td>
</tr>
<tr height = \"33%\">
<td>

<select style = \"width: 100%; height: 80%; text-align: center; font-size: 16px; background-color: #3A3A3A; color: white; border: 0px; font-weight: bold;\">
<option>дата сначала новые</option>
</select>

</td>
</tr>
<tr>
<td style = \"background-color: #808080; cursor: pointer;\">
выбрать период
</td>
</tr>
</table>

</td>
</tr>
<tr height = \"13%\">
<td align = \"center\">

<table border = \"0\" align = \"center\" width = \"95%\" height = \"90%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border: 1px solid black; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
отобразить работы
</td>
</tr>
<tr>
<td>
<select style = \"width: 100%; height: 80%; text-align: center; font-size: 16px; background-color: #3A3A3A; color: white; border: 0px; font-weight: bold;\">
<option>всех врачей</option>
</select>
</td>
</tr>
</table>


</td>
</tr>
<tr height = \"13%\">
<td align = \"center\">

<table border = \"0\" align = \"center\" width = \"95%\" height = \"90%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border: 1px solid black; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
диагноз
</td>
</tr>
<tr>
<td>
<select style = \"width: 100%; height: 80%; text-align: center; font-size: 16px; background-color: #3A3A3A; color: white; border: 0px; font-weight: bold;\">
<option>все диагнозы</option>
</select>
</td>
</tr>
</table>


</td>
</tr>
<tr height = \"13%\">
<td align = \"center\">

<table border = \"0\" align = \"center\" width = \"95%\" height = \"90%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border: 1px solid black; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
договоры
</td>
</tr>
<tr>
<td>
<select style = \"width: 100%; height: 80%; text-align: center; font-size: 16px; background-color: #3A3A3A; color: white; border: 0px; font-weight: bold; outline: none:\">
<option>все договоры</option>
</select>
</td>
</tr>
</table>

</td>
</tr>
<tr height = \"13%\">
<td align = \"center\">

<table border = \"0\" align = \"center\" width = \"95%\" height = \"90%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border: 1px solid black; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
поиск в карте
</td>
</tr>
<tr>
<td>

<textarea style = \"width: 100%; height: 80%;\" placeholder = \"вводите для поиска\"></textarea>

</td>
</tr>
</table>

</td>
</tr>
<tr >
<td align = \"center\">

<table border = \"1\" align = \"center\" width = \"95%\" height = \"90%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #8080FF;\">
<td>
просмотр всей карты
</td>
</tr>
<tr onclick = \"page_add_new_visit('",$screen,"','",$id_pac,"','step1');\" style = \"background-color: #008080;\">
<td>

новая запись карты

</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
<td style = \"background-color: #22272B;\">
<div id = \"f_medcart_general_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
</td>
</tr>
<tr height = \"1%\">
<td>
<img width=\"50\" height=\"50\" src=\"pics/loading.gif\" alt=\"Подождите...\">
</td>
</tr>
<tr>
<td>
</td>
</tr>
</table>

</div>
</td>

</tr>
</table>

</td>
</tr>
</table>

<script>
load_medcart_general_sp('",$screen,"','",$id_pac,"');
</script>


";


}

?>
