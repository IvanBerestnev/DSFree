<?php

function open_page_edit_default_ssetka($vals)
{

#print_r($vals);


$id_used_ssetka = $vals['id_used_ssetka'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_ssetka_default where id_used_ssetka = '$id_used_ssetka' and number_cell = '$screen'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_ssetka_default = $row['id_ssetka_default'];
$param = $row['param'];
$json_default_set = $row['default_set'];
$active = $row['active'];

If($param == "jurnal_pacs")
{

$default_set = json_decode($json_default_set,true);

$ar_rus_default = array("dunit"=>"стом.установка","c_days"=>"количество дней","doc"=>"выбранный врач");

echo "
<script>

function act_ssetka_default_active(param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_ssetka_default_active') + \"&data[param]=\" + encodeURIComponent(param) + \"&data[id_ssetka_default]=\" + encodeURIComponent('",$id_ssetka_default,"'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('modal_add');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function act_change_default_param(type,val)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_change_default_param') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[val]=\" + encodeURIComponent(val) + \"&data[id_ssetka_default]=\" + encodeURIComponent('",$id_ssetka_default,"'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



}
}
}



}

</script>

<span class=\"close\" onclick=\"close_mw('fon_modal_add');\">X</span>
<table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"8%\" style = \"background-color: black; color: white; font-weight: bold;\">
<td>
Настройки по умолчанию
</td>
</tr>
<tr height = \"15%\" style = \"background-color: #575757; font-weight: bold;\">

<td >
Экран ",$screen,"
</td>
</tr>
<tr height = \"15%\" style = \"font-weight: bold; font-size: 19px;\">
<td>
<b>Журнал пациентов</b>
</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 19px;\" cellpadding=\"0\" cellspacing= \"0\">";

Foreach($default_set as $kd=>$v)
{

echo "
<tr>
<td>",$ar_rus_default[$kd],"</td>
<td>";

If($kd == "doc")
{

$sql = "select * from tab_personal";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

echo "<select onchange = \"act_change_default_param('doc',this.value);\">";

echo "<option value = \"\">все врачи</option>";

while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];
$surname = $row['surname_pers'];

echo "<option";

If($id_pers == $v)
{
echo " selected";
}

echo " value = \"",$id_pers,"\">",$surname,"</option>";

}


}




echo "</select>";


}
ElseIf($kd == "dunit")
{

echo "<select onchange = \"act_change_default_param('dunit',this.value);\">";

For($x=0;$x<=5;$x++)
{

If($x == 0)
{
$x_name = "на выбор";
$x_val = "any";
}
Else{
$x_name = $x;
$x_val = $x;
}

echo "<option";

If($x_val == $v)
{
echo " selected";
}

echo " value = \"",$x_val,"\">",$x_name,"</option>";
}

echo "</select>";
}

ElseIf($kd == "c_days")
{

echo "<select onchange = \"act_change_default_param('c_days',this.value);\">";

For($x=0;$x<=14;$x++)
{

If($x == 0)
{
$x_name = "на выбор";
$x_val = "any";
}
Else{
$x_name = $x;
$x_val = $x;
}
	
echo "<option";

If($x == $v)
{
echo " selected";
}

echo " value = \"",$x_val,"\">",$x_name,"</option>";
}

echo "</select>";
}

echo "</td>

</tr>";

}

echo "</table>


</td>
</tr>";

If($active !== "1")
{
echo "
<tr height = \"15%\" style = \"background-color: #8AE234; color: black; cursor: pointer;\">
<td onclick = \"act_ssetka_default_active('1');\">
<b>Закрепить</b>
</td>
</tr>
";
}
Else{
echo "
<tr height = \"15%\" style = \"background-color: #FF8080; color: black; cursor: pointer;\">
<td onclick = \"act_ssetka_default_active('');\">
<b>Открепить</b>
</td>
</tr>
";
}

echo "

</table>

";

}

}


}

?>
