<?php

function start_dsfree_pc()
{

include_once("../components/functions/checkexit.php");
checkexit();

include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();

#print_r($ar_vals);

$id_user_cookie = $ar_vals['id_user_cookie'];
$name_user_cookie= $ar_vals['name_user_cookie'];
$level_cookie = $ar_vals['level_cookie'];

$first_char = ucfirst(mb_substr($name_user_cookie, 0, 1));


$ar_levels_rus = array("3"=>"Суперпользователь","2"=>"Администратор","1"=>"Врач","0"=>"Медсестра");


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_used_ssetka where id_pers = '$id_user_cookie'";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
while($row = mysqli_fetch_assoc($query))
{

$id_used_ssetka = $row['id_used_ssetka'];
$used = $row['used'];

$ar_used_ssetka[$id_used_ssetka] = $used;

}

$id_used_ssetka = array_search("1", $ar_used_ssetka);

$str_used_ssetka = implode(",",array_keys($ar_used_ssetka));

#echo $str_used_ssetka;

}
Else{

$id_used_ssetka = "";

}

/*
$ar_primary_docum = array(
"Договор"=>array("от 18 лет. Пациент платит сам","от 18 лет. 3е лицо платит"),
"ИДС"=>array("Стандарт","Терапия-общая","Терапия-кариес","Терапия-эндо"),
"Акт ВР"=>array("Стандарт")
);

*/


echo "
<script>

function getXmlHttp() {
var xmlhttp;
try {
xmlhttp = new ActiveXObject(\"Msxml2.XMLHTTP\");
} catch (e) {
try {
xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");
} catch (E) {
xmlhttp = false;
}
}
if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
xmlhttp = new XMLHttpRequest();
}
return xmlhttp;
}


function start_dsfree()
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('checkexit'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var cont = document.getElementById('f_start_dsfree');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>";





echo "

<script>

function show_base_settings(param)
{

if(param == 'show')
{
document.getElementById('modal_base_settings').style.display = 'block';
}
else if(param == 'lock')
{
document.getElementById('modal_base_settings').style.display = 'none';
}

}

function show_modal_general_setting()
{
document.getElementById('fon_modal').style.display = 'block';
document.getElementById('modal').style.width = '1400px';
document.getElementById('modal').style.height = '800px';
document.getElementById('modal_base_settings').style.display = 'none';

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('show_modal_general_setting'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('modal');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}
}

function close_mw(fon)
{
document.getElementById(fon).style.display = 'none';
}


function trunc_screen(screen)
{
var id_f_page_default_ssetka = 'id_f_page_default_ssetka_' + screen;
document.getElementById(id_f_page_default_ssetka).innerHTML = '';
}



function exit_dsfree()
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('exit_dsfree'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('hid_div');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function loading_ssetka(id_used_ssetka)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('loading_ssetka') + \"&data[id_used_ssetka]=\" + encodeURIComponent(id_used_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_loading_ssetka');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function navigate_screen_ssetka(direct)
{

var now_loaded_ssetka = document.getElementById('now_loaded_ssetka').innerHTML;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('navigate_screen_ssetka') + \"&data[direct]=\" + encodeURIComponent(direct) + \"&data[now_loaded_ssetka]=\" + encodeURIComponent(now_loaded_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('now_loaded_ssetka');
cont.innerHTML = xmlhttp.responseText;

var new_used_ssetka = cont.innerHTML;

loading_ssetka(new_used_ssetka);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function load_page_screen(name_page,screen,param)
{

var main_loaded_page = 'main_loaded_page_' + name_page;

var areaOption = document.getElementById(main_loaded_page);
if (areaOption) {


var fon_modal = 'fon_modal_' + screen;
var modal = 'modal_' + screen;

document.getElementById(fon_modal).style.display = 'block';

document.getElementById(modal).style.width = '300px';
document.getElementById(modal).style.height = '100px';

document.getElementById(modal).innerHTML = \"<span class='close' onclick=close_mw(\'\"+fon_modal+\"\');>X</span><table align = 'center' width = '100%' height = '100%' style = 'background-color: #2E3436; color: lime; font-weight: bold;'><tr><td align = 'center'>Окно с подпрограммой уже открыто.</td></tr></table>\";


return false;

} else {

}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('load_page_screen') + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var id_f_page_default_ssetka = 'id_f_page_default_ssetka_' + screen;

var cont = document.getElementById(id_f_page_default_ssetka);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}
</script>

<style>

@import url(https://fonts.googleapis.com/css?family=Roboto:300);
*{
  margin: 0; padding: 0;
  font-family: 'Roboto', sans-serif;

}
.cm-e-menu {
	background-color: #222;
	position: relative;
	z-index: 1000;
	color: #fff;
	font-weight: 200;
	
	}
.cm-e-menu ul {
	margin: 0; padding: 0;
}
.cm-e-menu li {
	position: relative;
	white-space: nowrap;
	cursor: pointer;
	text-transform: capitalize !important;
	list-style: none;

	-webkit-transition: background-color ease-in 300ms;
	-moz-transition: background-color ease-in 300ms;
	-ms-transition: background-color ease-in 300ms;
	-o-transition: background-color ease-in 300ms;
	transition: background-color ease-in 300ms;
}
.cm-e-menu li:hover {
	background-color: #3d3d3d;
	text-shadow: 0 10px 10px #222;
}
.cm-e-menu ul li.topmenu {
	display: inline-table;
	padding: .3em 1em;
font-weight: bold;
margin-right: 20px;
}
.cm-e-menu .topmenu ul {
	display:none;
	position: absolute;
	background-color: #222;
	
}
.cm-e-menu li:hover > ul {
	display: table;
}
.cm-e-menu ul.submenu {
	top: 100%; left: 0;
	padding-top: .5em;
	padding-bottom: .5em;	
	box-shadow: 0 0 10px black;

}
.cm-e-menu ul.submenu .submenu {
	top: -.5em; left: 100%;
	font-size: 1em
}
.cm-e-menu ul.submenu li {
	padding: .2em 1.5em;
	font-size: .9rem;
	padding-left: .2em;
}
.cm-e-menu li.divider {
	padding: 0;
	border-top: 1px solid #343434;
	margin: .5rem auto .3rem;
	cursor: default;
}
.cm-e-menu li.divider:hover {
	background-color: transparent;
}
ul, li {
	background-image: url(\"\");
}


.close {

border-radius: 15px;

		background: #CC0000;
		color: #FFFFFF;
		line-height: 25px;
		
		position: absolute;
		right: -12px;
		text-align: center;
		top: -10px;
		width: 24px;
		text-decoration: none;
		font-weight: bold;
		
		-moz-box-shadow: 1px 1px 3px #000;
		-webkit-box-shadow: 1px 1px 3px #000;
		box-shadow: 1px 1px 3px #000;



	}

	.close:hover { background: #FF2424; cursor: pointer;}
	.close:active { background: black; }


@keyframes show{
0%{
 transform: scale(0) rotate(-45deg);
}
100% {
 transform: scale(1) rotate(0deg);
}
}


.but_trunc_screen{

float: right; 
background-color: #CC0000; 
cursor: pointer; 
padding-left: 20px; 
padding-right: 20px; 
margin-right: 3px; f
font-weight: bold;
border-radius: 15px;
}

.but_trunc_screen:hover { background: #FF2424; cursor: pointer;}
.but_trunc_screen:active { background: black; }

input {outline:none;}


</style>



<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #555753; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"75px\">
<td align = \"right\" style = \"background-color: #2E3436;\">

<span onclick = \"show_base_settings('show');\" style = \"background: #ff0000; color: #fff; padding: 5px 20px; border-radius: 50%; font-size: 35px; cursor: pointer; margin-right: 5px;\">
",$first_char,"
</span>

</td>
</tr>
<tr>
<td style = \"overflow-x: hidden; overflow-y: hidden;\">

<div id = \"f_loading_ssetka\" style = \"width: 100%; height: 100%; background-color: #555753;\"></div>

</td>
</tr>
</table>

<div id = \"modal_base_settings\" style = \"width: 250px; border: 1px solid black; position: absolute; top: 0px; right: 0px; z-index: 3000; background-color: white; display: none;\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #555753; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"50px\" align = \"center\">
<td style = \"position: relative; font-weight: bold;\">",$name_user_cookie,"
<span onclick = \"show_base_settings('lock');\" style = \"border: 1px solid black; background-color: FireBrick; color: white; font-weight: bold; padding: 10px; cursor: pointer; position: absolute; right: 5px; top: 5px;\">
х
</span>
</td>
</tr>

<tr height = \"50px\" align = \"center\">
<td>тип: 
",$ar_levels_rus[$level_cookie],"
</td>
</tr>

<tr height = \"50px\" align = \"center\">
<td>
уровень доступа: ",$level_cookie,"
</td>
</tr>

<tr align = \"center\"  style = \"cursor: pointer;\">
<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"text-align: center; border-collapse: collapse; background-color: #555753; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50px\">
<td width = \"50%\">
экран
</td>

<td onclick = \"navigate_screen_ssetka('back');\" width = \"25%\">&#9665;</td>
<td onclick = \"navigate_screen_ssetka('next');\">&#9655;</td>

</tr>
</table>


</td>
</tr>";

If($level_cookie == "3")
{

echo "
<tr height = \"50px\">
<td onclick = \"show_modal_general_setting();\" align = \"center\" style = \"cursor: pointer;\">
<b>настройки</b>
</td>
</tr>";

}




echo "
<tr onclick = \"exit_dsfree();\" height = \"50px\" align = \"center\" style = \"cursor: pointer;\">
<td>
<b>выйти из программы</b>
</td>
</tr>
</table>

</div>


<div id = \"fon_modal\" style = \"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); right: 0; bottom: 0; left: 0; margin: auto; position: fixed; z-index: 2000;  \">
<div id = \"modal\" style = \"display: block; position: fixed; top: 0%; right: 0; bottom: 0; left: 0; margin: auto; background: white; transition: 1s; animation: show 0.3s 1; animation-fill-mode: forwards;\"></div>
</div>


<div id = \"hid_div\" style = \"display: none;\"></div>

<div id = \"now_loaded_ssetka\" style = \"display: none;\">",$id_used_ssetka,"</div>


<script>
loading_ssetka('",$id_used_ssetka,"');
</script>

";




}


?>
