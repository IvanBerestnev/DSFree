<?php

function open_page_add_act_dw($vals)
{

#print_r($vals);

$name_page = $vals['name_page'];


If($name_page == "select_price")
{
include_once("select_price.php");
select_price($vals);
}

ElseIf($name_page == "add_new_usl")
{
include_once("add_new_usl.php");
add_new_usl($vals);
}

ElseIf($name_page == "page_delete_usluga_from_actdw")
{
include_once("page_delete_usluga_from_actdw.php");
page_delete_usluga_from_actdw($vals);
}




}

?>
