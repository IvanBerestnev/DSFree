<?php

function users_dsfree()
{

echo "

<script>

function load_users_dsfree()
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_users_dsfree'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_users_avail');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function add_new_user_dsfree()
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_user_dsfree'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('div_hid');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function edit_dsf_users(id_user,type,val)
{

if(type == 'pass_set')
{

var id_inp_pass_user = document.getElementById('id_inp_pass_user').value;
var id_inp_repass_user = document.getElementById('id_inp_repass_user').value;

if(id_inp_pass_user !== id_inp_repass_user)
{
document.getElementById('f_id_pass_txt').innerHTML = 'пароли должны совпадать';
return false;
}
else{
var val = id_inp_pass_user;
}



}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('edit_dsf_users') + \"&data[id_user]=\" + encodeURIComponent(id_user) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[val]=\" + encodeURIComponent(val));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('div_hid');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function open_modal_users_dsfree(txt,w,h)
{

document.getElementById('modal_add').style.width = w;
document.getElementById('modal_add').style.height = h;
document.getElementById('modal_add').innerHTML = txt;
document.getElementById('fon_modal_add').style.display = 'block';

}




</script>

<style>
input{
text-align: center;
font-size: 15px
}
</style>



<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div id = \"f_users_avail\" style = \"overflow-y:scroll; height: 100%; width: 100%;\">
</div>

</td>
</tr>
<tr height = \"15%\">
<td align = \"right\">
<span onclick = \"add_new_user_dsfree();\" style = \"border: 1px dotted black; color: white; font-weight: bold; margin-right: 15px; cursor: pointer; background-color: #373737; padding-top: 18px; padding-bottom: 18px; padding-left: 32px; padding-right: 32px; font-size: 16px;\">
Добавить нового пользователя
</span>
</td>
</tr>
</table>
<div id = \"div_hid\" style = \"display: none;\"></div>

<div id = \"fon_modal_add\" style = \"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); right: 0; bottom: 0; left: 0; margin: auto; position: fixed; z-index: 4000;\">
<div id = \"modal_add\" style = \"display: block; position: fixed; top: 0%; right: 0; bottom: 0; left: 0; margin: auto; background: white;\">


</div>
</div>

<script>
load_users_dsfree();
</script>


";

//<span class=\"close\" onclick=\"close_mw('fon_modal_add');\">X</span>



}


?>
