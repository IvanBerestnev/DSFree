<?php

function inventar($vals)
{

#print_r($vals);
$screen = $vals['screen'];



echo "

<script>

function but_enable_interval_contrl(screen,act)
{



if(act == 'enable')
{



var id_input_interval_contrl = 'id_input_interval_contrl_' + screen;
document.getElementById(id_input_interval_contrl).disabled = false;

var but_enable_interval_contrl = 'but_enable_interval_contrl_' + screen;
document.getElementById(but_enable_interval_contrl).style.display = 'none';

var but_disable_interval_contrl = 'but_disable_interval_contrl_' + screen;
document.getElementById(but_disable_interval_contrl).style.display = 'table';

var id_mode_view_inventar = 'mode_view_inventar_' + screen;
document.getElementById(id_mode_view_inventar).innerHTML = 'view_prosrok';

var div_overlay_up_ctrl = 'div_overlay_up_ctrl_' + screen;
document.getElementById(div_overlay_up_ctrl).style.display = 'inline-block';

load_block_inventar(screen,'show_limit','0');

}

else if(act == 'disable')
{



var id_input_interval_contrl = 'id_input_interval_contrl_' + screen;
document.getElementById(id_input_interval_contrl).disabled = true;

var but_enable_interval_contrl = 'but_enable_interval_contrl_' + screen;
document.getElementById(but_enable_interval_contrl).style.display = 'table';

var but_disable_interval_contrl = 'but_disable_interval_contrl_' + screen;
document.getElementById(but_disable_interval_contrl).style.display = 'none';

var id_input_interval_contrl = 'id_input_interval_contrl_' + screen;
document.getElementById(id_input_interval_contrl).value = '0';

var id_span_val_by_range_int_ctrl = 'id_span_val_by_range_int_ctrl_' + screen;
document.getElementById(id_span_val_by_range_int_ctrl).innerHTML = '0';

var id_mode_view_inventar = 'mode_view_inventar_' + screen;
document.getElementById(id_mode_view_inventar).innerHTML = 'view_all';

var div_overlay_up_ctrl = 'div_overlay_up_ctrl_' + screen;
document.getElementById(div_overlay_up_ctrl).style.display = 'none';

load_block_inventar(screen,'show_all','0');


}


}


function change_val_by_range_int_ctrl(val,screen)
{

var id_input_interval_contrl = 'id_input_interval_contrl_' + screen;
var input_interval_contrl = document.getElementById(id_input_interval_contrl).value;
var id_span_val_by_range_int_ctrl = 'id_span_val_by_range_int_ctrl_' + screen;
document.getElementById(id_span_val_by_range_int_ctrl).innerHTML = input_interval_contrl;

load_block_inventar(screen,'show_limit',val);

}

function modal_page_inventar(screen,name_page,param)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('modal_page_inventar')+ \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[name_page]=\" + encodeURIComponent(name_page) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

if(name_page == 'page_delete_item')
{
var x = '25%';
var y = '20%';
}
else if(name_page == 'open_modal_edit_type_inventar')
{
var x = '25%';
var y = '20%';
}
else{
var x = '35%';
var y = '50%';
}

document.getElementById(modal).style.width = x;
document.getElementById(modal).style.height = y;

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


function load_block_inventar(screen,type,param)
{

if(type == 'show_all')
{
var sel_choice_type_load_block_inventar = 'sel_choice_type_load_block_inventar_' + screen;
var areaOption = document.getElementById(sel_choice_type_load_block_inventar);

if (areaOption) {

var selector = document.getElementById(sel_choice_type_load_block_inventar);
var choice_type = selector[selector.selectedIndex].value;

} else {
var choice_type = '';
}


var inp_search_names_load_block_inventar = 'inp_search_names_load_block_inventar_' + screen;
var inp_search_names = document.getElementById(inp_search_names_load_block_inventar).value;

var param = inp_search_names + '@' + choice_type;
}




var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_block_inventar') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_inventar = 'f_inventar_' + screen;

var cont = document.getElementById(f_inventar);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function show_comment_block_inventar(screen,id,act)
{

var id_comment_block_inventar = 'id_comment_block_inventar_' + id + '_' + screen;

var display_now = document.getElementById(id_comment_block_inventar).style.display;

if(display_now == 'none')
{
document.getElementById(id_comment_block_inventar).style.display = 'table-cell';
}

else if(display_now == 'table-cell')
{
document.getElementById(id_comment_block_inventar).style.display = 'none';

}


}

function load_types_inventar(screen)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_types_inventar') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_types_inventar = 'f_types_inventar_' + screen;

var cont = document.getElementById(f_types_inventar);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}




}

function erase_input_field_search_inv(screen)
{
var inp_search_names_load_block_inventar = 'inp_search_names_load_block_inventar_' + screen;
document.getElementById(inp_search_names_load_block_inventar).value = '';
}




</script>


<style>

.inp_inventar_search_",$screen,"{
width: 85%;
height: 70%;
 background: transparent;
 border: none;
    border-bottom: 1px solid grey;
color: white;
font-size: 18px;
font-weight: bold;
}

.inp_inventar_search_",$screen,":focus{
outline:none;

}

.inp_inventar_search_",$screen,"::-webkit-input-placeholder {font-size:15px;}

select:focus{
outline:none;

}


.class_textarea_block_inventar_",$screen,":focus{
outline:none;

}




</style>



<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"4%\">
<td colspan = \"3\" style = \"background-color: black;\">
Инвентарь
<span onclick=\"trunc_screen('",$screen,"');\" class=\"but_trunc_screen\">X</span>
</td>
</tr>

<tr height = \"10%\">
<td width = \"15%\" rowspan = \"3\" style = \"background-color: #242424;\">
</td>

<td style = \"background-color: #22272B; position: relative;\">


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"30%\" align = \"left\">

<div onclick = \"modal_page_inventar('",$screen,"','page_add_new_item');\" style=\"background-color: #008080; cursor: pointer; height: 75%; width: 75%; display: table; text-align: center;\">
<span style=\"vertical-align: middle; display: table-cell;\">+</span>
</div>

</td>
<td>
<input id = \"inp_search_names_load_block_inventar_",$screen,"\" onkeyup = \"load_block_inventar('",$screen,"','show_all','name',this.value);\" class = \"inp_inventar_search_",$screen,"\" placeholder = \"поиск по названию\">
</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" align = \"center\">

<div onclick = \"erase_input_field_search_inv('",$screen,"'); load_block_inventar('",$screen,"','show_all');\" style=\"background-color: #FF8080; cursor: pointer; height: 75%; width: 75%; display: table;\">
<span style=\"vertical-align: middle; display: table-cell;\">х</span>
</div>

</td>
<td>

<div id = \"f_types_inventar_",$screen,"\"></div>
";


//загрузить категории

echo "

</td>
<td width = \"25%\" align = \"right\">

<div onclick = \"modal_page_inventar('",$screen,"','open_modal_edit_type_inventar','');\" style=\"background-color: #8080FF; cursor: pointer; height: 75%; width: 75%; display: table; text-align: center;\">
<span style=\"vertical-align: middle; display: table-cell;\">&#9881;</span>
</div>

</td>
</tr>
</table>

</td>
</tr>
</table>


<div id = \"div_overlay_up_ctrl_",$screen,"\" style=\"display: none; width: 100%; height: 100%;  background-color: rgba(0,0,0,0.5); top: 0; right: 0; bottom: 0; left: 0; margin: auto; position: absolute; z-index: 3000; cursor: not-allowed;\"></div>

</td>

<td width = \"15%\" rowspan = \"3\" style = \"background-color: #242424;\">
</td>

</tr>

<tr>
<td>
<div id = \"f_inventar_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #242424;\">
</div>
</td>

</tr>

<tr height = \"10%\">
<td style = \"background-color: #22272B;\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"40%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">
интервал
<br>
контроля
</td>
<td align = \"center\">

<div id = \"but_enable_interval_contrl_",$screen,"\" onclick = \"but_enable_interval_contrl('",$screen,"','enable');\" style=\"background-color: #008080; cursor: pointer; height: 75%; width: 75%; display: table;\">
<span style=\"vertical-align: middle; display: table-cell;\">вкл</span>
</div>

<div id = \"but_disable_interval_contrl_",$screen,"\" onclick = \"but_enable_interval_contrl('",$screen,"','disable');\" style=\"background-color: #FF8080; cursor: pointer; height: 75%; width: 75%; display: none;\">
<span style=\"vertical-align: middle; display: table-cell;\">выкл</span>
</div>

<span id = \"mode_view_inventar_",$screen,"\" style = \"display: none;\">mode_start</span>

</td>
</tr>
</table>

</td>
<td>

<input onchange = \"change_val_by_range_int_ctrl(this.value,'",$screen,"');\" id = \"id_input_interval_contrl_",$screen,"\" style = \"width: 75%;\" type=\"range\" id=\"volume\" name=\"volume\" min=\"0\" max=\"100\" value = \"0\" disabled>
<span id = \"id_span_val_by_range_int_ctrl_",$screen,"\">
0
</span>
 д

</td>
</tr>
</table>

</td>
</tr>

</table>
<script>
load_block_inventar('",$screen,"','show_all'); load_types_inventar('",$screen,"');
</script>
";

}

?>
