<?php

function page_print_medcart($vals)
{

#print_r($vals);

$id_visit = $vals['param'];
$screen = $vals['screen'];

echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

$locat_ds = "";
$id_struct_invisit = "";

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$id_tm = $row['id_tm'];
$txt_treat = $row['txt_treat'];

If($txt_treat !== "")
{

$ar_txt_treat = json_decode($txt_treat,true);

#print_r($ar_txt_treat);die();

Foreach($ar_txt_treat as $id_razd=>$ar_vals)
{
$str_templ = $ar_vals['templ'];
$ar_templ = explode("@",$str_templ);
$ar_id_struct[] = $ar_templ[0];

$ar_names_razd[] = $ar_vals['name'];

}

$ar_unique_id_struct = array_unique($ar_id_struct);

If(count($ar_unique_id_struct) == 1)
{
$id_struct_invisit = $ar_unique_id_struct[0];
}


}
Else{

echo "
<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #2E3436; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Нет информации для печати
</td>
</tr>
</table>
";
die();

}



If($id_tm !== "")
{

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$text = $row['text'];
$ar_decoded = json_decode($text,true);

#print_r($ar_decoded);

Foreach($ar_decoded as $ar_val)
{

Foreach($ar_val as $k_val=>$ar_v)

If($k_val == $id_struct_invisit)
{

$locat_ds = $ar_v['locat_ds'];

}

}

#echo $locat_ds;





}













}

}



If($locat_ds == "")
{

#print_r($ar_names_razd);

echo "выберете после какого раздела расположить диагноз

<select>
";

Foreach($ar_names_razd as $rzd)
{
echo "<option>",$rzd,"</option>";
}

echo "</select>";


}
Else{

#echo "печать карты с диагнозом после раздела ",$locat_ds;

echo "

<script>
close_mw('fon_modal_",$screen,"');
act_print_medcart('",$id_visit,"','",$screen,"','",$locat_ds,"');
</script>

";

}



}

?>
