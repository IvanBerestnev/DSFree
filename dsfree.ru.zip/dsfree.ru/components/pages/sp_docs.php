<?php


function sp_docs($vals)
{

#print_r($vals);

$screen = $vals['screen'];

If(isset($vals['belong']))
{
$belong = $vals['belong'];
}
Else{
$belong = "";
}


include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();
$level_cookie = $ar_vals['level_cookie'];
$int_level_cookie = (int)$level_cookie;

include_once("../components/blocks/check_permissions.php");
$permission = check_permissions($int_level_cookie,"sp_docs","");

If($permission == "disable")
{
include_once("../components/pages/page_lock.php");

$signal = page_lock();

If($signal == "stop")
{
return false;
}

}
ElseIf($permission == "read")
{
include_once("../components/pages/sp_docs_readonly.php");
sp_docs_readonly($screen,$belong);
#die();

return false;

}







echo "

<span id = \"main_loaded_page_sp_docs\" class = \"main_loaded_page\" style = \"display: none;\">opened</span>

<script>

function load_sp_doc(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sp_doc') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_sp_docs = 'f_sp_docs_' + screen;

var cont = document.getElementById(f_sp_docs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function load_cert_doc(screen,id_doc)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_cert_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_doc]=\" + encodeURIComponent(id_doc));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_certs_docs = 'f_certs_docs_' + id_doc + '_' + screen;

var cont = document.getElementById(f_certs_docs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


function add_cert_doc(screen,id_doc)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_cert_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_doc]=\" + encodeURIComponent(id_doc));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_certs_docs = 'f_certs_docs_' + id_doc + '_' + screen;

var cont = document.getElementById(f_certs_docs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

function load_view_cert(id_cert,screen,act)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_view_cert') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_cert]=\" + encodeURIComponent(id_cert) + \"&data[act]=\" + encodeURIComponent(act));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_view_cert = 'f_view_cert_' + screen + '_' + id_cert;

var cont = document.getElementById(f_view_cert);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}


function update_cert_doc(id_cert,screen,name_param,val)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('update_cert_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_cert]=\" + encodeURIComponent(id_cert) + \"&data[name_param]=\" + encodeURIComponent(name_param) + \"&data[val]=\" + encodeURIComponent(val));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


}
}
}

}


function delete_cert_doc(id_cert,screen)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('delete_cert_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_cert]=\" + encodeURIComponent(id_cert));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_view_cert = 'f_view_cert_' + screen + '_' + id_cert;


var cont = document.getElementById(f_view_cert);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}



}

function delete_doc(screen,id_pers)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('delete_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pers]=\" + encodeURIComponent(id_pers));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '60%';
document.getElementById(modal).style.height = '50%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}



function act_add_new_doc(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_add_new_doc') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_sp_docs = 'f_sp_docs_' + screen;

var cont = document.getElementById(f_sp_docs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}


function change_fio_doc(id_pers,type,val)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('change_fio_doc') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[val]=\" + encodeURIComponent(val) + \"&data[id_pers]=\" + encodeURIComponent(id_pers));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

}
}
}


}


function change_color_doc(screen,id_pers)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('change_color_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pers]=\" + encodeURIComponent(id_pers));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var fon_modal = 'fon_modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';

var modal = 'modal_' + screen;

document.getElementById(modal).style.width = '60%';
document.getElementById(modal).style.height = '50%';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"3%\" style = \"background-color: black; color: white; font-weight: bold; text-align: center; cursor: default;\">
<td>
Список врачей";

If($belong !== "y")
{
echo "<span onclick = \"trunc_screen('",$screen,"');\" class = \"but_trunc_screen\">X</span>";
}


echo "</td>
</tr>

<tr>
<td>

<div id = \"f_sp_docs_",$screen,"\" style = \"height: 100%; width: 100%; overflow-y: scroll; \"></div>

</td>
</tr>


<tr height = \"5%\" style = \"background-color: black; color: white; font-weight: bold; text-align: center;\">
<td align = \"center\">


<div onclick = \"act_add_new_doc('",$screen,"');\" style = \"width: 100px; height: 90%; background-color: green; color: white; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 20px;\">+</div>


</td>
</tr>


</table>
<script>
load_sp_doc('",$screen,"');
</script>

";



}




?>
