<?php

function screen_setka_myprofile_add($id_pers)
{

include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();

$id_user_cookie = $ar_vals['id_user_cookie'];
$name_user_cookie= $ar_vals['name_user_cookie'];
$level_cookie = $ar_vals['level_cookie'];

If($id_pers == "")
{
$id_pers = $id_user_cookie;
}


If($level_cookie == "3")
{
//3 уровень доступа. Суперпользователь. Нужен список других пользователей для управления их сеткой

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select id_user, name_user from dsf_users";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while ($row = mysqli_fetch_assoc($query))
{
$id_user = $row['id_user'];
$name_user = $row['name_user'];

$ar_users[$id_user] = $name_user;
}
}

}
Else{
$ar_users = array();
}




include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


include_once("../components/functions/tab_avail_ssetka.php");
$ar_avail_ssetka = tab_avail_ssetka();

echo "

<script>

function show_info_setka_in_addsetka(id_user)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('show_info_setka_in_addsetka') + \"&data[id_user]=\" + encodeURIComponent(id_user));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_info_profile');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

function add_profile_ssetka_user(id_ssetka)
{

var select = document.getElementById('id_sel_users_add_setka');
if(select)
{
var id_selected_user = select.options[select.selectedIndex].value;
}
else{
var id_selected_user = '",$id_pers,"';
}


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_profile_ssetka_user') + \"&data[id_user]=\" + encodeURIComponent(id_selected_user) + \"&data[id_ssetka]=\" + encodeURIComponent(id_ssetka));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_hidden');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
";

If(!empty($ar_users))
{

echo "
<tr height = \"5%\" style = \"background-color: #2E3436; color: white; font-weight: bold;\">
<td colspan = \"2\" align = \"right\" style = \"padding-right: 20px;\">
назначить для пользователя
<select onchange = \"show_info_setka_in_addsetka(this.value);\" id = \"id_sel_users_add_setka\">";

Foreach($ar_users as $id=>$name)
{
echo "<option";

If($id == $id_pers)
{
echo " selected";
}

echo " value = \"",$id,"\">",$name,"</option>";
}

echo "</select>
</td>
</tr>
";


}

echo "
<tr>
<td width = \"70%\">

<div style = \"width: 100%; height: 100%; overflow-y: scroll; border-top: 1px solid black;\">";

Foreach($ar_avail_ssetka as $id_ssetka=>$avail_ssetka)
{

echo "<table width = \"100%\" height = \"35%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; border-bottom: 1px solid black; background-color: #2E3436; \" cellpadding=\"0\" cellspacing= \"0\">";
echo "<tr><td align = \"center\">";

If(key($avail_ssetka) == "simple")
{

$name_special = $avail_ssetka['simple']['name'];

$rows = $avail_ssetka['simple']['params']['rows'];
$cols = $avail_ssetka['simple']['params']['cols'];
$spacex = $avail_ssetka['simple']['params']['spacex'];
$spacey = $avail_ssetka['simple']['params']['spacey'];

echo "<table border = \"0\" width = \"75%\" height = \"85%\" style = \"border-collapse: collapse; table-layout: fixed;\" cellpadding=\"0\" cellspacing= \"0\">";

$x=1;

For($r=1;$r<=$rows;$r++)
{
echo "<tr>";

For($c=1;$c<=$cols;$c++)
{
echo "<td align = \"center\" style = \"background-color: grey; color: white; font-weight: bold;\">",$x,"";

echo "</td>";

If($spacey !== "0")
{
If($c < $cols)
{
echo "<td width = \"10px\"></td>";
}
}

$x++;
}

echo "</tr>";

If($spacex !== "0")
{
If($r < $rows)
{
echo "<tr height = \"10px\"><td align = \"center\" colspan = \"",$cols,"\"></td></tr>";
}

}
}

echo "</table>";


}
ElseIf(key($avail_ssetka) == "special")
{

$count_tr = count($avail_ssetka['special']['params']);
$name_special = $avail_ssetka['special']['name'];
$working_cells = $avail_ssetka['special']['working_cells'];

echo "<table border = \"0\" width = \"75%\" height = \"85%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">";

$g=1;
$h=1;

For($c=0;$c<$count_tr;$c++)
{

$height = $avail_ssetka['special']['params'][$c]['height'];
$cells = $avail_ssetka['special']['params'][$c]['cells'];
If(isset($avail_ssetka['special']['params'][$c]['x'])){$x = $avail_ssetka['special']['params'][$c]['x'];}

echo "<tr height = \"",$height,"\"><td >";
echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\"><tr>";

For($td_c=0;$td_c<=$cells;$td_c++)
{

If(isset($x[$td_c]))
{
$v = $x[$td_c];
$width = " width=\"".$v."\"";
}
Else{
$width = "";
}

If(in_array($g,$working_cells))
{
echo "<td",$width," style= \"background-color: grey; font-weight: bold; color: white;\">",$h,"</td>";
$h++;
}
Else{
echo "<td",$width," ></td>";
}




$g++;
}

echo "</tr></table>";
echo "</td></tr>";

}

echo "</table>";
}



echo "
</td>

<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center;  color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
",$name_special,"
</td>
</tr>
<tr>
<td>
<span onclick = \"add_profile_ssetka_user('",$id_ssetka,"');\" style = \"padding-top: 18px; padding-bottom: 18px; padding-left: 32px; padding-right: 32px; font-size: 16px; border: 1px dotted black; cursor: pointer; background-color: #373737;\">
Добавить
</span>
</td>
</tr>
</table>


</td>


</tr>";

echo "</table>";
}




echo "
</div>

</td>
<td style = \"background-color: #2E3436; color: white;\">
<div id = \"f_info_profile\"></div>
</td>
</tr>

</table>

<div id = \"f_hidden\"></div>

<script>
show_info_setka_in_addsetka('",$id_pers,"');
</script>

";


}

?>
