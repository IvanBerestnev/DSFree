<?php

function page_create_base_set_dsfree()
{

//1 строка 3 столбца на 33%. внутри таблица на высоту 75%
//основной цвет фона #2F3436
//не согласен с условиями - FFEAEA
//согласен - BCF7BC

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_users where name_user='superuser'";
$query = mysqli_query($connection,$sql);

echo "

<script>

function getXmlHttp() {
var xmlhttp;
try {
xmlhttp = new ActiveXObject(\"Msxml2.XMLHTTP\");
} catch (e) {
try {
xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");
} catch (E) {
xmlhttp = false;
}
}
if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
xmlhttp = new XMLHttpRequest();
}
return xmlhttp;
}

function act_save_superuser()
{

var password = document.getElementById('id_pass').value;
var confirm_password = document.getElementById('id_pass_confirm').value;

if(password == '' || confirm_password == '')
{
document.getElementById('f_advice_tip').innerHTML = \"Оба поля должны быть заполнены\";

setTimeout(erase_tips, 2000);

return false;


}

if(password !== confirm_password)
{
document.getElementById('f_advice_tip').innerHTML = \"Пароли должны совпадать\";

setTimeout(erase_tips, 2000);
return false;


}


if(password.length < 3)
{
document.getElementById('f_advice_tip').innerHTML = \"Пароль должен быть от 3 символов\";

setTimeout(erase_tips, 2000);
return false;


}

var selector = document.getElementById('sel_begin_twc');
var begin = selector[selector.selectedIndex].value;

var selector = document.getElementById('sel_end_twc');
var end = selector[selector.selectedIndex].value;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('create_superuser') + \"&data[password]=\" + encodeURIComponent(password) + \"&data[begin]=\" + encodeURIComponent(begin) + \"&data[end]=\" + encodeURIComponent(end));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_advice_tip');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}
}


function erase_tips()
{
document.getElementById('f_advice_tip').innerHTML = \"\";
}

function page_create_base_set_dsfree_show(param)
{

if(param == 'agree')
{
document.getElementById('id_page_create_base_set_dsfree').style.display = 'none';
document.getElementById('id_page_create_base_set_dsfree_agree').style.display = 'block';
}


if(param == 'cancel')
{
document.getElementById('id_page_create_base_set_dsfree').style.display = 'none';
document.getElementById('id_page_create_base_set_dsfree_cancel').style.display = 'block';
}


}

function recalculate_time_work_clinic_preset(begin,end)
{

if(begin == '')
{
var selector = document.getElementById('sel_begin_twc');
var begin = selector[selector.selectedIndex].value;

}


if(end == '')
{
var selector = document.getElementById('sel_end_twc');
var end = selector[selector.selectedIndex].value;
}


var ar_begin = begin.split(':');
var hour_b = Number(ar_begin[0]);
var min_b = Number(ar_begin[1]);
var time_begin = (hour_b*60) + min_b;

var ar_end = end.split(':');
var hour_e = Number(ar_end[0]);
var min_e = Number(ar_end[1]);
var time_end = (hour_e*60) + min_e;





var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('recalculate_time_work_clinic_preset') + \"&data[begin]=\" + encodeURIComponent(time_begin) + \"&data[end]=\" + encodeURIComponent(time_end));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {
var cont = document.getElementById('f_time_work_clinic_preset');
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}





}



</script>

<style>



@media (max-width: 3840px) {
td.left_right_td {
width: 38%;
}

td#zagol_td_welcome{
font-size: 30px;
font-weight: bold;
}

td.td_welcome{
font-size: 25px;
}
}

@media (max-width: 1920px) {
td.left_right_td {
width: 20%;
}
}

</style>

<table border = \"0\" width = \"100%\" height = \"100%\" style = 
\"border-collapse: collapse; table-layout: fixed; background-color: 
#2F3436;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td class = \"left_right_td\" >
</td>
<td>

<table border = \"0\" width = \"100%\" style = \"border-collapse: 
collapse; table-layout: fixed; height: 75%;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
<div id = \"id_page_create_base_set_dsfree\" style = \"display: block; height: 100%; width: 100%; \">

<table border = \"0\" width = \"100%\" height = \"100%\" style = 
\"border-collapse: collapse; background-color: 
Gainsboro;\" cellpadding=\"5\" cellspacing= \"0\">
<tr height = \"10%\">
<td  colspan = \"3\" id = \"zagol_td_welcome\">
Добро пожаловать в DSFree!
</td>
</tr>
<tr>
<td class = \"td_welcome\" height = \"10%\" colspan = \"3\">
Для начала, cоздайте Суперпользователя, который будет иметь полный доступ ко 
всем настройкам программы. Затем, авторизуйтесь повторно используя ранее 
введенные имя и пароль.
</td>
</tr>
<tr>
<td class = \"td_welcome\" height = \"5%\" colspan = \"3\">
Перед тем, как продолжить, прочтите пожалуйста следующий текст.
</td>
</tr>
<tr>
<td class = \"td_welcome\" colspan = \"3\">
<div style = \"overflow-y: scroll; height: 100%; width: 100%; background-color: Silver; color: black;\">
Я, Берестнев Иван Владимирович, как автор программы, заявляю, что 
оставляю за собой эксклюзивное право на владение этой программы.
<br><br>
<b>Я разрешаю:</b>
<br>
1. Использовать программу в неограниченном объеме на полностью 
бесплатной основе стоматологическими клиниками.
<br>
2. Изменять программный код программы для личного использования.
<br>
<br>
<b>Я не разрешаю:</b>
<br>
1. Изменять программный код таким образом, что становится доступным 
централизованное использование неограниченным количеством клиник на 
платной основе.
<br>
2. Использовать программу и(или) ее модификации для централизованного 
использования клиниками на платной основе.
<br>
<br>
<b>Примечания:</b>
<br><br>
1. Программа создана для локального использования стоматологическими 
клиниками на собственном сервере внутри внутриклинической локальной 
сети или удаленно работниками этого учреждения.
<br>
2. Программа защищена свободной лицензией GPL v3.
</td>
</tr>
<tr height = \"8%\" align = \"center\">
<td onclick = \"page_create_base_set_dsfree_show('cancel');\" width = \"35%\" style = \"background-color: FFEAEA; font-weight: 
bold; cursor: pointer;\">
Я не согласен c условиями
</td>
<td>
</td>
<td onclick = \"page_create_base_set_dsfree_show('agree');\" width = \"35%\" style = \"background-color: BCF7BC; font-weight: bold; cursor: pointer;\">
Я согласен с условиями
</td>
</tr>
</table>

</div>

<div id = \"id_page_create_base_set_dsfree_agree\" style = \"display: none; height: 100%; width: 100%;\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = 
\"border-collapse: collapse; background-color: Gainsboro; color: black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td colspan = \"2\" align = \"\" id = \"zagol_td_welcome\" >
Создание суперпользователя и установка времени работы клиники
</td>
</tr>

<tr height = \"15%\" style = \"background-color: Silver;\">
<td colspan = \"2\" class = \"td_welcome\">
Имя пользователя -  <b>superuser</b>
</td>
</tr>

<tr height = \"5%\">
<td colspan = \"2\" class = \"td_welcome\">
Установите пароль для <b>superuser</b>
</td>
</tr>


<tr align = \"center\">
<td width = \"50%\" height = \"10%\" >

<input id = \"id_pass\" type = \"password\" style = \"width: 90%; font-size: 30px; text-align: center;\">

</td>
<td>

<input id = \"id_pass_confirm\" type = \"password\" style = \"width: 90%; font-size: 30px; text-align: center;\">

</td>
</tr>

<tr align = \"center\">
<td class = \"td_welcome\" valign = \"top\" width = \"50%\" height = \"10%\" >
пароль
</td>
<td class = \"td_welcome\" valign = \"top\">
повторите пароль
</td>
</tr>

<tr height = \"5%\">
<td class = \"td_welcome\" colspan = \"2\" align = \"center\">
<div id = \"f_advice_tip\">

</div>

</td>
</tr>

<tr>
<td class = \"td_welcome\" align = \"center\" colspan = \"2\" style = \"background-color: Silver;\">
Время работы клиники
</td>
</tr>
<tr align = \"center\">

<td id = \"f_time_work_clinic_preset\" colspan = \"2\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = 
\"border-collapse: collapse; background-color: Gainsboro; color: black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td id = \"td_begin_twc\">
<select id = \"sel_begin_twc\" onchange = \"recalculate_time_work_clinic_preset(this.value,'');\" style = \"width: 80%; height: 50%; text-align: center; font-weight: bold; font-size: 26px;\">
";

For($i=0;$i<1410;$i=$i+30)
{

$hm = date("H:i", mktime(0, $i, 0, 1, 1, 1970));

If($hm == "20:00")
{
continue;
}

echo "<option value = \"",$hm,"\"";

If($hm == "09:00")
{
echo " selected";
}

echo ">",$hm,"</option>";

}




echo "
</select>
</td>
<td id = \"td_end_twc\">
<select id = \"sel_end_twc\" onchange = \"recalculate_time_work_clinic_preset('',this.value);\" style = \"width: 80%; height: 50%; text-align: center; font-weight: bold; font-size: 26px;\">";

For($i=30;$i<1440;$i=$i+30)
{

$hm = date("H:i", mktime(0, $i, 0, 1, 1, 1970));

If($hm == "09:00")
{
continue;
}

echo "<option value = \"",$hm,"\"";

If($hm == "20:00")
{
echo " selected";
}

echo ">",$hm,"</option>";

}




echo "</select>
</td>
</tr>
</table>

</td>

</tr>


<tr height = \"10%\">
<td onclick = \"act_save_superuser();\" style = \"background-color: BCF7BC; cursor: pointer;\" class = \"td_welcome\" colspan = \"2\" align = \"center\">
Продолжить
</td>
</tr>

</table>

</div>

<div id = \"id_page_create_base_set_dsfree_cancel\" style = \"display: 
none; height: 100%; width: 100%;\">

<table border = \"1\" width = \"100%\" height = \"100%\" style = 
\"border-collapse: collapse; background-color: 
white;\" cellpadding=\"5\" cellspacing= \"0\">
<tr>
<td class = \"td_welcome\" align = \"center\">
Отменено пользователем.
<br>
Обновите страницу для повтора.
</td>
</tr>
</table>


</div>


</td>
</tr>
</table>

</td>
<td class = \"left_right_td\" >
</td>
</tr>

</table>



";

}

?>
