<?php

function act_save_new_position_ds($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_ds_income = $vals['id_ds_income'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];
$position_ds = $vals['position_ds'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];
$ar_decoded = json_decode($text,true);
#print_r($ar_decoded);

$ar_decoded[$id_ds_income][$id_str_templ]['locat_ds'] = $position_ds;

$json_ar_decoded = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);

$sql = "update tab_templ_medcart set text = '$json_ar_decoded' where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_block_position_ds('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"');
close_mw('fon_modal_",$screen,"');
</script>
";

}



}

?>
