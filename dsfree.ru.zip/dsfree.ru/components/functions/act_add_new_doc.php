<?php

function act_add_new_doc($vals)
{


function rand_color() {
    return '#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
}


$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");




$id_pers = md5(uniqid(rand(),1));
$rand_color = rand_color();



$sql = "insert into tab_personal values ('$id_pers','','','','doc','$rand_color','white','#655BC1','white')";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_sp_doc('",$screen,"');
</script>
";

}

?>
