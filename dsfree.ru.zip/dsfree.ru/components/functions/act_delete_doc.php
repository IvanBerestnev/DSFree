<?php

function act_delete_doc($vals)
{

#print_r($vals);


$screen = $vals['screen'];
$id_pers = $vals['id_pers'];
$mode = $vals['mode'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

If($mode == "mode_1")
{

$sql = "delete from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);
echo "<script>close_mw('fon_modal_",$screen,"'); load_sp_doc('",$screen,"');</script>";

}







}

?>
