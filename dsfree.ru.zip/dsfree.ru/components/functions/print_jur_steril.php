<?php

function print_jur_steril($vals)
{

#print_r($vals);

#$type_recieved = $vals['type'];
#$is_prosrok = $vals['is_prosrok'];

#$ar_is_prosrok = explode("@",$is_prosrok);
#$categ = $ar_is_prosrok[0];
#$days = $ar_is_prosrok[1];

function trim_sec($time)
{
$ar_time = explode(":",$time);
$h = $ar_time[0];
$m = $ar_time[1];
$hm = $h.":".$m;
return $hm;
}


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


include_once "../components/lib/vendor/autoload.php";

$document_with_table = new \PhpOffice\PhpWord\PhpWord();





$styleCell = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black','valign' => 'center');
$myFontStyle = array('bold' => false, 'align' => 'center', 'size' => 8);






#$date = date("Y-m-d H:i:s");

$section = $document_with_table->addSection();
$table = $section->addTable();



$sql = "select * from jur_stril order by date DESC";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

$i=0;

while($row = mysqli_fetch_assoc($query))
{

$date = $row['date'];
$obor_steril = $row['obor_steril'];
$name_izd =  $row['name_izd'];
$amount = $row['amount'];
$package = $row['package'];
$begin_ster = $row['begin_ster'];
$end_ster = $row['end_ster'];
$press = $row['press'];
$temp = $row['temp'];

$begin_ster = trim_sec($begin_ster);
$end_ster = trim_sec($end_ster);

$be_ster = $begin_ster."-".$end_ster;

#$name_izd = str_replace("\n", '<w:br/>', $name_izd);

$ar_exit[$date][$be_ster][$i]['obor_steril'] = $obor_steril;
$ar_exit[$date][$be_ster][$i]['name_izd'] = $name_izd;
$ar_exit[$date][$be_ster][$i]['amount'] = $amount;
$ar_exit[$date][$be_ster][$i]['package'] = $package;
$ar_exit[$date][$be_ster][$i]['begin_ster'] = $begin_ster;
$ar_exit[$date][$be_ster][$i]['end_ster'] = $end_ster;
$ar_exit[$date][$be_ster][$i]['press'] = $press;
$ar_exit[$date][$be_ster][$i]['temp'] = $temp;

$i++;
}


#print_r($ar_exit);die();


Foreach($ar_exit as $date=>$ar_values)
{



#echo $hrow;die();

Foreach($ar_values as $be_ster=>$ar_valls)
{

$count = count($ar_valls);

$hrow = 9500/$count;

Foreach($ar_valls as $k=>$ar_vals)
{

$obor_steril = $ar_vals['obor_steril'];
$name_izd =  $ar_vals['name_izd'];
$amount = $ar_vals['amount'];
$package = $ar_vals['package'];
$begin_ster = $ar_vals['begin_ster'];
$end_ster = $ar_vals['end_ster'];
$press = $ar_vals['press'];
$temp = $ar_vals['temp'];


$table->addRow($hrow, array("exactHeight" => true));

$table->addCell(1150, $styleCell)->addText($date,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(1250, $styleCell)->addText(htmlspecialchars($obor_steril),$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(3250, $styleCell)->addText("Набор №".htmlspecialchars($name_izd),$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(350, $styleCell)->addText($amount,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(1250, $styleCell)->addText($package,$myFontStyle,array('align' => 'center','size'=>'12'));

$table->addCell(750, $styleCell)->addText($begin_ster,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(720, $styleCell)->addText($end_ster,$myFontStyle,array('align' => 'center','size'=>'12'));

$table->addCell(850, $styleCell)->addText($press,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(800, $styleCell)->addText($temp,$myFontStyle,array('align' => 'center','size'=>'12'));

$table->addCell(1100, $styleCell)->addText();
$table->addCell(850, $styleCell)->addText();
$table->addCell(850, $styleCell)->addText();

$table->addCell(1150, $styleCell)->addText();

}





}

}









/*
$table->addRow(600, array("exactHeight" => true));

$table->addCell(1150, $styleCell)->addText($date,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(1250, $styleCell)->addText(htmlspecialchars($obor_steril),$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(4000, $styleCell)->addText("Набор №".htmlspecialchars($name_izd),$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(350, $styleCell)->addText($amount,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(1250, $styleCell)->addText($package,$myFontStyle,array('align' => 'center','size'=>'12'));

$table->addCell(700, $styleCell)->addText($begin_ster,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(720, $styleCell)->addText($end_ster,$myFontStyle,array('align' => 'center','size'=>'12'));

$table->addCell(850, $styleCell)->addText($press,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(800, $styleCell)->addText($temp,$myFontStyle,array('align' => 'center','size'=>'12'));

$table->addCell(850, $styleCell)->addText();
$table->addCell(850, $styleCell)->addText();
$table->addCell(850, $styleCell)->addText();

$table->addCell(1250, $styleCell)->addText();
*/


}


// Create writer to convert document to xml
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');



// Get all document xml code
$fullxml = $objWriter->getWriterPart('document')->write();

// Get only table xml code
$tablexml = '</w:t></w:r></w:p>'.preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml).'<w:p><w:r><w:t>';

//Open template with ${table}
$template_document = new \PhpOffice\PhpWord\TemplateProcessor("../components/download/jur_steril.docx");




// Replace mark by xml code of table
$template_document->setValue('mytable', $tablexml);
#$template_document->setValue('type', $type_recieved);
#$template_document->setValue('date', $date);
#$template_document->setValue('period', $period);


$filename = "стерилизация.docx";



$template_document->saveAs($filename);


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);


}


?>
