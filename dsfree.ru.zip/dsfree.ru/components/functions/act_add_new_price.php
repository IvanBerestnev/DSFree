<?php

function act_add_new_price($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$new_txt = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_price = md5(uniqid(rand(),1));

$sql = "insert into price values ('$id_price','$new_txt','',now())";
$query = mysqli_query($connection,$sql);


echo "
<script>
close_mw('fon_modal_first_",$screen,"');
load_block_price('','",$screen,"');
</script>
";


}

?>
