<?php

function download_epikriz($vals)
{

#print_r($vals);

$id_visit = $vals;


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


include_once "../components/lib/vendor/autoload.php";

$document_with_table = new \PhpOffice\PhpWord\PhpWord();




$tableStyle = array('borderSize' => 1, 'borderColor' => '999999');
$styleCell = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');

$styleCell_rowspan = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');

$myFontStyle = array('bold' => true, 'align' => 'center');
$myFontStyle_other = array('align' => 'center');

$date = date("Y-m-d H:i:s");

$section = $document_with_table->addSection();
$table = $section->addTable();



$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{


$row = mysqli_fetch_assoc($query);
$id_dogovor = $row['id_dogovor'];


$sql = "select * from tab_pacs_dogovors where id_dogovor = '$id_dogovor'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$rows = mysqli_fetch_assoc($query);
$data_dogovor = $rows['data_dogovor'];
$num_dog_data = $id_dogovor." от ".$data_dogovor;


$id_pac = $rows['id_pac'];

}

#echo $num_dog_data;die();

$txt_treat = $row['txt_treat'];
$ds = $row['ds'];
$date_time = $row['date_time'];
$fio_doc = $row['fio_doc'];


///////////Информация о пациенте

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);
$ar_pac = mysqli_fetch_assoc($query);

$ar_fio_pac['surname'] = $ar_pac['surname_pac'];
$ar_fio_pac['name'] = $ar_pac['name_pac'];
$ar_fio_pac['patronymic'] = $ar_pac['patronymic_pac'];
$fio_pac = implode(" ",$ar_fio_pac);



$table->addRow();
$table->addCell(11000, $styleCell)->addText(htmlspecialchars("Дата: ".$date_time),$myFontStyle,array('align' => 'left','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));
$table->addRow();
$table->addCell(800, $styleCell)->addText("",$myFontStyle_other,array('align' => 'left','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));


$ar_txt_treat = json_decode($txt_treat,true);

Foreach($ar_txt_treat as $id_razd=>$ar_valls)
{
	
$name = $ar_valls['name'];
$cont = $ar_valls['cont'];


#$name = str_replace("\n", '<w:br/>', $name);
#$ar_name = explode("\n",$text);

#$comment = str_replace("\n", '<w:br/>', $comment);

#$name = preg_replace("\n","/<br\W*?\/>/", $name);
#$comment = preg_replace("\n","/<br\W*?\/>/", $comment);
$table->addRow();
$table->addCell(11000, $styleCell)->addText($name,$myFontStyle,array('align' => 'left','size'=>'12'));


$table->addRow();
$table->addCell(800, $styleCell)->addText(htmlspecialchars($cont),$myFontStyle_other,array('align' => 'left','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));

$table->addRow();
$table->addCell(800, $styleCell)->addText("",$myFontStyle_other,array('align' => 'left','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));


If($name == $locat_ds)
{

$table->addRow();
$table->addCell(11000, $styleCell)->addText("Диагноз",$myFontStyle,array('align' => 'left','size'=>'12'));

$table->addRow();
$table->addCell(800, $styleCell)->addText(htmlspecialchars($ds),$myFontStyle_other,array('align' => 'left','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));

$table->addRow();
$table->addCell(800, $styleCell)->addText("",$myFontStyle_other,array('align' => 'left','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));

}


}



}


// Create writer to convert document to xml
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');

// Get all document xml code
$fullxml = $objWriter->getWriterPart('document')->write();

// Get only table xml code
$tablexml = '</w:t></w:r></w:p>'.preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml).'<w:p><w:r><w:t>';

//Open template with ${table}
$template_document = new \PhpOffice\PhpWord\TemplateProcessor("../components/download/epikriz.docx");



// Replace mark by xml code of table
$template_document->setValue('mytable', $tablexml);

$template_document->setValue('date_visit', $date_time);
$template_document->setValue('fio_pac', $fio_pac);



$filename = "Эпикриз ".$fio_pac.".docx";
$template_document->saveAs($filename);


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);




}

?>
