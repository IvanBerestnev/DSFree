<?php

function save_new_msd($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$msd_dtime = $vals['msd_dtime'];
$month = $vals['month'];
$year = $vals['year'];
$unit = $vals['unit'];
$days = $vals['days'];

$ar_days = explode(",",$days);


$ar_msd_dtime = explode("@",$msd_dtime);


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



Foreach($ar_msd_dtime as $dtime)
{

$ar_dtime = explode("#",$dtime);

$id_doc = $ar_dtime[0];
$space_per_time = $ar_dtime[1];

$ar_space_per_time = explode(" - ",$space_per_time);

$str_per_time = $ar_space_per_time[0]."-".$ar_space_per_time[1];

#$ar_msd[$id_doc] = $str_per_time;

Foreach($ar_days as $day)
{

$date = $year."-".$month."-".$day;

$id_shedule = md5(uniqid(rand(),1));

$sql = "insert into tab_shedule_pers values ('$id_shedule','$id_doc','$date','$unit','$str_per_time')";
$query = mysqli_query($connection,$sql);


}


}


}

?>
