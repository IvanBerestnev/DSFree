<?php

function change_fio_doc($vals)
{

$type = $vals['type'];
$val = $vals['val'];
$id_pers = $vals['id_pers'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update tab_personal set $type = '$val' where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);


}

?>
