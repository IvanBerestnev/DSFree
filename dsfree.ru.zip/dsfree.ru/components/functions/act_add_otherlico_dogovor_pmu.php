<?php

function act_add_otherlico_dogovor_pmu($vals)
{

#print_r($vals);

$id_other_lico = $vals['id_other_lico'];
$id_pac = $vals['id_pac'];
$screen = $vals['screen'];
$id_dog = $vals['id_dog'];

If($id_other_lico == "")
{
$id_other_lico = "self";
}


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



$sql = "update tab_pacs_dogovors set whopaid = '$id_other_lico' where id_dogovor = '$id_dog'";
$query = mysqli_query($connection,$sql);

echo "
<script>

all_dogovor_pmu('",$id_pac,"','",$screen,"');
var fon_modal = 'fon_modal_' + '",$screen,"';
close_mw(fon_modal);
</script>
";


}

?>
