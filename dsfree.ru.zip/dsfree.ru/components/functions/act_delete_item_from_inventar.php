<?php

function act_delete_item_from_inventar($vals)
{

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_item = $vals['id_item'];
$screen = $vals['screen'];

$sql = "delete from limit_list where id = '$id_item'";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_block_inventar('",$screen,"','show_all','');
load_types_inventar('",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>
";

}


?>
