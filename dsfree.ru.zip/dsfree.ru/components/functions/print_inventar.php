<?php

function print_inventar($vals)
{

#print_r($vals);

$type_recieved = $vals['type'];
$is_prosrok = $vals['is_prosrok'];

$ar_is_prosrok = explode("@",$is_prosrok);
$categ = $ar_is_prosrok[0];
$days = $ar_is_prosrok[1];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


include_once "../components/lib/vendor/autoload.php";

$document_with_table = new \PhpOffice\PhpWord\PhpWord();

$tableStyle = array('borderSize' => 1, 'borderColor' => '999999');
$styleCell = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');

$styleCell_rowspan = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');

$myFontStyle = array('bold' => true, 'align' => 'center');
$myFontStyle_other = array('align' => 'center');

$date = date("Y-m-d H:i:s");

$section = $document_with_table->addSection();
$table = $section->addTable();


$ar_sql = array();

If($type_recieved == "")
{

}
Else{
$ar_sql[] = " type = '".$type_recieved."'";
}

If($categ == "print_all")
{
$date_now = date('Y-m-d');

$period = "Показаны все позиции";

}
Else{

$Date = date('Y-m-d');

$date_now = date('Y-m-d', strtotime($Date. ' + '.$days.' days'));

$ar_sql[] = " DATE(limit_list.limit) <= \"".$date_now."\"";

$period = "Показаны просроченные позиции до даты (включительно) ".$date_now;

}

If(count($ar_sql) > 0)
{
$add_sql = " where ".implode(" and ",$ar_sql);
}
Else{
$add_sql = "";
}


$sql = "select * from limit_list".$add_sql." order by name ASC";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{
$i=1;

$table->addRow();
$table->addCell(800, $styleCell)->addText('№',$myFontStyle,array('align' => 'center','bold' => true));
$table->addCell(1700, $styleCell)->addText('срок годн',$myFontStyle,array('align' => 'center','bold' => true));
$table->addCell(6000, $styleCell)->addText('название',$myFontStyle,array('align' => 'center','bold' => true));

$table->addCell(2000, $styleCell)->addText('категория',$myFontStyle,array('align' => 'center','bold' => true));

$table->addCell(5500, $styleCell)->addText('комментарий',$myFontStyle,array('align' => 'left','bold' => true));


while($row = mysqli_fetch_assoc($query))
{

$name = $row['name'];
$comment = $row['comment'];
$limit = "до ".$row['limit'];

$type = $row['type'];

$name = str_replace("\n", '<w:br/>', $name);
#$ar_name = explode("\n",$text);

$comment = str_replace("\n", '<w:br/>', $comment);

#$name = preg_replace("\n","/<br\W*?\/>/", $name);
#$comment = preg_replace("\n","/<br\W*?\/>/", $comment);


$table->addRow();
$table->addCell(800, $styleCell)->addText($i,$myFontStyle_other,array('align' => 'center','size'=>'12'));
$table->addCell(1700, $styleCell)->addText($limit,$myFontStyle_other,array('align' => 'center','size'=>'12'));
$table->addCell(6000, $styleCell)->addText($name,$myFontStyle_other,array('align' => 'left','size'=>'12'));

$table->addCell(2000, $styleCell)->addText($type,$myFontStyle_other,array('align' => 'center','size'=>'12'));

$table->addCell(5500, $styleCell)->addText($comment,$myFontStyle_other,array('align' => 'left','size'=>'12'));


$i++;
}

}


// Create writer to convert document to xml
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');

// Get all document xml code
$fullxml = $objWriter->getWriterPart('document')->write();

// Get only table xml code
$tablexml = '</w:t></w:r></w:p>'.preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml).'<w:p><w:r><w:t>';

//Open template with ${table}
$template_document = new \PhpOffice\PhpWord\TemplateProcessor("../components/download/inventar.docx");


If($type_recieved == "")
{
$type_recieved = "все категории";
}


// Replace mark by xml code of table
$template_document->setValue('mytable', $tablexml);
$template_document->setValue('type', $type_recieved);
$template_document->setValue('date', $date);
$template_document->setValue('period', $period);


$filename = "Инвентаризация.docx";
$template_document->saveAs($filename);


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);


}


?>
