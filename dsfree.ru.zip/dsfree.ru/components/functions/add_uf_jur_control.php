<?php

function add_uf_jur_control($vals)
{

$id_room = $vals['id_room'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_misc_sets where id = '5'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['val'];
$arr = json_decode($json_arr,true);

}


$id_uf = md5(uniqid(rand(),1));

$arr[$id_room]['ufs'][$id_uf]['device_type'] = "closed";
$arr[$id_room]['ufs'][$id_uf]['docum'] = "Акт ввода в эксплуатацию № от";
$arr[$id_room]['ufs'][$id_uf]['siz'] = "Не предусмотрено";
$arr[$id_room]['ufs'][$id_uf]['limit'] = "8000";
$arr[$id_room]['ufs'][$id_uf]['place'] = "Над дверным проемом";

$str_json = json_encode($arr, JSON_UNESCAPED_UNICODE);


$sql = "update tab_misc_sets set val = '$str_json' where id = '5'";
$query = mysqli_query($connection,$sql);

}

?>
