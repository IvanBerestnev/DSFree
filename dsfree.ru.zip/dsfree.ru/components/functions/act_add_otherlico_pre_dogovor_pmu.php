<?php

function act_add_otherlico_pre_dogovor_pmu($vals)
{

#print_r($vals);
$id_pac = $vals['id_pac'];
$id_other_lico = $vals['id_other_lico'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac = '$id_other_lico'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$surname_pac = $row['surname_pac'];

}

echo "

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"background-color: #008080; color: white;\">
",$surname_pac,"
</td>
<td onclick = \"reset_who_paid('",$screen,"'); change_val_selected_whopaid_dog_pmu('",$screen,"','self');\" width = \"20%\" style = \"background-color: #FF8080; color: white;\">
х
</td>
</tr>
</table>


<script>

var fon_modal = 'fon_modal_' + '",$screen,"';
close_mw(fon_modal);




</script>
";

}

?>
