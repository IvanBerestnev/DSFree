<?php

function author_site($vals)
{

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$name_auth = $vals['name_auth'];
$pass_auth = $vals['pass_auth'];

If($pass_auth == "" or $name_auth == "")
{
include_once("../components/blocks/txt_messgs.php");
$ext_ar = txt_messgs("wrong_pass_empty");

$messg = $ext_ar['txt'];
$w = $ext_ar['w'];
$h = $ext_ar['h'];

echo "<script>show_txt_modal('",$messg,"','",$w,"','",$h,"');</script>";
die();
}

$hash_pass = md5($pass_auth);

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_users where name_user = '$name_auth' and password_user = '$hash_pass'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
//Авторизация удалась. Имя и пароль совпадают. Получаем данные пользователя.

$row = mysqli_fetch_assoc($query);
$id_cookie = md5(uniqid(rand(),1));
$id_user = $row['id_user'];

//Проверка, отключен ли пользователь. Если отключен, то завершаем авторизацию
$used = $row['used'];
If($used == "0")
{
include_once("../components/blocks/txt_messgs.php");
$ext_ar = txt_messgs("user_disable_auth");

$messg = $ext_ar['txt'];
$w = $ext_ar['w'];
$h = $ext_ar['h'];

echo "<script>show_txt_modal('",$messg,"','",$w,"','",$h,"');</script>";
die();
}


//Прежде чем добавить новую записи - удалим старые с id пользователя и еще проверим все на срок давности. Что выше часа - удаляем.

$sql = "delete from auths where id_user = '$id_user'";
$query = mysqli_query($connection,$sql);

//И добавляем новую запись

$sql = "insert into auths values ('$id_cookie','$id_user',now())";
$query = mysqli_query($connection,$sql);

setcookie("dsf_cookie", $id_cookie, time()+3600, "/", "");

echo "<meta http-equiv=\"refresh\" content=\"0\">";

}
Else{

//echo "<meta http-equiv=\"refresh\" content=\"0\">";
include_once("../components/blocks/txt_messgs.php");
$ext_ar = txt_messgs("wrong_password");

$messg = $ext_ar['txt'];
$w = $ext_ar['w'];
$h = $ext_ar['h'];

echo "<script>show_txt_modal('",$messg,"','",$w,"','",$h,"');</script>";
die();

}

}

?>
