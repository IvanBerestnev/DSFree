<?php

function write_new_jur_stril($vals)
{

#print_r($vals);



$screen = $vals['screen'];
$day = $vals['day'];
$month = $vals['month'];
$year = $vals['year'];
$time_b = $vals['time_b'];
$time_e = $vals['time_e'];
$autoclav = $vals['autoclav'];
$izd = $vals['izd'];
$mode = $vals['mode'];

//раскладка режима
$ar_mode = explode(" + ",$mode);
$temp = $ar_mode[0];
$press = $ar_mode[1];

//раскладка изделий
$ar_izd = explode("#",$izd);


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


//Получение сведений о всех изделиях в наборах
$sql = "select * from tab_steril_kit";
$query = mysqli_query($connection,$sql);

while($row = mysqli_fetch_assoc($query))
{
$name_short = $row['name_short'];
$items = $row['items'];
$pso_available = $row['pso_available'];

$ar_items = explode(", ",$items);

Foreach($ar_items as $itm)
{
$ar_itm[$name_short][] = $itm;

$ar_pso_available[$itm] = $pso_available;

}





}

#print_r($ar_pso_available);die();


//Получение сведений о препарате теста, базовом методе дезинфекции и его исключениях
$sql = "select * from tab_misc_sets where id = '4'";
$query = mysqli_query($connection,$sql);
$row = mysqli_fetch_assoc($query);
$val = $row['val'];
$arr = json_decode($val,true);
//получение базового и противоположенного метода дезинфекции
$default_method = $arr['method']['default'];
$ar_all_methods = array("man","mech");
$ar_all_methods_base = array("man"=>"ручной","mech"=>"механический");
#unset($ar_all_methods[$default_method]);

if (($key = array_search($default_method, $ar_all_methods)) !== false) {
    unset($ar_all_methods[$key]);
}

#print_r($ar_all_methods);die();

$ar_all_methods_recalc = array_values($ar_all_methods);
$oppisite_method = $ar_all_methods_recalc[0];

#echo $default_method;
#echo $oppisite_method;
#die();

//получение нужного препарата
$count_default_azopiram = $arr['azopiram']['default'];
$agent = $arr['azopiram']['names'][$count_default_azopiram];
//получение списка исключений
$bd_excludes = $arr['method']['excludes'];

$ar_all_excludes = array();

Foreach($bd_excludes as $excl)
{

If(isset($ar_itm[$excl]))
{

$itms = $ar_itm[$excl];

Foreach($itms as $is)
{

$ar_all_excludes[] = $is;

}

}


}

#print_r($ar_all_excludes);die();

#print_r($ar_itm);die();


$date = $year."-".$month."-".$day;

Foreach($ar_izd as $str_izd)
{

$id = md5(uniqid(rand(),1));

$ar_str_izd = explode("@",$str_izd);
$name_izd = $ar_str_izd[0];
$count_izd = $ar_str_izd[1];
$pakage_izd = $ar_str_izd[2];

$sql = "insert into jur_stril value ('$id','$date','$autoclav','$name_izd','$count_izd','$pakage_izd','$time_b','$time_e','$temp','$press')";
#$query = mysqli_query($connection,$sql);

$arr_all_items = $ar_itm[$name_izd];


For($c=1;$c<=$count_izd;$c++)
{

Foreach($arr_all_items as $aitems)
{
$ar_all_items_simple[] = $aitems;
}

}





}


$array_frequency = array_count_values($ar_all_items_simple);

#print_r($array_frequency);die();

Foreach($array_frequency as $i=>$c)
{

If($c>3)
{
$c = "3";

$ar_new_freq[$i] = $c;
}
Else{
$ar_new_freq[$i] = $c;
}

}


#print_r($ar_new_freq);die();

Foreach($ar_new_freq as $item=>$count_item)
{

If(in_array($item,$ar_all_excludes))
{
$ar_itog[$item]['count'] = $count_item;
$ar_itog[$item]['method'] = $oppisite_method;

#echo $default_method;
#echo $oppisite_method;

}
Else{

$ar_itog[$item]['count'] = $count_item;
$ar_itog[$item]['method'] = $default_method;


}

}

#print_r($ar_itog);die();

Foreach($ar_itog as $name_izd=>$ar_valls)
{

$method = $ar_valls['method'];
$count_izd = $ar_valls['count'];
$id = md5(uniqid(rand(),1));

If(isset($ar_pso_available[$name_izd]))
{

$az_yn = $ar_pso_available[$name_izd];

If($az_yn == "y")
{
$sql = "insert into jur_pso value ('$id','$date','$ar_all_methods_base[$method]','$agent','$name_izd','$count_izd')";
$query = mysqli_query($connection,$sql);
}

}




}


echo "
<script>
load_jur_steril('",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>
";


}

?>
