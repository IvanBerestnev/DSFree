<?php

function act_set_doc_medcart_self($vals)
{

#print_r($vals);

$id_visit = $vals['id_visit'];
$fio_doc = $vals['id_writed_razd'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "update pacs_visits set fio_doc = '$fio_doc' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If($fio_doc == "")
{
$fio_doc_view = "врач не выбран";
}
Else{
$fio_doc_view = $fio_doc;
}

echo "
<script>
var span_fio_doc_medcart_self = 'span_fio_doc_medcart_self_",$screen,"';
document.getElementById(span_fio_doc_medcart_self).innerHTML = '",$fio_doc_view,"';
close_mw('fon_modal_",$screen,"');
</script>
";


}

?>
