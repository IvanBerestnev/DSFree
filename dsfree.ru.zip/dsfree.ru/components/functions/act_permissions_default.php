<?php

function act_permissions_default($vals)
{

#print_r($vals);


$id_permission = $vals['id_permission'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


include_once("../components/functions/tab_permissions_default.php");
$ar = tab_permissions_default();


$ar_encode = json_encode($ar, JSON_UNESCAPED_UNICODE);

#$ar_encode = json_decode($json_val,true);
$sql = "select * from tab_permissions where id_permission = '$id_permission'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$sql = "update tab_permissions values permissions = '$ar_encode' where id_permission = '$id_permission'";
$query = mysqli_query($connection,$sql);
}
Else{
$sql = "insert into tab_permissions values ('$id_permission','$ar_encode')";
$query = mysqli_query($connection,$sql);

}






echo "

<script>

document.getElementById('fon_modal_gen_settings').style.display = 'none';
load_settings('permissions','');

</script>

";

}

?>

