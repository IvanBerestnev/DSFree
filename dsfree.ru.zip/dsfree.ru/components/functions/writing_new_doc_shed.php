<?php

function writing_new_doc_shed($vals)
{

$screen = $vals['screen'];
$beg = $vals['beg'];
$end = $vals['end'];
$id_pers = $vals['id_pers'];
$date = $vals['date'];
$unit = $vals['unit'];

function convert_time_to_min($time_norm)
{
$ar_t_b = explode(":",$time_norm);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];
$time_b = ($hb*60)+$mb;
return $time_b;
}

$min_beg = convert_time_to_min($beg);
$min_end = convert_time_to_min($end);


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$ar_time_shed_bd = array();

$sql = "select * from tab_shedule_pers where date = '".$date."' and (time like '%".$beg."%' or time like '%".$end."%') and unit = '$unit' and id_pers = '$id_pers' order by date ASC;";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_shed = $row['id_shedule'];
$time = $row['time'];

$ar_time = explode("-",$time);

$ar_id_shed[] = $id_shed;

Foreach($ar_time as $t)
{

$t_min = convert_time_to_min($t);

$ar_time_shed_bd[] = $t_min;

}


$ar_time = array();

}



}



If(isset($ar_time_shed_bd))
{
$ar_time_shed_bd[] = $min_beg;
$ar_time_shed_bd[] = $min_end;

asort($ar_time_shed_bd);
}



$mini = min($ar_time_shed_bd);
$maxi = max($ar_time_shed_bd);

If(isset($ar_id_shed))
{

$str_id_shed = implode("','",$ar_id_shed);
$sql = "delete from tab_shedule_pers where id_shedule IN('$str_id_shed')";
$query = mysqli_query($connection,$sql);


}



$id_shedule = md5(uniqid(rand(),1));

$t_mini = date("H:i", mktime(0, $mini, 0, 1, 1, 1970));
$t_maxi = date("H:i", mktime(0, $maxi, 0, 1, 1, 1970));

$new_time = $t_mini."-".$t_maxi;

$sql = "insert into tab_shedule_pers values ('$id_shedule','$id_pers','$date','$unit','$new_time')";
#echo $sql;
$query = mysqli_query($connection,$sql);




echo "
<script>

reload_jurpacs_cell_colors('",$screen,"');

var first_date_jur = 'first_date_jur_",$screen,"';
var fdj = document.getElementById(first_date_jur).innerHTML;
var ar_fdj = fdj.split('.');
var n_time_js = ar_fdj.join('-');
send_date_from_cal_to_jurpacs(n_time_js,'",$screen,"');



close_mw('fon_modal_",$screen,"');
</script>
";

#print_r($ar_time_shed_bd);


}

?>
