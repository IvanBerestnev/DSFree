<?php

function add_cert_doc($vals)
{


$screen = $vals['screen'];
$id_doc = $vals['id_doc'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_cert = md5(uniqid(rand(),1));

$sql = "insert into tab_docs_cert values ('$id_cert','$id_doc','',now())";
$query = mysqli_query($connection,$sql);

echo "

<script>load_cert_doc('",$screen,"','",$id_doc,"');</script>

";


}

?>
