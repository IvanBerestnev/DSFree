<?php

function delete_ssetka_from_profile($vals)
{

$id_used_ssetka = $vals['id_used_ssetka'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_used_ssetka where id_used_ssetka = '$id_used_ssetka'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_pers = $row['id_pers'];
$used = $row['used'];

$sql = "delete from tab_used_ssetka where id_used_ssetka = '$id_used_ssetka'";
$query = mysqli_query($connection,$sql);

If($used == "1")
{

$sql = "select * from tab_used_ssetka where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$id=0;
while($row_next = mysqli_fetch_assoc($query))
{



$ar_ids[] = $row_next['id_used_ssetka'];
$id++;
}



$id_used_ssetka_new = end($ar_ids);

$sql = "update tab_used_ssetka set used = '1' where id_used_ssetka = '$id_used_ssetka_new'";
$query = mysqli_query($connection,$sql);

$run_add_script = "<script>load_settings('screen_setka_myprofile_show','');</script>";
}
Else{
$run_add_script = "<script>load_settings('screen_setka_myprofile_add','".$id_pers."');</script>";
}



}
Else{
$run_add_script = "<script>load_settings('screen_setka_myprofile_show','');</script>";
}

}



//Загружать если нет других профилей

echo $run_add_script;


}

?>
