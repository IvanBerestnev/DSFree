<?php

function act_delete_dogovor_pmu($vals)
{

$id_dog = $vals['id_dog'];
$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "delete from tab_pacs_dogovors where id_dogovor = '$id_dog'";
#echo $sql;
$query = mysqli_query($connection,$sql);

echo "<script>all_dogovor_pmu('",$id_pac,"','",$screen,"');</script>";

}

?>
