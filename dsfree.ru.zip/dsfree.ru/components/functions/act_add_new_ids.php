<?php

function act_add_new_ids($vals)
{

$screen = $vals['screen'];
$new_type = $vals['new_type'];

$name_file_new_ids = $vals['name_file_new_ids'];
$name_new_ids = $vals['name_new_ids'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id = md5(uniqid(rand(),1));

$sql = "insert into tab_ids values ('$id','$new_type','$name_file_new_ids','$name_new_ids')";
$query = mysqli_query($connection,$sql);

}


?>
