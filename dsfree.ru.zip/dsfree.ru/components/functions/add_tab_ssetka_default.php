<?php

function add_tab_ssetka_default($vals)
{

$id_used_ssetka = $vals['id_used_ssetka'];
$number_cell = $vals['number_cell'];
$param = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

If($param == "")
{
$sql = "delete from tab_ssetka_default where id_used_ssetka = '$id_used_ssetka' and number_cell = '$number_cell'";
$query = mysqli_query($connection,$sql);

$act = "hidden";
$id_ssetka_default = "";

}
Else{

$sql = "delete from tab_ssetka_default where id_used_ssetka = '$id_used_ssetka' and number_cell = '$number_cell'";
$query = mysqli_query($connection,$sql);

If($param == "jurnal_pacs")
{

$id_ssetka_default = md5(uniqid(rand(),1));

$ar_default = array("dunit"=>"1","c_days"=>"7","doc"=>"");
$json_ar_default = json_encode($ar_default, JSON_UNESCAPED_UNICODE);

$sql = "insert into tab_ssetka_default values ('$id_ssetka_default','$id_used_ssetka','$number_cell','$param','$json_ar_default','')";
$query = mysqli_query($connection,$sql);

$act = "show";

}
ElseIf($param == "mass_doc_shed")
{

$id_ssetka_default = md5(uniqid(rand(),1));

$sql = "insert into tab_ssetka_default values ('$id_ssetka_default','$id_used_ssetka','$number_cell','$param','$json_ar_default','')";
$query = mysqli_query($connection,$sql);

$act = "hidden";
$id_ssetka_default = "";

}
ElseIf($param == "sp_docs")
{

$id_ssetka_default = md5(uniqid(rand(),1));

$sql = "insert into tab_ssetka_default values ('$id_ssetka_default','$id_used_ssetka','$number_cell','$param','$json_ar_default','')";
$query = mysqli_query($connection,$sql);

$act = "hidden";
$id_ssetka_default = "";

}

}


echo "
<script>
show_button_rp_edit_default_ssetka('",$act,"','",$id_ssetka_default,"','",$id_used_ssetka,"','",$number_cell,"');

//удаление лишнего из других селектов
erasing_excess_options_ssetka_default('",$param,"','",$number_cell,"','",$id_used_ssetka,"');

</script>
";

}

?>
