<?php

function act_change_doc_shed_times($vals)
{

function convert_time_to_min($time_norm)
{
$ar_t_b = explode(":",$time_norm);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];
$time_b = ($hb*60)+$mb;
return $time_b;
}

#print_r($vals);die();
$screen = $vals['screen'];
$id_doc = $vals['doc'];
$param = $vals['param'];

$ar_param = explode("#",$param);

$id_shedule_come = $ar_param[3];
$old_id_doc = $ar_param[2];
$unit = $ar_param[1];

$dt_be = $ar_param[0];
$ar_dt_be = explode("@",$dt_be);
$dt_b = $ar_dt_be[0];
$dt_e = $ar_dt_be[1];

$ar_dt_b = explode(" ",$dt_b);
$d_b = $ar_dt_b[0];
$t_b = $ar_dt_b[1];

$ar_dt_e = explode(" ",$dt_e);
$d_e = $ar_dt_e[0];
$t_e = $ar_dt_e[1];

$ar_t_b = explode(":",$t_b);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];

$ar_t_e = explode(":",$t_e);
$he = $ar_t_e['0'];
$me = $ar_t_e['1'];

$time_b = $hb.":".$mb;
$time_e = $he.":".$me;


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_shedule_pers where id_shedule = '$id_shedule_come'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$date = $row['date'];

$time = $row['time'];
$ar_time = explode("-",$time);

$stb = $ar_time[0];
$ste = $ar_time[1];

$datetime_begin = $date." ".$stb.":00";
$datetime_end = $date." ".$ste.":00";

$sql = "select * from pacs_ent where begin between STR_TO_DATE('$datetime_begin', '%Y-%m-%d %H:%i:%s') and STR_TO_DATE('$datetime_end', '%Y-%m-%d %H:%i:%s') and unit = '$unit' order by begin ASC";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_ent = $row['id_ent'];

$ar_ents[] = $id_ent;

}

$str_ents = implode("','",$ar_ents);


$sql = "UPDATE pacs_ent SET doc = '$id_doc' where id_ent IN('$str_ents')";
#echo $sql;
$query = mysqli_query($connection,$sql);

}

}

#echo "<br><br>";

$sql = "update tab_shedule_pers set id_pers = '$id_doc' where id_shedule = '$id_shedule_come'";
#echo $sql;
$query = mysqli_query($connection,$sql);




//Проверка смежных значений для оптимизации количества времени врача

$sql = "select * from tab_shedule_pers where id_pers = '$id_doc' and unit = '$unit' and date = '$d_b' and (time like('%$time_b%') or time like('%$time_e%'))";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{

$i=0;
while($row = mysqli_fetch_assoc($query))
{
$id_shedule = $row['id_shedule'];
$time = $row['time'];

$ar_time = explode("-",$time);
$tb = $ar_time[0];
$te = $ar_time[1];

$ar_stime[] = $tb;
$ar_stime[] = $te;

$ar_self_shed[] = $id_shedule;

$i++;
}


#print_r($ar_self_shed);die();

If($i>1)
{

#echo "123";die();

$ar_stime_uniq = array_unique($ar_stime);

Foreach($ar_stime_uniq as $stime)
{
$stime_min = convert_time_to_min($stime);
$ar_stime_uniq_min[] = $stime_min;
}


If(count($ar_stime) === count($ar_stime_uniq_min))
{

}
Else{

asort($ar_stime_uniq_min);

#print_r($ar_stime_uniq_min);die();

$min = min($ar_stime_uniq_min);
$max = max($ar_stime_uniq_min);

$t_min = date("H:i", mktime(0, $min, 0, 1, 1, 1970));
$t_max = date("H:i", mktime(0, $max, 0, 1, 1, 1970));

$opt_period = $t_min."-".$t_max;

$str_self_shed = implode("','",$ar_self_shed);
$sql = "delete from tab_shedule_pers where id_shedule IN('$str_self_shed')";
#echo $sql;
$query = mysqli_query($connection,$sql);

//$sql = "select * from tab_shedule_pers where id_pers = '$id_pers' and unit = '$unit' and date = '$date'";
$id_shedule_new = md5(uniqid(rand(),1));
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_doc','$date','$unit','$opt_period')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

}

}

}


//и еще раз повторно поиск по всему дню

#$sql = "select * from tab_shedule_pers where id_pers = '$id_pers' and unit = '$unit' and date = '$date'  and (time like('%$b_new_period%') or time like('%$e_new_period%'))";
$sql = "select * from tab_shedule_pers where id_pers = '$id_doc' and unit = '$unit' and date = '$date'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{


$i=0;
while($row = mysqli_fetch_assoc($query))
{
$id_shedule = $row['id_shedule'];
$time = $row['time'];

$ar_time = explode("-",$time);
$tb = $ar_time[0];
$te = $ar_time[1];

$ar_stime[] = $tb;
$ar_stime[] = $te;

$ar_self_shed[] = $id_shedule;

$i++;
}

If($i>1)
{

#echo "123";die();

$ar_stime_uniq = array_unique($ar_stime);

Foreach($ar_stime_uniq as $stime)
{

$stime_min = convert_time_to_min($stime);

$ar_stime_uniq_min[] = $stime_min;

}


If(count($ar_stime) === count($ar_stime_uniq_min))
{
//массив уникальный





}
Else{


asort($ar_stime_uniq_min);


#print_r($ar_stime_uniq_min);die();

$min = min($ar_stime_uniq_min);
$max = max($ar_stime_uniq_min);

$t_min = date("H:i", mktime(0, $min, 0, 1, 1, 1970));
$t_max = date("H:i", mktime(0, $max, 0, 1, 1, 1970));

$opt_period = $t_min."-".$t_max;

#echo $opt_period;




$str_self_shed = implode("','",$ar_self_shed);
$sql = "delete from tab_shedule_pers where id_shedule IN('$str_self_shed')";
#echo $sql;
$query = mysqli_query($connection,$sql);


//$sql = "select * from tab_shedule_pers where id_pers = '$id_pers' and unit = '$unit' and date = '$date'";
$id_shedule_new = md5(uniqid(rand(),1));
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_doc','$date','$unit','$opt_period')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

}




}


}


///////////-------------

echo "<script>reload_jurpacs_cell_colors('",$screen,"');var first_date_jur = 'first_date_jur_",$screen,"';var fdj = document.getElementById(first_date_jur).innerHTML;var ar_fdj = fdj.split('.');var n_time_js = ar_fdj.join('-');send_date_from_cal_to_jurpacs(n_time_js,'",$screen,"');close_mw('fon_modal_",$screen,"');</script>";


}

?>
