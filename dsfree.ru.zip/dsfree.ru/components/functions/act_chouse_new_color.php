<?php

function act_chouse_new_color($vals)
{


#print_r($vals);


$screen = $vals['screen'];
$type = $vals['type'];
$id_pers = $vals['id_pers'];
$rand_color = $vals['rand_color'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


If($type == "bg_gen")
{
$sql = "update tab_personal set bg_color_gen = '$rand_color' where id_pers = '$id_pers'";
}

ElseIf($type == "txt_gen")
{
$sql = "update tab_personal set txt_color_gen = '$rand_color' where id_pers = '$id_pers'";
}
ElseIf($type == "bg_pac")
{
$sql = "update tab_personal set bg_color_pac = '$rand_color' where id_pers = '$id_pers'";
}
ElseIf($type == "txt_pac")
{
$sql = "update tab_personal set txt_color_pac = '$rand_color' where id_pers = '$id_pers'";
}


$query = mysqli_query($connection,$sql);


echo "

<script>

</script>

";

}


?>
