<?php

function print_template_ds($vals)
{

#print_r($vals);

$id_ds = $vals['id_ds'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss where id_ds = '$id_ds'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$name_ds = $row['name_ds'];
}

function remove_utf8_bom($str)
{
    return str_replace("\xEF\xBB\xBF",'',$str); 
}


include_once "../components/lib/vendor/autoload.php";
$document_with_table = new \PhpOffice\PhpWord\PhpWord();

$tableStyle = array('borderSize' => 1, 'borderColor' => '999999');
$styleCell = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');
$styleCell_rowspan = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');
$myFontStyle = array('bold' => true, 'align' => 'center');
$myFontStyle_other = array('align' => 'center');

$date = date("Y-m-d H:i:s");

$section = $document_with_table->addSection();
$table = $section->addTable();

$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$text = $row['text'];


#htmlspecialchars_decode
/////
#$text = preg_replace('/[[:cntrl:]]/', '', $text);
#echo $text;die();
#$ar_decoded = json_decode($text,true);
////





 $json = preg_replace('/[[:cntrl:]]/', '', $text);



#$json = json_decode(remove_utf8_bom($json));


$ar_decoded = json_decode(urldecode($json), true);




 #echo json_last_error();
 # echo json_last_error_msg();
#print_r($ar_decoded);die();


#print_r($ar_decoded);
#echo $ar_decoded;

If(isset($ar_decoded[$id_ds]))
{

#print_r($ar_decoded[$id_ds]);

$ar_cont = $ar_decoded[$id_ds];

Foreach($ar_cont as $valls)
{


$name = $valls['name'];

$table->addRow();
$table->addCell(11000, $styleCell)->addText($name,$myFontStyle,array('align' => 'center','size'=>'10','spaceAfter'=>0,'lineHeight'=>1.0));
$table->addRow();
$table->addCell(11000, $styleCell)->addText("",$myFontStyle_other,array('align' => 'left','size'=>'10','spaceAfter'=>0,'lineHeight'=>1.0));


$cont = $valls['cont'];

Foreach($cont as $vals)
{

$name_razd = $vals['name'];

$table->addRow();
$table->addCell(11000, $styleCell)->addText($name_razd,$myFontStyle,array('align' => 'left','size'=>'10','spaceAfter'=>0,'lineHeight'=>1.0));
$table->addRow();
$table->addCell(11000, $styleCell)->addText("",$myFontStyle_other,array('align' => 'left','size'=>'10','spaceAfter'=>0,'lineHeight'=>1.0));

$ar_text = $vals['cont'];

Foreach($ar_text as $txt)
{

$table->addRow();
$table->addCell(11000, $styleCell)->addText($txt,$myFontStyle_other,array('align' => 'left','size'=>'10','spaceAfter'=>0,'lineHeight'=>1.0));
$table->addRow();
$table->addCell(11000, $styleCell)->addText("",$myFontStyle_other,array('align' => 'left','size'=>'10','spaceAfter'=>0,'lineHeight'=>1.0));

}


}


}


}

}

}


// Create writer to convert document to xml
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');

// Get all document xml code
$fullxml = $objWriter->getWriterPart('document')->write();

// Get only table xml code
$tablexml = '</w:t></w:r></w:p>'.preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml).'<w:p><w:r><w:t>';

//Open template with ${table}
$template_document = new \PhpOffice\PhpWord\TemplateProcessor("../components/download/read_template.docx");



// Replace mark by xml code of table
$template_document->setValue('mytable', $tablexml);
$template_document->setValue('datetime_now', $date);
$template_document->setValue('name_ds', $name_ds);



$filename = $name_ds.".docx";
$template_document->saveAs($filename);


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);



}

?>
