<?php

function exit_dsfree()
{

$id_cookie = $_COOKIE['dsf_cookie'];

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "delete from auths where id_cookie = '$id_cookie'";
$query = mysqli_query($connection,$sql);

setcookie("dsf_cookie", "", time()-3600, "/", "");

echo "<meta http-equiv=\"refresh\" content=\"0\">";


}

?>
