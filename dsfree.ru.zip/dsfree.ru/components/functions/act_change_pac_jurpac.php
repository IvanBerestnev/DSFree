<?php

function act_change_pac_jurpac($vals)
{

$id_ent = $vals['id_ent'];
$screen = $vals['screen'];
$id_choiced_pac = $vals['id_choiced_pac'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "update pacs_ent set id_pacs = '$id_choiced_pac' where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);


echo "<script>reload_jurpacs_cell_colors('",$screen,"');var first_date_jur = 'first_date_jur_",$screen,"';var fdj = document.getElementById(first_date_jur).innerHTML;var ar_fdj = fdj.split('.');var n_time_js = ar_fdj.join('-');send_date_from_cal_to_jurpacs(n_time_js,'",$screen,"');close_mw('fon_modal_",$screen,"');</script>";



}

?>
