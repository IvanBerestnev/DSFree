<?php

function create_superuser($vals)
{
	
#print_r($vals);

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$id_user = md5(uniqid(rand(),1));
$password = $vals['password'];

$hash_pass = md5($password);

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "insert dsf_users values ('$id_user','superuser','3','$hash_pass','1',now())";
$query = mysqli_query($connection,$sql);


$begin = $vals['begin'];
$end = $vals['end'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "insert into presets values ('tc_begin','$begin','Начало работы клиники','jur')";
$query = mysqli_query($connection,$sql);

$sql = "insert into presets values ('tc_end','$end','Конец работы клиники','jur')";
$query = mysqli_query($connection,$sql);


include_once("tab_permissions_default.php");
$ar_tab_permissions_default = tab_permissions_default();
$ar_encode = json_encode($ar_tab_permissions_default, JSON_UNESCAPED_UNICODE);

$sql = "insert into tab_permissions values ('1','$ar_encode')";
$query = mysqli_query($connection,$sql);

setcookie("dsf_cookie_inf", "superuser_created", time()+1, "/", "");
echo "<meta http-equiv=\"refresh\" content=\"0\">";

}

?>
