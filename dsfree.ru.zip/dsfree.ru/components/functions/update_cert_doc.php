<?php

function update_cert_doc($vals)
{
	

#print_r($vals);
$screen = $vals['screen'];
$id_cert = $vals['id_cert'];
$name_param = $vals['name_param'];
$val = $vals['val'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

If($name_param == "name_cert")
{

$sql = "update tab_docs_cert set $name_param = '$val' where id_cert = '$id_cert'";
$query = mysqli_query($connection,$sql);


}
Else{

$sql = "select * from tab_docs_cert where id_cert = '$id_cert'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$date_cert = $row['date_cert'];

$ar_date_cert = explode("-",$date_cert);

$year = $ar_date_cert[0];
$month = $ar_date_cert[1];
$day = $ar_date_cert[2];

If($name_param == "year")
{
$year = $val;
}
ElseIf($name_param == "month")
{
$month = $val;
}
ElseIf($name_param == "day")
{
$day = $val;
}


$str_new_date = $year."-".$month."-".$day;

$sql = "update tab_docs_cert set date_cert = '$str_new_date' where id_cert = '$id_cert'";
$query = mysqli_query($connection,$sql);


}


}






}


?>
