<?php

function act_save_new_txt_razd_visit($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_writed_razd = $vals['id_writed_razd'];
$text = $vals['text'];
$id_visit = $vals['id_visit'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$text_bd = $row['txt_treat'];
$ar_text_bd = json_decode($text_bd,true);


$ar_text_bd[$id_writed_razd]['cont'] = $text;
$json_ar = json_encode($ar_text_bd, JSON_UNESCAPED_UNICODE);

$sql = "update pacs_visits set txt_treat = '$json_ar' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);



}


}


?>
