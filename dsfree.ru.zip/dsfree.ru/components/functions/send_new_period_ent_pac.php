<?php

function send_new_period_ent_pac($vals)
{


#print_r($vals);

$id_ent = $vals['id_ent'];
$screen = $vals['screen'];
$new_period = $vals['new_period'];
$date = $vals['date'];


$ar_new_period = explode("-",$new_period);
$mb = $ar_new_period[0];
$me = $ar_new_period[1];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$begin = $date." ".$mb.":00";
$end = $date." ".$me.":00";

$sql = "update pacs_ent set begin = '$begin' where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);

$sql = "update pacs_ent set end = '$end' where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);


echo "<script>reload_jurpacs_cell_colors('",$screen,"');var first_date_jur = 'first_date_jur_",$screen,"';var fdj = document.getElementById(first_date_jur).innerHTML;var ar_fdj = fdj.split('.');var n_time_js = ar_fdj.join('-');send_date_from_cal_to_jurpacs(n_time_js,'",$screen,"');close_mw('fon_modal_",$screen,"');</script>";


}

?>
