<?php

function print_jur_pso($vals)
{

#print_r($vals);

#$type_recieved = $vals['type'];
#$is_prosrok = $vals['is_prosrok'];

#$ar_is_prosrok = explode("@",$is_prosrok);
#$categ = $ar_is_prosrok[0];
#$days = $ar_is_prosrok[1];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


include_once "../components/lib/vendor/autoload.php";

$document_with_table = new \PhpOffice\PhpWord\PhpWord();





$styleCell = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');
$myFontStyle = array('bold' => false, 'align' => 'center', 'size' => 8);






#$date = date("Y-m-d H:i:s");

$section = $document_with_table->addSection();
$table = $section->addTable();



$sql = "select * from jur_pso";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{
	
while($row = mysqli_fetch_assoc($query))
{

$date = $row['date'];
$method = $row['method'];
$agent =  $row['agent'];
$izd = $row['izd'];
$amount = $row['amount'];

#$name_izd = str_replace("\n", '<w:br/>', $name_izd);


$table->addRow(200, array("exactHeight" => true));

$table->addCell(1200, $styleCell)->addText($date,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(1450, $styleCell)->addText(htmlspecialchars($method),$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(2200, $styleCell)->addText(htmlspecialchars($agent),$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(6000, $styleCell)->addText($izd,$myFontStyle,array('align' => 'center','size'=>'12'));
$table->addCell(500, $styleCell)->addText($amount,$myFontStyle,array('align' => 'center','size'=>'12'));


$table->addCell(1150, $styleCell)->addText();
$table->addCell(1090, $styleCell)->addText();

$table->addCell(1350, $styleCell)->addText();


}




}


// Create writer to convert document to xml
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');



// Get all document xml code
$fullxml = $objWriter->getWriterPart('document')->write();

// Get only table xml code
$tablexml = '</w:t></w:r></w:p>'.preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml).'<w:p><w:r><w:t>';

//Open template with ${table}
$template_document = new \PhpOffice\PhpWord\TemplateProcessor("../components/download/jur_pso.docx");




// Replace mark by xml code of table
$template_document->setValue('mytable', $tablexml);
#$template_document->setValue('type', $type_recieved);
#$template_document->setValue('date', $date);
#$template_document->setValue('period', $period);


$filename = "стерилизация.docx";



$template_document->saveAs($filename);


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);


}


?>
