<?php

function act_rename_razd($vals)
{

$id_writed_razd = $vals['id_writed_razd'];
$id_visit = $vals['id_visit'];
$new_txt = $vals['new_txt'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$txt_treat = $row['txt_treat'];

$ar_txt_treat = json_decode($txt_treat,true);

$ar_txt_treat[$id_writed_razd]['name'] = $new_txt;

$json_ar = json_encode($ar_txt_treat, JSON_UNESCAPED_UNICODE);

$sql = "update pacs_visits set txt_treat = '$json_ar' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

}

echo "
<script>
var name_razdel_medcart_self = 'name_razdel_medcart_self_",$id_writed_razd,"_",$screen,"';
document.getElementById(name_razdel_medcart_self).innerHTML = '",$new_txt,"';
close_mw('fon_modal_",$screen,"');
</script>
";


}

?>
