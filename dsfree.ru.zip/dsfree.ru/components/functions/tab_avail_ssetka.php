<?php


function tab_avail_ssetka()
{




#$tab_avail_ssetka = Array ( ["simple"] => Array ( ["name"] => "Простая сетка", ["padding"] => Array ( ["a"] => "15", ["b"] => "15", ["c"] => "15", ["d"] => "15" ), ["params"] => Array ( ["cols"] => "2", ["rows"] => "2", ["spacex"] => "15", ["spacey"] => "15" ), ["bind"] => "") );

$tab_avail_ssetka[0]["simple"]["name"] = "Простая сетка";
$tab_avail_ssetka[0]["simple"]["padding"]["a"] = "15";
$tab_avail_ssetka[0]["simple"]["padding"]["b"] = "15";
$tab_avail_ssetka[0]["simple"]["padding"]["c"] = "15";
$tab_avail_ssetka[0]["simple"]["padding"]["d"] = "15";
$tab_avail_ssetka[0]["simple"]["params"]["cols"] = "2";
$tab_avail_ssetka[0]["simple"]["params"]["rows"] = "2";
$tab_avail_ssetka[0]["simple"]["params"]["spacex"] = "15";
$tab_avail_ssetka[0]["simple"]["params"]["spacey"] = "15";
$tab_avail_ssetka[0]["simple"]["bind"] = "";


#$tab_avail_ssetka[1] = Array ( ["special"] => Array ( ["name"] => "Композитная сетка 2х2", ["padding"] => Array ( ["a"] => "100", ["b"] => "150", ["c"] => "100", ["d"] => "150" ), ["working_cells"] => Array ( ["0"] => "1", ["1"] => "3", ["2"] => "5", ["3"] => "7" ), ["params"] => Array ( ["0"] => Array ( ["height"] => "", ["cells"] => "2", ["x"] => Array ( ["0"] => "65%", ["1"] => "50px", ["2"] => "" ) ), ["1"] => Array ( ["height"] => "30px", ["cells"] => "0"), ["2"] => Array ( ["height"] => "", ["cells"] => "2", ["x"] => Array ( ["0"] => "35%", ["1"] => "50px", ["2"] => "" ) ) ), ["bind"] => "" ) );

$tab_avail_ssetka[1]["special"]["name"] = "Композитная сетка 2х2";
$tab_avail_ssetka[1]["special"]["padding"]["a"] = "100";
$tab_avail_ssetka[1]["special"]["padding"]["b"] = "150";
$tab_avail_ssetka[1]["special"]["padding"]["c"] = "100";
$tab_avail_ssetka[1]["special"]["padding"]["d"] = "150";
$tab_avail_ssetka[1]["special"]["working_cells"]["0"] = "1";
$tab_avail_ssetka[1]["special"]["working_cells"]["1"] = "3";
$tab_avail_ssetka[1]["special"]["working_cells"]["2"] = "5";
$tab_avail_ssetka[1]["special"]["working_cells"]["3"] = "7";

$tab_avail_ssetka[1]["special"]["params"]["0"]["height"] = "";
$tab_avail_ssetka[1]["special"]["params"]["0"]["cells"] = "2";
$tab_avail_ssetka[1]["special"]["params"]["0"]["x"]["0"] = "65%";
$tab_avail_ssetka[1]["special"]["params"]["0"]["x"]["1"] = "50px";
$tab_avail_ssetka[1]["special"]["params"]["0"]["x"]["2"] = "";

$tab_avail_ssetka[1]["special"]["params"]["1"]["height"] = "30px";
$tab_avail_ssetka[1]["special"]["params"]["1"]["cells"] = "0";

$tab_avail_ssetka[1]["special"]["params"]["2"]["height"] = "";
$tab_avail_ssetka[1]["special"]["params"]["2"]["cells"] = "2";
$tab_avail_ssetka[1]["special"]["params"]["2"]["x"]["0"] = "35%";
$tab_avail_ssetka[1]["special"]["params"]["2"]["x"]["1"] = "50px";
$tab_avail_ssetka[1]["special"]["params"]["2"]["x"]["2"] = "";
$tab_avail_ssetka[1]["special"]["bind"] = "";


#$tab_avail_ssetka[2] = Array ( ["2"] => Array ( ["special"] => Array ( ["name"] => "Композитная сетка 3х2", ["padding"] => Array ( ["a"] => "100", ["b"] => "150", ["c"] => "100", ["d"] => "150" ), ["working_cells"] => Array ( ["0"] => "1", ["1"] => "3", ["2"] => "5", ["3"] => "7", ["4"] => "9", ["5"] => "11" ), ["params"] => Array ( ["0"] => Array ( ["height"] => "", ["cells"] => "2", ["x"] => Array ( ["0"] => "65%", ["1"] => "50px", ["2"] => "") ), ["1"] => Array ( ["height"] => "30px", ["cells"] => "0" ), ["2"] => Array ( ["height"] => "", ["cells"] => "2", ["x"] => Array ( ["0"] => "35%", ["1"] => "50px", ["2"] => "" ) ), ["3"] => Array ( ["height"] => "30px", ["cells"] => "0" ), ["4"] => Array ( ["height"] => "", ["cells"] => "2", ["x"] => Array ( ["0"] => "65%", ["1"] => "50px", ["2"] => "" ) ) ), ["bind"] => "" ) ) );

$tab_avail_ssetka[2]["special"]["name"] = "Композитная сетка 3х2";
$tab_avail_ssetka[2]["special"]["padding"]["a"] = "100";
$tab_avail_ssetka[2]["special"]["padding"]["b"] = "150";
$tab_avail_ssetka[2]["special"]["padding"]["c"] = "100";
$tab_avail_ssetka[2]["special"]["padding"]["d"] = "150";
$tab_avail_ssetka[2]["special"]["working_cells"]["0"] = "1";
$tab_avail_ssetka[2]["special"]["working_cells"]["1"] = "3";
$tab_avail_ssetka[2]["special"]["working_cells"]["2"] = "5";
$tab_avail_ssetka[2]["special"]["working_cells"]["3"] = "7";
$tab_avail_ssetka[2]["special"]["working_cells"]["4"] = "9";
$tab_avail_ssetka[2]["special"]["working_cells"]["5"] = "11";

$tab_avail_ssetka[2]["special"]["params"]["0"]["height"] = "";
$tab_avail_ssetka[2]["special"]["params"]["0"]["cells"] = "2";
$tab_avail_ssetka[2]["special"]["params"]["0"]["x"]["0"] = "65%";
$tab_avail_ssetka[2]["special"]["params"]["0"]["x"]["1"] = "50px";
$tab_avail_ssetka[2]["special"]["params"]["0"]["x"]["2"] = "";

$tab_avail_ssetka[2]["special"]["params"]["1"]["height"] = "30px";
$tab_avail_ssetka[2]["special"]["params"]["1"]["cells"] = "0";

$tab_avail_ssetka[2]["special"]["params"]["2"]["height"] = "";
$tab_avail_ssetka[2]["special"]["params"]["2"]["cells"] = "2";
$tab_avail_ssetka[2]["special"]["params"]["2"]["x"]["0"] = "35%";
$tab_avail_ssetka[2]["special"]["params"]["2"]["x"]["1"] = "50px";
$tab_avail_ssetka[2]["special"]["params"]["2"]["x"]["2"] = "";

$tab_avail_ssetka[2]["special"]["params"]["3"]["height"] = "30px";
$tab_avail_ssetka[2]["special"]["params"]["3"]["cells"] = "0";

$tab_avail_ssetka[2]["special"]["params"]["4"]["height"] = "";
$tab_avail_ssetka[2]["special"]["params"]["4"]["cells"] = "2";
$tab_avail_ssetka[2]["special"]["params"]["4"]["x"]["0"] = "65%";
$tab_avail_ssetka[2]["special"]["params"]["4"]["x"]["1"] = "50px";
$tab_avail_ssetka[2]["special"]["params"]["4"]["x"]["2"] = "";

$tab_avail_ssetka[2]["special"]["bind"] = "";


return $tab_avail_ssetka;


};

?>
