<?php

function add_new_client($vals)
{

print_r($vals);

$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_pac = md5(uniqid(rand(),1));

$sql = "insert into tab_pacs values ('$id_pac','','','','','','','','','','','','','','','','','','','','','','a1',now())";
$query = mysqli_query($connection,$sql);

echo "<script>load_sp_clients('",$screen,"','','','",$id_pac,"');</script>";


}


?>
