<?php

function act_delete_price($vals)
{

$screen = $vals['screen'];
$param = $vals['param'];
$id_price = $vals['id_price'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "delete from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);


echo "
<script>
close_mw('fon_modal_first_",$screen,"');
load_block_price('','",$screen,"');
</script>
";



}

?>
