<?php

function act_edit_sp_medcart_ds($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$param = $vals['param'];

$ar_param = explode("@",$param);

$id_visit = $ar_param[0];
$new_ds = $ar_param[1];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update pacs_visits set ds = '$new_ds' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "

<script>

var span_ds_sp_medcart = 'span_ds_sp_medcart_",$id_visit,"_",$screen,"';
document.getElementById(span_ds_sp_medcart).innerHTML = '",$new_ds,"';
close_mw('fon_modal_",$screen,"');
</script>
";

}


?>
