<?php

function act_delete_usluga_price($vals)
{

$id_price = $vals['id_price'];
$screen = $vals['screen'];
$id_usl = $vals['param'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$txt_price = $row['txt_price'];

$ar_new = json_decode($txt_price,true);

unset($ar_new[$id_usl]);

If(count($ar_new) == 0)
{

$json_ar = "";

}
Else{

$json_ar = json_encode($ar_new, JSON_UNESCAPED_UNICODE);

}

$sql = "update price set txt_price = '$json_ar' where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_block_price_self('",$id_price,"','",$screen,"');
close_mw('fon_modal_first_",$screen,"');
</script>
";


}


}

?>
