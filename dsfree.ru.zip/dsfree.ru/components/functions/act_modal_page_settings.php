<?php

function act_modal_page_settings($vals)
{

print_r($vals);
$name = $vals['name'];

If($name == "act_reset_dsfree_default_mode0")
{

include_once("../components/functions/act_reset_dsfree_default_mode0.php");
act_reset_dsfree_default_mode0();

}



}

?>
