<?php

function act_del_client($vals)
{


$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "delete from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

$sql = "delete from pacs_ent where id_pacs = '$id_pac'";
$query = mysqli_query($connection,$sql);

$sql = "delete from pacs_visits where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_pacs_dogovors where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);


echo "
<script>
load_sp_clients('",$screen,"','','','');
close_mw('fon_modal_",$screen,"');
</script>
";

}


?>
