<?php

function send_new_period_shed_doc($vals)
{

#print_r($vals);



$screen = $vals['screen'];
$id_shedule = $vals['id_shedule'];
$old_chouse_t_period = $vals['old_chouse_t_period'];
$new_period = $vals['new_period'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_shedule_pers where id_shedule = '$id_shedule'";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pers = $row['id_pers'];

$gl_time = $row['time'];

$unit = $row['unit'];

$date = $row['date'];


$ar_gl_time = explode("-",$gl_time);
//глоб.промеж-к
//Г1
$b_gl_time = $ar_gl_time[0];
//Г2
$e_gl_time = $ar_gl_time[1];


$ar_old_chouse_t_period = explode("-",$old_chouse_t_period);
//старый промеж-к
//C1
$b_old_chouse_t_period = $ar_old_chouse_t_period[0];
//С2
$e_old_chouse_t_period = $ar_old_chouse_t_period[1];


If($new_period !== "delete")
{
$ar_new_period = explode("-",$new_period);
//новый промеж-к
//Н1
$b_new_period = $ar_new_period[0];
//Н2
$e_new_period = $ar_new_period[1];
}
Else{

goto a;

}





echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

//Проверка, нужна ли запись вообще
//Не пишем, если Новый промежуток равен старому


If($old_chouse_t_period == $new_period)
{

echo "<script>close_mw('fon_modal_",$screen,"');</script>";die();


}
ElseIf($b_old_chouse_t_period == $b_new_period)
{
#echo "1";die();
//Старый 1 равен новому 1(4 условный статус)

$id_shedule_new = md5(uniqid(rand(),1));

$third_one_status = $b_gl_time."-".$e_new_period;
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$third_one_status')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);
#echo $sql;


If($e_old_chouse_t_period !== $e_gl_time)
{

$id_shedule_new = md5(uniqid(rand(),1));
$third_two_status = $e_old_chouse_t_period."-".$e_gl_time;
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$third_two_status')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

}




#echo "<br>4 условный<br>";

$sql = "delete from tab_shedule_pers where id_shedule = '$id_shedule'";
#echo $sql;
$query = mysqli_query($connection,$sql);


}
ElseIf($e_old_chouse_t_period == $e_new_period)
{
//Старый 2 равен новому 1 (5 условный статус)
#echo "2";die();

$id_shedule_new = md5(uniqid(rand(),1));
$five_status_one = $b_new_period."-".$e_gl_time;
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$five_status_one')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

//////--------<<<<

If($b_gl_time !== $b_old_chouse_t_period)
{

$id_shedule_new = md5(uniqid(rand(),1));
$five_status_two = $b_gl_time."-".$b_old_chouse_t_period;
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$five_status_two')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

}





#echo "<br>5 условный<br>";

$sql = "delete from tab_shedule_pers where id_shedule = '$id_shedule'";
#echo $sql;
$query = mysqli_query($connection,$sql);



}
Else{

#echo "3";die();
a:

If($b_gl_time !== $b_old_chouse_t_period)
{

#echo "4";die();

//3е состояние
$three_status = $b_gl_time."-".$b_old_chouse_t_period;
$id_shedule_new = md5(uniqid(rand(),1));

#$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_doc','$d_b','$unit','$new_time')";
#$query = mysqli_query($connection,$sql);


$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$three_status')";
#echo $sql," --- 3й<br>";
$query = mysqli_query($connection,$sql);

#echo "<br>";
}


If($e_old_chouse_t_period !== $e_gl_time)
{

#echo "5";die();
//2е состояние
$second_status = $e_old_chouse_t_period."-".$e_gl_time;

$id_shedule_new = md5(uniqid(rand(),1));

$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$second_status')";
#echo $sql," --- 2й<br>";
$query = mysqli_query($connection,$sql);

#echo "<br>";
}



If($new_period !== "delete")
{

//запись нового периода
$new_period_wr = $b_new_period."-".$e_new_period;
$id_shedule_new = md5(uniqid(rand(),1));
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$new_period_wr')";
#echo $sql," --- новый";
$query = mysqli_query($connection,$sql);


//тест1



}


//удалить старую запись
$sql = "delete from tab_shedule_pers where id_shedule = '$id_shedule'";
#echo $sql;
$query = mysqli_query($connection,$sql);

#echo "<br>";




}


//Проверка смежных значений для оптимизации количества времени врача

If($new_period !== "delete")
{

$sql = "select * from tab_shedule_pers where id_pers = '$id_pers' and unit = '$unit' and date = '$date'  and (time like('%$b_new_period%') or time like('%$e_new_period%'))";
#$sql = "select * from tab_shedule_pers where id_pers = '$id_pers' and unit = '$unit' and date = '$date'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{


$i=0;
while($row = mysqli_fetch_assoc($query))
{
$id_shedule = $row['id_shedule'];
$time = $row['time'];

$ar_time = explode("-",$time);
$tb = $ar_time[0];
$te = $ar_time[1];

$ar_stime[] = $tb;
$ar_stime[] = $te;

$ar_self_shed[] = $id_shedule;

$i++;
}

If($i>1)
{

#echo "123";die();

function convert_time_to_min($time_norm)
{
$ar_t_b = explode(":",$time_norm);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];
$time_b = ($hb*60)+$mb;
return $time_b;
}

$ar_stime_uniq = array_unique($ar_stime);

Foreach($ar_stime_uniq as $stime)
{

$stime_min = convert_time_to_min($stime);

$ar_stime_uniq_min[] = $stime_min;

}


If(count($ar_stime) === count($ar_stime_uniq_min))
{
//массив уникальный





}
Else{


asort($ar_stime_uniq_min);


#print_r($ar_stime_uniq_min);die();

$min = min($ar_stime_uniq_min);
$max = max($ar_stime_uniq_min);

$t_min = date("H:i", mktime(0, $min, 0, 1, 1, 1970));
$t_max = date("H:i", mktime(0, $max, 0, 1, 1, 1970));

$opt_period = $t_min."-".$t_max;

#echo $opt_period;




$str_self_shed = implode("','",$ar_self_shed);
$sql = "delete from tab_shedule_pers where id_shedule IN('$str_self_shed')";
#echo $sql;
$query = mysqli_query($connection,$sql);


//$sql = "select * from tab_shedule_pers where id_pers = '$id_pers' and unit = '$unit' and date = '$date'";
$id_shedule_new = md5(uniqid(rand(),1));
$sql = "insert into tab_shedule_pers values ('$id_shedule_new','$id_pers','$date','$unit','$opt_period')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

}




}


}


//повторно еще раз








}






echo "<script>reload_jurpacs_cell_colors('",$screen,"');var first_date_jur = 'first_date_jur_",$screen,"';var fdj = document.getElementById(first_date_jur).innerHTML;var ar_fdj = fdj.split('.');var n_time_js = ar_fdj.join('-');send_date_from_cal_to_jurpacs(n_time_js,'",$screen,"');close_mw('fon_modal_",$screen,"');</script>";



}


}

?>
