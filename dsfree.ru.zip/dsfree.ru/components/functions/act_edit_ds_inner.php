<?php

function act_edit_ds_inner($vals)
{

$classif = $vals['classif'];
$ds = $vals['ds'];
$screen = $vals['screen'];
$id_ds = $vals['id_ds'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update sp_dss set name_ds = '$ds' where id_ds = '$id_ds'";
$query = mysqli_query($connection,$sql);

$sql = "update sp_dss set type = '$classif' where id_ds = '$id_ds'";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_saved_dss('",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>
";


}

?>
