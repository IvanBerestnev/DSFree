<?php

function act_reset_dsfree_default_mode0()
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "delete from limit_list";
$query = mysqli_query($connection,$sql);

$sql = "delete from pacs_ent";
$query = mysqli_query($connection,$sql);

$sql = "delete from pacs_visits";
$query = mysqli_query($connection,$sql);

$sql = "delete from presets";
$query = mysqli_query($connection,$sql);

$sql = "delete from price";
$query = mysqli_query($connection,$sql);

$sql = "delete from sp_dss";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_act_dw";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_docs_cert";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_ids";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_docs_cert";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_misc_sets";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_pacs";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_pacs_dogovors";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_permissions";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_personal";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_shedule_pers";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_ssetka_default";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

$sql = "delete from tab_used_ssetka";
$query = mysqli_query($connection,$sql);




include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];
$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "delete from auths";
$query = mysqli_query($connection,$sql);
$sql = "delete from dsf_users";
$query = mysqli_query($connection,$sql);

setcookie("dsf_cookie", "", time()-3600, "/", "");

echo "<meta http-equiv=\"refresh\" content=\"0\">";




}


?>
