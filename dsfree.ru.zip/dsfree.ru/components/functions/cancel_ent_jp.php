<?php

function cancel_ent_jp($vals)
{

$id_ent = $vals['id_ent'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "delete from pacs_ent where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);


echo "

<script>

close_mw('fon_modal_",$screen,"');
load_jurpacs('",$screen,"');

var id_screen_cell_jurpac_selected_id = 'id_",$screen,"_cell_jurpac_selected_id';
var id_screen_cell_jurpac_selected_color = 'id_",$screen,"_cell_jurpac_selected_color';

document.getElementById(id_screen_cell_jurpac_selected_id).innerHTML = '';
document.getElementById(id_screen_cell_jurpac_selected_color).innerHTML = '';

var jurpac_bottom_menu = 'jurpac_bottom_menu_",$screen,"';
document.getElementById(jurpac_bottom_menu).innerHTML = '';

</script>

";



}


?>
