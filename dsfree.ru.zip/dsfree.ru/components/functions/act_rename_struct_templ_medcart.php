<?php

function act_rename_struct_templ_medcart($vals)
{

#print_r($vals);

$id_ds_income = $vals['id_ds_income'];
$id_tm = $vals['id_tm'];
$id_str_templ = $vals['id_str_templ'];
$new_name = $vals['new_name'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$text = $row['text'];

$ar_decoded = json_decode($text,true);

#print_r($ar_decoded);

If(isset($ar_decoded[$id_ds_income][$id_str_templ]['name']))
{
$ar_decoded[$id_ds_income][$id_str_templ]['name'] = $new_name;

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);

$sql = "update tab_templ_medcart set text = '$json_ar' where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);



}



}


}

?>
