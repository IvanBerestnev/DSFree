<?php

function get_shed_pers_by_id_ent($id_ent)
{


function convert_time_to_min($time_norm)
{
$ar_t_b = explode(":",$time_norm);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];
$time_b = ($hb*60)+$mb;
return $time_b;
}



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from pacs_ent where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);


$begin_ent = $row['begin'];
$end_ent = $row['end'];


$ar_begin_ent = explode(" ",$begin_ent);
$date_b_ent = $ar_begin_ent[0];
$ftime_b_ent = $ar_begin_ent[1];
$ar_ftime_b_ent = explode(":",$ftime_b_ent);
$time_b_ent = $ar_ftime_b_ent[0].":".$ar_ftime_b_ent[1];


$ar_end_ent = explode(" ",$end_ent);
$date_e_ent = $ar_end_ent[0];
$ftime_e_ent = $ar_end_ent[1];
$ar_ftime_e_ent = explode(":",$ftime_e_ent);
$time_e_ent = $ar_ftime_e_ent[0].":".$ar_ftime_e_ent[1];

////////////////

$sql = "select * from tab_shedule_pers where date = '$date_b_ent'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
while($row = mysqli_fetch_assoc($query))
{

$time = $row['time'];

$ar_time = explode("-",$time);

$f_time = $ar_time[0];
$s_time = $ar_time[1];

$f_time_min = convert_time_to_min($f_time);
$s_time_min = convert_time_to_min($s_time);





}


}



}





}

















?>
