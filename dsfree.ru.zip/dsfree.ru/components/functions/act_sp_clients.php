<?php

function act_sp_clients($vals)
{

#print_r($vals);die();

$name_act = $vals['name_act'];

If($name_act == "act_del_client")
{

include_once("act_del_client.php");
act_del_client($vals);

}
ElseIf($name_act == "add_new_client")
{

include_once("add_new_client.php");
add_new_client($vals);

}


}

?>
