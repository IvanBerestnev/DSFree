<?php

function act_rename_ids($vals)
{

#print_r($vals);


$screen = $vals['screen'];
$id = $vals['id'];
$type = $vals['type'];
$new_name = $vals['new_name'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "update tab_ids set name = '$new_name' where id = '$id'";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_ids_edit_self('",$screen,"','",$type,"');
close_mw('fon_modal_",$screen,"');
</script>
";


}


?>
