<?php

function edit_info_pacs($vals)
{

#print_r($vals);die();

$id_pac = $vals['id_pac'];
$name = $vals['name'];
$val = $vals['val'];

$st = "0";

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$ar_excludes = array("country_pac","obl_pac","type_atd_pac","city_pac","type_street_pac","street_pac","type_house_pac","house_pac","flat_pac");


$ar_excludes_live = array("country_pac_live","obl_pac_live","type_atd_pac_live","city_pac_live","type_street_pac_live","street_pac_live","type_house_pac_live","house_pac_live","flat_pac_live");

If(in_array($name,$ar_excludes))
{
$adr = "adr_reg";
$st = "1";

}
ElseIf(in_array($name,$ar_excludes_live))
{
$adr = "adr_live";
$st = "1";
}

#echo $st;

If($st == "1")
{

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{
$ar = mysqli_fetch_assoc($query);

$json_adr= $ar[$adr];

$ar_adr = json_decode($json_adr,true);

$ar_adr[$name] = $val;


$val_s = json_encode($ar_adr, JSON_UNESCAPED_UNICODE);

$name = $adr;

}

}
Else{
$val_s = $val;



}


$sql = "update tab_pacs set $name = '$val_s' where id_pac = '$id_pac'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);



}

?>
