<?php

function edit_info_pacs($vals)
{

$id_pac = $vals['id_pac'];
$name = $vals['name'];
$val = $vals['val'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update tab_pacs set $name = '$val' where id_pac = '$id_pac'";
#echo $sql;
$query = mysqli_query($connection,$sql);



}

?>
