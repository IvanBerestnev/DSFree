<?php

function get_tab_ssetka_default($id_used_ssetka)
{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_ssetka_default where id_used_ssetka = '$id_used_ssetka'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$ar_exit[$row['number_cell']] = $row['param'];;

}

}
Else{
$ar_exit = array();
}

return $ar_exit;




}

?>
