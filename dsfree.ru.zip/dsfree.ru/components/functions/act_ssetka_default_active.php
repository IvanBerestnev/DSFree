<?php

function act_ssetka_default_active($vals)
{

$id_ssetka_default = $vals['id_ssetka_default'];
$param = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update tab_ssetka_default set active = '$param' where id_ssetka_default = '$id_ssetka_default'";
$query = mysqli_query($connection,$sql);

$sql = "select * from tab_ssetka_default where id_ssetka_default = '$id_ssetka_default'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_used_ssetka = $row['id_used_ssetka'];
$number_cell = $row['number_cell'];

echo "
<script>
open_page_edit_default_ssetka('",$id_used_ssetka,"','",$number_cell,"');
</script>
";

}



}

?>
