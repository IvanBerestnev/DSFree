<?php

function act_change_status_ids($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$type_ids = $vals['type_ids'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_misc_sets where id = 'id_avail_ids_work'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$val = $row['val'];

$ar_avail_types = json_decode($val,true);


$sql = "delete from tab_misc_sets where id = 'id_avail_ids_work'";
$query = mysqli_query($connection,$sql);

}
Else{
$ar_avail_types = array("general"=>"1","terap"=>"1","ortoped"=>"1","chirurg"=>"1","ortodont"=>"1","detstvo"=>"1");
}



If($ar_avail_types[$type_ids] == "1")
{
$ar_avail_types[$type_ids] = "0";
}
Else{
$ar_avail_types[$type_ids] = "1";
}

$json_ar = json_encode($ar_avail_types, JSON_UNESCAPED_UNICODE);

$sql = "insert into tab_misc_sets values('id_avail_ids_work','$json_ar')";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_sp_all_types_ids('",$screen,"');
open_modal_ids_edit_self('",$screen,"','page_change_status_ids','','",$type_ids,"');
</script>
";




}

?>
