<?php

function act_default_ssetka($vals)
{

$id_used_ssetka = $vals['id_used_ssetka'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_used_ssetka where used = '1' and id_pers = (select id_pers from tab_used_ssetka where id_used_ssetka = '$id_used_ssetka')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_used_setka_last = $row['id_used_ssetka'];

$sql = "update tab_used_ssetka set used = '' where id_used_ssetka = '$id_used_setka_last'";
$query = mysqli_query($connection,$sql);

$sql = "update tab_used_ssetka set used = '1' where id_used_ssetka = '$id_used_ssetka'";
$query = mysqli_query($connection,$sql);

echo "

<script>
load_menu_ctlr_type_setka('",$id_used_ssetka,"'); load_menu_setka_self('",$id_used_ssetka,"');
</script>

";

}








}


?>
