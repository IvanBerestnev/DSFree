<?php

function get_params_by_cookie()
{

If(isset($_COOKIE['dsf_cookie']))
{

$id_cookie = $_COOKIE['dsf_cookie'];

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_users where id_user = (select id_user from auths where id_cookie='$id_cookie')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);

$ar['id_user_cookie'] = $row['id_user'];
$ar['name_user_cookie'] = $row['name_user'];
$ar['level_cookie'] = $row['level'];

return $ar;

}

}
Else{
echo "<meta http-equiv=\"refresh\" content=\"0\">";
}




}


?>
