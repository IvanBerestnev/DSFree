<?php

function act_use_new_dogovor_medcart_sp($vals)
{

$param = $vals['param'];
$screen = $vals['screen'];

$ar_param = explode("@",$param);
$id_visit = $ar_param[0];
$id_dog = $ar_param[1];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update pacs_visits set id_dogovor = '$id_dog' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

$sql = "select * from tab_pacs_dogovors where id_dogovor = '$id_dog'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$data_dogovor = $row['data_dogovor'];

}


echo "
<script>
var span_id_dog_medcart_sp = 'span_id_dog_medcart_sp_",$screen,"';
document.getElementById(span_id_dog_medcart_sp).innerHTML = '",$id_dog," от ",$data_dogovor,"';
close_mw('fon_modal_",$screen,"');
</script>
";

}

?>
