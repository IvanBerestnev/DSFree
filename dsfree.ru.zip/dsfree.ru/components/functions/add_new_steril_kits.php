<?php

function add_new_steril_kits($vals)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id = md5(uniqid(rand(),1));

$sql = "insert into tab_steril_kit values ('$id','','','','y')";
$query = mysqli_query($connection,$sql);



}

?>
