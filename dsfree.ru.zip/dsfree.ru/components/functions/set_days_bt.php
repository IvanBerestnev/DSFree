<?php

function set_days_bt($vals)
{

#print_r($vals);

$month = $vals['month'];
$year = $vals['year'];
$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$birth_pac_day = $row['birth_pac_day'];
}


If($month !== "" and $year !== "")
{
$number = cal_days_in_month(CAL_GREGORIAN, $month, $year);

echo "<select id = \"sel_birth_pac_day\" onchange = \"edit_info_pacs('",$screen,"','",$id_pac,"','birth_pac_day',this.value);\" style = \"width: 25%; background-color: #2E3436; color: white;\">
<option value = \"\">день</option>
";
For($i=1;$i<=$number;$i++)
{

echo "<option";

If($birth_pac_day == $i)
{
echo " selected";
}

echo " value = \"",$i,"\">",$i,"</option>";

}
echo "</select>";
}
Else{

echo "
<select style = \"width: 25%; background-color: #2E3436; color: white;\" disabled>
<option>день</option>
</select>
";

}



}

?>
