<?php

function act_save_new_ds($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$ds = $vals['ds'];
$classif = $vals['classif'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_ds = md5(uniqid(rand(),1));

$sql = "insert into sp_dss values ('$id_ds','$ds','$classif')";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_saved_dss('",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>
";


}

?>
