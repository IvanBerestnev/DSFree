<?php

function datatime_razdel_medcart_self($vals)
{


#print_r($vals);

$id_visit = $vals['id_visit'];
$new_txt = $vals['new_txt'];
$screen = $vals['screen'];

$ar_new_txt = explode(" ",$new_txt);

$date = $ar_new_txt[0];
$time = $ar_new_txt[1];

$ar_date = explode("-",$date);
$year = $ar_date['0'];
$month = $ar_date['1'];
$day = $ar_date['2'];

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

$new_datetime_to_td = $day." ".$ar_months_rus[$month]." ".$year." ".$time;


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update pacs_visits set date_time = '$new_txt' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "

<script>
var medcart_self_td_datetime = 'medcart_self_td_datetime_",$id_visit,"_",$screen,"';
document.getElementById(medcart_self_td_datetime).innerHTML = '",$new_datetime_to_td,"';
close_mw('fon_modal_",$screen,"');
</script>

";

}

?>
