<?php

function act_add_new_dogovor_pmu($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$selected_age_dog_pmu = $vals['selected_age_dog_pmu'];
$selected_whopaid_dog_pmu = $vals['selected_whopaid_dog_pmu'];
$id_pac = $vals['id_pac'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_dogovor = md5(uniqid(rand(),1));

$sql = "insert into tab_pacs_dogovors values ('$id_pac','$id_dogovor',now(),now(),'$selected_age_dog_pmu','$selected_whopaid_dog_pmu','','$name_user')";
$query = mysqli_query($connection,$sql);

echo "
<script>
all_dogovor_pmu('",$id_pac,"','",$screen,"');
</script>
";


}


?>
