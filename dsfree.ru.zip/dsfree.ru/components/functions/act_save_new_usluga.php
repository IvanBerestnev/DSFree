<?php

function act_save_new_usluga($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$param = $vals['param'];
$id_price = $vals['id_price'];

$ar_param = explode("@",$param);

$name_usluga = $ar_param[0];
$cena_usluga = $ar_param[1];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$txt_price = $row['txt_price'];

If($txt_price !== "")
{

$ar_new = json_decode($txt_price,true);

}
Else{
$ar_new = array();

}

$id_dw = md5(uniqid(rand(),1));
$ar_new[$id_dw]['name'] = $name_usluga;
$ar_new[$id_dw]['cost'] = $cena_usluga;
$json_ar = json_encode($ar_new, JSON_UNESCAPED_UNICODE);
$sql = "update price set txt_price = '$json_ar' where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_block_price_self('",$id_price,"','",$screen,"');
close_mw('fon_modal_first_",$screen,"');
</script>
";


}




}

?>
