<?php

function act_i_read_new_version($vals)
{

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$id_hv = $vals['id_hv'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "update history_version set showed = '1' where id_hv = '$id_hv'";
$query = mysqli_query($connection,$sql);

echo "<meta http-equiv=\"refresh\" content=\"0\">";


}


?>
