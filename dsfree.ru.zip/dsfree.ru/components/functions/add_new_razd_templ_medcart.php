<?php

function add_new_razd_templ_medcart($vals)
{

#print_r($vals);

$id_ds_income = $vals['id_ds'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss where id_ds = '$id_ds_income'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row_ds = mysqli_fetch_assoc($query);
$name_ds = $row_ds['name_ds'];
}

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];
$ar_decoded = json_decode($text,true);

If(isset($ar_decoded[$id_ds_income][$id_str_templ]['cont']))
{

$id_razd_templ = md5(uniqid(rand(),1));

$ar_decoded[$id_ds_income][$id_str_templ]['cont'][$id_razd_templ]['name'] = "переименуй_меня_напр.жалобы_или_объективно_к_DS: ".$name_ds."";
$ar_decoded[$id_ds_income][$id_str_templ]['cont'][$id_razd_templ]['cont'] = array();

#print_r($ar_decoded);

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);

$sql = "update tab_templ_medcart set text = '$json_ar' where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

}

}


echo "<script>load_razd_templ_medcart('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"');</script>";



}

?>
