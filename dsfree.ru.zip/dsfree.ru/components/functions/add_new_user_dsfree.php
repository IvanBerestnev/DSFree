<?php

function add_new_user_dsfree()
{

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];



$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$id_user = md5(uniqid(rand(),1));

$sql = "insert into dsf_users values ('$id_user','','0','','0',now())";
$query = mysqli_query($connection,$sql);

echo "<script>load_users_dsfree();</script>";


}

?>
