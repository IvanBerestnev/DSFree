<?php

function add_new_struct_templ_medcart($vals)
{

$id_ds_income = $vals['id_ds'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss where id_ds = '$id_ds_income'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row_ds = mysqli_fetch_assoc($query);
$name_ds = $row_ds['name_ds'];

}


$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$id_tm = $row['id_tm'];
$text = $row['text'];
$time_edit = $row['time_edit'];

$ar_decoded = json_decode($text,true);

If(isset($ar_decoded[$id_ds_income]))
{

$ar_decode_ds = $ar_decoded[$id_ds_income];

$id_str_templ = md5(uniqid(rand(),1));
$ar_new = array($id_ds_income=>array($id_str_templ=>array("name"=>"переименуй_меня_напр._лист_медкарты_по_DS: ".$name_ds."","cont"=>array())));

#$m_ar_pre = array_merge($ar_decode_ds,$ar_new);

$m_ar = array_merge_recursive($ar_new,$ar_decoded);

$json_m_ar = json_encode($m_ar, JSON_UNESCAPED_UNICODE);

$sql = "update tab_templ_medcart set text = '$json_m_ar' where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

echo "<script>load_struct_templ_medcart('",$screen,"','",$id_ds_income,"');</script>";



die();

}
Else{

}


}



}


$id_tm = md5(uniqid(rand(),1));
$id_str_templ = md5(uniqid(rand(),1));
$ar_new = array($id_ds_income=>array($id_str_templ=>array("name"=>"переименуй_меня_напр._корка_медкарты_по_DS: ".$name_ds."","cont"=>array(),"locat_ds"=>"")));
$json_ar_new = json_encode($ar_new, JSON_UNESCAPED_UNICODE);

$sql = "insert into tab_templ_medcart values ('$id_tm','$json_ar_new',now())";
$query = mysqli_query($connection,$sql);

echo "<script>load_struct_templ_medcart('",$screen,"','",$id_ds_income,"');</script>";



}

?>
