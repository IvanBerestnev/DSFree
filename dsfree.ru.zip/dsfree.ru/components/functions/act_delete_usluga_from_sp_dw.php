<?php

function act_delete_usluga_from_sp_dw($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];
$no_cost = $vals['no_cost'];
$id_dw = $vals['id_dw'];

function array_remove_by_value($array, $value)
{
$key = array_search($value, $array);
unset($array[$key]);
return $array;
}

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$works = $row['works'];
$ar_works = json_decode($works,true);

$str_full_cost = $ar_works[$id_dw]['full_cost'];
$ar_str_full_cost = explode(";",$str_full_cost);

$ar_new = array_remove_by_value($ar_str_full_cost,$no_cost);

#print_r($ar_new);

If(count($ar_new) !== 0)
{


$str_ar_new = implode(";",$ar_new);
$ar_works[$id_dw]['full_cost'] = $str_ar_new;

}
Else{

unset($ar_works[$id_dw]);

If(count($ar_works) == 0)
{
$sql = "update tab_act_dw set works = '' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "<script>load_block_act_dw('",$id_visit,"','",$screen,"');close_mw('fon_modal_first_",$screen,"');</script>";

die();
}




}

$str_ar_works = json_encode($ar_works, JSON_UNESCAPED_UNICODE);
$sql = "update tab_act_dw set works = '$str_ar_works' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);



echo "<script>load_block_sp_delete_usluga_from_actdw('",$id_visit,"','",$id_dw,"','",$screen,"');load_block_act_dw('",$id_visit,"','",$screen,"');</script>";

}


}

?>
