<?php

function act_rename_ds_medcart_self($vals)
{


#print_r($vals);

$id_visit = $vals['id_visit'];
$new_txt = $vals['new_txt'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "update pacs_visits set ds = '$new_txt' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "

<script>
var span_ds_medcart_self = 'span_ds_medcart_self_",$screen,"';
document.getElementById(span_ds_medcart_self).innerHTML = '",$new_txt,"';
close_mw('fon_modal_",$screen,"');
</script>
";

}


?>
