<?php

function act_sp_medcart($vals)
{

#print_r($vals);

$name = $vals['name'];

If($name == "act_delete_visit_medcart_sp")
{
include_once("act_delete_visit_medcart_sp.php");
act_delete_visit_medcart_sp($vals);
}
ElseIf($name == "act_edit_sp_medcart_ds")
{
include_once("act_edit_sp_medcart_ds.php");
act_edit_sp_medcart_ds($vals);
}
ElseIf($name == "act_use_new_dogovor_medcart_sp")
{
include_once("act_use_new_dogovor_medcart_sp.php");
act_use_new_dogovor_medcart_sp($vals);
}
ElseIf($name == "act_use_new_datatime_medcart_sp")
{
include_once("act_use_new_datatime_medcart_sp.php");
act_use_new_datatime_medcart_sp($vals);
}



}

?>
