<?php

function add_room_jur_uf_control($vals)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_room = md5(uniqid(rand(),1));
$id_uf = md5(uniqid(rand(),1));

$ar_new = array($id_room => array('char'=>array('name'=>'','square'=>'','number'=>''),'ufs'=>array()));
$str_json = json_encode($ar_new, JSON_UNESCAPED_UNICODE);


$sql = "insert into tab_misc_sets values ('5','$str_json')";
$query = mysqli_query($connection,$sql);

}


?>
