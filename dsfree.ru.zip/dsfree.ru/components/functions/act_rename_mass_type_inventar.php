<?php

function act_rename_mass_type_inventar($vals)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$screen = $vals['screen'];
$old_name = $vals['old_name'];
$new_name = $vals['new_name'];


$sql = "update limit_list set type = REPLACE(type,'$old_name','$new_name')";
#echo $sql;
$query = mysqli_query($connection,$sql);

If($query)
{
echo "
<script>
load_block_inventar('",$screen,"','show_all'); load_types_inventar('",$screen,"'); close_mw('fon_modal_",$screen,"');
</script>
";
}



// 

}

?>
