<?php

function change_param_dogovor_pmu($vals)
{


#print_r($vals);

$id_dog = $vals['id_dog'];
$screen = $vals['screen'];
$type = $vals['type'];
$val = $vals['val'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


If($type == "age")
{
$sql = "update tab_pacs_dogovors set age = '$val' where id_dogovor = '$id_dog'";
$query = mysqli_query($connection,$sql);
}
ElseIf($type == "day" or $type == "month" or $type == "year")
{

$sql = "select * from tab_pacs_dogovors where id_dogovor = '$id_dog'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$data_dogovor = $row['data_dogovor'];

$ar_data_dogovor = explode("-",$data_dogovor);
$year = $ar_data_dogovor[0];
$month = $ar_data_dogovor[1];
$day = $ar_data_dogovor[2];

If($type == "day")
{
$new_date = $year."-".$month."-".$val;
}
ElseIf($type == "month")
{
$new_date = $year."-".$val."-".$day;
}
ElseIf($type == "year")
{
$new_date = $val."-".$month."-".$day;
}

$sql = "update tab_pacs_dogovors set data_dogovor = '$new_date' where id_dogovor = '$id_dog'";
$query = mysqli_query($connection,$sql);

}


}

}


?>
