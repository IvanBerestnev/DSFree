<?php

function add_new_azopiram_agent($vals)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_misc_sets where id = '4'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$val = $row['val'];
$ar_decoded = json_decode($val,true);

array_push($ar_decoded['azopiram']['names'], "");


$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);

$sql = "update tab_misc_sets set val = '$json_ar' where id = '4'";
$query = mysqli_query($connection,$sql);

}
Else{

#$id = md5(uniqid(rand(),1));
$ar = array("azopiram"=>array("names"=>array(""),"default"=>"0"),"method"=>array("default"=>"man","excludes"=>array()));
$json_ar = json_encode($ar, JSON_UNESCAPED_UNICODE);

$sql = "insert into tab_misc_sets values ('4','$json_ar')";
$query = mysqli_query($connection,$sql);

}




}

?>
