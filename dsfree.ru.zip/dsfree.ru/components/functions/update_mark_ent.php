<?php

function update_mark_ent($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$val = $vals['val'];
$id_ent = $vals['id_ent'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_ent where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);
If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$beg = $row['begin'];
$end = $row['end'];


$ar_beg = explode(" ",$beg);
$date = $ar_beg[0];
$ftime_b = $ar_beg[1];

#echo $ftime_b;

$ar_ftime_b = explode(":",$ftime_b);
$hb = $ar_ftime_b[0];
$hm = $ar_ftime_b[1];
$hm_b = $hb.":".$hm;

#echo $hm_b;

$ar_end = explode(" ",$end);

#print_r($ar_end);

$ftime_e = $ar_end[1];

#print_r($ftime_e);

$ar_ftime_e = explode(":",$ftime_e);
$hm_e = $ar_ftime_e[0].":".$ar_ftime_e[1];
$period_times = $hm_b."-".$hm_e;

}

$id_tip = "id_".$screen."_".$date."_".$period_times."_tip";




$sql = "update pacs_ent set mark_ent = '$val' where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);


If($val == "")
{
$displ_cont = "none";
}
Else{
$displ_cont = "block";
}



echo "
<script>
document.getElementById('cont_",$id_tip,"').style.display = '",$displ_cont,"';
document.getElementById('",$id_tip,"').innerHTML = '",$val,"';
</script>
";


}

?>
