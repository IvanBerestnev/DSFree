<?php

function act_save_new_param_medcart_self($vals)
{

$name = $vals['name'];

If($name == "act_rename_razd")
{
include_once("act_rename_razd.php");
act_rename_razd($vals);
}
ElseIf($name == "datatime_razdel_medcart_self")
{
include_once("datatime_razdel_medcart_self.php");
datatime_razdel_medcart_self($vals);
}
ElseIf($name == "act_delete_visit")
{
include_once("act_delete_visit.php");
act_delete_visit($vals);
}
ElseIf($name == "act_delete_razdel")
{
include_once("act_delete_razdel.php");
act_delete_razdel($vals);
}
ElseIf($name == "act_ds_rename_medcart_self")
{
include_once("act_rename_ds_medcart_self.php");
act_rename_ds_medcart_self($vals);
}
ElseIf($name == "act_set_doc_medcart_self")
{
include_once("act_set_doc_medcart_self.php");
act_set_doc_medcart_self($vals);
}


}


?>
