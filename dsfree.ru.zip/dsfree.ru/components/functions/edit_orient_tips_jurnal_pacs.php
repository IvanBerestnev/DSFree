<?php

function edit_orient_tips_jurnal_pacs($vals)
{

#print_r($vals);

$action = $vals['action'];
$day = $vals['day'];
$position = $vals['position'];
$screen = $vals['screen'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


If($action == "edit")
{
#echo "123";

//в таблице tab_misc_sets параметры всех окон с шестеренкой под id = 2

$sql = "select * from tab_misc_sets where id = '2'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$ar_json = $row['val'];
$ar_decoded = json_decode($ar_json,true);


If(isset($ar_decoded['params_jur_pacs'][$screen]['tips']['subseq']))
{

$ar_decoded['params_jur_pacs'][$screen]['tips']['subseq'][$day] = $position;

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);
$sql = "update tab_misc_sets set val = '$json_ar' where id = '2'";
$query = mysqli_query($connection,$sql);


}
Else{

$ar_decoded['params_jur_pacs'][$screen]['tips']['subseq'][$day] = $position;

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);
$sql = "update tab_misc_sets set val = '$json_ar' where id = '2'";
$query = mysqli_query($connection,$sql);

}

}
Else{
	
$ar_decoded['params_jur_pacs'][$screen]['tips']['subseq'][$day] = $position;

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);
$sql = "insert into tab_misc_sets values ('2','$json_ar')";
$query = mysqli_query($connection,$sql);


}






}
ElseIf($action == "delete")
{

#print_r($vals);

$sql = "select * from tab_misc_sets where id = '2'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$ar_json = $row['val'];
$ar_decoded = json_decode($ar_json,true);

unset($ar_decoded['params_jur_pacs'][$screen]['tips']['subseq']);

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);

$sql = "update tab_misc_sets set val = '$json_ar' where id = '2'";
$query = mysqli_query($connection,$sql);


}


echo "

<script>
load_sets_jurnal_pacs('",$screen,"','orientation_tips');
</script>

";



}

echo "
<script>
load_ctrl_jurpacs('dunit','",$screen,"');
load_ctrl_jurpacs('c_days','",$screen,"');
load_ctrl_jurpacs('doc','",$screen,"');
load_jurpacs('",$screen,"');
</script>
";



}

?>
