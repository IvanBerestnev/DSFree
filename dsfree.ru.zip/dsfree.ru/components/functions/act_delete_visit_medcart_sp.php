<?php

function act_delete_visit_medcart_sp($vals)
{

$id_visit = $vals['param'];
$screen = $vals['screen'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);
If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$id_pac = $row['id_pac'];

}

$sql = "delete from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "

<script>
load_medcart_general_sp('",$screen,"','",$id_pac,"');
close_mw('fon_modal_",$screen,"');
</script>

";


}


?>
