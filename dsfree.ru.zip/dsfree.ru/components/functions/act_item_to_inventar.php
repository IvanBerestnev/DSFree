<?php

function act_item_to_inventar($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$name_item_inventar = $vals['name_item_inventar'];
$types_item_inventar = $vals['types_item_inventar'];
$limit_data = $vals['limit_data'];
$comment_item_inventar = $vals['comment_item_inventar'];
$param = $vals['param'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



If($param !== "")
{
$sql = "delete from limit_list where id = '$param'";
$query = mysqli_query($connection,$sql);

}
Else{

$param = md5(uniqid(rand(),1));

}



$sql = "insert into limit_list values ('$param','$types_item_inventar','$name_item_inventar','$limit_data','$comment_item_inventar')";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_block_inventar('",$screen,"','show_all','');
load_types_inventar('",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>
";

}

?>
