<?php

function print_act_dw($vals)
{

#print_r($vals);die();

$id_act_dw = $vals['id_act_dw'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


include_once "../components/lib/vendor/autoload.php";

$document_with_table = new \PhpOffice\PhpWord\PhpWord();

//ffffff

$tableStyle = array('borderSize' => 1, 'borderColor' => '999999');
$styleCell = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');

$styleCell_rowspan = array('borderTopSize'=>1 ,'borderTopColor' =>'black','borderLeftSize'=>1,'borderLeftColor' =>'black','borderRightSize'=>1,'borderRightColor'=>'black','borderBottomSize' =>1,'borderBottomColor'=>'black');

$myFontStyle = array('bold' => true, 'align' => 'center');
$myFontStyle_other = array('align' => 'center');

$date = date("Y-m-d H:i:s");

$section = $document_with_table->addSection();
$table = $section->addTable();



$sql = "select * from tab_act_dw where id_act_dw = '$id_act_dw'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{
	
$row = mysqli_fetch_assoc($query);
$id_visit = $row['id_visit'];
$date_write = $row['date_write'];
$works = $row['works'];
$id_act_dw = $row['id_act_dw'];

$ar_date_write = explode(" ",$date_write);
$date_only_write = $ar_date_write[0];

$info_act_dw = $id_act_dw." от ".$date_only_write;

}

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_dogovor = $row['id_dogovor'];
$id_pac = $row['id_pac'];
}




$sql = "select * from tab_pacs_dogovors where id_dogovor = '$id_dogovor'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$rows = mysqli_fetch_assoc($query);
$data_dogovor = $rows['data_dogovor'];
$num_dog_data = $id_dogovor." от ".$data_dogovor;
}

#echo $num_dog_data;die();


$sql = "select * from tab_pacs where id_pac = '$id_pac'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$rows = mysqli_fetch_assoc($query);
$surname_pac = $rows['surname_pac'];
$name_pac = $rows['name_pac'];
$fio_pac = $surname_pac." ".$name_pac;
}

#echo $fio_pac;die();

$table->addRow();
$table->addCell(7500, $styleCell)->addText("Услуги и их количество",$myFontStyle,array('align' => 'center','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));
$table->addCell(3500, $styleCell)->addText("Стоимость",$myFontStyle,array('align' => 'center','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));

$ar_works = json_decode($works,true);

Foreach($ar_works as $ar_valls)
{
	
$name = $ar_valls['name'];
$full_cost = $ar_valls['full_cost'];

$ar_full_cost = explode(";",$full_cost);

Foreach($ar_full_cost as $ap_cost)
{

$ar_ap_cost = explode("-",$ap_cost);

$cost_actual = $ar_ap_cost[0];
$cost_price = $ar_ap_cost[1];

If($cost_actual == $cost_price)
{
$ar_new_costs[] = $cost_actual." р.";
}
Else{

$discont = (100-($cost_actual*100)/$cost_price)."%";

$ar_new_costs[] = $cost_price." - ".$discont." = ".$cost_actual." р.";

}

$ar_cost_summ[] = $cost_actual;

}


$str_cost = "</w:t><w:br/><w:t>".implode("</w:t><w:br/><w:t>",$ar_new_costs)."</w:t><w:br/><w:t>";


$table->addRow();
$table->addCell(7500, $styleCell)->addText($name,$myFontStyle_other,array('align' => 'left','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));
$table->addCell(3500, $styleCell)->addText($str_cost,$myFontStyle_other,array('align' => 'center','size'=>'12','spaceAfter'=>0,'lineHeight'=>1.0));

$ar_new_costs = array();
}




// Create writer to convert document to xml
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');

// Get all document xml code
$fullxml = $objWriter->getWriterPart('document')->write();

// Get only table xml code
$tablexml = '</w:t></w:r></w:p>'.preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml).'<w:p><w:r><w:t>';

//Open template with ${table}
$template_document = new \PhpOffice\PhpWord\TemplateProcessor("../components/download/act_dw.docx");



// Replace mark by xml code of table
$template_document->setValue('mytable', $tablexml);
$template_document->setValue('num_dog_data', $num_dog_data);
$template_document->setValue('fio_pac', $fio_pac);
$template_document->setValue('info_act_dw', $info_act_dw);

$cost_summ = "Общая сумма составляет - ".array_sum($ar_cost_summ)." рублей.";

$template_document->setValue('cost_summ', $cost_summ);


$filename = "акт выполненных работ.docx";
$template_document->saveAs($filename);


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);




}

?>
