<?php

function act_add_external_medcart_temple($vals)
{


#print_r($vals);

$screen = $vals['screen'];
$id_ds = $vals['id_ds'];
$name_funct = $vals['name_funct'];
$name_ds = $vals['name_ds'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_ds_new = md5(uniqid(rand(),1));

$sql = "insert into sp_dss values ('$id_ds_new','$name_ds','')";
$query = mysqli_query($connection,$sql);

include_once("../components/blocks/templates/".$name_funct.".php");
$ar = $name_funct();

$ar_new[$id_ds_new] = $ar[$id_ds];

array_walk_recursive($ar_new, function(&$item, $key) {
    $item = addslashes($item);
    
});


#$json_ar = htmlspecialchars($ar_new);

$json_ar = json_encode($ar_new, JSON_UNESCAPED_UNICODE);

$json_ar = str_replace('<', 'менее', $json_ar);
$json_ar = str_replace('>', 'более', $json_ar);

$json_ar = preg_replace('/[[:cntrl:]]/', '', $json_ar);

$id_tm = md5(uniqid(rand(),1));

$sql = "insert into tab_templ_medcart values ('$id_tm','$json_ar',now())";
$query = mysqli_query($connection,$sql);





}


?>
