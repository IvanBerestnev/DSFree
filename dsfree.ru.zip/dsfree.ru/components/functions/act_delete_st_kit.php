<?php

function act_delete_st_kit($vals)
{

$id = $vals['id'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "delete from tab_steril_kit where id = '$id'";
$query = mysqli_query($connection,$sql);



}

?>
