<?php

function delete_ds($vals)
{

$screen = $vals['screen'];
$id_ds = $vals['id_ds'];

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "delete from sp_dss where id_ds = '$id_ds'";
mysqli_query($connection,$sql);


$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{


while($row = mysqli_fetch_assoc($query))
{

$text = $row['text'];
$id_tm = $row['id_tm'];

$ar_decoded = json_decode($text,true);

If(isset($ar_decoded[$id_ds]))
{
$sql = "delete from tab_templ_medcart where id_tm = '$id_tm'";
mysqli_query($connection,$sql);

}

}



}



echo "<script>
close_mw('fon_modal_",$screen,"');
load_saved_dss('",$screen,"');
</script>";

}

?>
