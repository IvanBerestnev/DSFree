<?php

function print_primary_docums($vals)
{

#print_r($vals);

$name = $vals['name'];
$param = $vals['param'];

If($name == "dogovor_pmu")
{
include_once("download_dogovor_pmu.php");
download_dogovor_pmu($param);
}

ElseIf($name == "anketa_zd")
{
include_once("download_anketa_zd.php");
download_anketa_zd($param);
}

ElseIf($name == "plan_treat")
{
include_once("download_plan_treat.php");
download_plan_treat($param);
}
ElseIf($name == "epikriz")
{
include_once("download_epikriz.php");
download_epikriz($param);
}

ElseIf($name == "medcart")
{
include_once("download_medcart.php");
download_medcart($param);
}


}

?>
