<?php

function add_write_jur_uf_control($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_uf_device = $vals['id_uf_device'];
$usl_dezinf = $vals['usl_dezinf'];
$obj_dezinf = $vals['obj_dezinf'];
$vid_microb = $vals['vid_microb'];
$exposure_mode = $vals['exposure_mode'];
$tbeg_jur_uf_control = $vals['tbeg_jur_uf_control'];
$tend_jur_uf_control = $vals['tend_jur_uf_control'];

$days = $vals['days'];
$month_jur_uf_control = $vals['month_jur_uf_control'];
$year_jur_uf_control = $vals['year_jur_uf_control'];


$ar_days = explode("#",$days);


#print_r($ar_dates);



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


Foreach($ar_days as $day)
{
$wdate = $year_jur_uf_control."-".$month_jur_uf_control."-".$day;

$id = md5(uniqid(rand(),1));

$sql = "insert into jur_uf_control values ('$id','$wdate','$usl_dezinf','$obj_dezinf','$vid_microb','$exposure_mode','$tbeg_jur_uf_control','$tend_jur_uf_control')";
$query = mysqli_query($connection,$sql);


}

echo "
<script>
load_jur_uf_control('",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>
";



}

?>
