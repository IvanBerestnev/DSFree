<?php

function tab_permissions_default()
{

$ar["jur_pacs"]["name"] = "Журнал записи пациентов";
$ar["jur_pacs"]["content"]["show_jur"]["name"] = "Просмотр журнала";
$ar["jur_pacs"]["content"]["show_jur"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["show_jur"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["show_jur"]["levels"]["1"] = "1";
$ar["jur_pacs"]["content"]["show_jur"]["levels"]["0"] = "1";

$ar["jur_pacs"]["content"]["write_doc_shed"]["name"] = "Установка расписания врачу в свободное время";
$ar["jur_pacs"]["content"]["write_doc_shed"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["write_doc_shed"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["write_doc_shed"]["levels"]["1"] = "0";
$ar["jur_pacs"]["content"]["write_doc_shed"]["levels"]["0"] = "0";


$ar["jur_pacs"]["content"]["write_pac_ent_into_shedule"]["name"] = "Запись пациента";
$ar["jur_pacs"]["content"]["write_pac_ent_into_shedule"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["write_pac_ent_into_shedule"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["write_pac_ent_into_shedule"]["levels"]["1"] = "1";
$ar["jur_pacs"]["content"]["write_pac_ent_into_shedule"]["levels"]["0"] = "0";

$ar["jur_pacs"]["content"]["correct_shed_time_doc"]["name"] = "Коррекция промежутка рабочего времени врача";
$ar["jur_pacs"]["content"]["correct_shed_time_doc"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["correct_shed_time_doc"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["correct_shed_time_doc"]["levels"]["1"] = "0";
$ar["jur_pacs"]["content"]["correct_shed_time_doc"]["levels"]["0"] = "0";


$ar["jur_pacs"]["content"]["del_period_shed_time_doc"]["name"] = "Удаление промежутка рабочего времени врача";
$ar["jur_pacs"]["content"]["del_period_shed_time_doc"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["del_period_shed_time_doc"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["del_period_shed_time_doc"]["levels"]["1"] = "0";
$ar["jur_pacs"]["content"]["del_period_shed_time_doc"]["levels"]["0"] = "0";


$ar["jur_pacs"]["content"]["change_doc_shed_times"]["name"] = "Замена врача";
$ar["jur_pacs"]["content"]["change_doc_shed_times"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["change_doc_shed_times"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["change_doc_shed_times"]["levels"]["1"] = "0";
$ar["jur_pacs"]["content"]["change_doc_shed_times"]["levels"]["0"] = "0";

$ar["jur_pacs"]["content"]["cancel_ent"]["name"] = "Отмена приема пациента";
$ar["jur_pacs"]["content"]["cancel_ent"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["cancel_ent"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["cancel_ent"]["levels"]["1"] = "0";
$ar["jur_pacs"]["content"]["cancel_ent"]["levels"]["0"] = "0";


$ar["jur_pacs"]["content"]["corr_time_ent_pac"]["name"] = "Коррекция времени приема пациента";
$ar["jur_pacs"]["content"]["corr_time_ent_pac"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["corr_time_ent_pac"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["corr_time_ent_pac"]["levels"]["1"] = "0";
$ar["jur_pacs"]["content"]["corr_time_ent_pac"]["levels"]["0"] = "0";

$ar["jur_pacs"]["content"]["change_pac_jurpac"]["name"] = "Замена пациента";
$ar["jur_pacs"]["content"]["change_pac_jurpac"]["levels"]["3"] = "1";
$ar["jur_pacs"]["content"]["change_pac_jurpac"]["levels"]["2"] = "1";
$ar["jur_pacs"]["content"]["change_pac_jurpac"]["levels"]["1"] = "0";
$ar["jur_pacs"]["content"]["change_pac_jurpac"]["levels"]["0"] = "0";

$ar["jur_pacs"]["content"]["info_pac"]["name"] = "Информация о пациенте";

$ar["jur_pacs"]["content"]["info_pac"]["availible"]["0"] = "read_write";
$ar["jur_pacs"]["content"]["info_pac"]["availible"]["1"] = "read";
$ar["jur_pacs"]["content"]["info_pac"]["availible"]["2"] = "disable";

$ar["jur_pacs"]["content"]["info_pac"]["levels"]["3"] = "read_write";
$ar["jur_pacs"]["content"]["info_pac"]["levels"]["2"] = "read_write";
$ar["jur_pacs"]["content"]["info_pac"]["levels"]["1"] = "read";
$ar["jur_pacs"]["content"]["info_pac"]["levels"]["0"] = "disable";


$ar["mass_doc_shed"]["name"] = "Массовое расписание врачей";
$ar["mass_doc_shed"]["availible"]["0"] = "read_write";
$ar["mass_doc_shed"]["availible"]["1"] = "disable";
$ar["mass_doc_shed"]["levels"]["3"] = "read_write";
$ar["mass_doc_shed"]["levels"]["2"] = "read_write";
$ar["mass_doc_shed"]["levels"]["1"] = "disable";
$ar["mass_doc_shed"]["levels"]["0"] = "disable";


$ar["sp_docs"]["name"] = "Список врачей";
$ar["sp_docs"]["availible"]["0"] = "read_write";
$ar["sp_docs"]["availible"]["1"] = "read";
$ar["sp_docs"]["availible"]["2"] = "disable";
$ar["sp_docs"]["levels"]["3"] = "read_write";
$ar["sp_docs"]["levels"]["2"] = "read_write";
$ar["sp_docs"]["levels"]["1"] = "disable";
$ar["sp_docs"]["levels"]["0"] = "disable";


return $ar;

}

?>
