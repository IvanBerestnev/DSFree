<?php

function checkexit_mobile()
{

If(isset($_COOKIE['dsf_cookie']))
{
$id_cookie = $_COOKIE['dsf_cookie'];

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from auths where id_cookie='$id_cookie'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_user = $row['id_user'];
$date = $row['date'];
#$level_access = $row['level_access'];

$timestamp_bd = strtotime($date);
$date_now = date('Y-m-d H:i:s');
$timestamp_now = strtotime($date_now);

If($timestamp_now-$timestamp_bd>3600)
{

//Выход из авторизации, т.к. время авторизации вышло
setcookie("dsf_cookie", "", time()-360000, "/", "");

//Удаление из БД
$sql = "delete from auths where id_cookie = '$id_cookie'";
$query = mysqli_query($connection,$sql);

//Создание куки интервалом 1 сек о таймауте куки и ресет
setcookie("dsf_cookie_inf", "cookie_timeout", time()+1, "/", "");

echo "<meta http-equiv=\"refresh\" content=\"0\">";
die();

}
Else{

$sql = "select used from dsf_users where used = '0' and id_user = (select id_user from auths where id_cookie = '$id_cookie')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

//Выход из авторизации, т.к. пользователь отключен
setcookie("dsf_cookie", "", time()-360000, "/", "");

//Удаление из кук из БД т.к. пользователь отключен
$sql = "delete from auths where id_cookie = '$id_cookie'";
$query = mysqli_query($connection,$sql);

//Создание куки интервалом 1 сек о том что пользователь отключен и ресет
setcookie("dsf_cookie_inf", "user_disable", time()+1, "/", "");
echo "<meta http-equiv=\"refresh\" content=\"0\">";

die();
}


}
}
Else{


echo "<meta http-equiv=\"refresh\" content=\"0\">";
//поддельные куки

#setcookie("dsf_cookie", "", time()-3600, "/", "");
#$txt = "wrong_cookie";
#include_once("../components/pages/logo.php");
#logo($txt);
#die();

}

}
Else{

#echo "<meta http-equiv=\"refresh\" content=\"0\">";
#echo "11111111111111111";
include_once("../components/pages/logo_mobile.php");
#$txt = "cookie_timeout";
logo_mobile("");
die();

}


}


?>
