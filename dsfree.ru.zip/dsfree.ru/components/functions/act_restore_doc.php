<?php

function act_restore_doc($vals)
{

$screen = $vals['screen'];
$id_doc = $vals['id_pers'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from archive_pers where id_pers = '$id_doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
	
$row = mysqli_fetch_assoc($query);


$id_pers = $row['id_pers'];
$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];
$type = $row['type'];

$bg_color_gen = $row['bg_color_gen'];
$txt_color_gen = $row['txt_color_gen'];
$txt_color_pac = $row['txt_color_pac'];
$bg_color_pac = $row['bg_color_pac'];


$sql = "insert into tab_personal values ('$id_pers','$name_pers','$surname_pers','$patronymic_pers','$type','$bg_color_gen','$txt_color_gen','$txt_color_pac','$bg_color_pac')";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_archive_sp_docs('",$screen,"');
</script>
";


}


}

?>
