<?php

function print_ids($vals)
{

#print_r($vals);die();

$id_ids = $vals['id_ids'];
$id_pac = $vals['id_pac'];
$id_dogovor = $vals['id_dogovor'];
$id_doc = $vals['id_doc'];
$cert_doc = $vals['cert_doc'];

$id_other_lica = $vals['id_other_lica'];

$day_income = $vals['day'];
$month_income = $vals['month'];
$year_income = $vals['year'];


$data_income = $day_income.".".$month_income.".".$year_income;


$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


//////инфа о враче
$sql = "select * from tab_personal where id_pers = '$id_doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

#$id_pers = $row['id_pers'];
$ar_pers['name_pers'] = $row['name_pers'];
$ar_pers['surname_pers'] = $row['surname_pers'];
$ar_pers['patronymic_pers'] = $row['patronymic_pers'];


}

If($cert_doc !== "")
{
$full_str_pers = $cert_doc.", ".implode(" ",$ar_pers);
}
Else{
$full_str_pers = implode(" ",$ar_pers);
}

$str_pers = implode(" ",$ar_pers);
}
////////////


/////Инфо о 3м лице

If($id_other_lica !== "")
{
$ar_id_other_lica = explode("@",$id_other_lica);

If(isset($ar_id_other_lica[0]))
{
$other_lica_1 = $ar_id_other_lica[0];

$sql = "select * from tab_pacs where id_pac = '$other_lica_1'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$ar_fio['surname_pac'] = $row['surname_pac'];
$ar_fio['name_pac'] = $row['name_pac'];
$ar_fio['patronymic_pac'] = $row['patronymic_pac'];

$phone = $row['phone'];

$str_fio_phone_1 = implode(" ",$ar_fio).", ".$phone;

}

}
Else{
$str_fio_phone_1 = "----------------------------------------------------------------------------------";
}

If(isset($ar_id_other_lica[1]))
{
$other_lica_2 = $ar_id_other_lica[1];


$sql = "select * from tab_pacs where id_pac = '$other_lica_2'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$ar_fio_2['surname_pac'] = $row['surname_pac'];
$ar_fio_2['name_pac'] = $row['name_pac'];
$ar_fio_2['patronymic_pac'] = $row['patronymic_pac'];

$phone = $row['phone'];

$str_fio_phone_2 = implode(" ",$ar_fio_2).", ".$phone;

}


}
Else{
$str_fio_phone_2 = "----------------------------------------------------------------------------------";
}



}
Else{
$str_fio_phone_1 = "----------------------------------------------------------------------------------";
$str_fio_phone_2 = "----------------------------------------------------------------------------------";
}


/////////////



$sql = "select * from tab_pacs_dogovors where id_dogovor = '$id_dogovor'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$data_dogovor = $row['data_dogovor'];

}


///Раскладываем дату договора

$ar_data_dogovor = explode("-",$data_dogovor);

$day_prereg = $ar_data_dogovor[2];

$day_reg = date("d",mktime(0,0,0,1,$day_prereg,1970));

$month_reg = $ar_data_dogovor[1];
$year_reg = $ar_data_dogovor[0];

///Собираем ${num_dog_data}
$num_dog_data = $id_dogovor." от \"".$day_reg."\" ".$ar_months_rus[$month_reg]." ".$year_reg."г.";


///////////Информация о пациенте

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);
$ar_pac = mysqli_fetch_assoc($query);

$ar_fio_pac['surname'] = $ar_pac['surname_pac'];
$ar_fio_pac['name'] = $ar_pac['name_pac'];
$ar_fio_pac['patronymic'] = $ar_pac['patronymic_pac'];

$phone = $ar_pac['phone'];

$fio_pac = implode(" ",$ar_fio_pac);
$fio_pac_phone = implode(" ",$ar_fio_pac).", ".$phone;


$pre_d_birth_pac = $ar_pac['birth_pac_day'];
$d_birth_pac = date("d",mktime(0,0,0,1,$pre_d_birth_pac,1970));

$m_birth_pac = $ar_pac['birth_pac_month'];
$y_birth_pac = $ar_pac['birth_pac_year'];



//Операции с адресом места жительства пациента
$adr_reg = $ar_pac['adr_reg'];
$ar_adr_reg = json_decode($adr_reg,true);
$str_adr_reg = implode(" ",$ar_adr_reg);



$adr_live = $ar_pac['adr_live'];
$ar_adr_live = json_decode($adr_live,true);
$str_adr_live = implode(" ",$ar_adr_live);




If($str_adr_reg !== $str_adr_live)
{

If($str_adr_live == "")
{
$str_adr_live = "------------------------------------------------------";
}
Else{

$ar_adr_live = json_decode($adr_live,true);
$str_adr_live = implode(" ",$ar_adr_live);

}




}
Else{
$str_adr_live = "------------------------------------------------------";
}




/////////////////




//////////////////Генерируем документ

include_once "../components/lib/vendor/autoload.php";
$document_with_table = new \PhpOffice\PhpWord\PhpWord();

// Create writer to convert document to xml
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');

// Get all document xml code
$fullxml = $objWriter->getWriterPart('document')->write();

// Get only table xml code
$tablexml = '</w:t></w:r></w:p>'.preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml).'<w:p><w:r><w:t>';

//Open template with ${table}
$template_document = new \PhpOffice\PhpWord\TemplateProcessor("../components/download/standart_ids.docx");



$template_document->setValue('num_dog_data', $num_dog_data);
$template_document->setValue('fio_pac', $fio_pac);

$template_document->setValue('fio_pac_phone', $fio_pac_phone);


$template_document->setValue('d_birth_pac', $d_birth_pac);
$template_document->setValue('m_birth_pac', $ar_months_rus[$m_birth_pac]);
$template_document->setValue('y_birth_pac', $y_birth_pac);

$template_document->setValue('day_reg', $day_income);
$template_document->setValue('month_reg', $ar_months_rus[$month_income]);
$template_document->setValue('year_reg', $year_income);

$template_document->setValue('str_pers', $str_pers);

$template_document->setValue('adr_pac', $str_adr_reg);
$template_document->setValue('adr_pac_live', $str_adr_live);

$template_document->setValue('full_str_pers', $full_str_pers);

$template_document->setValue('other_lica_1', $str_fio_phone_1);
$template_document->setValue('other_lica_2', $str_fio_phone_2);


$filename = "Анкета здоровья_".$fio_pac."_".$data_income.".docx";

$template_document->saveAs($filename);


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);





}

?>
