<?php

function act_block_act_dw_admin($vals)
{

#print_r($vals);

$id_act_dw = $vals['id_act_dw'];
$screen = $vals['screen'];
$param = $vals['param'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_act_dw where id_act_dw = '$id_act_dw'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$status = $row['status'];
}


$sql = "select * from tab_pacs where id_pac = (select id_pac from pacs_visits where id_visit = (select id_visit from tab_act_dw where id_act_dw = '$id_act_dw'))";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_pac = $row['id_pac'];
}



If($param == "admin_accept_yes")
{

If($status == "1")
{
$sql = "update tab_act_dw set status = '2' where id_act_dw = '$id_act_dw'";
$query = mysqli_query($connection,$sql);
}


}
ElseIf($param == "admin_accept_no")
{

If($status == "1" or $status == "2")
{
$sql = "update tab_act_dw set status = '0' where id_act_dw = '$id_act_dw'";
$query = mysqli_query($connection,$sql);
}



}
ElseIf($param == "admin_accept_pay_pacient")
{

If($status == "2")
{
$sql = "update tab_act_dw set status = '3' where id_act_dw = '$id_act_dw'";
$query = mysqli_query($connection,$sql);
echo "<script>close_mw('fon_modal_",$screen,"');</script>";
}

}



echo "<script>load_block_act_dw_admin('",$id_pac,"','",$screen,"');</script>";


}


}


?>
