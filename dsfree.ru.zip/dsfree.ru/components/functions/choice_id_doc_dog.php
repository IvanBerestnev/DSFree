<?php

function choice_id_doc_dog($vals)
{

$screen = $vals['screen'];
$val = $vals['val'];
$id_dog = $vals['id_dog'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update tab_pacs_dogovors set id_doc = '$val' where id_dogovor = '$id_dog'";
$query = mysqli_query($connection,$sql);


}

?>
