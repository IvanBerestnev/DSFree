<?php

function act_use_new_datatime_medcart_sp($vals)
{

#print_r($vals);

$param = $vals['param'];
$screen = $vals['screen'];

$ar_param = explode("@",$param);
$id_visit = $ar_param[0];
$new_datetime = $ar_param[1];

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update pacs_visits set date_time = '$new_datetime' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

$ar_new_datetime = explode(" ",$new_datetime);
$date = $ar_new_datetime['0'];
$time = $ar_new_datetime['1'];

$ar_date = explode("-",$date);
$year = $ar_date[0];
$month = $ar_date[1];
$day = $ar_date[2];

$rus_month = $ar_months_rus[$month];

$new_date = $day." ".$rus_month." ".$year;
$new_dt_txt = $new_date. " ".$time;
#echo $new_dt_txt;

echo "
<script>
var span_date_time_sp_medcart = 'span_date_time_sp_medcart_",$screen,"';
document.getElementById(span_date_time_sp_medcart).innerHTML = '",$new_dt_txt,"';
close_mw('fon_modal_",$screen,"');
</script>
";



}


?>
