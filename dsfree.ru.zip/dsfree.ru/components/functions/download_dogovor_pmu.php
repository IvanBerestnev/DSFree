<?php

function download_dogovor_pmu($param)
{

$id_dogovor = $param;

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"Июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs_dogovors where id_dogovor = '$id_dogovor'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pac = $row['id_pac'];
$data_dogovor = $row['data_dogovor'];
$age = $row['age'];
$whopaid = $row['whopaid'];

///Раскладываем дату договора

$ar_data_dogovor = explode("-",$data_dogovor);

$day_reg = $ar_data_dogovor[2];
$month_reg = $ar_data_dogovor[1];
$year_reg = $ar_data_dogovor[0];

///////////Информация о пациенте

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);
$ar_pac = mysqli_fetch_assoc($query);

$ar_fio_pac['surname'] = $ar_pac['surname_pac'];
$ar_fio_pac['name'] = $ar_pac['name_pac'];
$ar_fio_pac['patronymic'] = $ar_pac['patronymic_pac'];
$fio_pac = implode(" ",$ar_fio_pac);

$birth_pac_day = $ar_pac['birth_pac_day'];
$birth_pac_month = $ar_pac['birth_pac_month'];
$birth_pac_year = $ar_pac['birth_pac_year'];

If($birth_pac_day == "" and $birth_pac_month == "" and $birth_pac_year == "")
{
$birth_pac_str = "";
}
ElseIf($birth_pac_day !== "" and $birth_pac_month == "" and $birth_pac_year == "")
{
$birth_pac_str = "день рождения ".$birth_pac_day." числа";
}
ElseIf($birth_pac_day == "" and $birth_pac_month !== "" and $birth_pac_year == "")
{
$birth_pac_str = "месяц рождения - ".$birth_pac_month.", ";
}
ElseIf($birth_pac_day == "" and $birth_pac_month == "" and $birth_pac_year !== "")
{
$birth_pac_str = "год рождения - ".$birth_pac_year.", ";
}
ElseIf($birth_pac_day !== "" and $birth_pac_month !== "" and $birth_pac_year == "")
{
$birth_pac_str = "дата рождения ".$birth_pac_day." ".$birth_pac_month.", ";
}
ElseIf($birth_pac_day !== "" and $birth_pac_month == "" and $birth_pac_year !== "")
{
$birth_pac_str = $birth_pac_year." года рождения ".$birth_pac_day." числа неизвестного месяца";
}
ElseIf($birth_pac_day !== "" and $birth_pac_month !== "" and $birth_pac_year !== "")
{
$birth_pac_str = $birth_pac_day.".".$birth_pac_month.".".$birth_pac_year." года рождения";
}

$ar_info_str[] = $birth_pac_str;


//Операции с документом личности пациента
$docum_pac = $ar_pac['docum'];
If($docum_pac == "")
{
$docum_pac = "";
}


$ar_info_str[] = $docum_pac;

//Операции с адресом места жительства пациента
$ar_adr_pac[] = $ar_pac['country_pac'];
$ar_adr_pac[] = $ar_pac['obl_pac'];
$ar_adr_pac[] = $ar_pac['type_atd_pac'];
$ar_adr_pac[] = $ar_pac['city_pac'];
$ar_adr_pac[] = $ar_pac['type_street_pac'];
$ar_adr_pac[] = $ar_pac['street_pac'];
$ar_adr_pac[] = $ar_pac['type_house_pac'];
$ar_adr_pac[] = $ar_pac['house_pac'];
$ar_adr_pac[] = $ar_pac['flat_pac'];

Foreach($ar_adr_pac as $val)
{
If($val !== "")
{
$ar_adr_ne_pac[] = $val;
}
}

If(isset($ar_adr_ne_pac))
{
$adr_str_pac = "адрес места жительства ".implode(" ",$ar_adr_ne_pac);
//Адрес в конце
$adr_pac_end = implode(" ",$ar_adr_ne_pac);

$ar_info_str[] = $adr_str_pac;
}
Else{
$adr_str_pac = "НЕЛЬЗЯ ЗАКЛЮЧАТЬ ДОГОВОР!! НЕ УКАЗАН АДРЕС!!";
$adr_pac_end = "НЕЛЬЗЯ ЗАКЛЮЧАТЬ ДОГОВОР!! НЕ УКАЗАН АДРЕС!!";
$ar_info_str[] = $adr_str_pac;
}



//Операции с телефоном пациента и емайлом
$phone_pac = $ar_pac['phone'];
If($phone_pac !== "")
{
$phone_pac = "Телефон ".$phone_pac;
$phone_pac_end = $phone_pac;
}
Else{
$phone_pac = "НЕЛЬЗЯ ЗАКЛЮЧАТЬ ДОГОВОР! НЕ УКАЗАН ТЕЛЕФОН !!";
$phone_pac_end = "НЕЛЬЗЯ ЗАКЛЮЧАТЬ ДОГОВОР! НЕ УКАЗАН ТЕЛЕФОН !!";
}



$ar_info_str[] = $phone_pac;

#print_r($ar_info_str);die();


$email_pac = $ar_pac['email'];
If($email_pac !== "")
{
$email_pac = "адрес электронной почты ".$email_pac;
}

$ar_info_str[] = $email_pac;

Foreach($ar_info_str as $val)
{
If($val !== "")
{
$ar_info_str_new[] = $val;
}
}

$str_info_str_new = implode(", ",$ar_info_str_new);


//////////////////

include_once("../components/lib/phpword/PHPWord.php");
$PHPWord = new PHPWord();
$document = $PHPWord->loadTemplate("../components/download/dogovor_self_adult.docx");

$document->setValue('id_dogovor', $id_dogovor);
$document->setValue('city', $city);
$document->setValue('fio_pac', $fio_pac);
$document->setValue('day_now', $day_reg);
$document->setValue('month_now', $ar_months_rus[$month_reg]);
$document->setValue('year_now', $year_reg);
$document->setValue('str_info_str_new', $str_info_str_new);
$document->setValue('adr_pac_end', $adr_pac_end);
$document->setValue('phone_pac_end', $phone_pac_end);


$filename = "Договор_.docx";

$document->save($filename);

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Connection: Keep-Alive');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($filename));

ob_get_clean();
 echo file_get_contents($filename);
 ob_end_flush();
unlink($filename);

die();


}

}

?>
