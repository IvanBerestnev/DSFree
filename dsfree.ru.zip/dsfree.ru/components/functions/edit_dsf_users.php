<?php

function edit_dsf_users($vals)
{


include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_user = $vals['id_user'];
$type = $vals['type'];
$val = $vals['val'];

If($type == "p_create_pass")
{

//onclick = \"edit_dsf_users(\'$id_user\','pass_set','');\"

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_add\');\">X</span><table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\"><tr><td style = \"font-weight: bold;\">Создайте пароль</td></tr><tr><td><input id = \"id_inp_pass_user\"><br>пароль</td></tr><tr><td><input id = \"id_inp_repass_user\"><br>подтвердите</td></tr><tr height = \"10%\"><td><span id = \"f_id_pass_txt\"></span></td></tr><tr height = \"20%\" style = \"background-color: #8AE234; color: black; cursor: pointer; font-weight: bold;\"><td onclick = \"edit_dsf_users(\'".$id_user."\',\'pass_set\',\'\');\">сохранить</td></tr></table>";

echo "<script>open_modal_users_dsfree('",$txt,"','400','500')</script>";

die();
}
ElseIf($type == "pass_set")
{

#print_r($vals);die();


$hash_pass = md5($val);

$sql = "update dsf_users set password_user = '$hash_pass' where id_user = '$id_user'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);
echo "<script>close_mw('fon_modal_add');load_users_dsfree();</script>";
die();
}
ElseIf($type == "en_dis_acc")
{

$sql = "select * from dsf_users where id_user = '$id_user'";
$query = mysqli_query($connection,$sql);

$row = mysqli_fetch_assoc($query);

$name_user = $row['name_user'];
$password_user = $row['password_user'];

If($name_user == "" or $pass_user == "")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_add\');\">X</span><table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\"><tr><td style = \"font-weight: bold;\">Невозможно продолжить</td></tr><tr><td valign = \"top\">Для активизации учетной записи требуется заполненное имя или пароль</td></tr></table>";
echo "<script>open_modal_users_dsfree('",$txt,"','400','300')</script>";

}
Else{

$sql = "update dsf_users set used = '$val' where id_user = '$id_user'";
$query = mysqli_query($connection,$sql);
echo "<script>close_mw('fon_modal_add');load_users_dsfree();</script>";

}

die();
}
ElseIf($type == "p_delete")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_add\');\">X</span><table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\"><tr><td style = \"font-weight: bold;\">Удалить учетную запись?</td></tr><tr><td><b>ВНИМАНИЕ!</b><br><br>Аккуратно используйте эту опцию.<br><br>Используйте тогда - если Вы только что создали учетную запись и не успели в ней поработать.<br><br>По возможности - используйте функцию \'Отключить\'</td></tr><tr height = \"10%\"><td><span id = \"f_id_pass_txt\"></span></td></tr><tr height = \"20%\" style = \"background-color: #8AE234; color: black; cursor: pointer; font-weight: bold;\"><td onclick = \"edit_dsf_users(\'".$id_user."\',\'s_delete\',\'\');\">удалить</td></tr></table>";

echo "<script>open_modal_users_dsfree('",$txt,"','400','500')</script>";

die();

}
ElseIf($type == "s_delete")
{

$sql = "delete from dsf_users where id_user = '$id_user'";
$query = mysqli_query($connection,$sql);
echo "<script>close_mw('fon_modal_add');load_users_dsfree();</script>";
die();
}
ElseIf($type == "level_user")
{

$sql = "update dsf_users set level = '$val' where id_user = '$id_user'";
$query = mysqli_query($connection,$sql);
die();

}


$sql = "update dsf_users set $type = '$val' where id_user = '$id_user'";
#echo $sql;
$query = mysqli_query($connection,$sql);





}


?>
