<?php

function act_delete_cert_doc($vals)
{

$screen = $vals['screen'];
$id_cert = $vals['id_cert'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_docs_cert where id_cert = '$id_cert'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_doc = $row['id_doc'];

}


$sql = "delete from tab_docs_cert where id_cert = '$id_cert'";
$query = mysqli_query($connection,$sql);


echo "
<script>load_cert_doc('",$screen,"','",$id_doc,"');</script>
";


}

?>
