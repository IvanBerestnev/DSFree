<?php

function act_medcart_self_add_new_razd($vals)
{

#print_r($vals);

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];
$text = $vals['text'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$text_bd = $row['txt_treat'];
$ar_text_bd = json_decode($text_bd,true);

$new_id_razd = md5(uniqid(rand(),1));

$ar_text_bd[$new_id_razd]['name'] = $text;
$ar_text_bd[$new_id_razd]['cont'] = "";
$ar_text_bd[$new_id_razd]['templ'] = "";



}




$json_ar = json_encode($ar_text_bd, JSON_UNESCAPED_UNICODE);

$sql = "update pacs_visits set txt_treat = '$json_ar' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "<script>load_block_medcart_self('",$id_visit,"','",$screen,"');close_mw('fon_modal_",$screen,"');</script>";

}

?>
