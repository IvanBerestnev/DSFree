<?php

function set_pac_sex($vals)
{

#print_r($vals);

$id_pac = $vals['id_pac'];
$name_pac = $vals['name_pac'];
$patronymic_pac = $vals['patronymic_pac'];

If($patronymic_pac !== "")
{

$end_patr = mb_substr($patronymic_pac, -2);

If($end_patr == "ич")
{
echo "m";
}
ElseIf($end_patr == "на")
{
echo "w";
}
Else{
echo "";
}

}
ElseIf($name_pac !== "")
{

$end_name = mb_substr($name_pac, -1);

If($end_name == "а" or $end_name == "я")
{
echo "w";
}
Else{
echo "m";
}

}
Else{

echo "";

}




}

?>
