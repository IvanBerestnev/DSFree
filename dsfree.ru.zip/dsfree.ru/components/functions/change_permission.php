<?php

function change_permission($vals)
{

#print_r($vals);



$id_permission = $vals['id_permission'];
$eng_base_key = $vals['eng_base_key'];
$eng_cont_name = $vals['eng_cont_name'];
$code_users = $vals['code_users'];
$level_self = $vals['level_self'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_permissions where id_permission = '$id_permission'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$ar_permissions = $row['permissions'];
$ar = json_decode($ar_permissions,true);
}


If($eng_base_key == "jur_pacs")
{


If(isset($ar[$eng_base_key]['content'][$eng_cont_name]['levels'][$code_users]))
{

$now_level = $ar[$eng_base_key]['content'][$eng_cont_name]['levels'][$code_users];

If($now_level == "0" or $now_level == "1")
{

If($now_level == "1")
{
$now_level = "0";
}
ElseIf($now_level == "0")
{
$now_level = "1";
}

$ar[$eng_base_key]['content'][$eng_cont_name]['levels'][$code_users] = $now_level;

echo $now_level;

}
Else{

$ar[$eng_base_key]['content'][$eng_cont_name]['levels'][$code_users] = $level_self;

}

}
Else{

#echo "123";



}











}
Else{

$ar[$eng_base_key]['levels'][$code_users] = $level_self;


}


$ar_encode = json_encode($ar, JSON_UNESCAPED_UNICODE);
$sql = "update tab_permissions set permissions = '$ar_encode' where id_permission = '$id_permission'";
$query = mysqli_query($connection,$sql);



}

?>
