<?php

function act_add_page_price($vals)
{


$name = $vals['name'];

If($name == "act_delete_price")
{
include_once("act_delete_price.php");
act_delete_price($vals);
}
ElseIf($name == "act_add_new_price")
{
include_once("act_add_new_price.php");
act_add_new_price($vals);
}
ElseIf($name == "act_rename_new_price")
{
include_once("act_rename_new_price.php");
act_rename_new_price($vals);
}
ElseIf($name == "act_save_new_usluga")
{
include_once("act_save_new_usluga.php");
act_save_new_usluga($vals);
}
ElseIf($name == "act_save_new_usluga")
{
include_once("act_save_new_usluga.php");
act_save_new_usluga($vals);
}
ElseIf($name == "act_delete_usluga_price")
{
include_once("act_delete_usluga_price.php");
act_delete_usluga_price($vals);
}
ElseIf($name == "act_edit_usluga_price")
{
include_once("act_edit_usluga_price.php");
act_edit_usluga_price($vals);
}




}

?>
