<?php

function act_delete_razdel($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];
$id_writed_razd = $vals['id_writed_razd'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$txt_treat = $row['txt_treat'];

$ar_txt_treat = json_decode($txt_treat,true);

unset($ar_txt_treat[$id_writed_razd]);

If(count($ar_txt_treat) == 0)
{

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);
If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$id_pac = $row['id_pac'];

}


$sql = "delete from pacs_visits where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "
<script>
close_mw('fon_modal_",$screen,"');
edit_first_docum('medcart_general','",$id_pac,"','",$screen,"');
</script>
";

}
Else{

$json_ar = json_encode($ar_txt_treat, JSON_UNESCAPED_UNICODE);

$sql = "update pacs_visits set txt_treat = '$json_ar' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "<script>load_block_medcart_self('",$id_visit,"','",$screen,"');close_mw('fon_modal_",$screen,"');</script>";

}



}



}

?>
