<?php

function write_new_pac_ent_jurpac($vals)
{

#print_r($vals);die();

$screen = $vals['screen'];
$sel_beg = $vals['sel_beg'];
$sel_end = $vals['sel_end'];
$id_doc = $vals['id_doc'];
$id_pac = $vals['id_pac'];
$unit = $vals['unit'];
$type_sending = $vals['type_sending'];

$date_b = $vals['date_b'];
$date_e = $vals['date_e'];

$tb = date("H:i", mktime(0, $sel_beg, 0, 1, 1, 1970));
$te = date("H:i", mktime(0, $sel_end, 0, 1, 1, 1970));


$b = $date_b." ".$tb;
$e = $date_b." ".$te;


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

If($type_sending == "new_pac")
{
$id_new_pac = md5(uniqid(rand(),1));
$sql = "insert into tab_pacs values ('$id_new_pac','$id_pac','','','','','','','','','','','','','','','','','','','','','a1',now())";
$query = mysqli_query($connection,$sql);

$id_pac = $id_new_pac;
}


$id_ent = md5(uniqid(rand(),1));

$sql = "insert into pacs_ent values ('$id_ent','$id_pac','$b','$e','$unit','$id_doc','a',now(),'')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


echo "
<script>
reload_jurpacs_cell_colors('",$screen,"');
var first_date_jur = 'first_date_jur_",$screen,"';
var fdj = document.getElementById(first_date_jur).innerHTML;
var ar_fdj = fdj.split('.');
var n_time_js = ar_fdj.join('-');
send_date_from_cal_to_jurpacs(n_time_js,'",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>
";



}


?>
