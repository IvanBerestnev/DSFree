<?php

function add_profile_ssetka_user($vals)
{

$id_user = $vals['id_user'];
$id_ssetka = $vals['id_ssetka'];




include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

//Проверка, есть ли вообще у пользователя сохраненнный профиль. Если нет, то будет по умолчанию.

$sql = "select * from tab_used_ssetka where id_pers = '$id_user'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$used = "";
}
Else{
$used = "1";
}



include_once("../components/functions/tab_avail_ssetka.php");
$ar_avail_ssetka = tab_avail_ssetka();

$val = $ar_avail_ssetka[$id_ssetka];

$new_json_val = json_encode($val, JSON_UNESCAPED_UNICODE);


$id_used_ssetka = md5(uniqid(rand(),1));

$sql = "insert into tab_used_ssetka values ('$id_used_ssetka','$id_user','$new_json_val','$used')";
$query = mysqli_query($connection,$sql);

echo "
<script>
show_info_setka_in_addsetka('",$id_user,"');
</script>
";


}


?>
