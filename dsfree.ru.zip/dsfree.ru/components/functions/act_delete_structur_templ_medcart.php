<?php

function act_delete_structur_templ_medcart($vals)
{

#print_r($vals);

$id_ds_income = $vals['id_ds_income'];
$id_pac = $vals['id_pac'];
$id_tm = $vals['id_tm'];
$id_str_templ = $vals['id_str_templ'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];
$ar_decoded = json_decode($text,true);

If(isset($ar_decoded[$id_ds_income][$id_str_templ]))
{

unset($ar_decoded[$id_ds_income][$id_str_templ]);

#print_r($ar_decoded);

$ar_check = $ar_decoded[$id_ds_income];


If(empty($ar_check))
{
$sql = "delete from tab_templ_medcart where id_tm = '$id_tm'";
#echo $sql;
$query = mysqli_query($connection,$sql);
}
Else{

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);
$sql = "update tab_templ_medcart set text = '$json_ar' where id_tm = '$id_tm'";
#echo $sql;
$query = mysqli_query($connection,$sql);

}


}

}

echo "<script>load_struct_templ_medcart('",$screen,"','",$id_ds_income,"','",$id_pac,"');close_mw('fon_modal_",$screen,"');</script>";


}

?>
