<?php

function act_add_new_visit($vals)
{

$param = $vals['param'];
$screen = $vals['screen'];

$ar_param = explode("@",$param);
$id_pac = $ar_param['0'];
$id_dss = $ar_param['1'];
$id_str = $ar_param['2'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

/////////////////
///Получение свежайшего номера договора по дате.
$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac' order by data_dogovor DESC limit 1";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$data_dogovor = $row['data_dogovor'];

$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac' and data_dogovor = '$data_dogovor' order by data_write DESC limit 1";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row_new = mysqli_fetch_assoc($query);
$id_dogovor = $row_new['id_dogovor'];
}

}
Else{
#$id_visit = md5(uniqid(rand(),1));
echo "для продолжения оформите договор";
}

/////////////////
//////Получение названия dss
$sql = "select * from sp_dss where id_ds = '$id_dss'";
$query = mysqli_query($connection,$sql);
If(mysqli_num_rows($query) !== 0)
{
$row_dss = mysqli_fetch_assoc($query);
$name_ds = $row_dss['name_ds'];
}

//////////////
////Заполнение txt_treat

$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$bd_text = $row['text'];
$id_tm = $row['id_tm'];

$bd_text = preg_replace('/[[:cntrl:]]/', '', $bd_text);
$ar_bd_text = json_decode($bd_text,true);

If(key($ar_bd_text) == $id_dss)
{

$ar_work = $ar_bd_text[$id_dss][$id_str]['cont'];

Foreach($ar_work as $id_razd=>$ar_valls)
{

$name_razd = $ar_valls['name'];

$id_new_razd = md5(uniqid(rand(),1));

$ar_new_medcart_write[$id_new_razd]['name'] = $name_razd;
$ar_new_medcart_write[$id_new_razd]['cont'] = "";
$ar_new_medcart_write[$id_new_razd]['templ'] = $id_str."@".$id_razd."@".$id_dss;

}
}
}

}

////////////////

#print_r($ar_new_medcart_write);

If(isset($ar_new_medcart_write))
{

array_walk_recursive($ar_new_medcart_write, function(&$item, $key) {
    $item = addslashes($item);
});

$json_ar = json_encode($ar_new_medcart_write, JSON_UNESCAPED_UNICODE);
}
Else{
$json_ar = "";
}


$id_visit = md5(uniqid(rand(),1));
$sql = "insert into pacs_visits values ('$id_visit','$id_dogovor',now(),'$id_pac','','$name_ds','$json_ar','$id_tm')";
$query = mysqli_query($connection,$sql);

echo "<script>close_mw('fon_modal_",$screen,"');load_medcart_general_sp('",$screen,"','",$id_pac,"');</script>";
#echo $sql;


}

?>
