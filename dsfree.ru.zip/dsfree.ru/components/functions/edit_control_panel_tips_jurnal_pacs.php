<?php

function edit_control_panel_tips_jurnal_pacs($vals)
{

#print_r($vals);

$act = $vals['act'];
$value = $vals['value'];
$screen = $vals['screen'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_misc_sets where id = '2'";
$query = mysqli_query($connection,$sql);

If($act == "change_height_control_panel")
{

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$ar_json = $row['val'];
$ar_decoded = json_decode($ar_json,true);

$ar_decoded['params_jur_pacs'][$screen]['control_panel']['height'] = $value;

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);
$sql = "update tab_misc_sets set val = '$json_ar' where id = '2'";
$query = mysqli_query($connection,$sql);

}
Else{

$ar_decoded['params_jur_pacs'][$screen]['control_panel']['height'] = $value;

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);
$sql = "insert into tab_misc_sets values ('2','$json_ar')";
$query = mysqli_query($connection,$sql);

}



}
ElseIf($act == "default_set_control_panel")
{

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$ar_json = $row['val'];
$ar_decoded = json_decode($ar_json,true);

If(isset($ar_decoded['params_jur_pacs'][$screen]['control_panel']['height']))
{

unset($ar_decoded['params_jur_pacs'][$screen]['control_panel']['height']);

$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);

$sql = "update tab_misc_sets set val = '$json_ar' where id = '2'";
$query = mysqli_query($connection,$sql);


echo "
<script>
load_sets_jurnal_pacs('",$screen,"','panel_control');
</script>
";


}


}


}



echo "
<script>
trunc_screen('",$screen,"');
load_page_screen('jur_pacs','",$screen,"');
</script>
";


}

?>
