<?php

function act_add_new_data_act_dw($vals)
{

$name_act = $vals['name_act'];


If($name_act == "new_act_dw")
{

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];
$id_price = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$id_act_dw = md5(uniqid(rand(),1));
$sql = "insert into tab_act_dw values ('$id_act_dw','$id_visit','$id_price','','',now(),'0')";
$query = mysqli_query($connection,$sql);
echo "<script>load_block_act_dw('",$id_visit,"','",$screen,"');</script>";

}
ElseIf($name_act == "act_add_new_uslugi_act_dw")
{

#print_r($vals);

//name_add_new_usl + '@' + count_add_new_usl + '@' + new_cost_uslugi + '@' + default_cost_uslugi;
$screen = $vals['screen'];
$id_visit = $vals['id_visit'];
$param = $vals['param'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$ar_param = explode("@",$param);
$name_usl = $ar_param[0];
$count_usl = $ar_param[1];
$new_cost_usl = $ar_param[2];
$default_cost_uslugi = $ar_param[3];


For($i=0;$i<$count_usl;$i++){$ar_new_old[] = $new_cost_usl."-".$default_cost_uslugi;}
$str_new_def_old = implode(";",$ar_new_old);


$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$works = $row['works'];

If($works !== "")
{

$ar = json_decode($works,true);

$x=0;

Foreach($ar as $id_dw=>$ar_valls)
{

$name_usl_bd = $ar_valls['name'];
$full_cost_bd = $ar_valls['full_cost'];


If($name_usl_bd == $name_usl)
{

$new_f_cost = $full_cost_bd.";".$str_new_def_old;
$ar[$id_dw]['full_cost'] = $new_f_cost;

$str_ar = json_encode($ar, JSON_UNESCAPED_UNICODE);

$sql = "update tab_act_dw set works = '$str_ar' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "
<script>
load_block_act_dw('",$id_visit,"','",$screen,"');
close_mw('fon_modal_first_",$screen,"');
</script>";

die();

}

}

$id_dw = md5(uniqid(rand(),1));

$ar[$id_dw]['full_cost'] = $str_new_def_old;
#$ar[$id_dw]['discont'] = "0";
$ar[$id_dw]['name'] = $name_usl;


}
Else{

$id_dw = md5(uniqid(rand(),1));

$ar[$id_dw]['full_cost'] = $str_new_def_old;
#$ar[$id_dw]['discont'] = "0";
$ar[$id_dw]['name'] = $name_usl;

}


}
Else{


$id_dw = md5(uniqid(rand(),1));

$ar[$id_dw]['full_cost'] = $str_new_def_old;
#$ar[$id_dw]['discont'] = "0";
$ar[$id_dw]['name'] = $name_usl;



}






$str_ar = json_encode($ar, JSON_UNESCAPED_UNICODE);

#echo $str_ar;

$sql = "update tab_act_dw set works = '$str_ar' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);


echo "<script>load_block_act_dw('",$id_visit,"','",$screen,"');</script>";

}
ElseIf($name_act == "act_delete_act_dw")
{

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "delete from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "

<script>
close_mw('fon_modal_first_",$screen,"');
close_mw('fon_modal_",$screen,"');
</script>

";

}
ElseIf($name_act == "erase_delete_act_dw")
{

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update tab_act_dw set works = '' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "

<script>
close_mw('fon_modal_first_",$screen,"');
load_block_act_dw('",$id_visit,"','",$screen,"');
</script>

";

}

ElseIf($name_act == "update_gen_discont")
{

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];
$discont = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "update tab_act_dw set discont = '$discont' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

echo "

<script>
close_mw('fon_modal_first_",$screen,"');
load_block_act_dw('",$id_visit,"','",$screen,"');
</script>

";

}
ElseIf($name_act == "act_delete_concrt_usluga_from_actdw")
{

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];
$id_dw = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$works = $row['works'];

If($works !== "")
{

$ar = json_decode($works,true);

unset($ar[$id_dw]);

If(count($ar)>0)
{
$str_ar = json_encode($ar, JSON_UNESCAPED_UNICODE);
$sql = "update tab_act_dw set works = '$str_ar' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);
}
Else{
$sql = "update tab_act_dw set works = '' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);
}

}

}

echo "<script>load_block_act_dw('",$id_visit,"','",$screen,"');</script>";

}
ElseIf($name_act == "accept_visit")
{

#echo "123";
#print_r($vals);die();

$param = $vals['param'];
$id_visit = $vals['id_visit'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$works = $row['works'];
$status = $row['status'];


If($works == "")
{

If($status == "4")
{
$sql = "update tab_act_dw set status = '0' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);
}
Else{

$sql = "update tab_act_dw set status = '4' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

}



echo "<script>load_block_act_dw('",$id_visit,"','",$screen,"');</script>";

}
Else{

If($status == "0")
{
$sql = "update tab_act_dw set status = '1' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);
}
ElseIf($status == "1")
{
$sql = "update tab_act_dw set status = '0' where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);
}




echo "<script>load_block_act_dw('",$id_visit,"','",$screen,"');</script>";

}

}








}



echo "<script>close_mw('fon_modal_first_",$screen,"');</script>";


}

?>
