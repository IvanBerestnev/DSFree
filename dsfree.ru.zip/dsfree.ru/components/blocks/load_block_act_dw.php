<?php

function load_block_act_dw($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$status = $row['status'];

If($status == "0")
{
include_once("st0_block_act_dw.php");
st0_block_act_dw($vals);
}
ElseIf($status == "1")
{
include_once("st1_block_act_dw.php");
st1_block_act_dw($vals);
}
ElseIf($status == "2")
{
include_once("st2_block_act_dw.php");
st2_block_act_dw($vals);
}
ElseIf($status == "3")
{
include_once("st3_block_act_dw.php");
st3_block_act_dw($vals);
}
ElseIf($status == "4")
{
include_once("st4_block_act_dw.php");
st4_block_act_dw($vals);
}

}


Else{

echo "<script>open_page_add_act_dw('",$id_visit,"','",$screen,"','select_price');</script>";

}







}

?>
