<?php

function sel_run_act_bottom_jp($vals)
{

include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();
$level_cookie = $ar_vals['level_cookie'];
$int_level_cookie = (int)$level_cookie;



include_once("../components/blocks/check_permissions.php");




#print_r($vals);
$act = $vals['act'];
$screen = $vals['screen'];
$param = $vals['param'];



echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

If($act == "cancel_ent")
{


$permission = check_permissions($int_level_cookie,"jur_pacs","cancel_ent");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}	


include_once("cancel_ent.php");
cancel_ent($vals);


}
ElseIf($act == "write_pac_ent_into_shedule")
{

$permission = check_permissions($int_level_cookie,"jur_pacs","write_pac_ent_into_shedule");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}


#print_r($vals);

$ar_param = explode("#",$param);
$dt_be = $ar_param[0];
$ar_dt_be = explode("@",$dt_be);
$dt_b = $ar_dt_be[0];
$dt_e = $ar_dt_be[1];

#echo $dt_b, "@",$dt_e;

$ar_dt_b = explode(" ",$dt_b);
$t_b = $ar_dt_b[1];
$d_b = $ar_dt_b[0];
$ar_t_b = explode(":",$t_b);
$t_b_hour = $ar_t_b[0];
$t_b_min = $ar_t_b[1];
$t_b_m = ($t_b_hour*60)+$t_b_min;
$t_b_m_second = $t_b_m;

$ar_dt_e = explode(" ",$dt_e);
$t_e = $ar_dt_e[1];
$d_e = $ar_dt_e[0];
$ar_t_e = explode(":",$t_e);
$t_e_hour = $ar_t_e[0];
$t_e_min = $ar_t_e[1];
$t_e_m = ($t_e_hour*60)+$t_e_min;
$t_e_m_second = $t_e_m;

$unit = $ar_param[1];
$id_doc = $ar_param[2];

echo "

<script>


function load_field_ent_pac(page,param)
{

if(page == 'last_pacs')
{
var id_inp_search_surname_ent_pac = 'id_inp_search_surname_ent_pac_",$screen,"';
document.getElementById(id_inp_search_surname_ent_pac).value = '';

var id_but_write_pac_jurpac_active = 'id_but_write_pac_jurpac_active_",$screen,"';
document.getElementById(id_but_write_pac_jurpac_active).style.display = 'none';

var id_but_write_pac_jurpac_inactive = 'id_but_write_pac_jurpac_inactive_",$screen,"';
document.getElementById(id_but_write_pac_jurpac_inactive).style.display = 'block';

}
else if(page == 'search_pac_by_surname')
{


var not_match_searching_surname_pac = 'not_match_searching_surname_pac_",$screen,"';

var e = document.getElementById(not_match_searching_surname_pac);
if (e) {

} else {

var id_but_write_pac_jurpac_active = 'id_but_write_pac_jurpac_active_",$screen,"';
document.getElementById(id_but_write_pac_jurpac_active).style.display = 'none';

var id_but_write_pac_jurpac_inactive = 'id_but_write_pac_jurpac_inactive_",$screen,"';
document.getElementById(id_but_write_pac_jurpac_inactive).style.display = 'block';

}

}

var id_selected_id_pac_ent_pac = 'id_selected_id_pac_ent_pac_",$screen,"';
document.getElementById(id_selected_id_pac_ent_pac).innerHTML = ''

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_field_ent_pac') + \"&data[screen]=\" + encodeURIComponent('",$screen,"') + \"&data[page]=\" + encodeURIComponent(page) + \"&data[param]=\" + encodeURIComponent(param));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var id_f_write_ent_pac = 'id_f_write_ent_pac_' + ",$screen,";
var cont = document.getElementById(id_f_write_ent_pac);

cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}



function recalc_select_end_jurpac(sel_beg,add)
{

if(sel_beg == '')
{

var id_select_begin_jurpac = 'id_select_begin_jurpac_",$screen,"';
var e = document.getElementById(id_select_begin_jurpac);
var sel_beg = e.options[e.selectedIndex].value;

}


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('recalc_select_end_jurpac') + \"&data[screen]=\" + encodeURIComponent('",$screen,"') + \"&data[sel_beg]=\" + encodeURIComponent(sel_beg) + \"&data[add]=\" + encodeURIComponent(add) + \"&data[t_e_m_second]=\" + encodeURIComponent('",$t_e_m_second,"') + \"&data[screen]=\" + encodeURIComponent('",$screen,"'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var id_td_select_end_jurpac = 'id_td_select_end_jurpac_' + ",$screen,";
var cont = document.getElementById(id_td_select_end_jurpac);

cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function write_new_pac_ent_jurpac()
{

///

var not_match_searching_surname_pac = 'not_match_searching_surname_pac_",$screen,"';

var e = document.getElementById(not_match_searching_surname_pac);
if (e) {

//назовем живую фамилию под id_pac
var id_inp_search_surname_ent_pac = 'id_inp_search_surname_ent_pac_",$screen,"';
var id_pac = document.getElementById(id_inp_search_surname_ent_pac).value;

var type_sending = 'new_pac';

}
else{

var id_selected_id_pac_ent_pac = 'id_selected_id_pac_ent_pac_",$screen,"';
var id_pac = document.getElementById(id_selected_id_pac_ent_pac).innerHTML;

var type_sending = 'old_pac';

}

///


var id_select_begin_jurpac = 'id_select_begin_jurpac_",$screen,"';
var e = document.getElementById(id_select_begin_jurpac);
var sel_beg = e.options[e.selectedIndex].value;

var id_select_end_jurpac = 'id_select_end_jurpac_",$screen,"';

var e = document.getElementById(id_select_end_jurpac);
if (e) {

var sel_end = e.options[e.selectedIndex].value;

} else {

var id_span_end_jurpac = 'id_span_end_jurpac_",$screen,"';
var sel_end = document.getElementById(id_span_end_jurpac).innerHTML;

}


var id_doc = '",$id_doc,"';
var unit = '",$unit,"';



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('write_new_pac_ent_jurpac') + \"&data[screen]=\" + encodeURIComponent('",$screen,"') + \"&data[sel_beg]=\" + encodeURIComponent(sel_beg) + \"&data[sel_end]=\" + encodeURIComponent(sel_end) + \"&data[id_doc]=\" + encodeURIComponent(id_doc) + \"&data[unit]=\" + encodeURIComponent(unit) + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[date_b]=\" + encodeURIComponent('",$d_b,"') + \"&data[date_e]=\" + encodeURIComponent('",$d_e,"') + \"&data[type_sending]=\" + encodeURIComponent(type_sending));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var modal = 'modal_' + ",$screen,";
var cont = document.getElementById(modal);

cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}



}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"13%\">
<td colspan = \"2\" align = \"left\" style = \"padding-left: 5px; font-size: 17px; color: white; font-weight: bold; background-color: black;\">
Назначить пациента
</td>
</tr>

<tr>
<td width = \"30%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td width = \"50%\">

<select id = \"id_select_begin_jurpac_",$screen,"\" onchange = \"recalc_select_end_jurpac(this.value,'');\" style = \"width: 85%; font-size: 20px; text-align: center;\">";


For($t_b_m;$t_b_m<$t_e_m;$t_b_m=$t_b_m+5)
{

$t = date("H:i", mktime(0, $t_b_m, 0, 1, 1, 1970));

echo "<option value = \"",$t_b_m,"\">",$t,"</option>";

}



echo "
</select>

</td>
<td id = \"id_td_select_end_jurpac_",$screen,"\">

<select id = \"id_select_end_jurpac_",$screen,"\" style = \"width: 85%; font-size: 20px; text-align: center;\">";

$t_b_m_second_fp = $t_b_m_second;
$min_selected = $t_b_m_second_fp+180;


#echo $min_selected, " ",$t_e_m_second;

If($min_selected>$t_e_m_second)
{
$min_selected = $t_e_m_second;
}


#echo $min_selected;

$i=0;
For($t_b_m_second;$t_b_m_second<=$t_e_m_second;$t_b_m_second=$t_b_m_second+5)
{
If($i==0)
{
$i++;
continue;

}

$t = date("H:i", mktime(0, $t_b_m_second, 0, 1, 1, 1970));

echo "<option value = \"",$t_b_m_second,"\"";

If($t_b_m_second == $min_selected)
{
echo " selected";
}

echo ">",$t,"</option>";

}



echo "</select>

</td>
</tr>

<tr>
<td colspan = \"2\" style = \"background-color: #555753;\">

<button onclick = \"recalc_select_end_jurpac('','0.5');\" style = \"margin: 5px; padding: 3px;\">
15 мин
</button>

<button onclick = \"recalc_select_end_jurpac('','0.5');\" style = \"margin: 5px; padding: 3px;\">
30 мин
</button>


<button onclick = \"recalc_select_end_jurpac('','1');\" style = \"margin: 5px; padding: 3px;\">
1 час
</button>

<button onclick = \"recalc_select_end_jurpac('','1.5');\" style = \"margin: 5px; padding: 3px;\">
1.5 часа
</button>

<button onclick = \"recalc_select_end_jurpac('','2');\" style = \"margin: 5px; padding: 3px;\">
2 часа
</button>

<button onclick = \"recalc_select_end_jurpac('','2.5');\" style = \"margin: 5px; padding: 3px;\">
2.5 часа
</button>

<button onclick = \"recalc_select_end_jurpac('','3');\" style = \"margin: 5px; padding: 3px;\">
3 часа
</button>

<button onclick = \"recalc_select_end_jurpac('','3.5');\" style = \"margin: 5px; padding: 3px;\">
3.5 часа
</button>

<button onclick = \"recalc_select_end_jurpac('','4');\" style = \"margin: 5px; padding: 3px;\">
4 часа
</button>


</td>
</tr>

<tr>
<td height = \"15%\" colspan = \"2\" style = \"font-size: 18px; cursor: pointer;\">

<span style = \"display: block; height: 100%; width: 100%;\" id = \"id_but_write_pac_jurpac_inactive_",$screen,"\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; background-color: E6F0E6; color: grey; cursor: default;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>запись</td>
</tr>
</table>


</span>

<span style = \"display: none; height: 100%; width: 100%;\" id = \"id_but_write_pac_jurpac_active_",$screen,"\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; background-color: 47F949; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"write_new_pac_ent_jurpac();\">запись</td>
</tr>
</table>

</span>

</td>

</tr>

</table>

</td>

<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"16%\">
<td>

<input id = \"id_inp_search_surname_ent_pac_",$screen,"\" onkeyup = \"load_field_ent_pac('search_pac_by_surname',this.value);\" style = \"width: 95%; height: 75%; font-size: 25px;\">

</td>
<td onclick = \"load_field_ent_pac('last_pacs','');\" width = \"20%\" style = \"cursor: pointer; font-weight: bold; color: red; font-size: 25+px;\">
X
</td>
</tr>
<tr>
<td colspan = \"2\">

<div style = \"width: 100%; height: 100%;\" id = \"id_f_write_ent_pac_",$screen,"\"></div>


</td>
</tr>
</table>

</td>


</tr>
</table>

<span id = \"id_selected_id_pac_ent_pac_",$screen,"\"></span>

<script>
load_field_ent_pac('last_pacs','');
</script>

";


}
ElseIf($act == "write_doc_shed")
{

////////////////////
$permission = check_permissions($int_level_cookie,"jur_pacs","write_doc_shed");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}


include_once("write_doc_shed.php");
write_doc_shed($vals);



}

ElseIf($act == "change_doc_shed_times")
{


$permission = check_permissions($int_level_cookie,"jur_pacs","change_doc_shed_times");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}

include_once("change_doc_shed_times.php");
change_doc_shed_times($vals);




}

ElseIf($act == "correct_shed_time_doc")
{


////////////////////
$permission = check_permissions($int_level_cookie,"jur_pacs","correct_shed_time_doc");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}

include_once("correct_shed_time_doc.php");
correct_shed_time_doc($vals);




}

ElseIf($act == "del_period_shed_time_doc")
{

////////////////////
$permission = check_permissions($int_level_cookie,"jur_pacs","del_period_shed_time_doc");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}



include_once("del_period_shed_time_doc.php");
del_period_shed_time_doc($vals);





}

ElseIf($act == "change_pac_jurpac")
{

////////////////////
$permission = check_permissions($int_level_cookie,"jur_pacs","change_pac_jurpac");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}


include_once("change_pac_jurpac.php");
change_pac_jurpac($vals);

}

ElseIf($act == "corr_time_ent_pac")
{


////////////////////
$permission = check_permissions($int_level_cookie,"jur_pacs","corr_time_ent_pac");
If($permission == "0")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}

include_once("corr_time_ent_pac.php");
corr_time_ent_pac($vals);



}


ElseIf($act == "info_pac")
{


////////////////////
$permission = check_permissions($int_level_cookie,"jur_pacs","info_pac");

#echo $permission;

If($permission == "disable")
{
include_once("../components/pages/page_lock.php");
page_lock();
return false;
}
ElseIf($permission == "read")
{
#include_once("../components/pages/page_lock.php");
#page_lock();
include_once("../components/blocks/info_pac_readonly.php");
info_pac_readonly($vals);
#echo "только чтение";
return false;
}
ElseIf($permission == "read_write")
{
include_once("info_pac.php");
info_pac($vals);	
}





}



}

?>
