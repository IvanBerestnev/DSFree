<?php

function load_msd_calendar($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$type = $vals['type'];

$month = $vals['month'];
$year = $vals['year'];

$unit = $vals['unit'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



$num_wd = date("N",mktime(0, 0, 0, $month, 1, $year));
$q_days = cal_days_in_month(CAL_GREGORIAN, $month, $year);

$day_now = date("j");
$month_now = date("n");
$year_now = date("Y");



If($type == "only_freetime")
{

$datetime_begin = $year."-".$month."-"."01";
$datetime_end = $year."-".$month."-".$q_days;

$sql = "select * from tab_shedule_pers where date between STR_TO_DATE('$datetime_begin', '%Y-%m-%d') and STR_TO_DATE('$datetime_end', '%Y-%m-%d') and unit = '$unit'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$date_bd = $row['date'];

$ar_date_bd = explode("-",$date_bd);
$day_bd = $ar_date_bd[2];

$ar_date[] = $day_bd;


}

$ar_date_uniq = array_unique($ar_date);
asort($ar_date_uniq);


}
Else{

$ar_date_uniq = array();



}



#print_r($ar_date_uniq);die();

}
ElseIf($type == "only_wout_pacs")
{

$datetime_begin = $year."-".$month."-"."01 00:00:00";
$datetime_end = $year."-".$month."-".$q_days. " 23:59:59";

$sql = "select * from pacs_ent where begin between STR_TO_DATE('$datetime_begin', '%Y-%m-%d') and STR_TO_DATE('$datetime_end', '%Y-%m-%d') and unit = '$unit'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$datetime_bd = $row['begin'];

$ar_datetime_bd = explode(" ",$datetime_bd);

$date_bd = $ar_datetime_bd[0];

$ar_date_bd = explode("-",$date_bd);

$day_bd = $ar_date_bd[2];

$ar_date[] = $day_bd;


}

$ar_date_uniq = array_unique($ar_date);
asort($ar_date_uniq);


}
Else{

$ar_date_uniq = array();



}


#print_r($ar_date_uniq);die();

}

echo "

<script>





</script>

<style>

.cl_msd_cal_future_",$screen,"{

display: flex;
align-items: center;
justify-content: center;
height: 100%;

border: 1px dotted grey;

}

.cl_msd_cal_future_",$screen,":hover {

color: yellow;
background-color: grey;

transition: background-color .3s linear;
transition: color .3s linear;



}

.cl_msd_cal_past_",$screen,"{

display: flex;
align-items: center;
justify-content: center;
height: 100%;

border: 1px dotted #454545;

}

.cl_msd_cal_past_",$screen,":hover {

color: Magenta;
background-color: #454545;

transition: background-color .3s linear;

transition: color .4s linear;


}


</style>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"60%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #2E3436; text-align: center; font-weight: bold; color: white; cursor: default;\" height = \"15px\"><td>Пн</td><td>Вт</td><td>Ср</td><td>Чт</td><td>Пт</td><td style = \"color: OrangeRed;\">Сб</td><td style = \"color: OrangeRed;\">Вс</td></tr>
";

For($i=1,$u=1;$i<36,$u<=$q_days;$i++)
{
If($i==8 or $i==15 or $i==22 or $i==29 or $i==36)
{
echo "</tr><tr>";
}


If($i>=$num_wd)
{

If(!in_array($u,$ar_date_uniq))
{

echo "<td align = \"center\" style = \"position: relative; font-weight: bold; background-color: ";

If($month_now > $month)
{

If($year_now < $year)
{

echo "#888A85";
$color_txt = "black";
$name_class = "cl_msd_cal_future_".$screen;

}
ElseIf($year_now == $year)
{

echo "#555753";
$color_txt = "white";
$name_class = "cl_msd_cal_past_".$screen;



}
ElseIf($year_now > $year)
{

echo "#555753";
$color_txt = "white";
$name_class = "cl_msd_cal_future_".$screen;

}



}
ElseIf($month_now == $month)
{

If($year_now < $year)
{

echo "#888A85";
$color_txt = "black";
$name_class = "cl_msd_cal_future_".$screen;


}
ElseIf($year_now == $year)
{

If($day_now < $u)
{
echo "#888A85";
$color_txt = "black";
$name_class = "cl_msd_cal_future_".$screen;
}
Else{
echo "#555753";
$color_txt = "white";
$name_class = "cl_msd_cal_past_".$screen;
}

}
Else{

echo "#555753";
$color_txt = "white";
$name_class = "cl_msd_cal_past_".$screen;

}



}
ElseIf($month_now < $month)
{


If($year_now < $year)
{

echo "#888A85";
$color_txt = "black";
$name_class = "cl_msd_cal_past_".$screen;


}
ElseIf($year_now == $year)
{

echo "#888A85";
$color_txt = "black";
$name_class = "cl_msd_cal_future_".$screen;



}
ElseIf($year_now > $year)
{

echo "#555753";
$color_txt = "white";
$name_class = "cl_msd_cal_past_".$screen;

}

//echo "#888A85";
//$color_txt = "black";
}


echo "; color: ",$color_txt,"; cursor: pointer;\">

<div id = \"id_chouse_day_msd_call_",$screen,"_",$u,"\" onclick = \"chouse_day_msd_cal('",$u,"','",$screen,"','save');\" class = \"",$name_class,"\">",$u,"</div>

<div id = \"id_chousen_day_msd_call_",$screen,"_",$u,"\" onclick = \"chouse_day_msd_cal('",$u,"','",$screen,"','cancel');\" style = \"background-color: green; color: white; display: none; align-items: center; justify-content: center; height: 100%;\">",$u,"</div>

</td>";


}
Else{

echo "<td style = \"background-color: Silver; color: DimGray; cursor: default; font-weight: bold; text-decoration: line-through;\">",$u,"</td>";

}
$u++;


}

Else{
echo "<td></td>";
}
}

echo "
</table>


</td>
</tr>
</table>

";







}


?>
