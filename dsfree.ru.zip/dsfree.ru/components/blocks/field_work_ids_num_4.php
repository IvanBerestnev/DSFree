<?php

function field_work_ids_num_4($vals)
{

#print_r($vals);

$id_doc = $vals['type'];
$screen = $vals['screen'];
$id_pac_selected = $vals['id_pac_selected'];




include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");




echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">


<tr height = \"50px\">
<td style = \"padding-top: 10px; padding-left: 10px; padding-right: 10px;\">

<div style = \" width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B;\">
Договоры с пациентом
</div>

</td>
</tr>

<tr>
<td style = \"padding-right: 10px; padding-left: 10px; padding-top: 10px; \">
<div style = \"width: 100%; height: 100%; overflow-y: scroll; \">

<table border = \"0\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">

";



$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac_selected'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_dogovor = $row['id_dogovor'];
$data_dogovor = $row['data_dogovor'];


echo "

<tr>
<td height = \"50px\">

<div onclick = \"load_td_field_work_ids('",$screen,"','5','",$id_dogovor,"');\" style = \" width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B; cursor: pointer; position: relative;\" >

Договор №",$id_dogovor," от ",$data_dogovor,"


<span id = \"under_line_4_",$id_dogovor,"_",$screen,"\" class = \"under_line_4_",$screen,"\" style = \"position: absolute; width: 100%; height: 5px; bottom: 0px; background-color: #FF8080; display: none;\"></span>

</div>



</td>
</tr>

";

}

}


echo "</table>


</div>

</td>
</tr>
</table>

";




}


?>
