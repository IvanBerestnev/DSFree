<?php

function field_work_ids_num_4($vals)
{

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$screen = $vals['screen'];
$id_ids = $vals['type'];
$id_pac_selected = $vals['id_pac_selected'];

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

echo "

<script>

function change_num_days_ids(screen,type,val)
{

if(type == 'month')
{
var old_type = 'year';

var sel_year_ids = 'sel_year_ids_' + screen;
var e = document.getElementById(sel_year_ids);
var value = e.value;
var old_val = e.options[e.selectedIndex].value;

}
else if(type == 'year')
{
var old_type = 'month';

var sel_month_ids = 'sel_month_ids_' + screen;
var e = document.getElementById(sel_month_ids);
var value = e.value;
var old_val = e.options[e.selectedIndex].value;

}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('change_num_days_ids') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[val]=\" + encodeURIComponent(val) + \"&data[old_type]=\" + encodeURIComponent(old_type) + \"&data[old_val]=\" + encodeURIComponent(old_val));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var span_day_ids = 'span_day_ids_' + screen;

var cont = document.getElementById(span_day_ids);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>


<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; border-left: 1px solid #2E3436; border-right: 1px solid #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\" style = \"background-color: #2E3436;\">
<td colspan = \"3\">
</td>
</tr>
<tr>

<td width = \"15%\" style = \"background-color: #2E3436;\">

</td>

<td >

<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; border-left: 1px solid #2E3436; border-right: 1px solid #2E3436; border: 2px solid grey;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"25%\">
<td>

Дата ИДС

</td>
</tr>
<tr height = \"33%\">
<td>";

$day_now = date('d');
$month_now = date('m');
$year_now = date('Y');

$number_days = cal_days_in_month(CAL_GREGORIAN, $month_now, $year_now);

echo "<span id = \"span_day_ids_",$screen,"\"><select>";

For($i=1;$i<=$number_days;$i++)
{
$dn = date("d", mktime(0, 0, 0, 1, $i, 1970));
echo "<option";

If($dn == $day_now)
{
echo " selected";
}

echo ">",$dn,"</option>";
}

echo "</select></span> ";


echo "<select id = \"sel_month_ids_",$screen,"\" onchange = \"change_num_days_ids('",$screen,"','month',this.value);\" style = \"text-align: center;\">";


Foreach($ar_months_rus as $m=>$nm)
{

echo "

<option";

If($m == $month_now )
{

echo " selected";
}

echo " value = \"",$m,"\">",$nm,"</option>

";

}

echo "
</select>

";

//<input size = \"4\" value = \"",$year_now,"\">

$year_now_min = $year_now-15;
$year_now_max = $year_now+15;

echo "<select id = \"sel_year_ids_",$screen,"\" onchange = \"change_num_days_ids('",$screen,"','year',this.value);\" style = \"text-align: center;\">";

For($year_now_min;$year_now_min<=$year_now_max;$year_now_min++)
{
echo "<option";

If($year_now_min == $year_now)
{
echo " selected";
}

echo " value = \"",$year_now_min,"\">",$year_now_min,"</option>";
}

echo "

</select>

</td>
</tr>
<tr height = \"25%\">
<td style = \"background-color: #008080; cursor: pointer;\">
Создать
</td>
</tr>
</table>

</td>
<td width = \"15%\" style = \"background-color: #2E3436;\">

</td>


</tr>
<tr height = \"15%\" style = \"background-color: #2E3436;\">
<td  colspan = \"3\">
</td>
</tr>
</table>";



}


?>
