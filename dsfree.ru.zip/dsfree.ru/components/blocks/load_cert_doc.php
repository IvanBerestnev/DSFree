<?php

function load_cert_doc($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_doc = $vals['id_doc'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_docs_cert where id_doc = '$id_doc'";
$query = mysqli_query($connection,$sql);



If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_cert = $row['id_cert'];
$name_cert = $row['name_cert'];
$date_cert = $row['date_cert'];

If($name_cert == "")
{
$name_cert = "не задано";
}

echo "

<div id = \"f_view_cert_",$screen,"_",$id_cert,"\" style = \"\"></div>


<script>load_view_cert('",$id_cert,"','",$screen,"','default');</script>


";


}


}
Else{

echo "

<table border = \"0\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #404040; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
нет данных о сертификате
</td>
</tr>
</table>
";

}


}

?>
