<?php

function change_pac_jurpac($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_ent = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_ent where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pac = $row['id_pacs'];

$sql = "select * from tab_pacs where id_pac = '$id_pac'";

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];


echo "
<style>
input {outline:none;}
</style>

<script>

function load_pacs_to_change_pac_jurpac(surname_pac_search,screen,param)
{

if(param == 'but_erise')
{
erising_result_change_pac_jurpac(screen);
}

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_pacs_to_change_pac_jurpac') + \"&data[surname_pac_search]=\" + encodeURIComponent(surname_pac_search) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var modal = 'f_load_pacs_to_change_pac_jurpac_' + screen;

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


var id_but_change_pac_jurpac_active = 'id_but_change_pac_jurpac_active_' + screen;
document.getElementById(id_but_change_pac_jurpac_active).style.display = 'none';

var id_but_change_pac_jurpac_inactive = 'id_but_change_pac_jurpac_inactive_' + screen;
document.getElementById(id_but_change_pac_jurpac_inactive).style.display = 'inline-table';

}




function choice_pac_change_pac_jurpac(id_pac,screen)
{

//alert('123');

var class_choice_pac_change_pac_jurpac = 'class_choice_pac_change_pac_jurpac_' + screen;
var theOddOnes_cpcpj = document.getElementsByClassName(class_choice_pac_change_pac_jurpac);



for(var i=0; i<theOddOnes_cpcpj.length; i++)
{

var id_pacs_js = theOddOnes_cpcpj[i].id;

document.getElementById(id_pacs_js).style.backgroundColor = '#2E3436';
document.getElementById(id_pacs_js).style.color = 'white';

}


var id_choice_pac_change_pac_jurpac = 'id_choice_pac_change_pac_jurpac_' + screen + '_' + id_pac;
document.getElementById(id_choice_pac_change_pac_jurpac).style.backgroundColor = 'blue';
document.getElementById(id_choice_pac_change_pac_jurpac).style.color = 'white';


var id_selected_choice_pac_change_pac_jurpac = 'id_selected_choice_pac_change_pac_jurpac_' + screen;
document.getElementById(id_selected_choice_pac_change_pac_jurpac).innerHTML = id_pac;


var id_but_change_pac_jurpac_active = 'id_but_change_pac_jurpac_active_' + screen;
document.getElementById(id_but_change_pac_jurpac_active).style.display = 'inline-table';

var id_but_change_pac_jurpac_inactive = 'id_but_change_pac_jurpac_inactive_' + screen;
document.getElementById(id_but_change_pac_jurpac_inactive).style.display = 'none';





}

function erising_result_change_pac_jurpac(screen)
{


var class_choice_pac_change_pac_jurpac = 'class_choice_pac_change_pac_jurpac_' + screen;
var theOddOnes_cpcpj = document.getElementsByClassName(class_choice_pac_change_pac_jurpac);

for(var i=0; i<theOddOnes_cpcpj.length; i++)
{
var id_pacs_js = theOddOnes_cpcpj[i].id;
document.getElementById(id_pacs_js).style.backgroundColor = '#2E3436';
document.getElementById(id_pacs_js).style.color = 'white';
}

var id_but_change_pac_jurpac_active = 'id_but_change_pac_jurpac_active_' + screen;
document.getElementById(id_but_change_pac_jurpac_active).style.display = 'none';

var id_but_change_pac_jurpac_inactive = 'id_but_change_pac_jurpac_inactive_' + screen;
document.getElementById(id_but_change_pac_jurpac_inactive).style.display = 'inline-table';

var id_selected_choice_pac_change_pac_jurpac = 'id_selected_choice_pac_change_pac_jurpac_' + screen;
var areaOption = document.getElementById(id_selected_choice_pac_change_pac_jurpac);
if (areaOption) {
document.getElementById(id_selected_choice_pac_change_pac_jurpac).innerHTML = '';
}
else{
// element doesn't exist
}


var id_input_pacs_to_change_pac_jurpac = 'id_input_pacs_to_change_pac_jurpac_' + screen;
var areaOption = document.getElementById(id_input_pacs_to_change_pac_jurpac);
if (areaOption) {
document.getElementById(id_input_pacs_to_change_pac_jurpac).value = '';
}
else{
// element doesn't exist
}



}



function act_change_pac_jurpac(id_ent,screen)
{

var id_selected_choice_pac_change_pac_jurpac = 'id_selected_choice_pac_change_pac_jurpac_' + screen;
var areaOption = document.getElementById(id_selected_choice_pac_change_pac_jurpac);
if (areaOption) {
var id_choiced_pac = document.getElementById(id_selected_choice_pac_change_pac_jurpac).innerHTML;
}
else{
// element doesn't exist
}


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_change_pac_jurpac') + \"&data[id_ent]=\" + encodeURIComponent(id_ent) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_choiced_pac]=\" + encodeURIComponent(id_choiced_pac));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var modal = 'modal_' + screen;

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}




</script>

</script>
<table border = \"0\" width = \"100.5%\" height = \"100.5%\" style = \"border-collapse: collapse; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: black; color: white;\" height = \"12%\">
<td align = \"left\" colspan = \"3\" style = \"padding-left: 5px; font-weight: bold;\">
Замена пациента
</td>
</tr>
<tr>
<td rowspan = \"2\" width = \"30%\" style = \"color: white; font-weight: bold;\">";

echo $surname_pac, "<br>",$name_pac,"<br>",$patronymic_pac;

echo "</td>
<td rowspan = \"2\" style = \"background-color: #1F1F1F; color: grey; font-weight: bold; font-size: 32px;\" width = \"6%\">
&#10140;
</td>
<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\">
<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"80%\">
<input id = \"id_input_pacs_to_change_pac_jurpac_",$screen,"\" onkeyup = \"load_pacs_to_change_pac_jurpac(this.value,'",$screen,"','');\" style = \"width: 95%; height: 80%; font-size: 25px;\">
</td>
<td onclick = \"load_pacs_to_change_pac_jurpac('','",$screen,"','but_erise');\" style = \"color: LightCoral	; font-weight: bold; font-size: 20px; cursor: pointer;\">
&#10008;
</td>
</tr>
</table>


</td>
</tr>
<tr>
<td>
<div id = \"f_load_pacs_to_change_pac_jurpac_",$screen,"\" style = \"width: 100%; height: 100%;\"></div>
</td>
</tr>
</table>


</td>
</tr>
<tr style = \"\" height = \"10%\">
<td>


<table id = \"id_but_change_pac_jurpac_inactive_",$screen,"\" border = \"1\" width = \"100%\" height = \"100%\" style = \"display: inline-table; cursor: default; border-collapse: collapse; text-align: center; background-color: grey; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
заменить
</td>
</tr>
</table>


<table id = \"id_but_change_pac_jurpac_active_",$screen,"\" onclick = \"act_change_pac_jurpac('",$id_ent,"','",$screen,"');\" border = \"1\" width = \"100%\" height = \"100%\" style = \"display: none; cursor: pointer; border-collapse: collapse; text-align: center; background-color: green; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
заменить
</td>
</tr>
</table>


</td>
</tr>
</table>



<script>
load_pacs_to_change_pac_jurpac('','",$screen,"');
</script>

";


}




}



}

?>
