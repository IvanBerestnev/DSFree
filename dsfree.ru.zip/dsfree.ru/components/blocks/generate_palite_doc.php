<?php

function generate_palite_doc($vals)
{
	
#print_r($vals);

$screen = $vals['screen'];
$type = $vals['type'];
$id_pers = $vals['id_pers'];


function rand_color() {
    return '#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
}

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

$row = mysqli_fetch_assoc($query);

$bg_color_gen = $row['bg_color_gen'];
$txt_color_gen = $row['txt_color_gen'];

$bg_color_pac = $row['bg_color_pac'];
$txt_color_pac = $row['txt_color_pac'];


$class_td_cell_color = "class_td_color_".$type."_".$screen;

echo "

<table border = \"0\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; background-color: ; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">

";

For($i=0;$i<5;$i++)
{

echo "
<tr height = \"20%\">";

For($x=0;$x<8;$x++)
{



If($i==0 and $x==0)
{
$rand_color = "white";
$txt_cell = "";

}
ElseIf($i==0 and $x==1)
{

$rand_color = "black";
$txt_cell = "";

}
ElseIf($i==0 and $x==2)
{

If($type == "bg_gen")
{
$rand_color = $bg_color_gen;
}
ElseIf($type == "txt_gen")
{
$rand_color = $txt_color_gen;
}
ElseIf($type == "bg_pac")
{
$rand_color = $bg_color_pac;
}
ElseIf($type == "txt_pac")
{
$rand_color = $txt_color_pac;
}

$txt_cell = "&#10003;";

}
Else{

$rand_color = rand_color();

$txt_cell = "";

}

$id_td_cell_color = $type."_".$i."_".$x."_".$screen;




echo "<td id = \"",$id_td_cell_color,"\" class = \"",$class_td_cell_color,"\" onclick = \"chouse_new_color('",$type,"','",$id_td_cell_color,"','",$rand_color,"','",$screen,"','",$id_pers,"');\" style = \"background-color: ",$rand_color,"; cursor: pointer; font-weight: bold;\">",$txt_cell,"</td>";
}

echo "
</tr>
";

}


echo "

</table>

";


}

?>
