<?php

function block_temple_medcart_visit_choice_ds($vals)
{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$screen = $vals['screen'];
$id_ds = $vals['id_ds'];
$id_struct = $vals['id_struct'];
$id_razd = $vals['id_razd'];
$id_writed_razd = $vals['id_writed_razd'];

echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td align = \"center\">
выберете диагноз
</td>
</tr>
<tr>
<td>
<div style = \"width: 100%; height: 100%; overflow-y:scroll;\">";

$sql = "select * from sp_dss";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
";

while($row = mysqli_fetch_assoc($query))
{
$name_ds = $row['name_ds'];
$id_ds_sp = $row['id_ds']; 

echo "<tr onclick = \"load_block_temple_razd_visit_self('",$id_ds_sp,"','",$id_struct,"','",$id_razd,"','",$screen,"','",$id_writed_razd ,"');\" style = \"background-color: #C0C0C0; color: black; cursor: pointer;\" height = \"40px\"><td>",$name_ds,"</td></tr><tr height = \"20px\"><td></td></tr>";

}

echo "</table>";

}


echo "

</div>
</td>
</tr>
</table>

";


}

?>
