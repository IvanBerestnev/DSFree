<?php

function cancel_ent($vals)
{


$screen = $vals['screen'];
$param = $vals['param'];

echo "

<script>

function cancel_ent_jp()
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('cancel_ent_jp') + \"&data[id_ent]=\" + encodeURIComponent('",$param,"') + \"&data[screen]=\" + encodeURIComponent('",$screen,"'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var return_data_cancel_ent = 'return_data_cancel_ent_",$screen,"';
var cont = document.getElementById(return_data_cancel_ent);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<table border = \"0\" width = \"101%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; table-layout: fixed; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"background-color: #575757; color: white;\" colspan = \"2\">
<b>Отменить прием?</b>
</td>

</tr>
<tr>
<td onclick = \"cancel_ent_jp();\" style=\"background-color: #8AE234; color: black; cursor: pointer;\">
Да
</td>
<td onclick=\"close_mw('fon_modal_",$screen,"');\" style=\"background-color: #FF8080; color: black; cursor: pointer;\">
Нет
</td>

</tr>

</table>
<span style = \"display: none;\" id = \"return_data_cancel_ent_",$screen,"\"></span>
";


}


?>
