<?php

function load_other_lica_dogovor_pmu($vals)
{

#print_r($vals);

$id_pac_recieved = $vals['id_pac'];
$screen = $vals['screen'];
$id_dog = $vals['id_dog'];
$mode = $vals['mode'];




include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs where id_pac != '$id_pac_recieved'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
	
echo "<table border = \"1\" align = \"center\"  width = \"100%\" style = \" border-collapse: collapse; text-align: center; font-weight: bold; color: white;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$surname_pac = $row['surname_pac'];
$id_pac = $row['id_pac'];



If($mode == "out")
{
$script = "act_add_otherlico_pre_dogovor_pmu('".$id_pac_recieved."','".$id_pac."','".$screen."');";
}
ElseIf($mode == "inn")
{
$script = "act_add_otherlico_dogovor_pmu('".$id_pac_recieved."','".$id_pac."','".$id_dog."','".$screen."');";
}


echo "
<tr style = \"cursor: pointer;\" onclick = \"",$script,"\">
<td width = \"40%\">
",$surname_pac,"
</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
";
}

echo "</table>";

}
Else{

echo "

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
нет зарегистрированных клиентов
</td>
</tr>
</table>
";


}



}

//include_once("info_pac.php");
//info_pac($vals);


?>
