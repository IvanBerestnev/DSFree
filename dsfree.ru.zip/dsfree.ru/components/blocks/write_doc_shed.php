<?php

function write_doc_shed($vals)
{

#print_r($vals);

$act = $vals['act'];
$screen = $vals['screen'];
$param = $vals['param'];


$ar_param = explode("#",$param);

$unit = $ar_param[1];

$dt_be = $ar_param[0];
$ar_dt_be = explode("@",$dt_be);
$dt_b = $ar_dt_be[0];
$dt_e = $ar_dt_be[1];

$ar_dt_b = explode(" ",$dt_b);
$d_b = $ar_dt_b[0];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

#$sql = "select * from tab_shedule_pers where id_pers = '$id_pers' and date BETWEEN STR_TO_DATE('$date_begin', '%Y-%m-%d') AND STR_TO_DATE('$date_next', '%Y-%m-%d') order by date ASC";

#echo $sql;


$sql = "select * from tab_personal";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];
$surname_pers = $row['surname_pers'];
$name_pers = $row['name_pers'];

If($surname_pers == "")
{
echo "<script>close_mw('fon_modal_",$screen,"');load_page_screen('sp_docs','",$screen,"');</script>";die();
}

$ar_pers[$id_pers]['surname_pers'] = $surname_pers;
$ar_pers[$id_pers]['name_pers'] = $name_pers;

}

}
Else{

echo "<script>close_mw('fon_modal_",$screen,"');load_page_screen('sp_docs','",$screen,"');</script>";die();

}
echo "

<script>

function writing_new_doc_shed()
{

var id_sel_beg_shed_doc = 'id_sel_beg_shed_doc_",$screen,"';
var selector_id_sel_beg_shed_doc = document.getElementById(id_sel_beg_shed_doc);
var sel_beg_shed_doc = selector_id_sel_beg_shed_doc[selector_id_sel_beg_shed_doc.selectedIndex].value;


var id_sel_end_shed_doc = 'id_sel_end_shed_doc_",$screen,"';
var selector_id_sel_end_shed_doc = document.getElementById(id_sel_end_shed_doc);
var sel_end_shed_doc = selector_id_sel_end_shed_doc[selector_id_sel_end_shed_doc.selectedIndex].value;


var sel_id_pers = 'sel_id_pers_",$screen,"';
var selector_sel_id_pers = document.getElementById(sel_id_pers);
var id_pers = selector_sel_id_pers[selector_sel_id_pers.selectedIndex].value;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('writing_new_doc_shed') + \"&data[screen]=\" + encodeURIComponent('",$screen,"') + \"&data[beg]=\" + encodeURIComponent(sel_beg_shed_doc) + \"&data[end]=\" + encodeURIComponent(sel_end_shed_doc) + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[date]=\" + encodeURIComponent('",$d_b,"') + \"&data[unit]=\" + encodeURIComponent('",$unit,"'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var modal = 'modal_' + ",$screen,";
var cont = document.getElementById(modal);

cont.innerHTML = xmlhttp.responseText;


var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<table border = \"0\" width = \"100%\" height = \"100.5%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: black; color: white; font-weight: bold;\" height = \"15%\">
<td align = \"left\" style = \"padding-left: 5px; font-size: 20px;\">
Расписание врачу
</td>
</tr>
<tr height = \"20%\" style = \"background-color: #2E3436;\">
<td style = \"padding-right: 5px;\" align = \"right\">

<span onclick = \"load_page_screen('sp_docs','",$screen,"'); close_mw('fon_modal_",$screen,"');\" style = \"border: 1px solid red; float: left; color: white; border: 1px solid grey; margin-left: 10px; padding-left: 5px; padding-right: 5px; cursor: pointer; font-weight: bold;\">Новый врач</span>

<select id = \"sel_id_pers_",$screen,"\" onchange = \"load_availible_times_docs_shed(this.value,'",$screen,"','",$param,"');\" style = \"font-size: 20px;\">";

$i=0;
Foreach($ar_pers as $id_pers=>$vals)
{

If($i==0)
{
$id_selected_pers = $id_pers;
$i++;
}


$surname_pers = $vals['surname_pers'];
$name_pers = $vals['name_pers'];

$fio = $surname_pers." ".$name_pers;

echo "<option value = \"",$id_pers,"\">",$fio,"</option>";

}




echo "
</select>

</td>
</tr>
<tr style = \"background-color: #555753;\">
<td>
<div id = \"f_load_availible_times_docs_shed_",$screen,"\"></div>
</td>
</tr>
<tr height = \"15%\" style = \"background-color: #555753;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; table-layout: fixed;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
</td>
<td>
</td>
<td onclick = \"writing_new_doc_shed();\" style = \"font-size: 20px; background-color: green;color: white; font-weight: bold; cursor: pointer;\">

Запись

</td>
</tr>
</table>

</td>
</tr>
</table>

<script>
load_availible_times_docs_shed('",$id_selected_pers,"','",$screen,"','",$param,"');
</script>

";


}

?>
