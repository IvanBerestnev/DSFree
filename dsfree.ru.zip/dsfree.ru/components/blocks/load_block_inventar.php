<?php

function load_block_inventar($vals)
{



$type = $vals['type'];

If($type == "show_all")
{

include_once("load_block_inventar_show_all.php");
load_block_inventar_show_all($vals);

}
ElseIf($type == "show_limit")
{
include_once("load_block_inventar_show_limit.php");
load_block_inventar_show_limit($vals);

}




}

?>
