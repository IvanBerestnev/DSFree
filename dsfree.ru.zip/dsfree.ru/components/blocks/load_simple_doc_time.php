<?php

function load_simple_doc_time($vals)
{


$screen = $vals['screen'];
$id_pers = $vals['id_pers'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

$row = mysqli_fetch_assoc($query);

$bg_color_gen = $row['bg_color_gen'];
$txt_color_gen = $row['txt_color_gen'];

$bg_color_pac = $row['bg_color_pac'];
$txt_color_pac = $row['txt_color_pac'];

echo "

<table border = \"1\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; background-color: ; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\" id = \"demo_free_1_",$screen,"\" class = \"demo_free_",$screen,"\" style = \"background-color: ",$bg_color_gen,"; color: ",$txt_color_gen,";\">
09:00-14:00
</td>

<td id = \"demo_free_3_",$screen,"\" class = \"demo_free_",$screen,"\" align = \"center\" rowspan = \"3\" style = \"background-color: ",$bg_color_gen,"; color: ",$txt_color_gen,";\">
09:00-20:00
</td>

</tr>
<tr>
<td id = \"demo_busy_",$screen,"\" style = \"background-color: ",$bg_color_pac,"; color: ",$txt_color_pac,";\">
Иванов
</td>
</tr>
<tr>
<td id = \"demo_free_2_",$screen,"\" class = \"demo_free_",$screen,"\" style = \"background-color: ",$bg_color_gen,"; color: ",$txt_color_gen,";\">
17:00-20:00
</td>



</tr>
</table>




";


}

?>
