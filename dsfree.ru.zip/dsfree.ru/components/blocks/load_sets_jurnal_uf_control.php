<?php

function load_sets_jurnal_uf_control($vals)
{

#print_r($vals);

$name_page = $vals['name_page'];
$screen = $vals['screen'];

echo "

<script>

function load_rooms_jur_uf(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_rooms_jur_uf') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_rooms_jur_uf = 'f_rooms_jur_uf_' + screen;

var cont = document.getElementById(f_rooms_jur_uf);
cont.innerHTML = xmlhttp.responseText;

//alert(xmlhttp.responseText);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


function open_room_jur_uf_control(screen,id_room)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('open_room_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_room]=\" + encodeURIComponent(id_room));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_rooms_jur_uf = 'f_rooms_jur_uf_' + screen;

var cont = document.getElementById(f_rooms_jur_uf);
cont.innerHTML = xmlhttp.responseText;

//alert(xmlhttp.responseText);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}



}

</script>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">



<tr>
<td>

<div id = \"f_rooms_jur_uf_",$screen,"\" style = \"width: 100%; height: 100%;\">
</div>

</td>
</tr>

</table>



";

echo "<script>load_rooms_jur_uf('",$screen,"');</script>";


}

?>
