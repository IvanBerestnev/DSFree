<?php

function load_razd_templ_medcart($vals)
{

#print_r($vals);

$id_ds_income = $vals['id_ds'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];
$screen = $vals['screen'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];

$text = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_decoded = json_decode($text,true);



#var_dump(json_last_error());
#var_dump(json_last_error_msg());

#print_r($ar_decoded);die();

$work_array = $ar_decoded[$id_ds_income][$id_str_templ]['cont'];

#print_r($work_array);die();

If(count($work_array) !== 0)
{

echo "<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">";

Foreach($work_array as $id_razd=>$ar_vals)
{

$name = htmlspecialchars($ar_vals['name']);



echo "
<tr><td height = \"30px\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"edit_medcart_templ_razdel_self('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"','",$id_razd,"');\" style = \"background-color: #008080;\">
открыть раздел
</td>
<td onclick = \"page_delete_razdel_templ_medcart('",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"','",$screen,"','",$id_razd,"');\" width = \"10%\" style = \"background-color: #FF8080;\">
Х
</td>
</tr>
</table>

</td></tr>
<tr><td height = \"30px\">

<input onkeyup = \"act_rename_razd_templ_medcart(this.value,'",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"','",$screen,"','",$id_razd,"');\" style = \"width: 100%; height: 100%;\" value = \"",$name,"\">

</td></tr>
<tr height = \"30px\"><td></td></tr>
";

}

echo "</table>";

}
Else{

echo "<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Нет зарегистрированных<br> разделов  для<br> данного шаблона
</td>
</tr>
</table>
";

}

}

}

?>
