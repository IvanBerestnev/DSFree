<?php

function navigate_screen_ssetka($vals)
{

#print_r($vals);

$now_loaded_ssetka = $vals['now_loaded_ssetka'];
$direct = $vals['direct'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_used_ssetka where id_used_ssetka = '$now_loaded_ssetka'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pers = $row['id_pers'];

$sql = "select * from tab_used_ssetka where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

while($row_a = mysqli_fetch_assoc($query))
{
$id_used_ssetka = $row_a['id_used_ssetka'];
$ar_used_ssetka[] = $id_used_ssetka;
}


$key = array_search($now_loaded_ssetka, $ar_used_ssetka);

If($direct == "back")
{

$probe_key = $key-1;

If(isset($ar_used_ssetka[$probe_key]))
{

$selected_id_ssetka = $ar_used_ssetka[$probe_key];


}
Else{

$selected_id_ssetka = end($ar_used_ssetka);

}

}
ElseIf($direct == "next")
{

$probe_key = $key+1;

If(isset($ar_used_ssetka[$probe_key]))
{

$selected_id_ssetka = $ar_used_ssetka[$probe_key];


}
Else{

$selected_id_ssetka = array_shift($ar_used_ssetka);

}

}


echo $selected_id_ssetka;
#print_r($ar_used_ssetka);


}


}



}


?>
