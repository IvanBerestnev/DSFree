<?php

function load_sets_jurnal_steril($vals)
{
$name_page = $vals['name_page'];
$screen = $vals['screen'];

If($name_page == "steril_kits")
{

echo "

<script>

function load_steril_kits(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_steril_kits') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_id_steril_kits = 'f_id_steril_kits_' + screen;

var cont = document.getElementById(f_id_steril_kits);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function add_new_steril_kits(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_steril_kits') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

load_steril_kits(screen);

}
}
}

}


function add_new_info_steril_kits(val,type,id)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_info_steril_kits') + \"&data[val]=\" + encodeURIComponent(val) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[id]=\" + encodeURIComponent(id));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



}
}
}

}


function page_cnfm_del_st_kit(id,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_cnfm_del_st_kit') + \"&data[id]=\" + encodeURIComponent(id) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '30%';
document.getElementById(modal_first).style.height = '15%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}



}
}
}

}

function act_delete_st_kit(id,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_st_kit') + \"&data[id]=\" + encodeURIComponent(id));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_'+ screen;
close_mw(fon_modal_first);
load_steril_kits(screen);


}
}
}


}

</script>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>

<div id = \"f_id_steril_kits_",$screen,"\" style = \"height: 100%; overflow-y:scroll;\"></div>

</td>
</tr>

<tr height = \"10%\" style = \"background-color: #008080; font-weight: bold; cursor: pointer;\">
<td onclick = \"add_new_steril_kits('",$screen,"');\">
+
</td>
</tr>
</table>


<script>
load_steril_kits('",$screen,"');
</script>

";


}
ElseIf($name_page == "autoclav")
{

echo "

<script>

function load_autoclav(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_autoclav') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_id_autoclav = 'f_id_autoclav_' + screen;

var cont = document.getElementById(f_id_autoclav);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}


function add_new_autoclav(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_autoclav') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

load_autoclav(screen);

}
}
}

}

function delete_autoclav(id,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('delete_autoclav') + \"&data[id]=\" + encodeURIComponent(id) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '30%';
document.getElementById(modal_first).style.height = '15%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}



}
}
}


}

function act_delete_autoclav(id,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_autoclav') + \"&data[id]=\" + encodeURIComponent(id));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_'+ screen;
close_mw(fon_modal_first);
load_autoclav(screen);


}
}
}


}


function update_info_autoclav(val,type,screen,id,mode)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('update_info_autoclav') + \"&data[val]=\" + encodeURIComponent(val) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[mode]=\" + encodeURIComponent(mode) + \"&data[id]=\" + encodeURIComponent(id));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



}
}
}


}

</script>



<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>

<div id = \"f_id_autoclav_",$screen,"\" style = \"height: 100%; overflow-y:scroll;\"></div>

</td>
</tr>

<tr height = \"10%\" style = \"background-color: #008080; font-weight: bold; cursor: pointer;\">
<td onclick = \"add_new_autoclav('",$screen,"');\">
+
</td>
</tr>
</table>

<script>
load_autoclav('",$screen,"');
</script>


";


}



}

?>
