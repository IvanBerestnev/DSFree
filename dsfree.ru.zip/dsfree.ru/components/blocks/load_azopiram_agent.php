<?php

function load_azopiram_agent($vals)
{

#print_r($vals);

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_misc_sets where id = '4'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$val = $row['val'];

$ar_decoded = json_decode($val,true);

$ar_azopiram = $ar_decoded['azopiram']['names'];

If(!empty($ar_azopiram))
{

$default = $ar_decoded['azopiram']['default'];

echo "

<script>

function edit_data_azopiram_agent(screen,act,val,num)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('edit_data_azopiram_agent') + \"&data[val]=\" + encodeURIComponent(val) + \"&data[act]=\" + encodeURIComponent(act) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[num]=\" + encodeURIComponent(num));


xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hidden_f_load_azopiram_agent = 'hidden_f_load_azopiram_agent_' + screen;

var cont = document.getElementById(hidden_f_load_azopiram_agent);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}

</script>

<style>

.inp_name_azopiram_agent_",$screen,"::placeholder {
  font-weight: bold;
  opacity: 0.5;
  color: white;

}

.inp_name_azopiram_agent_",$screen,"{
background-color: #1A5FB4; color: white;
border: 0px; border-bottom: 1px solid white; font-weight: bold; font-size: 15px;
}


</style>


<table align = \"center\" border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #1A5FB4; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";



$i=0;

Foreach($ar_azopiram as $azp)
{

echo "
<tr height = \"40px\">
<td align = \"center\">

<input onkeyup = \"edit_data_azopiram_agent('",$screen,"','rename_agent',this.value,'",$i,"');\" class = \"inp_name_azopiram_agent_",$screen,"\" value = \"",$azp,"\" style = \"width: 80%; height: 90%;\" placeholder = \"название препарата\">


</td>

<td width = \"40%\" align = \"center\">
";

If($default == $i)
{
echo "по умолчанию";
}
Else{
echo "<span onclick = \"edit_data_azopiram_agent('",$screen,"','make_default','','",$i,"');\">назначить по умолчанию</span>";
}


echo "</td>

<td onclick = \"\" width = \"5%\" style = \"background-color: #FF8080; color: white; font-weight: bold;\" align = \"center\">
X
</td>



";

$i++;
}

#print_r($ar_azopiram);


echo "</table>";

}
Else{

echo "

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: grey; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
нет ни одного раствора<br>для проведения азопирамовой пробы
</td>
</tr>
</table>

";

}








}
Else{

echo "

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: grey; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
нет ни одного раствора<br>для проведения азопирамовой пробы
</td>
</tr>
</table>

";

}

echo "
<span id = \"hidden_f_load_azopiram_agent_",$screen,"\"></span>
";

}

?>
