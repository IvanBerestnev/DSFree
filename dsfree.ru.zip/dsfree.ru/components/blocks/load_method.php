<?php

function load_method($vals)
{

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_misc_sets where id = '4'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$val = $row['val'];
$ar_decoded = json_decode($val,true);

$excludes = $ar_decoded['method']['excludes'];

asort($excludes);

If(empty($excludes))
{

echo "

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
нет записей о исключениях
</td>
</tr>
</table>
";
die();
}
Else{



echo "

<style>

.inp_name_excludes_pso_",$screen,"::placeholder {
  font-weight: bold;
  opacity: 0.5;
  color: white;

}

.inp_name_excludes_pso_",$screen,"{
background-color: #1A5FB4; color: white;
border: 0px; border-bottom: 1px solid white; font-weight: bold; font-size: 15px;
}


</style>

<table align = \"center\" border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #1A5FB4; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

$e=0;
Foreach($excludes as $excl)
{

echo "<tr height = \"30px\">
<td align = \"center\">Набор № ";

echo $excl;

echo "
</td>
<td onclick = \"delete_from_jur_pso_excludes('",$e,"','",$screen,"');\" width = \"20%\" align = \"center\" style = \"background-color: #FF8080; cursor: pointer;\">
X
</td>
</tr>";
$e++;
}




echo "
</table>

";

}


}
Else{

echo "

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
нет записей о исключениях
</td>
</tr>
</table>

";

}


}

?>
