<?php

function load_sets_jurnal_pacs($vals)
{

#print_r($vals);

$name_page = $vals['name_page'];
$screen = $vals['screen'];

If($name_page == "orientation_tips")
{

$ar_positions_self = array("right"=>"справа","left"=>"слева");

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

//в таблице tab_misc_sets параметры всех окон с шестеренкой под id = 2

$sql = "select * from tab_misc_sets where id = '2'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$ar_json = $row['val'];

$ar_decoded = json_decode($ar_json,true);

If(isset($ar_decoded['params_jur_pacs'][$screen]['tips']['subseq']))
{
$ar_subseq = $ar_decoded['params_jur_pacs'][$screen]['tips']['subseq'];
}
Else{
$ar_subseq = array();
}


}

#print_r($ar_subseq);



echo "

<script>

function edit_orient_tips_jurnal_pacs(screen,day,position,action)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('edit_orient_tips_jurnal_pacs') + \"&data[day]=\" + encodeURIComponent(day) + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[position]=\" + encodeURIComponent(position) + \"&data[action]=\" + encodeURIComponent(action));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_span_hidden_sets_jurnal_pacs_ = 'f_span_hidden_sets_jurnal_pacs_' + screen;

var cont = document.getElementById(f_span_hidden_sets_jurnal_pacs_);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"30px\">
<td colspan = \"2\" style = \"font-weight: bold; \">



<span onclick = \"edit_orient_tips_jurnal_pacs('",$screen,"','','', 'delete');\" style = \"float: right; background-color: #008080;  padding-right: 5px; padding-left: 5px; cursor: pointer; border-radius: 10px; margin-right: 5px;\">
сброс в дефолт
</span>

<span style = \"color: yellow;\">Экран ",$screen," - Ориентация подсказок</span>


</td>
</tr>

<tr height = \"30px\" style = \"font-weight: bold; color: white;\">
<td>
порядковый номер дня
</td>
<td>
положение подсказки
</td>
</tr>
<tr style = \" font-weight: bold;\">

<td colspan = \"2\">

<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

";

For($i=1,$r=0;$i<=14;$i++)
{

If($r == 0)
{
$bgcolor = "grey";
$r = 1;
}
Else{
$bgcolor = "";
$r = 0;
}

echo "

<tr style = \"background-color: ",$bgcolor,"; \">

<td style = \"font-weight: bold; padding-top: 3px; padding-bottom: 3px;\">",$i,"</td>

<td>

<select style = \"border-radius: 5px;\" onchange = \"edit_orient_tips_jurnal_pacs('",$screen,"','",$i,"',this.value, 'edit');\">
";

Foreach($ar_positions_self as $k=>$v)
{


echo "<option";

If(isset($ar_subseq[$i]))
{

If($ar_subseq[$i] == "left")
{
echo " selected";
}


}


echo " value = \"",$k,"\">",$v,"</option>";








}

echo "
</select>

</td>

</tr>";
}

echo "

</table>

</div>

</td>

</tr>
</table>

<span id = \"f_span_hidden_sets_jurnal_pacs_",$screen,"\" style = \"display: ;\"></span>

";
}


}

?>
