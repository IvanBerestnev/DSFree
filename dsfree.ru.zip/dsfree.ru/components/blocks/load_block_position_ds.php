<?php

function load_block_position_ds($vals)
{

#print_r($vals);


$screen = $vals['screen'];
$id_ds_income = $vals['id_ds_income'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);


$text = $row['text'];


$ar_decoded = json_decode($text,true);

$locat_ds = $ar_decoded[$id_ds_income][$id_str_templ]['locat_ds'];

If($locat_ds == "")
{
echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"45%\">
<td>

</td>
</tr>
<tr >
<td onclick = \"modal_edit_position_ds('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"');\" style = \"background-color: #3A3A3A; cursor: pointer;\">
Позиция диагноза в карте не выбрана
</td>
</tr>
<tr height = \"45%\">
<td>

</td>
</tr>

</table>

"; 
}
Else{
echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"45%\">
<td>

</td>
</tr>
<tr height = \"10%\">
<td onclick = \"modal_edit_position_ds('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"');\" style = \"background-color: #3A3A3A; cursor: pointer;\">
диагноз в карте следует за разделом <br>

<span style = \"color: #F5C211;\">",

$locat_ds,"</span>
</td>
</tr>
<tr height = \"45%\">
<td>

</td>
</tr>

</table>";



}


}




}

?>
