<?php

function load_block_position_ds($vals)
{

#print_r($vals);


$screen = $vals['screen'];
$id_ds_income = $vals['id_ds_income'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$text = $row['text'];
$text = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_decoded = json_decode($text,true);

#var_dump(json_last_error());
#var_dump(json_last_error_msg());

#print_r($ar_decoded);

$locat_preds = $ar_decoded[$id_ds_income][$id_str_templ]['locat_preds'];
$locat_ds = $ar_decoded[$id_ds_income][$id_str_templ]['locat_ds'];


If($locat_preds == "first_position")
{
$locat_preds = "Первая позиция";
}
ElseIf($locat_preds == "disabled")
{
$locat_preds = "<span style = \"color: red;\">Предварительный диагноз отключен</span>";
}
Else{
$locat_preds = "после ".$locat_preds;
}


If($locat_ds == "after_preds")
{
$locat_ds = "После предварительного диагноза";
}
ElseIf($locat_ds == "disabled")
{
$locat_ds = "<span style = \"color: red;\">Диагноз отключен</span>";
}
ElseIf($locat_ds == "first_position")
{
$locat_ds = "Первая позиция";
}
Else{
$locat_ds = "после ".$locat_ds;
}

echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"45%\">
<td>

</td>
</tr>
<tr height = \"10%\">
<td onclick = \"modal_edit_position_ds('",$screen,"','",$id_ds_income,"','",$id_str_templ,"','",$id_tm,"');\" style = \"background-color: #3A3A3A; cursor: pointer;\">
предварительный диагноз в карте <br>

<span style = \"color: #F5C211;\">",

$locat_preds,"</span>

<br>

диагноз в карте <br>

<span style = \"color: #F5C211;\">",

$locat_ds,"</span>

</td>
</tr>
<tr height = \"45%\">
<td>

</td>
</tr>

</table>";






}




}

?>
