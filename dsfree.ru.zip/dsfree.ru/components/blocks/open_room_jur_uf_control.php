<?php

function open_room_jur_uf_control($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_room = $vals['id_room'];


echo "

<script>

function load_sp_ufs(screen,id_room)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_sp_ufs') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_room]=\" + encodeURIComponent(id_room));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_open_room_jur_uf_control = 'f_open_room_jur_uf_control_' + screen;

var cont = document.getElementById(f_open_room_jur_uf_control);
cont.innerHTML = xmlhttp.responseText;

//alert(xmlhttp.responseText);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}


function add_uf_jur_control(screen,id_room)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_uf_jur_control') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_room]=\" + encodeURIComponent(id_room));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

load_sp_ufs(screen,id_room);

}
}
}

}

</script>


<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\">
<td onclick=\"load_sets_jurnal_uf_control('",$screen,"','rooms');\" >

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"left\" style = \"padding-left: 10px;\">
назад
</td>
<td>
список уф-облучателей
</td>
</tr>
</table>


</td>
</tr>
<tr>
<td>

<div id = \"f_open_room_jur_uf_control_",$screen,"\" style = \"height: 100%; width: 100%; overflow-y: scroll;\"></div>

</td>
</tr>
<tr onclick = \"add_uf_jur_control('",$screen,"','",$id_room,"');\" height = \"15%\" style = \"background-color: #008080; color: white; cursor: pointer;\">
<td>
добавить уф
</td>
</tr>
</table>

<script>load_sp_ufs('",$screen,"','",$id_room,"')</script>

";

}

?>
