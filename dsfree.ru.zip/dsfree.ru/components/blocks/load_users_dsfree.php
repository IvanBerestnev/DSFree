<?php

function load_users_dsfree()
{

include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_users order by level DESC";
$query = mysqli_query($connection,$sql);

$ar_levels = array("0"=>"медсестра","1"=>"врач","2"=>"администратор");

If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_user = $row['id_user'];
$level = $row['level'];
$name_user = $row['name_user'];
$password_user = $row['password_user'];
$used = $row['used'];

echo "<table border = \"0\" width = \"100%\" height = \"15%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; border: 1px dotted black;\" cellpadding=\"0\" cellspacing= \"0\">";

echo "<tr>";

echo "<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"color: white; border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #373737; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>";

If($level == "3")
{
echo "<b>Суперпользователь</b>";
}
Else{

echo "<select onchange = \"edit_dsf_users('",$id_user,"','level_user',this.value);\">";

Foreach($ar_levels as $k=>$v)
{
echo "<option";
If($k == $level)
{
echo " selected";
}
echo " value = \"",$k,"\">",$v,"</option>";
}

echo "<select>";


}


echo "
</td>
<td>";

If($level == "3")
{
echo $name_user;
}
Else{
echo "<input onkeyup = \"edit_dsf_users('",$id_user,"','name_user',this.value);\" value = \"",$name_user,"\">";
}



echo "
</td>
";

If($password_user !== "")
{
echo "
<td style = \"cursor: pointer;\" onclick = \"edit_dsf_users('",$id_user,"','p_create_pass','');\">
сбросить пароль
</td>
";
}
Else{
echo "
<td style = \"cursor: pointer;\" onclick = \"edit_dsf_users('",$id_user,"','p_create_pass','');\">
создать пароль
</td>
";
}

echo "</td>

<td>";

If($level !== "3")
{

echo "
<table border = \"0\" width = \"100%\" height = \"100%\" style = \"color: white; border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #373737; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>

";

If($used == "0")
{
echo "<td onclick = \"edit_dsf_users('",$id_user,"','en_dis_acc','1');\">
включить
</td>";
}
Else{
echo "
<td onclick = \"edit_dsf_users('",$id_user,"','en_dis_acc','0');\">
отключить
</td>
";
}



echo "
</td>
</tr>
<tr>
<td onclick = \"edit_dsf_users('",$id_user,"','p_delete','');\">

удалить

</td>
</tr>
</table>";

}




echo "

</td>

</tr>
</table>

</td>";

echo "</tr>";
echo "</table><br>";


}


}



}


?>
