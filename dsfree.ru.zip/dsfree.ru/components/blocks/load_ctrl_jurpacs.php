<?php

function load_ctrl_jurpacs($vals)
{

#print_r($vals);

$id_used_ssetka = $vals['id_used_ssetka'];
$screen = $vals['screen'];
$param = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_ssetka_default where id_used_ssetka = '$id_used_ssetka' and number_cell = '$screen'";

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_default_set = $row['default_set'];
$active = $row['active'];

$default_set = json_decode($json_default_set,true);

$result = $default_set[$param];

#echo $active;
#echo "123";


}
Else{

$active = "";
$default_set = array("dunit"=>"1","c_days"=>"7","doc"=>"");
$result = $default_set[$param];



}

If($active == "")
{

If($param == "dunit")
{
echo "Установка <select id = \"sel_dunit_",$screen,"\" onchange = \"load_jurpacs('",$screen,"');\">";

For($du=1;$du<=10;$du++)
{
echo "<option";

If($du == $result)
{
echo " selected";
}

echo " value = \"",$du,"\">",$du,"</option>";
}

echo "</select>";

}
ElseIf($param == "c_days")
{

#echo "123";

echo "Количество дней  <select id = \"sel_c_days_",$screen,"\" onchange = \"load_jurpacs('",$screen,"');\">";

If($result == "any")
{
$default_set = array("dunit"=>"1","c_days"=>"7","doc"=>"");
$result = $default_set[$param];
}

For($cd=1;$cd<=14;$cd++)
{
echo "<option";

If($cd == $result)
{
echo " selected";
}

echo " value = \"",$cd,"\">",$cd,"</option>";
}

echo "</select>";

}
ElseIf($param == "doc")
{
	
If($result == "")
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_personal";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

echo "
<table border = \"0\" width = \"99%\" height = \"45px\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{
$id_pers = $row['id_pers'];
$surname = $row['surname_pers'];
$name_pers = $row['name_pers'];
$patronymic_pers = $row['patronymic_pers'];

$name_pers_short = mb_substr($name_pers, 0, 1,'UTF8');
$patronymic_pers_short = mb_substr($patronymic_pers, 0, 1,'UTF8');

$color = $row['bg_color_gen'];



echo "
<tr height = \"25px\" onclick = \"ctrl_jurpacs_doc_review('",$id_pers,"','",$screen,"','choice');\" >
<td>",$surname," ",$name_pers_short,". ",$patronymic_pers_short,".

</td>
<td style = \"background-color: ",$color,";\"
</td>
</tr>
";

}

echo "</table>";


}

}
Else{
//Состояние, где выбран врач и не активировано
$id_pers = $result;

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pers = $row['id_pers'];
$surname = $row['surname_pers'];
$name_pers = $row['name_pers'];
$patronymic_pers = $row['patronymic_pers'];

$name_pers_short = mb_substr($name_pers, 0, 1,'UTF8');
$patronymic_pers_short = mb_substr($patronymic_pers, 0, 1,'UTF8');

$color = $row['bg_color_gen'];

echo "
<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"position: relative;\">

<span onclick = \"ctrl_jurpacs_spdocs_review('",$id_used_ssetka,"','','",$screen,"','close');\" style = \"position: absolute; top: 0px; right: 0px; padding: 5px 15px; background-color: red;\">
X
</span>
";

//load_jurpacs('",$screen,"');
//load_ctrl_jurpacs('doc','",$screen,"');

echo $surname," ",$name_pers_short,". ",$patronymic_pers_short,".

<span style = \"display:none;\" id = \"f_ctrl_id_pers_",$screen,"\">",$id_pers,"</span>
</td>
</table>



";

}


}


}




}
Else{

If($param == "dunit")
{

If($result == "any")
{

echo "Установка <select id = \"sel_dunit_",$screen,"\" onchange = \"load_jurpacs('",$screen,"');\">";

For($du=1;$du<=10;$du++)
{
echo "<option";

If($du == $result)
{
echo " selected";
}

echo " value = \"",$du,"\">",$du,"</option>";
}

echo "</select>";


}
Else{

echo "Установка - <span id = \"span_dunit_",$screen,"\">",$result,"</span>";

}



}
ElseIf($param == "c_days")
{

#echo "123123";

If($result == "any")
{
	
#echo $result;
#echo "123123";

$default_set = array("dunit"=>"1","c_days"=>"7","doc"=>"");
$result = $default_set[$param];

//
#$result = 

echo "Количество дней <select id = \"sel_c_days_",$screen,"\" onchange = \"load_jurpacs('",$screen,"');\">";

For($cd=1;$cd<=14;$cd++)
{
echo "<option";

If($cd == $result)
{
echo " selected";
}

echo " value = \"",$cd,"\">",$cd,"</option>";
}

echo "</select>";

}
Else{

echo "Количество дней - <span id = \"span_c_days_",$screen,"\">",$result,"</span>";

}



}
ElseIf($param == "doc")
{

If($result == "")
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_personal";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

echo "
<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: blue;\" height = \"25px\" class = \"class_ctrl_doc_",$screen,"\">
<td colspan = \"2\" align = \"center\" onclick = \"close_choice_pers('",$screen,"');\">
Выбрать всех
</td>


</tr>
";


while($row = mysqli_fetch_assoc($query))
{
	
$id_pers = $row['id_pers'];
$surname = $row['surname_pers'];
$name_pers = $row['name_pers'];
$patronymic_pers = $row['patronymic_pers'];
$name_pers_short = mb_substr($name_pers, 0, 1,'UTF8');
$patronymic_pers_short = mb_substr($patronymic_pers, 0, 1,'UTF8');

$color = $row['bg_color_gen'];

echo "
<tr id = \"id_ctrl_doc_",$screen,"_",$id_pers,"\" class = \"class_ctrl_doc_",$screen,"\" height = \"25px\" >
<td onclick = \"ctrl_jurpacs_doc_review('",$id_pers,"','",$screen,"','bg');\">";

echo $surname," ",$name_pers_short,". ",$patronymic_pers_short,".";


echo "
</td>
<td style = \"background-color: ",$color,";\"
</td>
</tr>
";

}

echo "</table>
<span style = \"display: none;\" id = \"f_ctrl_id_pers_",$screen,"\"></span>
";

}


}
Else{

//состояние где выбран врач и активирован

$id_pers = $result;

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pers = $row['id_pers'];
$surname = $row['surname_pers'];
$name_pers = $row['name_pers'];
$patronymic_pers = $row['patronymic_pers'];
$name_pers_short = mb_substr($name_pers, 0, 1,'UTF8');
$patronymic_pers_short = mb_substr($patronymic_pers, 0, 1,'UTF8');

$color = $row['bg_color_gen'];

echo "
<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"position: relative;\">


";

//load_jurpacs('",$screen,"');
//load_ctrl_jurpacs('doc','",$screen,"');

echo $surname," ",$name_pers_short,". ",$patronymic_pers_short,".";

echo "
<span style = \"display:none;\" id = \"f_ctrl_id_pers_",$screen,"\">",$id_pers,"</span>
</td>
</table>



";

}

}

}

}








}

?>
