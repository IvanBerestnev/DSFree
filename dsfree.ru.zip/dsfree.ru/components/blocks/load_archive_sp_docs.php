<?php

function load_archive_sp_docs($vals)
{

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_personal where type = 'doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
	
while($row = mysqli_fetch_assoc($query))
{

$id_pers_actual = $row['id_pers'];
$ar_pers_actual[] = $id_pers_actual;

}

}


$sql = "select * from archive_pers where type = 'doc'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; margin-top: 10px; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";
	
while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];

If(!in_array($id_pers,$ar_pers_actual))
{

$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];

$color = $row['bg_color_gen'];
$txt_color = $row['txt_color_gen'];

echo "

<tr style = \"\">
<td height = \"80px\">

<table border = \"0\" height = \"100%\" width = \"100%\" style = \"cursor: default; border-collapse: collapse; table-layout: fixed; color: white; margin-top: 10px; font-weight: bold; background-color: ",$color,"; color: ",$txt_color,"\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
",$surname_pers," ",$name_pers," ",$patronymic_pers,"
</td>
<td onclick = \"act_restore_doc('",$id_pers,"','",$screen,"');\" width = \"25%\" align = \"center\" style = \"cursor: pointer;\">
восстановить
</td>
</tr>
</table>


</td>
</tr>

<tr height = \"20px\" style = \"background-color: #2E3436;\">
<td>
</td>
</tr>


";


}



}

echo "</table>";


}


}


?>


