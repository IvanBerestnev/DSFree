<?php

function load_pacs_to_change_pac_jurpac($vals)
{

#print_r($vals);
$surname_pac_search = $vals['surname_pac_search'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


If($surname_pac_search !== "")
{

$sql = "select * from tab_pacs where surname_pac like ('$surname_pac_search%') order by surname_pac ASC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "
<div style = \"overflow-y: scroll; height: 100%; width: 100%;\">
<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; text-align: left; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_pac = $row['id_pac'];

$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];

echo "
<tr class = \"class_choice_pac_change_pac_jurpac_",$screen,"\" id = \"id_choice_pac_change_pac_jurpac_",$screen,"_",$id_pac,"\" onclick = \"choice_pac_change_pac_jurpac('",$id_pac,"','",$screen,"');\" height = \"35px\" style = \"font-weight: bold; cursor: pointer;\">
<td style = \"padding-left: 5px;\">",$surname_pac," ",$name_pac," ",$patronymic_pac,"
</td>
</tr>";



}


echo "
</table>
</div>
";


echo "<span style = \"display: none;\" id = \"id_selected_choice_pac_change_pac_jurpac_",$screen,"\"></span>";


}
Else{

echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
ничего не найдено
</td>
</tr>
</table>
";

}


}
Else{

//echo "поиск последних 10 человек";

$sql = "select distinct id_pacs from pacs_ent order by begin limit 10";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$ar_ids[] = $row['id_pacs'];

}

$count_ar_ids = count($ar_ids);
$str_ids = implode("','",$ar_ids);


$sql = "select * from tab_pacs where id_pac IN('$str_ids')";
$query = mysqli_query($connection,$sql);

echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\" style = \"background-color: #555753; font-weight: bold; color: white;\">
<td>
последние ",$count_ar_ids," пациентов
</td>
</tr>
<tr>
<td>
<div style = \"height: 100%; width: 100%; overflow-y: scroll;\">";


If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: left;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_pac = $row['id_pac'];

$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];

echo "<tr class = \"class_choice_pac_change_pac_jurpac_",$screen,"\" id = \"id_choice_pac_change_pac_jurpac_",$screen,"_",$id_pac,"\" onclick = \"choice_pac_change_pac_jurpac('",$id_pac,"','",$screen,"');\" height = \"40\"><td style = \" padding-left: 15px; font-weight: bold; color: white;  cursor: pointer;\">",$surname_pac," ",$name_pac," ",$patronymic_pac,"</td></tr>";
}

echo "</table>";

}

echo "</div>
</td>
</tr>
</table>

<span style = \"display: none;\" id = \"id_selected_choice_pac_change_pac_jurpac_",$screen,"\"></span>

";



}










}




}

?>
