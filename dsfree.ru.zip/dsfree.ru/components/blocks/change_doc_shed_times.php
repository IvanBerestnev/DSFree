<?php

function change_doc_shed_times($vals)
{


#print_r($vals);die();

$act = $vals['act'];
$screen = $vals['screen'];
$param = $vals['param'];


$ar_param = explode("#",$param);

$id_doc = $ar_param[2];
#$id_shedule = $ar_param[3];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_personal";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];




$surname_pers = $row['surname_pers'];
$name_pers = $row['name_pers'];

$ar_pers[$id_pers]['surname_pers'] = $surname_pers;
$ar_pers[$id_pers]['name_pers'] = $name_pers;

}

}

$chouse_doc = $ar_pers[$id_doc]['surname_pers']." ".$ar_pers[$id_doc]['name_pers'];

unset($ar_pers[$id_doc]);




echo "

<script>

function act_change_doc_shed_times()
{

var id_change_doc_param = 'id_change_doc_param_",$screen,"';
var change_doc_param = document.getElementById(id_change_doc_param).innerHTML;

var id_change_doc_span_selected_doc = 'id_change_doc_span_selected_doc_",$screen,"';
var change_doc_span_selected_doc = document.getElementById(id_change_doc_span_selected_doc).innerHTML;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_change_doc_shed_times') + \"&data[param]=\" + encodeURIComponent(change_doc_param) + \"&data[screen]=\" + encodeURIComponent('",$screen,"') + \"&data[doc]=\" + encodeURIComponent(change_doc_span_selected_doc));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var modal = 'modal_",$screen,"';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var id_sel_run_act_bottom_jp = 'id_sel_run_act_bottom_jp_",$screen,"';
document.getElementById(id_sel_run_act_bottom_jp).selectedIndex = 0;



var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}





}

</script>

<table border = \"0\" width = \"100%\" height = \"100.5%\" style = \" border-collapse: collapse; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"20%\">
<td colspan = \"3\" align = \"left\" style = \"padding-left: 5px; background-color: black; color: white; font-weight: bold; font-size: 18px;\">
Замена врача
</td>
</tr>

<tr style = \"font-weight: bold;\">
<td width = \"45%\">
",$chouse_doc,"
</td>
<td style = \"font-size: 30px; color: #CC0000;\">
&#10140;

</td>
<td width = \"45%\">

";

If(count($ar_pers)>1)
{
echo "<select>";
Foreach($ar_pers as $id_pers=>$vals)
{
$surname_pers = $vals['surname_pers'];


echo "<option>",$surname_pers,"</option>";
}

echo "</select>";
}
Else{



Foreach($ar_pers as $id_pers=>$vals)
{
$surname_pers = $vals['surname_pers'];
$name_pers = $vals['name_pers'];


echo "<span style = \"display: none;\" id = \"id_change_doc_span_selected_doc_",$screen,"\">",$id_pers,"</span>",$surname_pers," ",$name_pers;
}


}

echo "

</td>
</tr>

<tr onclick = \"act_change_doc_shed_times();\" height = \"25%\" style = \"background-color: green;\">
<td width = \"40%\" colspan = \"3\" style = \"padding-left: 5px; background-color: green; color: white; font-weight: bold; font-size: 18px;\">
заменить
</td>
</tr>

</table>

<span style = \"display: none;\" id = \"id_change_doc_param_",$screen,"\">",$param,"</span>



";



}

?>
