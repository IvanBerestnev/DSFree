<?php

function delete_doc($vals)
{


$screen = $vals['screen'];
$id_pers = $vals['id_pers'];

echo "

<script>

function chouse_mode_delete_doc(screen,mode)
{

var f_chouse_mode_delete_doc = 'f_chouse_mode_delete_doc_' + screen;
document.getElementById(f_chouse_mode_delete_doc).innerHTML = mode;


var class_table = 'table_' + screen;
var theOddOnes = document.getElementsByClassName(class_table);

for(var i=0; i<theOddOnes.length; i++)
{

var id_table = theOddOnes[i].id;

document.getElementById(id_table).style.backgroundColor = 'white';
document.getElementById(id_table).style.color = 'black';
document.getElementById(id_table).style.fontWeight = 'normal';
}


var table = 'table_' + screen + '_' + mode;
document.getElementById(table).style.backgroundColor = '#FFA500';
document.getElementById(table).style.color = 'white';
document.getElementById(table).style.fontWeight = 'bold';

var but_continue_inactive = 'but_continue_' + screen + '_inactive';
var but_continue_active = 'but_continue_' + screen + '_active';


document.getElementById(but_continue_inactive).style.display = 'none';
document.getElementById(but_continue_active).style.display = 'flex';


}

function act_delete_doc(screen,id_pers)
{


var f_chouse_mode_delete_doc = 'f_chouse_mode_delete_doc_' + screen;
var mode = document.getElementById(f_chouse_mode_delete_doc).innerHTML;


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_pers]=\" + encodeURIComponent(id_pers) + \"&data[mode]=\" + encodeURIComponent(mode));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_chouse_mode_delete_doc = 'f_chouse_mode_delete_doc_' + screen;


var cont = document.getElementById(f_chouse_mode_delete_doc);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}

</script>

<table border = \"1\" height = \"100%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td height = \"10%\" colspan = \"2\" style = \"background-color: black; color: #ED8984; font-weight: bold; \">

Внимание

</td>
</tr>

<tr>
<td colspan = \"2\" height = \"15%\" style = \"background-color: grey; color: white; font-weight: bold; \">

Вы собираетесь удалить врача из программы.<br>
Выберете режим удаления:

</td>
</tr>

<tr>
<td colspan = \"2\">

<div style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2E3436;\">

<table class = \"table_",$screen,"\" id = \"table_",$screen,"_mode_1\" border = \"1\" height = \"30%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; background-color: white; margin-top: 10px; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"chouse_mode_delete_doc('",$screen,"','mode_1');\">
Режим 1. Примените, если Вы случайно создали врача и не успели что-либо сделать в его аккаунте.
</td>
</tr>
</table>

<table class = \"table_",$screen,"\" id = \"table_",$screen,"_mode_2\" border = \"1\" height = \"30%\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: black; background-color: white; margin-top: 10px; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"chouse_mode_delete_doc('",$screen,"','mode_2');\">
Режим 2. Примените, если Вы хотите удалить врача и связанное с ним расписание. Информация в медицинских картах связанная с врачом остается.
</td>
</tr>
</table>

</div>

</td>
</tr>

<tr height = \"15%\" align = \"center\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" style = \"background-color: #ED8984; color: white; font-weight: bold;\">
отмена
</td>

<td >
<span id = \"but_continue_",$screen,"_inactive\" style = \"display: flex; align-items: center; justify-content: center; height: 100%; background-color: #C0C0C0; color: white; font-weight: bold;\">
продолжить
</span>

<span id = \"but_continue_",$screen,"_active\" onclick = \"act_delete_doc('",$screen,"','",$id_pers,"');\" style = \"display: none; align-items: center; justify-content: center; height: 100%; background-color: green; color: white; font-weight: bold;\">
продолжить
</span>


</td>


</tr>


</table>
<span style = \"display: ;\" id = \"f_chouse_mode_delete_doc_",$screen,"\"></span>

";




}

?>
