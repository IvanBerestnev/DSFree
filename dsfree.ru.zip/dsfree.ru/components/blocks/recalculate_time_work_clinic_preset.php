<?php

function recalculate_time_work_clinic_preset($vals)
{

#print_r($vals);

$begin_income = $vals['begin'];
$end_income = $vals['end'];

If($begin_income>$end_income)
{
$begin = $end_income;
$end = $begin_income;
}
Else{
$begin = $begin_income;
$end = $end_income;
}


$begin_min = date("H:i", mktime(0, $begin, 0, 1, 1, 1970));
$end_min = date("H:i", mktime(0, $end, 0, 1, 1, 1970));


echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = 
\"border-collapse: collapse; background-color: Gainsboro; color: black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td id = \"td_begin_twc\">
<select id = \"sel_begin_twc\" onchange = \"recalculate_time_work_clinic_preset(this.value,'');\" style = \"width: 80%; height: 50%; text-align: center; font-weight: bold; font-size: 26px;\">
";

For($i=0;$i<1410;$i=$i+30)
{

$hm = date("H:i", mktime(0, $i, 0, 1, 1, 1970));

If($hm == $end_min)
{
continue;
}

echo "<option value = \"",$hm,"\"";

If($hm == $begin_min)
{
echo " selected";
}

echo ">",$hm,"</option>";

}




echo "
</select>
</td>
<td id = \"td_end_twc\">
<select id = \"sel_end_twc\" onchange = \"recalculate_time_work_clinic_preset('',this.value);\" style = \"width: 80%; height: 50%; text-align: center; font-weight: bold; font-size: 26px;\">";

For($i=30;$i<1440;$i=$i+30)
{

$hm = date("H:i", mktime(0, $i, 0, 1, 1, 1970));



If($hm == $begin_min)
{
continue;
}

echo "<option value = \"",$hm,"\"";

If($hm == $end_min)
{
echo " selected";
}

echo ">",$hm,"</option>";

}




echo "</select>
</td>
</tr>
</table>

";


}

?>
