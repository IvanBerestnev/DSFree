<?php

function load_jur_uf_control($vals)
{

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

function diff_time($b,$e)
{
$ar_b = explode(":",$b);
$ar_e = explode(":",$e);
$fmin = ($ar_b[0]*60)+$ar_b[1];
$emin = ($ar_e[0]*60)+$ar_e[1];
$dtm = $emin-$fmin;
$dt = date("H:i",mktime(0,$dtm,0,1,1,1970));
return $dt;
}

function trim_sec($time)
{
$ar_time = explode(":",$time);
$h = $ar_time[0];
$m = $ar_time[1];
$hm = $h.":".$m;
return $hm;
}

function normal_date($date)
{

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

$ar_dw = array(
"0"=>"<span style = \"color: #F5C211; font-weight: bold;\">Вс</span>",
"1"=>"<span style = \"font-weight: bold;\">Пн</span>",
"2"=>"<span style = \"font-weight: bold;\">Вт</span>",
"3"=>"<span style = \"font-weight: bold;\">Ср</span>",
"4"=>"<span style = \"font-weight: bold;\">Чт</span>",
"5"=>"<span style = \"font-weight: bold;\">Пт</span>",
"6"=>"<span style = \"color: #F5C211; font-weight: bold;\">Сб</span>"

);

$ar_date = explode("-",$date);
$d = $ar_date[2];
$m = $ar_date[1];
$y = $ar_date[0];

$n = date("w", mktime(0,0,0,$m,$d,$y));

$dmy = $d." ".$ar_months_rus[$m]." ".$y." (".$ar_dw[$n].")";
return $dmy;
}


$sql = "select * from jur_uf_control order by date DESC";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
";

while($row = mysqli_fetch_assoc($query))
{

$id = $row['id'];
$date = $row['date'];
$usl_dezinf = $row['usl_dezinf'];
$obj_dezinf = $row['obj_dezinf'];
$vid_microb = $row['vid_microb'];
$exposure_mode = $row['exposure_mode'];
$time_beg = $row['time_beg'];
$time_end = $row['time_end'];

$time_beg = trim_sec($time_beg);
$time_end = trim_sec($time_end);

$t_diff = diff_time($time_beg,$time_end);

$date = normal_date($date);

echo "<tr height = \"30px\">

<td width = \"40px\" style = \"background-color: #FF8080; color: white; font-weight: bold;\">
Х
</td>

<td>
",$date,"
</td>

<td>
",$usl_dezinf,"
</td>
<td>
",$obj_dezinf,"
</td>
<td>
",$vid_microb,"
</td>
<td>
",$exposure_mode,"
</td>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
",$time_beg,"
</td>
<td>
",$time_end,"
</td>
</tr>
</table>


</td>


<td>",$t_diff,"</td>

</tr>
";

}

echo "</table>";



}


}

?>
