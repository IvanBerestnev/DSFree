<?php


function load_names_first_docums($vals)
{

#print_r($vals);

$type = $vals['type'];
$mode = $vals['mode'];
$screen = $vals['screen'];
$id_pac = $vals['id_pac'];

If($type == "single")
{

If($mode == "work")
{
$color = "#3A3A3A";
$script_dogovor_pmu = "open_first_docum('dogovor_pmu','".$id_pac."','".$screen."');";
$script_medcart = "edit_first_docum('medcart_general','".$id_pac."','".$screen."');";
$script_act_dw_admin = "open_first_docum('act_dw_admin','".$id_pac."','".$screen."');";
}
ElseIf($mode == "edit")
{
$color = "#10437B";
$script_dogovor_pmu = "";
$script_medcart = "edit_first_docum('edit_medcart_step1','".$id_pac."','".$screen."');";
$script_act_dw_admin = "";

}

//////здесь проверять уже открытые страницы

echo "

<script>


function open_first_docum(name_docum,id_pac,screen)
{

var main_loaded_primary_page = 'main_loaded_primary_page_' + name_docum + '_' + id_pac;

var areaOption = document.getElementById(main_loaded_primary_page);
if (areaOption) {


var fon_modal = 'fon_modal_' + screen;
var modal = 'modal_' + screen;

document.getElementById(fon_modal).style.display = 'block';

document.getElementById(modal).style.width = '300px';
document.getElementById(modal).style.height = '100px';

document.getElementById(modal).innerHTML = \"<span class='close' onclick=close_mw(\'\"+fon_modal+\"\');>X</span><table align = 'center' width = '100%' height = '100%' style = 'background-color: #2E3436; color: lime; font-weight: bold;'><tr><td align = 'center'>Окно с подпрограммой первичной документации уже открыто.</td></tr></table>\";


return false;

} else {



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('open_first_docum') + \"&data[name_docum]=\" + encodeURIComponent(name_docum) + \"&data[id_pac]=\" + encodeURIComponent(id_pac) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_main_primary_docums = 'f_main_primary_docums_' + screen;

var cont = document.getElementById(f_main_primary_docums);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}
}


function edit_first_docum(name_docum,param,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('edit_first_docum') + \"&data[name_docum]=\" + encodeURIComponent(name_docum) + \"&data[param]=\" + encodeURIComponent(param) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

if(name_docum == 'page_print_medcart')
{

var fon_modal = 'fon_modal_' + screen;
var modal = 'modal_' + screen;
document.getElementById(fon_modal).style.display = 'block';
document.getElementById(modal).style.width = '300px';
document.getElementById(modal).style.height = '100px';

var cont = document.getElementById(modal);


}
else{

var f_main_primary_docums = 'f_main_primary_docums_' + screen;
var cont = document.getElementById(f_main_primary_docums);

}



cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}

</script>


<style>

.class_names_first_docums{
background-color: ",$color,"; height: 70%; width: 90%; display:flex; align-items:center; justify-content: center;
cursor: pointer;
font-weight: bold;
}

</style>

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td height = \"170\" width = \"50%\" align = \"center\">

<div onclick = \"",$script_dogovor_pmu,"\" class = \"class_names_first_docums\">

Договор платных<br>
медицинских услуг

</div>

</td>

<td height = \"170\" width = \"50%\" align = \"center\">

<div class = \"class_names_first_docums\">

Анкета о здоровье

</div>



</td>
</tr>

<td height = \"170\" width = \"50%\" align = \"center\">

<div class = \"class_names_first_docums\">

Информированное <br>
добровольное<br>
согласие

</div>
</td>

<td height = \"170\" width = \"50%\" align = \"center\">

<div class = \"class_names_first_docums\">

План лечения

</div>
</td>


</tr>
<tr>
<td height = \"170\" width = \"50%\" align = \"center\">

<div onclick = \"",$script_medcart,"\" class = \"class_names_first_docums\">

Медицинская карта

</div>
</td>

<td height = \"170\" width = \"50%\" align = \"center\">

<div onclick = \"",$script_act_dw_admin,"\" class = \"class_names_first_docums\">

Акт выполненных<br>работ

</div>


</td>
</tr>
<tr>
<td height = \"170\" width = \"50%\" align = \"center\">

<div class = \"class_names_first_docums\">

Эпикриз

</div>


</td>
<td height = \"170\" width = \"50%\" align = \"center\">

<div class = \"class_names_first_docums\">

Гарантия

</div>
</td>
</tr>




</table>





";

}
ElseIf($type == "multiple")
{

If($mode == "work")
{
echo "Рабочий режим пакета";
}
ElseIf(($mode == "edit"))
{
echo "Редактирование пакета";
}

}

}

?>
