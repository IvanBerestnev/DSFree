<?php

function st4_block_act_dw($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];


echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\" style = \"background-color: #111111;\">
</td>
<td >
акт принят.
<br>
посещение без оплаты.
</td>
<td width = \"25%\" style = \"background-color: #111111;\">
</td>
</tr>
<tr height = \"10%\">
<td onclick = \"act_add_new_data_act_dw('",$id_visit,"','",$screen,"','accept_visit','');\" colspan = \"3\" style = \"background-color: #808080; cursor: pointer;\">
отмена
</td>
</tr>
</table>

";

}

?>
