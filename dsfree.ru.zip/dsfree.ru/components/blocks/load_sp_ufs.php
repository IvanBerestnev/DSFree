<?php

function load_sp_ufs($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_room = $vals['id_room'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_misc_sets where id = '5'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['val'];
$arr = json_decode($json_arr,true);



If(empty($arr[$id_room]['ufs']))
{

echo "
<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
нет данных о уф облучателях
</td>
</tr>
</table>
";

}
Else{

$ar = $arr[$id_room]['ufs'];

echo "<table align = \"center\" border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

$i=1;
Foreach($ar as $id_uf=>$ar_valls)
{

$limit = $ar_valls['limit'];
$docum = $ar_valls['docum'];
$siz = $ar_valls['siz'];
$place = $ar_valls['place'];

echo "

<tr>
<td width = \"30px\" rowspan = \"2\">",$i,"
</td>

</tr>

<tr>
<td height = \"90px\">

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"25%\">

<select>
<option>открытого типа</option>
<option>закрытого типа</option>
</select>

</td>
<td width = \"25%\">

<input size = \"4\" value = \"",$limit,"\" placeholder = \"срок\"> часов

</td>
<td>

<input value = \"",$siz,"\" placeholder = \"сиз\">

</td>
</tr>
</table>

</td>



</tr>
<tr>
<td>

<input value = \"",$docum,"\" style = \"width: 90%;\" placeholder = \"номер, дата акта ввода в эксплуатацию\">

</td>
<td>

<input value = \"",$place,"\" style = \"width: 90%;\" placeholder = \"расположение\">

</td>




</tr>
</table>

</td>
</tr>
";
$i++;
}

echo "</table>";

}

}

}

?>
