<?php

function correct_shed_time_doc($vals)
{

function convert_time_to_min($time_norm)
{
$ar_t_b = explode(":",$time_norm);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];
$time_b = ($hb*60)+$mb;
return $time_b;
}


#print_r($vals);die();

$param = $vals['param'];

$ar_param = explode("#",$param);



$period_gen = $ar_param[0];




$ar_period_gen = explode("@",$period_gen);
$datetime_choise_beg = $ar_period_gen[0];

$ar_date_choise_beg = explode(" ",$datetime_choise_beg);

$date_choise_beg = $ar_date_choise_beg[0];
$f_time_choise_beg = $ar_date_choise_beg[1];

$ar_f_time_choise_beg = explode(":",$f_time_choise_beg);

$hb = $ar_f_time_choise_beg[0];
$mb = $ar_f_time_choise_beg[1];
$hmb = $hb.":".$mb;

$datetime_choise_end = $ar_period_gen[1];

#echo $datetime_choise_end;

$ar_datetime_choise_end = explode(" ",$datetime_choise_end);

$date_choise_end = $ar_datetime_choise_end[0];
$f_time_choise_end = $ar_datetime_choise_end[1];

$ar_f_time_choise_end = explode(":",$f_time_choise_end);

$he = $ar_f_time_choise_end[0];
$me = $ar_f_time_choise_end[1];
$hme = $he.":".$me;

$chouse_t_period = $hmb."-".$hme;
#echo $chouse_t_period;

$unit = $ar_param[1];
$chousen_pers = $ar_param[2];
$id_ent = $ar_param[3];


$screen = $vals['screen'];


$arr_utcsd['date'] = $date_choise_beg;
$arr_utcsd['dunit'] = $unit;
$arr_utcsd['chousen_schema'] = "dark";
$arr_utcsd['chousen_pers'] = $chousen_pers;
$arr_utcsd['screen'] = $screen;


include_once("used_times_correct_shed_doc.php");


$ar_exit = used_times_correct_shed_doc($arr_utcsd);

#print_r($ar_exit);
#echo $chouse_t_period;

$i=0;

Foreach($ar_exit as $ar_vals)
{

$ar_times = $ar_vals['times'];
$f_b = array_shift($ar_times);
$f_e = end($ar_times);

$f_be = $f_b."-".$f_e;

$type = $ar_vals['type'];

#$ar_new[$f_be] = $ar_vals;

If($f_be !== $chouse_t_period)
{

$ar_new[$i][$f_be] = $ar_vals;

}
Else{

$i++;

}

}

#print_r($ar_new);die();

If(isset($ar_new))
{



If(isset($ar_new[1]))
{

$ar_after = $ar_new[1];
$ar_last_after = array_shift($ar_after);
$type_after = $ar_last_after['type'];

If($type_after == "free_time")
{
$end_avail_time = end($ar_last_after['times']);
}
Else{
$end_avail_time = $hme;
}

$min_end_avail_time = convert_time_to_min($end_avail_time);

}


If(isset($ar_new[0]))
{

$ar_before = $ar_new[0];
$ar_last_before = end($ar_before);
$type_before = $ar_last_before['type'];

If($type_before == "free_time")
{
$start_avail_time = array_shift($ar_last_before['times']);
}
Else{
$start_avail_time = $hmb;
}

$min_start_avail_time = convert_time_to_min($start_avail_time);


}


If(!isset($min_end_avail_time))
{
$min_end_avail_time = convert_time_to_min($hme);
}


If(!isset($min_start_avail_time))
{
$min_start_avail_time = convert_time_to_min($hmb);
}



$min_hmb = convert_time_to_min($hmb);
$min_hme = convert_time_to_min($hme);



}
Else{

#echo $hmb."--".$hme;

$min_start_avail_time = convert_time_to_min($hmb);
$min_end_avail_time = convert_time_to_min($hme);

$min_hmb = convert_time_to_min($hmb);
$min_hme = convert_time_to_min($hme);


}



echo "

<script>

function timeConvert(n) {
var totalTimeInMin = n;
var h = Math.floor(totalTimeInMin / 60);
var m = totalTimeInMin % 60;
if(h < 10)
{
nh = '0' + h;
}
else{
nh = h;
}
if(m < 10)
{
nm = '0' + m;
}
else{
nm = m;
}
var exit = nh + ':' + nm;
return exit;
}



function change_time_move(val,type)
{

//конвертация времени с range
var low = timeConvert(val);

//переменная левая внизу экрана
var f_low_corr_shed_doc = 'f_low_corr_shed_doc_",$screen,"';

//переменная правая внизу экрана
var f_height_corr_shed_doc = 'f_height_corr_shed_doc_",$screen,"';

//переменная range слева
var id_low_corr_shed_doc = 'id_low_corr_shed_doc_",$screen,"';
//значение перменной range слева
var low_corr_shed_doc = document.getElementById(id_low_corr_shed_doc).value;
//пребразование переменной range справа в цифровой ф-т
var d_low_corr_shed_doc = Number(low_corr_shed_doc);

//переменная range справа
var id_height_corr_shed_doc = 'id_height_corr_shed_doc_",$screen,"';
//значение перменной range справа
var height_corr_shed_doc = document.getElementById(id_height_corr_shed_doc).value;
//пребразование переменной range справа в цифровой ф-т
var d_height_corr_shed_doc = Number(height_corr_shed_doc);


var f_id_write_change_cor_shed_doc_active = \"f_id_write_change_cor_shed_doc_active_",$screen,"\";
var f_id_write_change_cor_shed_doc_inactive = \"f_id_write_change_cor_shed_doc_inactive_",$screen,"\";

document.getElementById(f_id_write_change_cor_shed_doc_active).style.display = 'inline-table';
document.getElementById(f_id_write_change_cor_shed_doc_inactive).style.display = 'none';

if(type == 'low')
{

if(val < d_height_corr_shed_doc)
{
document.getElementById(f_low_corr_shed_doc).innerHTML = low;
}
else if(val > d_height_corr_shed_doc)
{
document.getElementById(f_height_corr_shed_doc).innerHTML = low;
}
else if(val == d_height_corr_shed_doc)
{

document.getElementById(f_low_corr_shed_doc).innerHTML = low;
document.getElementById(f_height_corr_shed_doc).innerHTML = low;

document.getElementById(f_id_write_change_cor_shed_doc_active).style.display = 'none';
document.getElementById(f_id_write_change_cor_shed_doc_inactive).style.display = 'inline-table';

}


}
else if(type == 'height')
{


if(val > d_low_corr_shed_doc)
{
document.getElementById(f_height_corr_shed_doc).innerHTML = low;
}
else if(val < d_low_corr_shed_doc)
{
document.getElementById(f_low_corr_shed_doc).innerHTML = low;
}
else if(val == d_low_corr_shed_doc)
{

document.getElementById(f_height_corr_shed_doc).innerHTML = low;
document.getElementById(f_low_corr_shed_doc).innerHTML = low;

document.getElementById(f_id_write_change_cor_shed_doc_active).style.display = 'none';
document.getElementById(f_id_write_change_cor_shed_doc_inactive).style.display = 'inline-table';

}


}



}

function send_new_period_shed_doc()
{

var f_old_chouse_t_period_chng_shed_doc = 'f_old_chouse_t_period_chng_shed_doc_",$screen,"';
var old_chouse_t_period_chng_shed_doc = document.getElementById(f_old_chouse_t_period_chng_shed_doc).innerHTML;

var f_id_ent_chng_shed_doc = 'f_id_ent_chng_shed_doc_",$screen,"';
var id_ent_chng_shed_doc = document.getElementById(f_id_ent_chng_shed_doc).innerHTML;

//новый период
//низ
var f_low_corr_shed_doc = 'f_low_corr_shed_doc_",$screen,"';
var low_corr_shed_doc = document.getElementById(f_low_corr_shed_doc).innerHTML;

//верх
var f_height_corr_shed_doc = 'f_height_corr_shed_doc_",$screen,"';
var height_corr_shed_doc = document.getElementById(f_height_corr_shed_doc).innerHTML;

var new_period = low_corr_shed_doc + '-' + height_corr_shed_doc;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('send_new_period_shed_doc') + \"&data[screen]=\" + encodeURIComponent('",$screen,"') + \"&data[old_chouse_t_period]=\" + encodeURIComponent(old_chouse_t_period_chng_shed_doc) + \"&data[id_shedule]=\" + encodeURIComponent(id_ent_chng_shed_doc) + \"&data[new_period]=\" + encodeURIComponent(new_period));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var modal = 'modal_",$screen,"';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<style>

.slider {

-webkit-appearance: none;
width: 100%;
height: 25px;
position: absolute;
background: #a4a4a4;
outline: none;


}

.slider input {

pointer-events: none;
position: absolute;
overflow: hidden;
left: 25%;
top: 15px;
width: 50%;
outline: none;
height: 18px;
margin: 0px;
padding: 0px;

}

.slider::-webkit-slider-thumb {

-webkit-appearance: none;
appearance: none;
width: 35px;
height: 35px;
background: #ea4550;
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 1;
outline: 0;

}

.slider::-moz-range-thumb {

width: 20px;
height: 20px;
background: #ea4550;
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 10;
-moz-appearance: none;
width: 9px;

}

.slider input::-moz-range-track {

position: relative;
z-index: -1;
border: 0;

}

.slider input:last-of-type::-moz-range-track {

-moz-appearance: none;
background: none transparent;
border: 0;

}

.slider input[type=range]::-moz-focus-outer {
border: 0;
}

</style>

<table border = \"0\" width = \"100%\" height = \"100.5%\" style = \" border-collapse: collapse; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"color: white; font-weight: bold; background-color: black;\">
<td colspan = \"2\" align = \"left\">
Коррекция времени врача
</td>
</tr>



<tr>
<td colspan = \"2\">

<div style = \"float: left;\">
<input class=\"slider\" id=\"id_low_corr_shed_doc_",$screen,"\" oninput = \"change_time_move(this.value,'low');\" type=\"range\" step = \"5\" min=\"",$min_start_avail_time,"\" max=\"",$min_end_avail_time,"\" value=\"",$min_hmb,"\">
<input class=\"slider\" id=\"id_height_corr_shed_doc_",$screen,"\" oninput = \"change_time_move(this.value,'height');\" type=\"range\" step = \"5\" min=\"",$min_start_avail_time,"\" max=\"",$min_end_avail_time,"\" value=\"",$min_hme,"\">
</div>

</td>
</tr>

<tr height = \"20%\">

<td width = \"50%\">
<span id=\"f_low_corr_shed_doc_",$screen,"\" style = \"font-weight: bold; color: white;\">",$hmb,"</span>
</td>

<td width = \"50%\">
<span id=\"f_height_corr_shed_doc_",$screen,"\" style = \"font-weight: bold; color: white;\">",$hme,"</span>
</td>
</tr>

<tr height = \"20%\">
<td colspan = \"2\">

<table id = \"f_id_write_change_cor_shed_doc_active_",$screen,"\" border = \"1\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; background-color: green; color: white; font-weight: bold; cursor: pointer; display: inline-table;\" cellpadding=\"0\" cellspacing= \"0\">
<tr onclick = \"send_new_period_shed_doc();\">
<td>
Записать
</td>
</tr>
</table>

<table id = \"f_id_write_change_cor_shed_doc_inactive_",$screen,"\" border = \"1\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; background-color: grey; color: white; font-weight: bold; cursor: pointer; display: none;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Записать
</td>
</tr>
</table>

</td>
</tr>

</table>

<span id = \"f_old_chouse_t_period_chng_shed_doc_",$screen,"\" style = \"display: none;\">",$chouse_t_period,"</span>
<span id = \"f_id_ent_chng_shed_doc_",$screen,"\" style = \"display: none;\">",$id_ent,"</span>

";

//$id_ent

}


?>
