<?php

function load_sp_clients($vals)
{


#print_r($vals);

$screen = $vals['screen'];
$surname = $vals['surname'];
$sex = $vals['sex'];
$id_pac_recieved = $vals['id_pac'];



$ar_sex = array("w"=>"(жен)","m"=>"(муж)");

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


If($surname == "")
{
$sql = "select * from tab_pacs";
}
Else{
$sql = "select * from tab_pacs where surname_pac like '%".$surname."%'";
}


$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_pac = $row['id_pac'];
$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];

$sex_pac = $row['sex_pac'];

If($sex_pac !== "")
{
$sex_pac = $ar_sex[$sex_pac];
}



echo "

<tr class = \"td_self_load_sp_clients_",$screen,"\">
<td >
",$surname_pac," ",$name_pac," ",$patronymic_pac," ",$sex_pac,"
</td>

<td width = \"20%\" height = \"50px\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td onclick = \"open_modal_load_sp_clients('info_pac','",$id_pac,"','",$screen,"');\" width = \"50%\" style = \"background-color: #008080; font-weight: bold;\">
ред.
</td>
<td onclick = \"open_modal_load_sp_clients('page_del_client','",$id_pac,"','",$screen,"');\" style = \"background-color: #FF8080; font-weight: bold;\">
х
</td>
</tr>
</table>

</td>

</tr>
<tr height = \"20px\">
<td colspan = \"2\">




</td>
</tr>

";


}

echo "</table>";

}
Else{

echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
Нет клиентов в базе
</td>
</tr>
</table>

";

}

If($id_pac_recieved !== "")
{
echo "
<script>
open_modal_load_sp_clients('info_pac','",$id_pac_recieved,"','",$screen,"');
</script>
";

}


}


?>
