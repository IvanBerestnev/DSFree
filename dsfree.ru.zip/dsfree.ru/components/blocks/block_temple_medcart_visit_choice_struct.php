<?php

function block_temple_medcart_visit_choice_struct($vals)
{


$screen = $vals['screen'];
$id_ds = $vals['id_ds'];
$id_struct = $vals['id_struct'];
$id_razd = $vals['id_razd'];
$id_writed_razd = $vals['id_writed_razd'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");




$sql = "select * from sp_dss where id_ds = '$id_ds'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$name_ds = $row['name_ds'];
$id_ds_sp = $row['id_ds']; 
}


echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"10%\">
<td align = \"center\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"33%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td style = \"background-color: #8A969C;\">
",$name_ds,"
</td>
<td onclick = \"load_block_temple_razd_visit_self('','','','",$screen,"','",$id_writed_razd ,"');\" width = \"20%\" style = \"background-color: #FF8080; cursor: pointer;\">
x
</td>
</tr>
</table>

</td>
<td width = \"33%\">
</td>
<td>
</td>
</tr>
</table>

</td>
</tr>

<tr height = \"15%\">
<td align = \"center\">
выберете структурный шаблон
</td>
</tr>
<tr>
<td>
<div style = \"width: 100%; height: 100%; overflow-y:scroll;\">";

$status = "";

$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
";

while($row = mysqli_fetch_assoc($query))
{

$text = $row['text'];

$text = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_text = json_decode($text,true);

If(isset($ar_text[$id_ds]))
{

$ar_all_struct = $ar_text[$id_ds];

Foreach($ar_all_struct as $id_struct_intemple=>$ar_valls_struct)
{
$name = $ar_valls_struct['name'];

echo "
<tr onclick = \"load_block_temple_razd_visit_self('",$id_ds,"','",$id_struct_intemple,"','','",$screen,"','",$id_writed_razd ,"');\" style = \"background-color: #C0C0C0; color: black; cursor: pointer;\" height = \"40px\">
<td>
",$name,"
</td>
</tr>
<tr height = \"20px\"><td></td></tr>
";

}

$status = "1";


}


#echo "<tr onclick = \"load_block_temple_razd_visit_self('",$id_ds_sp,"','",$id_struct,"','",$id_razd,"','",$screen,"');\" style = \"background-color: #C0C0C0; color: black; cursor: pointer;\" height = \"40px\"><td>",$name_ds,"</td></tr><tr height = \"20px\"><td></td></tr>";

}

echo "</table>";


If($status == "")
{
echo "
<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr><td align = \"center\">структурных шаблонов не найдено</td>
</table>
";
}



}


echo "

</div>
</td>
</tr>
</table>

";


}

?>
