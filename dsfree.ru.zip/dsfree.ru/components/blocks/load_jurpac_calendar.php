<?php

function load_jurpac_calendar($merg_arr)
{
	
#print_r($merg_arr);

$c_days = $merg_arr['c_days'];	
$date = $merg_arr['date'];
$ar_date = explode("-",$date);
$day = $ar_date['0'];
$month = $ar_date['1'];
$year = $ar_date['2'];

$dunit = $merg_arr['dunit'];
$id_pers = $merg_arr['id_pers'];
$screen = $merg_arr['screen'];




If($id_pers == "")
{
$id_pers = "all";
}


///Здесь проверка по дефолту если любое значение - количество дней
If($c_days == "any")
{
$c_days = "7";
}


///Здесь проверка по дефолту если любое значение - выбор установки
If($dunit == "any")
{
$dunit = "1";
}



$ar_dw_rus = array("Mon"=>"понедельник","Tue"=>"вторник","Wed"=>"среда","Thu"=>"четверг","Fri"=>"пятница","Sat"=>"<span style = \"font-weight: bold; color: OrangeRed;\">суббота</span>","Sun"=>"<span style = \"font-weight: bold; color: OrangeRed;\">воскресенье</span>",);




include_once("../components/blocks/used_times_pacs.php");


$vals['chousen_schema'] = "dark";
$vals['chousen_pers'] = $id_pers;
$vals['dunit'] = $dunit;
$vals['screen'] = $screen;


#echo "<td>",used_times_pacs($vals), "</td>";



echo "
<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
";

$x=0;
For($i=0;$i<$c_days;$i++)
{


$vals['date'] = date("Y-m-d", mktime(0, 0, 0, $month, $day+$i, $year));

$date = date("d.m.y", mktime(0, 0, 0, $month, $day+$i, $year));
$dw_eng = date("D", mktime(0, 0, 0, $month, $day+$i, $year));

If($x==0)
{
$first_date = $date;
}

echo "<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td";


echo " style = \"font-weight: bold; background-color: #303030;\">";

If($x == 0)
{
echo "<span id = \"first_date_jur_",$screen,"\">",$date,"</span>";
}
Else{
echo $date;
}

echo "<br>
",$ar_dw_rus[$dw_eng],"
</td>
</tr>
<tr>
<td>",
used_times_pacs($vals),
"
</td>
</tr>
</table>

</td>";



$x++;
}


echo "
</tr>
</table>
";

}

?>
