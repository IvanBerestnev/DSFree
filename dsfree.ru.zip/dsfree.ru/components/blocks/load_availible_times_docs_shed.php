<?php

function load_availible_times_docs_shed($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_selected_pers = $vals['id_selected_pers'];
$param = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$ar_param = explode("#",$param);

$unit = $ar_param[1];

$dt_be = $ar_param[0];
$ar_dt_be = explode("@",$dt_be);
$dt_b = $ar_dt_be[0];
$dt_e = $ar_dt_be[1];

$ar_dt_b = explode(" ",$dt_b);
$d_b = $ar_dt_b[0];
$t_b = $ar_dt_b[1];

$ar_dt_e = explode(" ",$dt_e);
$d_e = $ar_dt_e[0];
$t_e = $ar_dt_e[1];

$ar_t_b = explode(":",$t_b);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];

$ar_t_e = explode(":",$t_e);
$he = $ar_t_e['0'];
$me = $ar_t_e['1'];

$time_b = $hb.":".$mb;
$time_e = $he.":".$me;




$sql = "select * from tab_shedule_pers where date = '".$d_b."' and (time like '%".$time_b."%' or time like '%".$time_e."%') and unit = '$unit' and id_pers = '$id_selected_pers' order by date ASC;";
#echo $sql;


$c_b_min = ($hb*60)+$mb;
$c_e_min = ($he*60)+$me;

$rc_b_min = ($hb*60)+$mb;
$rc_e_min = ($he*60)+$me;



echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">

<select id = \"id_sel_beg_shed_doc_",$screen,"\" style = \"font-size: 25px; font-weight: bold;\">";

For($c_b_min;$c_b_min<$c_e_min;$c_b_min=$c_b_min+5)
{

$t = date("H:i", mktime(0, $c_b_min, 0, 1, 1, 1970));

echo "<option value = \"",$t,"\" style = \"font-size: 25px; font-weight: bold;\">",$t,"</option>";

}



echo "</select>

</td>
<td>

<select id = \"id_sel_end_shed_doc_",$screen,"\" style = \"font-size: 25px; font-weight: bold;\">

";

$i=0;
For($rc_b_min;$rc_b_min<=$rc_e_min;$rc_b_min=$rc_b_min+5)
{

If($i==0)
{
$i++;
continue;
}

$t = date("H:i", mktime(0, $rc_b_min, 0, 1, 1, 1970));

echo "<option";

If($rc_b_min == $rc_e_min)
{
echo " selected"; 
}

echo " style = \"font-size: 25px; font-weight: bold;\" value = \"",$t,"\">",$t,"</option>";

}



echo "

</select>


</td>
</tr>
</table>

";





}


?>
