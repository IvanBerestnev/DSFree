<?php

function load_ids_edit_self($vals)
{

$screen = $vals['screen'];
$type = $vals['type'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$ar_types = array("general"=>"Общий раздел","terap"=>"Терапевтическая стоматология","ortoped"=>"Ортопедическая стоматология","chirurg"=>"Хирургическая стоматология","ortodont"=>"Ортодонтия","detstvo"=>"Детская стоматология");



echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"padding: 10px;\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3336;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td style = \"font-weight: bold;\">
",$ar_types[$type],"
</td>
</tr>
<tr>
<td>

<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">


<table border = \"0\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #3A3A3A; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">

";

If($type == "general")
{

echo "
<tr height = \"75px\">
<td width = \"35%\">
Стандартный ИДС
</td>
<td width = \"5%\">

</td>
<td width = \"30%\">
standart_ids.docx
</td>
<td width = \"5%\">

</td>
<td>

</td>
</tr>
<tr style = \"background-color: #2E3336;\" height = \"50px\">
<td colspan = \"5\">
</td>
</tr>
";

}



$sql = "select * from tab_ids where type = '$type'";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id = $row['id'];
$name_file = $row['name_file'];
$name = $row['name'];

echo "
<tr height = \"75px\">
<td width = \"35%\">
",$name,"
</td>
<td onclick = \"open_modal_ids_edit_self('",$screen,"','page_rename_ids','",$type,"','",$id,"');\" width = \"5%\" style = \"background-color: #F5C211; color: black; cursor: pointer;\">
ред
</td>
<td width = \"30%\">
",$name_file,"
</td>
<td onclick = \"open_modal_ids_edit_self('",$screen,"','page_rename_ids_file','",$type,"','",$id,"');\" width = \"5%\" style = \"background-color: #F5C211; color: black; cursor: pointer;\">
ред
</td>
<td onclick = \"open_modal_ids_edit_self('",$screen,"','page_delete_ids','",$type,"','",$id,"');\" style = \"color: #FF8080; cursor: pointer;\">
удалить
</td>
</tr>
<tr style = \"background-color: #2E3336;\" height = \"50px\">
<td colspan = \"5\">
</td>
</tr>
";

}

}
Else{

If($type !== "general")
{

echo "
<tr>
<td>


В данном разделе нет шаблонов ИДС



</td>
</tr>
";

}



}


echo "

</table>

</div>


</td>
</tr>
<tr onclick = \"open_modal_ids_edit_self('",$screen,"','page_add_ids','",$type,"','');\" height = \"10%\" style = \"background-color: #008080; font-weight: bold; cursor: pointer;\">
<td>
Добавить ИДС
</td>
</tr>
</table>


</td>
</tr>
</table>

";



}


?>
