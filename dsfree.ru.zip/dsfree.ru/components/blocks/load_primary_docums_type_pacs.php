<?php

function load_primary_docums_type_pacs($vals)
{

#print_r($vals);

$type = $vals['type'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



If($type == "last_pacs")
{

$sql = "select distinct id_pacs from pacs_ent order by begin limit 10";

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$ar_ids[] = $row['id_pacs'];
}

$count_ar_ids = count($ar_ids);
$str_ids = implode("','",$ar_ids);

$sql = "select * from tab_pacs where id_pac IN('$str_ids')";
$query = mysqli_query($connection,$sql);

}

}
ElseIf($type == "all_pacs")
{


$sql = "select * from tab_pacs order by surname_pac ASC";
$query = mysqli_query($connection,$sql);


}





If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: left;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_pac = $row['id_pac'];

$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];

echo "<tr class = \"class_choice_pac_primary_docum_",$screen,"\" id = \"id_choice_pac_primary_docum_",$screen,"_",$id_pac,"\" onclick = \"choice_pac_primary_docum('",$id_pac,"','",$screen,"');\" height = \"40\"><td style = \" padding-left: 15px; font-weight: bold; color: white;\">",$surname_pac," ",$name_pac," ",$patronymic_pac,"</td></tr>";
}

echo "</table>";

}











}

?>
