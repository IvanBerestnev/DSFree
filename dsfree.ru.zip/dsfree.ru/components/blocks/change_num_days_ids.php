<?php

function change_num_days_ids($vals)
{

#print_r($vals);

$val = $vals['val'];
$type = $vals['type'];
$screen = $vals['screen'];

$old_val = $vals['old_val'];


$month_now = date('m');
$year_now = date('Y');

If($type == "month")
{
$month_now = $val;


$year_now = $old_val;
}

If($type == "year")
{
$year_now = $val;

$month_now = $old_val;
}



$number_days = cal_days_in_month(CAL_GREGORIAN, $month_now, $year_now);

echo "<select id = \"sel_day_ids_",$screen,"\">";

For($i=1;$i<=$number_days;$i++)
{
$dn = date("d", mktime(0, 0, 0, 1, $i, 1970));
echo "<option value = \"",$dn,"\"";



echo ">",$dn,"</option>";
}

echo "</select>";


}

?>
