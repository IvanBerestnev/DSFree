<?php

function load_jurpacs($vals)
{

#print_r($vals);die();

echo "

<style>

.tooltip {
  position: relative;
  display: inline-block;
  
  width: 100%;
  text-decoration: inherit;
}

.tooltip .tooltiptext {
  visibility: hidden;
  
  background-color: black;
  
  text-align: center;
  border-radius: 6px;
  padding: 5px;
  
  /* Position the tooltip */
  position: absolute;
  z-index: 1;
  
  top: -6px;
  left: 105%;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
}

</style>
";


$screen = $vals['screen'];
$id_used_ssetka = $vals['id_used_ssetka'];

include_once("../components/blocks/load_jurpac_calendar.php");

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_ssetka_default where id_used_ssetka = '$id_used_ssetka' and number_cell = '$screen'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_default_set = $row['default_set'];

$default_set = json_decode($json_default_set,true);

#print_r($default_set);
#echo "<br><br>";

#$c_days = $default_set['c_days'];

$c_days_vals = $vals['c_days'];

If($c_days_vals == "")
{
$vals['c_days'] = $default_set['c_days'];
}

$dunit_vals = $vals['dunit'];

If($dunit_vals == "")
{
$vals['dunit'] = $default_set['dunit'];
}

$id_pers_vals = $vals['id_pers'];

If($id_pers_vals == "")
{
$vals['id_pers'] = $default_set['doc'];
}



#print_r($default_set);
#echo "<br><br>";
#print_r($vals);
#echo "<br><br>";
#die();



}
Else{


$default_set = array("dunit"=>"1","c_days"=>"7","doc"=>"");

#print_r($default_set);
#echo "<br><br>";

#$c_days = $default_set['c_days'];

$c_days_vals = $vals['c_days'];

If($c_days_vals == "")
{
$vals['c_days'] = $default_set['c_days'];
}

$dunit_vals = $vals['dunit'];

If($dunit_vals == "")
{
$vals['dunit'] = $default_set['dunit'];
}

$id_pers_vals = $vals['id_pers'];

If($id_pers_vals == "")
{
$vals['id_pers'] = $default_set['doc'];
}




}



load_jurpac_calendar($vals);


}



?>
