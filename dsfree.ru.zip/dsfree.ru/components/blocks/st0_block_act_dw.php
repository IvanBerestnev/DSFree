<?php

function st0_block_act_dw($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_visit = $vals['id_visit'];

$itog_cena_general_usluga = "0";
$ar_new_general_cost = array();

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

echo "

<style>

.avail_uslugi_page_act_dw_",$screen,":hover{

background-color: #F5C211;
color: black;

}

</style>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td colspan = \"2\" align = \"right\" style = \"background-color: #1D1D1D;\">

<span onclick = \"open_page_add_act_dw('",$id_visit,"','",$screen,"','delete_act_dw');\" style = \"background-color: #FF8080; color: white; cursor: pointer; margin-left: 10px; padding: 5px; float: left\">
удалить акт
</span>

<span onclick = \"open_page_add_act_dw('",$id_visit,"','",$screen,"','erase_act_dw');\" style = \"background-color: #FF8080; color: white; cursor: pointer; margin-right: 10px; padding: 5px;\">
очистить акт
</span>

</td>
</tr>
<tr>

<td width = \"50%\">
<div style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: ;\">";

$sql = "select * from price where id_price = (select id_price from tab_act_dw where id_visit = '$id_visit')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">";

$row = mysqli_fetch_assoc($query);
$txt_price = $row['txt_price'];
$id_price = $row['id_price'];

$ar_txt_price = json_decode($txt_price,true);

Foreach($ar_txt_price as $id_usl=>$ar_usl)
{

$name_usl = $ar_usl['name'];
$cost_usl = $ar_usl['cost'];

//open_page_add_act_dw(param,screen,name_page)

echo "<tr class = \"avail_uslugi_page_act_dw_",$screen,"\" onclick = \"open_page_add_act_dw('",$id_price,"@",$id_usl,"@",$id_visit,"','",$screen,"','add_new_usl');\" style = \"cursor: pointer;\"><td style = \"padding-top: 10px; padding-bottom: 10px; \">",$name_usl,"</td><td width = \"20%\">",$cost_usl," р.</td></tr>
<tr height = \"15px\">
<td>
</td>
</tr>
";

}




echo "</table>";

}

echo "
</div>
</td>

<td>
<div style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2E3336;\">";

$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$itog_cena_general_usluga = "0";

$row = mysqli_fetch_assoc($query);
$works = $row['works'];


If($works !== "")
{

$ar_works = json_decode($works,true);

#print_r($ar_decode_works);die();

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">";

Foreach($ar_works as $id_dw=>$ar_vals)
{
$name = $ar_vals['name'];
$full_cost = $ar_vals['full_cost'];

$ar_full_cost = explode(";",$full_cost);
$count_uslugi = count($ar_full_cost);

Foreach($ar_full_cost as $f_cost)
{

$ar_f_cost = explode("-",$f_cost);
$new_cost = $ar_f_cost[0];
$ar_new_cost[] = $new_cost;
$ar_new_general_cost[] = $new_cost;
}

$itog_cena_usluga = array_sum($ar_new_cost);


echo "
<tr >
<td height = \"120px\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"background-color: #2E3336;\">
</td>
<td onclick = \"open_page_add_act_dw('",$id_visit,"@",$id_dw,"','",$screen,"','page_delete_concrt_usluga_from_actdw');\" height = \"30px\" style = \"cursor: pointer; background-color: #FF8080;\" width = \"20%\">
х
</td>
</tr>
<tr style = \"border-top: 1px solid #2E3436;\">
<td>

",$name,"

</td>
<td onclick = \"open_page_add_act_dw('",$id_visit,"@",$id_dw,"','",$screen,"','page_delete_usluga_from_actdw');\" style = \"cursor: pointer; \">

x",$count_uslugi,"

</td>
</tr>
<tr>
<td height = \"30px\" colspan = \"2\" style = \"border: 1px solid grey; background-color: #8080FF;\">
",

$itog_cena_usluga," р.
</td>
</tr>
</table>

</td>
</tr>

<tr height = \"20px\">
<td>
</td>
</tr>

";

$ar_new_cost = array();
}


echo "</table>";


$itog_cena_general_usluga = array_sum($ar_new_general_cost);

}

#echo $works;




}



echo "</div>


</td>
</tr>
<tr height = \"10%\">
<td colspan = \"2\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #808080;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"50%\">
Общая сумма: ";

include_once("itog_cena_usluga_adw.php");
$itog_cena_usluga_adw = itog_cena_usluga_adw($id_visit);

echo $itog_cena_usluga_adw;

echo " рублей
</td>
<td>
<span onclick = \"open_page_add_act_dw('".$id_visit."','",$screen,"','page_general_discont_act_dw');\" style = \"background-color: #F5C211; color: black; cursor: pointer; padding: 5px;\">
Скидка
</span>
</td>
<td>
<span onclick = \"act_add_new_data_act_dw('",$id_visit,"','",$screen,"','accept_visit','');\" style = \"background-color: #008080;cursor: pointer; padding: 5px;\">Принять</span>

</td>
</tr>
</table>


</td>
</tr>

</table>

";


}

?>
