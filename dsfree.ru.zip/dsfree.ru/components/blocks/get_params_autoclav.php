<?php

function get_params_autoclav($vals)
{

$screen = $vals['screen'];
$type = $vals['type'];
$id_autoclav = $vals['id_autoclav'];
$second_param = $vals['second_param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_misc_sets where id = '3'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$val = $row['val'];
$arr = json_decode($val,true);
}


If($type == "autoclav")
{


If(count($arr) == 1)
{

Foreach($arr as $id_steril=>$ar_vals)
{
$name = $ar_vals['name'];

echo "
<div id = \"f_selected_autoclav_",$screen,"\" style = \"font-weight: bold;\">",$name,"</div>
<div id = \"f_selected_autoclav_id_",$screen,"\" style = \"display: none;\">",$id_steril,"</div>
";

}

$selected_id_steril = $id_steril;

}
Else{

echo "<select id = \"ans_autoclav_",$screen,"\" onchange = \"get_params_autoclav('mode','",$screen,"',this.value,'');\">";

$i=0;

Foreach($arr as $id_steril=>$ar_vals)
{

If($i == 0)
{
$selected_id_steril = $id_steril;
}

$name = $ar_vals['name'];
echo "<option value = \"",$id_steril,"\">",$name,"</option>";

$i++;
}


echo "</select>";


}

echo "
<script>

get_params_autoclav('mode','",$screen,"','",$selected_id_steril,"','');


</script>

";


}
ElseIf($type == "mode")
{

$temp0 = $arr[$id_autoclav]['mode0']['temp'];
$press0 = $arr[$id_autoclav]['mode0']['press'];
$time0 = $arr[$id_autoclav]['mode0']['time'];

$temp1 = $arr[$id_autoclav]['mode1']['temp'];
$press1 = $arr[$id_autoclav]['mode1']['press'];
$time1 = $arr[$id_autoclav]['mode1']['time'];


$ar_mode[$time0] = $temp0."&deg;С + ".$press0." атм";
$ar_mode[$time1] = $temp1."&deg;С + ".$press1." атм";

echo "<select id = \"ans_mode_",$screen,"\" onchange = \"get_params_autoclav('time_end_autoclaving','",$screen,"',this.value,'');\">";

Foreach($ar_mode as $time=>$m)
{

echo "<option value = \"",$time,"\">",$m,"</option>";

}

echo "</select>";


echo "

<script>
get_params_autoclav('time_end_autoclaving','",$screen,"','",$time0,"','');
</script>

";


}
ElseIf($type == "time_end_autoclaving")
{

$time_autoclaving = $id_autoclav;

#echo $time_autoclaving;

$hour_now = date("H");
$min_now = date("i");

$hi_now = ($hour_now)*60+$min_now;


$sql = "select val from presets where presets.set IN ('tc_begin','tc_end')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$val = $row['val'];

$ar_val = explode(":",$val);
$h = $ar_val[0];
$m = $ar_val[1];

$time = ($h*60)+$m;

$ar_times_bd[] = $time;

}

#print_r($ar_times_bd);

$beg = $ar_times_bd[0];
$end = $ar_times_bd[1];



For($beg;$beg<=$end;$beg=$beg+1)
{

#$hr_cicle = date("H:i",mktime(0, $beg, 0, 1, 1, 1970));
$ar_all_wt_clinic[] = $beg;


#echo "<option>",$hr_cicle,"</option>";
}


#echo $hi_now;

#$rand_time = array_rand($ar_all_wt_clinic, 1);
#echo $rand_time;


If(in_array($hi_now,$ar_all_wt_clinic))
{
$compared_time = $hi_now;
$end_autoclaving = $time_autoclaving + $compared_time;

$end_autoclaving_hm = date("H:i",mktime(0, $end_autoclaving, 0, 1, 1, 1970));

}
Else{
#$rand_time = array_rand($ar_all_wt_clinic, 1);

$k = array_rand($ar_all_wt_clinic);
$rand_time = $ar_all_wt_clinic[$k];

$compared_time = $rand_time;
$end_autoclaving = $time_autoclaving + $compared_time;

$end_autoclaving_hm = date("H:i",mktime(0, $end_autoclaving, 0, 1, 1, 1970));

}

echo "<select id = \"ans_time_b_",$screen,"\" onchange = \"get_params_autoclav('recalc_time_autoclaving','",$screen,"','",$time_autoclaving,"',this.value);\">";

Foreach($ar_all_wt_clinic as $wt)
{

$wt_hm = date("H:i",mktime(0, $wt, 0, 1, 1, 1970));

echo "<option value = \"",$wt,"\"";


If($wt == $compared_time)
{
echo " selected";
}


echo ">",$wt_hm,"</option>";

}





echo "</select> - <span id = \"f_recalc_time_autoclaving_",$screen,"\">",$end_autoclaving_hm,"</span>";

}



}
ElseIf($type == "recalc_time_autoclaving")
{

$min_b = $second_param;
$min_period = $id_autoclav;

#echo $min_b, " -- ",$min_period;

$summ = $min_b+$min_period;
$summ_hm = date("H:i",mktime(0, $summ, 0, 1, 1, 1970));

echo $summ_hm;


}




}

?>
