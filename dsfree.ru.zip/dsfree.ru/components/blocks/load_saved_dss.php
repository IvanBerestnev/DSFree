<?php

function load_saved_dss($vals)
{

#print_r($vals);
$screen = $vals['screen'];
$id_pac = $vals['id_pac'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "
<style>
.but_td_sp_dss_",$screen,":hover{

background-color: #8080FF;

}
</style>

<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_ds = $row['id_ds'];

echo "
<tr >
<td height = \"30px\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
</td>
<td onclick = \"print_template_ds('",$screen,"','",$id_ds,"');\" width = \"10%\" style = \"cursor: pointer; background-color: #1A5FB4;\">
печать
</td>
<td onclick = \"open_add_new_ds('",$screen,"','inner','",$id_ds,"');\" width = \"10%\" style = \"cursor: pointer; background-color: #008080;\">
ред
</td>
<td onclick = \"page_delete_ds('",$screen,"','",$id_ds,"');\" width = \"10%\" style = \"cursor: pointer; background-color: #FF8080;\">
х
</td>
</tr>
</table>

</td>
</tr>
<tr height = \"30px\">
<td class = \"but_td_sp_dss_",$screen,"\" align = \"left\" style = \"cursor: pointer;\" onclick = \"edit_first_docum('edit_medcart_step2','",$id_ds,"@",$id_pac,"','",$screen,"');\">",$row['name_ds'],"
</td>
</tr>
<tr height = \"20px\">
<td>
</td>
</tr>
";

}

echo "</table>";

}
Else{

echo "<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Нет зарегистрированных диагнозов
</td>
</tr>
</table>
";

}


}

?>
