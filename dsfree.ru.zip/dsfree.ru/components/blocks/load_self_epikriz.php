<?php

function load_self_epikriz($vals)
{

#print_r($vals);

$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">";


while($row = mysqli_fetch_assoc($query))
{

$id_visit = $row['id_visit'];
$id_dogovor = $row['id_dogovor'];
$date_time = $row['date_time'];

$ds = $row['ds'];
$fio_doc = $row['fio_doc'];

echo "
<tr style = \"background-color: #2E3336; border: 1px solid black; \" >
<td height = \"100px\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
",$date_time,"
</td>
<td width = \"50%\">
Договор №",$id_dogovor,"
</td>

<td onclick = \"print_primary_docums('epikriz','",$id_visit,"','",$screen,"');\" width = \"10%\" rowspan = \"2\" style = \"background-color: #008080; cursor: pointer;\">
Печать
</td>


</tr>
<tr>
<td>
DS: ",$ds,"
</td>
<td>
др. ",$fio_doc,"
</td>
</tr>
</table>

</td>
</tr>

<tr>
<td height = \"20px\">
</td>
</tr>

";

}



echo "</table>";
}









}

?>
