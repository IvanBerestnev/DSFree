<?php

function ctrl_jurpacs_spdocs_review($vals)
{

$screen = $vals['screen'];
$act = $vals['act'];
$id_pers = $vals['id_pers'];
$id_used_ssetka = $vals['id_used_ssetka'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

If($act == "close")
{

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_personal";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

//Получить сохраненного перса
$sql_dp = "select * from tab_ssetka_default where id_used_ssetka = '$id_used_ssetka' and number_cell = '$screen'";
$query_dp = mysqli_query($connection,$sql_dp);

If(mysqli_num_rows($query_dp) !== 0)
{
$row = mysqli_fetch_assoc($query_dp);
$json_default_set = $row['default_set'];
$default_set = json_decode($json_default_set,true);
$def_doc = $default_set['doc'];

}


echo "
<table border = \"0\" width = \"99%\" height = \"45px\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"25px\" onclick = \"ctrl_jurpacs_spdocs_review('",$id_used_ssetka,"','",$def_doc,"','",$screen,"','tochoice');\" >
<td colspan = \"2\">вернуться назад</td>
</tr>

";

while($row = mysqli_fetch_assoc($query))
{
$id_pers = $row['id_pers'];
$surname = $row['surname_pers'];
$color = $row['bg_color_gen'];

echo "
<tr height = \"25px\" onclick = \"ctrl_jurpacs_spdocs_review('",$id_used_ssetka,"','",$id_pers,"','",$screen,"','tochoice');\" >
<td>",$surname,"

</td>
<td style = \"background-color: ",$color,";\"
</td>
</tr>
";

}

echo "</table>";

echo "
<span style = \"display: none;\" id = \"f_ctrl_id_pers_",$screen,"\"></span>
</td>
</table>




";


}

}
ElseIf($act == "tochoice")
{

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$surname = $row['surname_pers'];
$id_pers = $row['id_pers'];

echo "
<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"position: relative;\">

<span onclick = \"ctrl_jurpacs_spdocs_review('",$id_used_ssetka,"','all','",$screen,"','close');\" style = \"position: absolute; top: 0px; right: 0px; padding: 5px 15px; background-color: red;\">X</span>
";

//load_jurpacs('",$screen,"');
//load_ctrl_jurpacs('doc','",$screen,"');

echo $surname;

echo "
<span style = \"display: none;\" id = \"f_ctrl_id_pers_",$screen,"\">",$id_pers,"</span>
</td>
</table>
";

}

}

}

?>
