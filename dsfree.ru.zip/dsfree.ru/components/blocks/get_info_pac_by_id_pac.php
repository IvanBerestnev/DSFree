<?php

function get_info_pac_by_id_pac($id_pac)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_pacs where id_pac = '$id_pac'";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$ar = mysqli_fetch_assoc($query);

}

return $ar;

}

?>
