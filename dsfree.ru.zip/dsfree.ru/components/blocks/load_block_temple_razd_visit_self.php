<?php

function load_block_temple_razd_visit_self($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_ds = $vals['id_ds'];
$id_struct = $vals['id_struct'];
$id_razd = $vals['id_razd'];
$id_writed_razd = $vals['id_writed_razd'];


If($id_ds !== "")
{

If($id_struct !== "")
{

If($id_razd !== "")
{

#echo "выбран диагноз, структурный шаблон и раздел. выбор собственно шаблона";
include_once("block_temple_medcart_visit_choice_selftemple.php");
block_temple_medcart_visit_choice_selftemple($vals);

}
Else{

#echo "выбран диагноз, структурный шаблон. выбор раздела";
include_once("block_temple_medcart_visit_choice_razd.php");
block_temple_medcart_visit_choice_razd($vals);

}

}
Else{

#echo "выбран диагноз. выбор структурного шаблона";
include_once("block_temple_medcart_visit_choice_struct.php");
block_temple_medcart_visit_choice_struct($vals);


}

}
Else{

#echo "выбор диагноза";

include_once("block_temple_medcart_visit_choice_ds.php");
block_temple_medcart_visit_choice_ds($vals);

}


}


?>
