<?php

function used_times_correct_shed_doc($vals)
{

#$vals['date'] = "2022-04-14";
	
#print_r($vals);echo "<br><br>";
#die();

$date = $vals['date'];
$unit = $vals['dunit'];
$chousen_schema = $vals['chousen_schema'];
$id_select_id_doc = $vals['chousen_pers'];
$screen = $vals['screen'];



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



$r=0;

//Загрузка цветовой схемы

/*

$sql_color = $chousen_schema."_editd_schema_color";

$sql = "select * from presets_mobile where name = '$sql_color'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

#die();

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$val = $row['val'];
$ar_val = explode(";",$val);

Foreach($ar_val as $params)
{

$ar_params = explode("@",$params);
$k_old=$ar_params[0];
$ar_k_old = explode("-",$k_old);
$k = $ar_k_old[0];
$v=$ar_params[1];
$ar_schema_color[$k] = $v;

}
}


*/

//Получаем массив времени работы клиники в интервалом 5 мин


$sql = "select * from presets where presets.set='tc_begin' union select * from presets where presets.set='tc_end';";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
while ($row = mysqli_fetch_assoc($query))
{
$ar_bd[] = $row['val'];
}
}


$tc_clinic_begin = $ar_bd[0];
$ar_tc_clinic_begin = explode(":",$tc_clinic_begin);
$tc_clinic_begin_hour = $ar_tc_clinic_begin[0];
$tc_clinic_begin_min = $ar_tc_clinic_begin[1];

$tc_clinic_begin_min_final = $tc_clinic_begin_hour*60 + $tc_clinic_begin_min;

$tc_clinic_end = $ar_bd[1];
$ar_tc_clinic_end = explode(":",$tc_clinic_end);
$tc_clinic_end_hour = $ar_tc_clinic_end[0];
$tc_clinic_end_min = $ar_tc_clinic_end[1];

$tc_clinic_end_min_final = $tc_clinic_end_hour*60 + $tc_clinic_end_min;

#echo "<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; background-color: C4C4C4; vertical-align: top;\" cellpadding=\"0\" cellspacing= \"0\">";

For($tc_clinic_begin_min_final;$tc_clinic_begin_min_final<=$tc_clinic_end_min_final;$tc_clinic_begin_min_final=$tc_clinic_begin_min_final+5)
{
$ar_work_time_clinic[] = $tc_clinic_begin_min_final;
$ar_wtime_clinic[] = $tc_clinic_begin_min_final;
}


#print_r($ar_work_time_clinic);die();


////Время расписания врачей

$sql = "select * from tab_shedule_pers where date = '$date' and unit = '$unit'";
$query = mysqli_query($connection,$sql);

$ar_shed_min = array();

If(mysqli_num_rows ($query) !== 0)
{
$x=0;
while ($row = mysqli_fetch_assoc($query))
{
#$ar_used_doc_time[] = $row['time'];

$times = $row['time'];
$id_pers = $row['id_pers'];
$id_shedule = $row['id_shedule'];

$ar_times = explode("-",$times);
$bt = $ar_times[0];
$et = $ar_times[1];

$ar_bt = explode(":",$bt);
$bt_hour = $ar_bt[0];
$bt_min = $ar_bt[1];

$bt_min_full = $bt_hour*60+$bt_min;

$ar_et = explode(":",$et);
$et_hour = $ar_et[0];
$et_min = $ar_et[1];

$et_min_full = $et_hour*60+$et_min;

For($bt_min_full;$bt_min_full<=$et_min_full;$bt_min_full=$bt_min_full+5)
{
$t = date("H:i", mktime(0, $bt_min_full, 0, 1, 1, 1970));

#$ar_shed_min[$id_pers][$x][] = $t;



$ar_shed_min[$id_pers][$id_shedule][] = $bt_min_full;



#$ar_work_time_clinic[]

$ar_only_shed[] = $bt_min_full;

#$ar_shed_min[$id_pers]['id_shedule'] = $id_shedule;

}



$x++;
}
}

#print_r($ar_shed_min);die();
#print_r($ar_only_shed);die();

///Преобразовать массив 

$f=0;

Foreach($ar_shed_min as $id_doc=>$arr_sm)
{
Foreach($arr_sm as $id_shedule=>$ar_sm)
{


$shed_b = $ar_sm[0];
$shed_e = end($ar_sm);

$ar_shed_be[] = $shed_b;
$ar_shed_be[] = $shed_e;

$ar_docs_min[$f]['times'] = $ar_sm;
$ar_docs_min[$f]['id_doc'] = $id_doc;
$ar_docs_min[$f]['id_shedule'] = $id_shedule;
$f++;
}


}

#print_r($ar_docs_min);die();


//Получаем массив занятого времени пациентами на текущую дату

$date_first = $date." "."00:00:00";
$date_second = $date." "."23:59:59";

$sql = "select * from pacs_ent where unit = '$unit' and begin BETWEEN STR_TO_DATE('$date_first', '%Y-%m-%d %H:%i:%s') AND STR_TO_DATE('$date_second', '%Y-%m-%d %H:%i:%s')";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$i=0;

while ($row = mysqli_fetch_assoc($query))
{

$s=0;

$id_ent = $row['id_ent'];
$id_pac = $row['id_pacs'];
$begin = $row['begin'];
$end = $row['end'];
$id_doc = $row['doc'];

$ar_begin = explode(" ",$begin);
$ar_only_time_begin = $ar_begin[1];

$ar_pt_begin = explode(":",$ar_only_time_begin);
$h_pt_begin = $ar_pt_begin[0];
$m_pt_begin = $ar_pt_begin[1];
$min_pt_begin = (int)$h_pt_begin*60+(int)$m_pt_begin;

$ar_end = explode(" ",$end);
$ar_only_time_end = $ar_end[1];

$ar_pt_end = explode(":",$ar_only_time_end);
$h_pt_end = $ar_pt_end[0];
$m_pt_end = $ar_pt_end[1];
$min_pt_end = (int)$h_pt_end*60+(int)$m_pt_end;

$mptb = $min_pt_begin;
$mpte = $min_pt_end;

For($min_pt_begin;$min_pt_begin<=$min_pt_end;$min_pt_begin=$min_pt_begin+5)
{

$t = date("H:i", mktime(0, $min_pt_begin, 0, 1, 1, 1970));
$ar_timest[] = $min_pt_begin;

$ar_only_pactime[] = $min_pt_begin;
$s++;
}


For($mptb;$mptb<$mpte;$mptb=$mptb+5)
{

$ar_only_pactimeq[] = $min_pt_begin;

}


///


$ar_busy_time_pacs[$i]['times'] = $ar_timest;
$ar_busy_time_pacs[$i]['id_ent'] = $id_ent;
$ar_busy_time_pacs[$i]['id_doc'] = $id_doc;
$ar_busy_time_pacs[$i]['id_pac'] = $id_pac;

$ar_only_beg_tp[] = $ar_timest[0];
$ar_only_end_tp[] = end($ar_timest);

$ar_only_id_pac[] = $row['id_pacs'];

$ar_timest = array();

$ar_begin = "";
$ar_end = "";

$ar_pt_end = "";
$ar_pt_end = "";

$min_pt_begin_t = "";
$min_pt_begin_test = "";

$i++;
}

#print_r($ar_busy_time_pacs);die();
#print_r($ar_only_pactime);die();

asort($ar_only_pactime);
#print_r($ar_only_pactime);die();

Foreach($ar_only_pactime as $w)
{
$t = date("H:i", mktime(0, $w, 0, 1, 1, 1970));
$ar_only_pactime_hm[] = $w;
}

#print_r($ar_only_pactime_hm);die();

$ar_ids = array_unique($ar_only_id_pac);
$str_ids = implode("','",$ar_ids);

$sql = "select * from tab_pacs where id_pac IN('$str_ids')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
while ($row = mysqli_fetch_assoc($query))
{
$id_pac = $row['id_pac'];
$ar_id_sur[$id_pac] = $row['surname_pac'];
}
}

//здесь only_id_pacs

$ar_only_id_pac_uniq = array_unique($ar_only_id_pac);
#print_r($ar_only_id_pac_uniq); echo "<br><br>";
$str_only_id_pac_uniq = implode("','",$ar_only_id_pac_uniq);
#echo $str_only_id_pac_uniq;

//Получение информации о пациенте
$sql = "select * from tab_pacs where id_pac IN ('$str_only_id_pac_uniq')";
#echo $sql;
$query = mysqli_query($connection,$sql);
If(mysqli_num_rows ($query) !== 0)
{
while ($row = mysqli_fetch_assoc($query))
{
$id_pac = $row['id_pac'];
$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];

$ar_gen_pacs[$id_pac]['surname_pac'] = $surname_pac;
$ar_gen_pacs[$id_pac]['name_pac'] = $name_pac;
}

}


}

#print_r($ar_busy_time_pacs);die();
#print_r($ar_work_time_clinic);die();

//Получаем общий итоговый массив

If(isset($ar_busy_time_pacs))
{

///1s

Foreach($ar_work_time_clinic as $time)
{
$i=0;
Foreach($ar_busy_time_pacs as $ar_vaaals)
{

$ar_times_pacctime = $ar_vaaals['times'];
$id_ent = $ar_vaaals['id_ent'];
$id_doc = $ar_vaaals['id_doc'];
$id_pac = $ar_vaaals['id_pac'];

//Проверка есть ли время в ar_busy_time_pacs

If(is_array($ar_times_pacctime))
{

If(in_array($time,$ar_times_pacctime))
{

$b_times_pactime = $ar_times_pacctime[0];

$t = date("H:i", mktime(0, $time, 0, 1, 1, 1970));

$ar_result_pac[$b_times_pactime]['type'] = "pacs_time";
$ar_result_pac[$b_times_pactime]['times'][] = $time;
$ar_result_pac[$b_times_pactime]['id_ent'] = $id_ent;
$ar_result_pac[$b_times_pactime]['id_pac'] = $id_pac;
//1 поправка
$ar_result_pac[$b_times_pactime]['id_doc'] = $id_doc;

$ar_only_pactime[] = $t;
$i++;
}



}
Else{

}

}

}

#echo "ar_result_pac<br><br>";print_r($ar_result_pac);die();

$b=0;
Foreach($ar_result_pac as $ar_rr_pac)
{

$ar_pttimes = $ar_rr_pac['times'];

If(count($ar_pttimes)==2)
{
$f_pptime = $ar_pttimes[0];
$ar_spec_pptimes[] = $f_pptime;

$ar_spec_short_time[] = $f_pptime;

#$e_pptime = $ar_pttimes[1];
#$ar_spec_pptimes[] = $e_pptime;

}
Else{

$wo_f_ar = array_shift($ar_pttimes);
$need_ar = array_pop($ar_pttimes);

Foreach($ar_pttimes as $ttime)
{
$ar_spec_pptimes[] = $ttime;
}



}

$ar_pttimes = array();
$b++;

}

}





$r=0;
$q=0;
$w=0;

#print_r($ar_docs_min);die();
#print_r($ar_spec_pptimes);die();
 

If(isset($ar_docs_min))
{

//2s

Foreach($ar_docs_min as $n=>$ars_d)
{

$a_tms_shed = array_values($ars_d['times']);
$id_doc = $ars_d['id_doc'];
$id_shedule = $ars_d['id_shedule'];

If(isset($ar_spec_pptimes))
{
$result = array_diff($a_tms_shed, $ar_spec_pptimes);
$result_ar = array_values($result);
}
Else{

$result_ar = array_values($a_tms_shed);

}




#$ar_spec_short_time

$ar_r[$n]['times'] = $result_ar;
$ar_r[$n]['id_doc'] = $id_doc;
$ar_r[$n]['id_shedule'] = $id_shedule;

}


#echo "ar_r<br><br>";print_r($ar_r);die();



$f=0;
Foreach($ar_r as $c=>$ar_arr)
{

$t_arr = $ar_arr['times'];
$id_doc = $ar_arr['id_doc'];
$id_shedule = $ar_arr['id_shedule'];

Foreach($t_arr as $m=>$time_t)
{

$nm = $m+1;

If(isset($t_arr[$nm]))
{

$time_t_next = $t_arr[$nm];

If($time_t_next-$time_t==5)
{
#$t = date("H:i", mktime(0, $time_t, 0, 1, 1, 1970));
$ar_go[$f]['times'][] = $time_t;
$ar_go[$f]['id_doc'] = $id_doc;

$ar_go[$f]['id_shedule'] = $id_shedule;

#$f++;

//коррекция
$ar_go[$f]['times'][] = $time_t_next;

}
Else{

If($time_t_next-$time_t>5)
{

$f++;

#$t = date("H:i", mktime(0, $time_t_next, 0, 1, 1, 1970));

#$ar_go[$f]['times'][] = $time_t_next;
#$ar_go[$f]['id_doc'] = $id_doc;

#$ar_go[$f]['times'][] = $time_t;
#$ar_go[$f]['times'][] = $time_t_next;
#$ar_go[$f]['id_doc'] = $id_doc;
#$ar_go[$f]['id_shedule'] = $id_shedule;


#$f++;

}


}



}
Else{
#$t = date("H:i", mktime(0, $time_t, 0, 1, 1, 1970));
#$ar_go[$f]['times'][] = $time_t;
#$ar_go[$f]['times'][] = $t;
#$ar_go[$f]['id_doc'] = $id_doc;
$f++;
}


}


}

#print_r($ar_go);die();

If(!isset($ar_go))
{
goto a;
}

Foreach($ar_go as $na=>$ar_go_share)
{

$id_shedule = $ar_go_share['id_shedule'];
$id_doc = $ar_go_share['id_doc'];
$go_times = $ar_go_share['times'];


Foreach($go_times as $g_time)
{

$pre_g_time = $g_time+5;

If(isset($ar_spec_short_time))
{

If(in_array($pre_g_time,$ar_spec_short_time))
{
#$next_g_time = $pre_g_time+10;
array_push($go_times,$pre_g_time);
$ar_go_result[$na]['times'] = $go_times;
$ar_go_result[$na]['id_doc'] = $id_doc;
$ar_go_result[$na]['id_shedule'] = $id_shedule;
}
Else{
$ar_go_result[$na]['times'] = $go_times;
$ar_go_result[$na]['id_doc'] = $id_doc;
$ar_go_result[$na]['id_shedule'] = $id_shedule;
}

}
Else{

//Новый код

$ar_go_result[$na]['times'] = $go_times;
$ar_go_result[$na]['id_doc'] = $id_doc;
$ar_go_result[$na]['id_shedule'] = $id_shedule;


}



}

}

#print_r($ar_go_result);die();

If(isset($ar_go_result))
{

Foreach($ar_go_result as $ar_gr)
{

$gr_times = $ar_gr['times'];
$f_gr_time = $gr_times[0];
$id_doc = $ar_gr['id_doc'];
$id_shedule = $ar_gr['id_shedule'];

Foreach($gr_times as $gr_time)
{
#$t = date("H:i", mktime(0, $gr_time, 0, 1, 1, 1970));
$ar_result_pac[$f_gr_time]['times'][] = $gr_time;
}

$ar_result_pac[$f_gr_time]['id_doc'] = $id_doc;
$ar_result_pac[$f_gr_time]['id_shedule'] = $id_shedule;

$ar_result_pac[$f_gr_time]['type'] = "empty_time";
}

ksort($ar_result_pac);

}


#print_r($ar_result_pac);die();

a:

///Получение времени без расписания

#print_r($ar_wtime_clinic);die();
#print_r($ar_only_shed);die();

$o=0;
Foreach($ar_wtime_clinic as $wtime)
{

If(!in_array($wtime,$ar_only_shed))
{
#$t = date("H:i", mktime(0, $wtime, 0, 1, 1, 1970));
$ar_free_time_pre[$o][] = $wtime;

}
Else{
$o++;

}
}





asort($ar_shed_be);



$ar_shed_be_tmpl = array_values($ar_shed_be);


unset($ar_shed_be);


$ar_shed_be = $ar_shed_be_tmpl;

#print_r($ar_shed_be);die();
#print_r($ar_free_time_pre);die();

#$ar_shed_be_add = array();

$x=0;

Foreach($ar_shed_be as $p=>$sb_t_p)
{

$n = $p+1;

If(isset($ar_shed_be[$n]))
{

$sb_t_n = $ar_shed_be[$n];


If($sb_t_n-$sb_t_p == 5)
{



$ar_shed_be_add[$x][] = $sb_t_p;
$ar_shed_be_add[$x][] = $sb_t_n;

$x++;
}

}


}


#print_r($ar_shed_be_add);die();





#print_r($ar_free_time_pre);die();



If(isset($ar_free_time_pre))
{


////
If(isset($ar_shed_be_add))
{

$ar_ttempftp = array_merge($ar_free_time_pre,$ar_shed_be_add);



unset($ar_free_time_pre);
$ar_free_time_pre = $ar_ttempftp;


#print_r($ar_free_time_pre);die();

}
////

#print_r($ar_free_time_pre);die();

//FreeTimepre
$r=0;
Foreach($ar_free_time_pre as $free_time_pre)
{

If(count($free_time_pre) == 1 or count($free_time_pre) >= 2)
{

Foreach($free_time_pre as $ft_pre)
{

$b_free_time_pre = $ft_pre-5;
$n_free_time_pre = $ft_pre+5;



If(in_array($b_free_time_pre,$ar_shed_be))
{
#$t = date("H:i", mktime(0, $b_free_time_pre, 0, 1, 1, 1970));
$ar_free_time[$r][] = $b_free_time_pre;

}

#$t = date("H:i", mktime(0, $ft_pre, 0, 1, 1, 1970));
$ar_free_time[$r][] = $ft_pre;

If(in_array($n_free_time_pre,$ar_shed_be))
{
#$t = date("H:i", mktime(0, $n_free_time_pre, 0, 1, 1, 1970));
$ar_free_time[$r][] = $n_free_time_pre;
}

}


}
Else{

$f_ftp = $free_time_pre[0];
$s_ftp = $free_time_pre[1];

$ar_free_time[$r][] = $f_ftp;
$ar_free_time[$r][] = $s_ftp;

}



$r++;
}


#print_r($ar_free_time);die();
#print_r($ar_result_pac);die();

Foreach($ar_free_time as $arr_ff_times)
{

$f_ff_times = $arr_ff_times[0];

Foreach($arr_ff_times as $ff_time)
{
$t = date("H:i", mktime(0, $ff_time, 0, 1, 1, 1970));
$a_ff_time[] = $t;
}

$ar_free_time_freetime[$f_ff_times]['type'] = "free_time";
$ar_free_time_freetime[$f_ff_times]['times'] = $a_ff_time;

$a_ff_time = array();
}



}
Else{


If(isset($ar_shed_be_add))
{
///////////!!!


Foreach($ar_shed_be_add as $arr_ff_times)
{

$f_ff_times = $arr_ff_times[0];

Foreach($arr_ff_times as $ff_time)
{
$t = date("H:i", mktime(0, $ff_time, 0, 1, 1, 1970));
$a_ff_time[] = $t;
}

$ar_free_time_freetime[$f_ff_times]['type'] = "free_time";
$ar_free_time_freetime[$f_ff_times]['times'] = $a_ff_time;

$a_ff_time = array();
}


}
Else{

$ar_free_time_freetime = array();

}


#print_r($ar_shed_be_add);die();
#print_r($ar_free_time_freetime);

}



}
Else{

//видимо здесь код
$first_ar_work_time_clinic = $ar_work_time_clinic[0];

Foreach($ar_work_time_clinic as $tworkstclin)
{

$ar_norm_tworkstclin[] = date("H:i", mktime(0, $tworkstclin, 0, 1, 1, 1970));

}

$ar_free_time_freetime[$first_ar_work_time_clinic]['type'] = "free_time";
$ar_free_time_freetime[$first_ar_work_time_clinic]['times'] = $ar_norm_tworkstclin;

}


#print_r($ar_free_time_freetime);die();


#print_r($ar_result_pac);die();



If(isset($ar_result_pac))
{

Foreach($ar_result_pac as $out_inx=>$ar_misc)
{

$type = $ar_misc['type'];

If($type == "empty_time")
{

$id_doc = $ar_misc['id_doc'];
$times_misc = $ar_misc['times'];
$id_shedule = $ar_misc['id_shedule'];

Foreach($times_misc as $time_misc)
{
$t = date("H:i", mktime(0, $time_misc, 0, 1, 1, 1970));
$ar_time_misc[] = $t;
}

$ar_time_misc_uniq = array_unique($ar_time_misc);

$ar_itog_general[$out_inx]['type'] = "empty_time";
$ar_itog_general[$out_inx]['times'] = $ar_time_misc_uniq;
$ar_itog_general[$out_inx]['id_doc'] = $id_doc;
$ar_itog_general[$out_inx]['id_shedule'] = $id_shedule;

$ar_time_misc = array();
$times_misc = array();
}
ElseIf($type == "pacs_time")
{

$id_doc = $ar_misc['id_doc'];
$id_ent = $ar_misc['id_ent'];
$id_pac = $ar_misc['id_pac'];
$times_misc = $ar_misc['times'];

Foreach($times_misc as $time_misc)
{
$t = date("H:i", mktime(0, $time_misc, 0, 1, 1, 1970));
$ar_time_misc_pt[] = $t;
}

$ar_time_misc_pt_uniq = array_unique($ar_time_misc_pt);

$ar_itog_general[$out_inx]['type'] = "pacs_time";
$ar_itog_general[$out_inx]['times'] = $ar_time_misc_pt_uniq;
$ar_itog_general[$out_inx]['id_ent'] = $id_ent;
$ar_itog_general[$out_inx]['id_pac'] = $id_pac;

//2 поправка
$ar_itog_general[$out_inx]['id_doc'] = $id_doc;

$ar_time_misc_pt = array();
$times_misc = array();
}

}


}
Else{

$ar_itog_general = array();

}

#print_r($ar_itog_general);die();
#print_r($ar_free_time_freetime);die();

$ar_exit = $ar_itog_general+$ar_free_time_freetime;





ksort($ar_exit);
#print_r($ar_only_id_pac); echo "<br><br>";



///

#print_r($ar_exit);die(); echo "<br><br>";

//Получение списка врачей
$sql = "select * from tab_personal where type = 'doc'";
$query = mysqli_query($connection,$sql);
//

If(mysqli_num_rows ($query) !== 0)
{

while ($row = mysqli_fetch_assoc($query))
{
$id_pers = $row['id_pers'];
$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];
$color = $row['bg_color_gen'];
$ar_gen_docs[$id_pers]['name_pers'] = $name_pers;
$ar_gen_docs[$id_pers]['surname_pers'] = $surname_pers;
$ar_gen_docs[$id_pers]['patronymic_pers'] = $patronymic_pers;
$ar_gen_docs[$id_pers]['color'] = $color;
}

}

//и пошло

return $ar_exit;

}
?>


