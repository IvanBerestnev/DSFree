<?php

function load_field_ent_pac($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$page = $vals['page'];

$name = $vals['name'];
$surname = $vals['surname'];
$patronymic = $vals['patronymic'];



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

echo "

<script>

function choice_pac_ent_pac(id_pac)
{

var class_choice_pac_ent_pac = 'class_choice_pac_ent_pac_",$screen,"';
var theOddOnes = document.getElementsByClassName(class_choice_pac_ent_pac);

for(var i=0; i<theOddOnes.length; i++)
{

var id_pacs_js = theOddOnes[i].id;

document.getElementById(id_pacs_js).style.backgroundColor = '#2E3436';
document.getElementById(id_pacs_js).style.color = 'white';

}


var id_choice_pac_ent_pac = 'id_choice_pac_ent_pac_",$screen,"_'+id_pac;
document.getElementById(id_choice_pac_ent_pac).style.backgroundColor = 'blue';
document.getElementById(id_choice_pac_ent_pac).style.color = 'white';


var id_selected_id_pac_ent_pac = 'id_selected_id_pac_ent_pac_",$screen,"';
document.getElementById(id_selected_id_pac_ent_pac).innerHTML = id_pac;


var id_but_write_pac_jurpac_active = 'id_but_write_pac_jurpac_active_",$screen,"';
document.getElementById(id_but_write_pac_jurpac_active).style.display = 'block';

var id_but_write_pac_jurpac_active = 'id_but_write_pac_jurpac_inactive_",$screen,"';
document.getElementById(id_but_write_pac_jurpac_active).style.display = 'none';


}

</script>

";



If($page == "last_pacs")
{

$sql = "select distinct id_pacs from pacs_ent order by begin limit 10";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$ar_ids[] = $row['id_pacs'];

}

$count_ar_ids = count($ar_ids);
$str_ids = implode("','",$ar_ids);


$sql = "select * from tab_pacs where id_pac IN('$str_ids') order by surname_pac ASC";
$query = mysqli_query($connection,$sql);

}

}
ElseIf($page == "all_pacs")
{

#echo "123";

$sql = "select * from tab_pacs order by surname_pac ASC";
$query = mysqli_query($connection,$sql);

}
ElseIf($page == "search_pac_by_fio")
{

#print_r($vals);
$sql = "select * from tab_pacs where surname_pac like '$surname%' and name_pac like '$name%' and patronymic_pac like '$patronymic%' order by surname_pac ASC";
#echo $sql;
$query = mysqli_query($connection,$sql);

}



echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td colspan = \"2\">
<div style = \"height: 100%; width: 100%; overflow-y: scroll;\">";


If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: left;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_pac = $row['id_pac'];

$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];
$patronymic_pac = $row['patronymic_pac'];

echo "<tr class = \"class_choice_pac_ent_pac_",$screen,"\" id = \"id_choice_pac_ent_pac_",$screen,"_",$id_pac,"\" onclick = \"choice_pac_ent_pac('",$id_pac,"');\" height = \"40\"><td style = \" padding-left: 15px; font-weight: bold; color: white; cursor: pointer;\">",$surname_pac," ",$name_pac," ",$patronymic_pac,"</td></tr>";
}

echo "</table>";

}
Else{

echo "
<table border = \"0\" height = \"100%\" width = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Нет результатов
</td>
</tr>
</table>
";

}

echo "</div>
</td>
</tr>
</table>

";
















}

?>
