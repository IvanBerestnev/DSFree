<?php

function load_block_price($vals)
{

#print_r($vals);
$screen = $vals['screen'];
$id_price = $vals['id_price'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

If($id_price == "")
{

echo "
<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style=\"background-color: #22272B; font-weight: bold;\">
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; border: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"20%\" >
<div style = \"background-color: #008080; cursor: pointer; height: 75%; width: 75%; display: table;\">
<span onclick = \"load_add_page_price('add_new_price','",$screen,"','','');\" style = \"vertical-align: middle; display: table-cell;\">+</span>
</div>
</td>
<td>
</td>
</tr>
</table>

</td>
</tr>
<tr style=\"background-color: #2E3436; font-weight: bold;\">
<td>
<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">";

$sql = "select * from price";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_price = $row['id_price'];
$name_price = $row['name_price'];
$datetime = $row['datetime'];

echo "
<tr height = \"50px\" style = \"background-color: #8A969C; cursor: pointer;\">
<td onclick = \"load_block_price('",$id_price,"','",$screen,"');\">",

$name_price
,"
</td>
<td onclick = \"load_add_page_price('rename_price','",$screen,"','','",$id_price,"');\" width = \"10%\">
&#9998;
</td>
<td onclick = \"load_add_page_price('delete_price','",$screen,"','','",$id_price,"');\" width = \"10%\">
х
</td>
</tr>
<tr height = \"15px\">
<td>
</td>
</tr>
";

}

echo "</table>";

}
Else{

echo "
<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
нет прайсов
</td>
</tr>
</table>
";

}


echo "
</div>
</td>
</tr>
</table>

";

}
Else{

#$json_ar = json_encode($ar_new_medcart_write, JSON_UNESCAPED_UNICODE);

$sql = "select * from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$name_price = $row['name_price'];
}

echo "
<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style=\"background-color: #22272B; font-weight: bold;\">
<td height = \"5%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"20%\" align = \"left\">
<div style = \"height: 75%; width: 75%; display: table;\">
<span onclick = \"load_block_price('','",$screen,"');\" style = \"background-color: #8080FF; cursor: pointer; vertical-align: middle; display: table-cell; text-align: center;\">&#10096;</span>
</div>
</td>
<td style = \"font-weight: bold;\">
",$name_price,"
</td>

</tr>
</table>

</td>
</tr>
<tr>
<td>
<div id = \"f_load_block_price_self_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y:scroll; background-color: #2E3436;\">
</div>
</td>
</tr>
<tr style = \"background-color: #008080;\">
<td onclick = \"load_add_page_price('add_new_usluga','",$screen,"','','",$id_price,"');\" height = \"5%\">+
</td>
</tr>
</table>
<script>load_block_price_self('",$id_price,"','",$screen,"')</script>
";


}




}

?>
