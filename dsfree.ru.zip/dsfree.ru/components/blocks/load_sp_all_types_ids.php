<?php

function load_sp_all_types_ids($vals)
{

#print_r($vals);
$screen = $vals['screen'];

$ar_all_types = array("general"=>"Общий раздел","terap"=>"Терапевтическая стоматология","ortoped"=>"Ортопедическая стоматология","chirurg"=>"Хирургическая стоматология","ortodont"=>"Ортодонтия","detstvo"=>"Детская стоматология");

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_misc_sets where id = 'id_avail_ids_work'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$val = $row['val'];
$ar_avail_types = json_decode($val,true);


}

}
Else{

$ar_avail_types = array("general"=>"1","terap"=>"1","ortoped"=>"1","chirurg"=>"1","ortodont"=>"1","detstvo"=>"1");

}

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"margin-left: 0px; border-collapse: collapse; text-align: center; color: white; text-align: center; background-color: #2E3336; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";


Foreach($ar_all_types as $name=>$rname)
{

$status = $ar_avail_types[$name];

If($status == "1")
{
$color = "orange";
$text = "Д";
}
Else{
$color = "#8080FF";
$text = "Н";
}

echo "

<tr height = \"17%\">
<td style = \"padding: 10px;\">

<div onclick = \"load_ids_edit_self('",$screen,"','",$name,"');\" style = \"height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B; position: relative; cursor: pointer;\">

<span onclick = \"open_modal_ids_edit_self('",$screen,"','page_change_status_ids','','",$name,"');\" style = \"position: absolute; top: 0px; left: 0px; background-color: ",$color,"; padding-left: 15px; padding-right: 15px; cursor: pointer; color: black;\">",$text,"</span>

",$rname,"
</div>




</td>
</tr>


";

}

echo "





</table>





";



}


?>
