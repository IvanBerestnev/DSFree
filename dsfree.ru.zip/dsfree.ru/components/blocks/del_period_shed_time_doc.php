<?php

function del_period_shed_time_doc($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$param = $vals['param'];

$ar_param = explode("#",$param);
$id_shedule = $ar_param[3];

$period_gen = $ar_param[0];
$ar_period_gen = explode("@",$period_gen);
$datetime_choise_beg = $ar_period_gen[0];

$ar_date_choise_beg = explode(" ",$datetime_choise_beg);

$date_choise_beg = $ar_date_choise_beg[0];
$f_time_choise_beg = $ar_date_choise_beg[1];

$ar_f_time_choise_beg = explode(":",$f_time_choise_beg);

$hb = $ar_f_time_choise_beg[0];
$mb = $ar_f_time_choise_beg[1];
$hmb = $hb.":".$mb;

$datetime_choise_end = $ar_period_gen[1];

#echo $datetime_choise_end;

$ar_datetime_choise_end = explode(" ",$datetime_choise_end);

$date_choise_end = $ar_datetime_choise_end[0];
$f_time_choise_end = $ar_datetime_choise_end[1];

$ar_f_time_choise_end = explode(":",$f_time_choise_end);

$he = $ar_f_time_choise_end[0];
$me = $ar_f_time_choise_end[1];
$hme = $he.":".$me;

$chouse_t_period = $hmb."-".$hme;

echo "<span class=\"close\" onclick=\"close_mw('fon_modal_",$screen,"');\">X</span>";

echo "

<script>

function send_new_period_shed_doc()
{

var id_old_chouse_t_period_chng_shed_doc = 'id_old_chouse_t_period_chng_shed_doc_",$screen,"';
var old_chouse_t_period_chng_shed_doc = document.getElementById(id_old_chouse_t_period_chng_shed_doc).innerHTML;

var id_ent_chng_shed_doc = 'id_ent_chng_shed_doc_",$screen,"';
var id_shedule = document.getElementById(id_ent_chng_shed_doc).innerHTML;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('send_new_period_shed_doc') + \"&data[screen]=\" + encodeURIComponent('",$screen,"') + \"&data[old_chouse_t_period]=\" + encodeURIComponent(old_chouse_t_period_chng_shed_doc) + \"&data[id_shedule]=\" + encodeURIComponent(id_shedule) + \"&data[new_period]=\" + encodeURIComponent('delete'));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var modal = 'modal_",$screen,"';

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}


</script>

<table border = \"1\" width = \"101%\" height = \"101%\" style = \"margin-left: 0px; border-collapse: collapse; table-layout: fixed; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #2E3436; color: white;\">
<td colspan = \"2\">
Удалить временной промежуток?

</td>
</tr>

<tr height = \"33%\" style = \"cursor: pointer;\">
<td onclick=\"close_mw('fon_modal_",$screen,"');\" style = \"background-color: #FF8080;\">
нет

</td>

<td onclick = \"send_new_period_shed_doc();\" style = \"background-color: #8AE234;\">
да

</td>

</tr>

</table>

<span style = \"display: none;\" id = \"id_ent_chng_shed_doc_",$screen,"\">",$id_shedule,"</span>
<span style = \"display: none;\" id = \"id_old_chouse_t_period_chng_shed_doc_",$screen,"\">",$chouse_t_period,"</span>


";


}

?>
