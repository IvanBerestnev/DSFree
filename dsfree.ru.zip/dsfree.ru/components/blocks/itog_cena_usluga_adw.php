<?php

function itog_cena_usluga_adw($id_visit)
{

#$id_visit = $vals['id_visit'];

$ar_new_cost = array();
$discont = "0";
$itog_cena_usluga = "";

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$works = $row['works'];
$discont = $row['discont'];


If($works !== "")
{

$ar_works = json_decode($works,true);

Foreach($ar_works as $id_dw=>$ar_vals)
{
$name = $ar_vals['name'];
$full_cost = $ar_vals['full_cost'];

$ar_full_cost = explode(";",$full_cost);
$count_uslugi = count($ar_full_cost);

Foreach($ar_full_cost as $f_cost)
{

$ar_f_cost = explode("-",$f_cost);
$new_cost = $ar_f_cost[0];
$ar_new_cost[] = $new_cost;
$ar_new_general_cost[] = $new_cost;
}



}

$itog_cena_usluga = array_sum($ar_new_cost);
$part = ((int)$discont*(int)$itog_cena_usluga)/100;
$new_cena = $itog_cena_usluga-$part;

echo $new_cena;
}
Else{
echo "0";
}

}
Else{

echo "0";

}



}

?>
