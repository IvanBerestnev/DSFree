<?php

function load_td_field_work_ids($vals)
{

#print_r($vals);


$num_field = $vals['num_field'];




If($num_field == "2")
{

include_once("field_work_ids_num_2.php");
field_work_ids_num_2($vals);

}
ElseIf($num_field == "3")
{


include_once("field_work_ids_num_3.php");
field_work_ids_num_3($vals);

}
ElseIf($num_field == "4")
{


include_once("field_work_ids_num_4.php");
field_work_ids_num_4($vals);

}




}

?>
