<?php

function load_menu_choice_type_setka($vals)
{

include_once("../components/functions/checkexit.php");
$ar_vals = checkexit();

$id_user_now = $ar_vals['id_user'];
$name_user_now= $ar_vals['name_user'];
$level = $ar_vals['level'];

$id_user = $vals['id_user'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_used_ssetka where id_pers = '$id_user'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
<select onchange = \"load_menu_ctlr_type_setka(this.value);\">";

while ($row = mysqli_fetch_assoc($query))
{

$used = $row['used'];
$json_vals = $row['vals'];
$val = json_decode($json_vals,true);

$key = key($val);
$id_used_ssetka = $row['id_used_ssetka'];

echo "<option";

If($used == "1")
{
$id_used_now = $id_used_ssetka;
echo " selected";
}

echo " value = \"",$id_used_ssetka,"\">",$val[$key]['name'],"</option>";

}

echo "</select>
</td>
</tr>
</table>

<script>
load_menu_ctlr_type_setka('",$id_used_now,"');
</script>
";

}
Else{

echo "<script>load_settings('screen_setka_myprofile_add','",$id_user,"');</script>";

}



}

?>
