<?php

function field_work_ids_num_2($vals)
{

$type = $vals['type'];
$screen = $vals['screen'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


echo "<table border = \"0\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">";

If($type == "general")
{

echo "

<tr>
<td height = \"100px\" style = \"padding: 10px;\">

<div onclick = \"load_td_field_work_ids('",$screen,"','3','standart_ids');\" style = \" width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B; cursor: pointer; position: relative;\" >

Стандартный ИДС

<span id = \"under_line_2_standart_ids_",$screen,"\" class = \"under_line_2_",$screen,"\" style = \"position: absolute; width: 100%; height: 5px; bottom: 0px; border: 1px solid #8080FF; background-color: #8080FF; display: none;\"></span>

</div>

</td>
</tr>

";

}


$sql = "select * from tab_ids where type = '$type'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id = $row['id'];
$name_file = $row['name_file'];
$name = $row['name'];

echo "

<tr>
<td height = \"100px\" style = \"padding: 10px;\">

<div onclick = \"load_td_field_work_ids('",$screen,"','3','",$id,"');\" style = \" width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B; cursor: pointer; position: relative;\" >

",$name,"


<span id = \"under_line_2_",$id,"_",$screen,"\" class = \"under_line_2_",$screen,"\" style = \"position: absolute; width: 100%; height: 5px; bottom: 0px; border: 1px solid #8080FF; background-color: #8080FF; display: none;\"></span>

</div>



</td>
</tr>

";

}

}


echo "

</div>

</table>";


}


?>
