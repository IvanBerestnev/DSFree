<?php

function txt_messgs($txt_messg)
{

If($txt_messg == "superuser_created")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_start\');\">X</span><table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 20px;\" cellpadding=\"0\" cellspacing= \"0\"><tr><td style = \"font-weight: bold; color: Lime; padding-left: 20px;\" align = \"left\">Сообщение</td></tr><tr><td style = \"\">Создание суперпользователя завершено.<br>Войдите под именем <span style = \"color: Lime;\">superuser</span> и паролем который ввели ранее.</td></tr></table>";

$ar['txt'] = $txt;
$ar['w'] = "500";
$ar['h'] = "150";

return $ar;

}
ElseIf($txt_messg == "wrong_cookie")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_start\');\">X</span><table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 20px;\" cellpadding=\"0\" cellspacing= \"0\"><tr><td style = \"font-weight: bold; color: #EF2929; padding-left: 20px;\" align = \"left\">Ошибка</td></tr><tr><td style = \"\">Неправильные <span style = \"color: Lime;\">cookie</span>.<br>Выход из программы.</td></tr></table>";

$ar['txt'] = $txt;
$ar['w'] = "400";
$ar['h'] = "150";

return $ar;
}
ElseIf($txt_messg == "wrong_password")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_start\');\">X</span><table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 20px;\" cellpadding=\"0\" cellspacing= \"0\"><tr height = \"25%\"><td style = \"font-weight: bold; color: #EF2929; padding-left: 20px;\" align = \"left\">Ошибка</td></tr><tr><td style = \"\">Неправильное имя или пароль</td></tr></table>";

$ar['txt'] = $txt;
$ar['w'] = "400";
$ar['h'] = "150";

return $ar;
}
ElseIf($txt_messg == "wrong_pass_empty")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_start\');\">X</span><table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 20px;\" cellpadding=\"0\" cellspacing= \"0\"><tr height = \"25%\"><td style = \"font-weight: bold; color: #EF2929; padding-left: 20px;\" align = \"left\">Ошибка</td></tr><tr><td style = \"\">Имя и (или) пароль не должны быть пустыми</td></tr></table>";

$ar['txt'] = $txt;
$ar['w'] = "400";
$ar['h'] = "150";

return $ar;

}
ElseIf($txt_messg == "cookie_timeout")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_start\');\">X</span><table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 20px;\" cellpadding=\"0\" cellspacing= \"0\"><tr height = \"25%\"><td style = \"font-weight: bold; color: orange; padding-left: 20px;\" align = \"left\">Внимание.</td></tr><tr><td style = \"\">Срок службы <span style = \"color: Lime;\">cookie</span> вышел.<br>Повторите авторизацию.</td></tr></table>";

$ar['txt'] = $txt;
$ar['w'] = "400";
$ar['h'] = "150";

return $ar;

}

ElseIf($txt_messg == "user_disable_auth")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_start\');\">X</span><table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 20px;\" cellpadding=\"0\" cellspacing= \"0\"><tr height = \"25%\"><td style = \"font-weight: bold; color: orange; padding-left: 20px;\" align = \"left\">Внимание.</td></tr><tr><td style = \"\">Вашего пользователя отключили. Авторизация невозможна.</td></tr></table>";

$ar['txt'] = $txt;
$ar['w'] = "400";
$ar['h'] = "150";

return $ar;

}


ElseIf($txt_messg == "user_disable")
{

$txt = "<span class=\"close\" onclick=\"close_mw(\'fon_modal_start\');\">X</span><table border = \"0\" width = \"101%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; font-size: 20px;\" cellpadding=\"0\" cellspacing= \"0\"><tr height = \"25%\"><td style = \"font-weight: bold; color: orange; padding-left: 20px;\" align = \"left\">Внимание.</td></tr><tr><td style = \"\">Вашего пользователя отключили. Продолжение работы невозможно.</td></tr></table>";

$ar['txt'] = $txt;
$ar['w'] = "400";
$ar['h'] = "150";

return $ar;

}




#setcookie("dsf_cookie_inf", "", time()-3600, "/", "");
}


?>
