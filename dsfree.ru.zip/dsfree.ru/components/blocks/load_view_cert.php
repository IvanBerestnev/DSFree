<?php

function load_view_cert($vals)
{


#print_r($vals);

$screen = $vals['screen'];
$id_cert = $vals['id_cert'];
$act = $vals['act'];

$ar_months_rus = array("01"=>"январь","02"=>"февраль","03"=>"март","04"=>"апрель","05"=>"май","06"=>"июнь","07"=>"июль","08"=>"август","09"=>"сентябрь","10"=>"октябрь","11"=>"ноябрь","12"=>"декабрь");

$ar_certs_rus = array("специальность","Стоматолог общей практики","Стоматолог-терапевт","Стоматолог-ортопед","Стоматолог-хирург","Стоматолог-ортодонт","Детский стоматолог","Организация здравоохранения");

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_docs_cert where id_cert = '$id_cert'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$name_cert = $row['name_cert'];
$date_cert = $row['date_cert'];

If($name_cert == "")
{
$name_cert = "пусто";
}

}


If($act == "default")
{



echo "

<table border = \"1\" height = \"50px\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; background-color: ; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"50%\">",$name_cert,"
</td>
<td>до ",$date_cert,"
</td>

<td onclick = \"load_view_cert('",$id_cert,"','",$screen,"','edit');\" width = \"10%\" style = \"background-color: green; color: white; font-weight: bold; cursor: pointer;\">
ред
</td>
</tr>
</table>

";







}
ElseIf($act == "edit")
{

#print_r($vals);

echo "

<table border = \"1\" height = \"50px\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td>

<table border = \"0\" height = \"50px\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white; background-color: grey; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">

<td onclick = \"delete_cert_doc('",$id_cert,"','",$screen,"');\" width = \"10%\" style = \"background-color: #ED8984; color: white; font-weight: bold; cursor: pointer;\">
Х
</td>

<td width = \"50%\">

<select onchange = \"update_cert_doc('",$id_cert,"','",$screen,"','name_cert',this.value);\">";


Foreach($ar_certs_rus as $cr)
{
echo "<option";

If($cr == $name_cert)
{
echo " selected";
}

echo ">",$cr,"</option>";

}




echo "
</select>
<br>

";

$ar_date_cert = explode("-",$date_cert);
$year = $ar_date_cert[0];
$month = $ar_date_cert[1];
$day = $ar_date_cert[2];

$m_year = $year-10;
$n_year = $year+10;

$num_dmonths = cal_days_in_month(CAL_GREGORIAN, $month, $year);


echo "

<select style = \"width: 33%;\" onchange = \"update_cert_doc('",$id_cert,"','",$screen,"','year',this.value);\">
";

For($m_year;$m_year<=$n_year;$m_year++)
{
echo "<option";

If($m_year == $year)
{
echo " selected";
}

echo " value = \"",$m_year,"\">",$m_year,"</option>";
}

echo "
</select>

<select style = \"width: 33%;\" onchange = \"update_cert_doc('",$id_cert,"','",$screen,"','month',this.value);\">
";

Foreach($ar_months_rus as $k=>$m)
{

echo "<option";

If($k == $month)
{
echo " selected";

}

echo " value = \"",$k,"\">",$m,"</option>";

}

echo "

</select>

<select onchange = \"update_cert_doc('",$id_cert,"','",$screen,"','day',this.value);\">
";

For($i=1; $i<=$num_dmonths; $i++)
{
echo "<option";

If($i == $day)
{
echo " selected";
}

echo " value = \"",$i,"\">",$i,"</option>";

}

echo "
</select>


</td>
</tr>
</table>

</td>
<td onclick = \"load_view_cert('",$id_cert,"','",$screen,"','default');\" width = \"10%\" style = \"font-weight: bold; color: white; background-color: green; cursor: pointer;\">
назад
</td>
</tr>
</table>

";


}


}

?>
