<?php

function load_add_write_jur_uf_control($vals)
{

#print_r($vals);

$step = $vals['step'];
$screen = $vals['screen'];


If($step == "step1")
{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


echo "

<script>

function enable_but_ok_add_write_jur_uf_control(screen)
{

var act_but_ok_add_write_jur_uf_control = 'act_but_ok_add_write_jur_uf_control_' + screen;
var inact_but_ok_add_write_jur_uf_control = 'inact_but_ok_add_write_jur_uf_control_' + screen;

document.getElementById(act_but_ok_add_write_jur_uf_control).style.display = 'flex';
document.getElementById(inact_but_ok_add_write_jur_uf_control).style.display = 'none';


}

</script>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td height = \"15%\">

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"33%\">
уф-облучатель
</td>
<td>

<select id = \"sel_uf_id_device_",$screen,"\" onchange = \"enable_but_ok_add_write_jur_uf_control('",$screen,"');\" style = \"width: 80%;\">
<option selected disabled>выберете</option>";

$sql = "select * from tab_misc_sets where id = '5'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['val'];
$arr = json_decode($json_arr,true);

Foreach($arr as $id_room=>$ar_valls)
{

$name_room = $ar_valls['char']['name'];

$ar_ufs = $ar_valls['ufs'];

Foreach($ar_ufs as $id_ufs=>$ar_val)
{
$place = $ar_val['place'];
$ar_all_ufs[$id_ufs] = $name_room."-".$place;

}


}

}

Foreach($ar_all_ufs as $id_uf=>$namef_uf)
{
echo "<option value = \"",$id_uf,"\">",$namef_uf,"</option>";
}

//<option value = \"111\">лампа 1</option>
//<option value = \"222\">В отсутствии людей</option>

echo "
</select>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td height = \"50%\" align = \"center\">

<table border = \"1\" width = \"95%\" height = \"90%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td>

условия обеззараживания

</td>
</tr>
<tr>
<td>

<select id = \"sel_usl_dezinf_",$screen,"\" style = \"width: 80%;\">
<option>В присутствии людей</option>
<option>В отсутствии людей</option>
</select>

</td>
</tr>
</table>

</td>
<td align = \"center\">

<table border = \"1\" width = \"95%\" height = \"90%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td>

объект обеззараживания

</td>
</tr>
<tr>
<td>

<select id = \"sel_obj_dezinf_",$screen,"\" style = \"width: 80%;\">
<option>воздух</option>
<option>поверхность</option>
</select>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td align = \"center\">

<table border = \"1\" width = \"95%\" height = \"90%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td>

вид микроорганизма

</td>
</tr>
<tr>
<td >

<select id = \"sel_vid_microb_",$screen,"\" style = \"width: 80%;\">
<option>санитарно-показательный</option>
<option>иной</option>
</select>

</td>
</tr>
</table>

</td>
<td align = \"center\">

<table border = \"1\" width = \"95%\" height = \"90%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td>

режим облучения

</td>
</tr>
<tr>
<td>

<select id = \"sel_exposure_mode_",$screen,"\" style = \"width: 80%;\">
<option>непрерывный</option>
<option>повторно-кратковременный</option>
</select>

</td>
</tr>
</table>



</td>
</tr>
</table>


</td>
</tr>
<tr height = \"15%\">
<td align = \"center\">

<div onclick = \"load_add_write_jur_uf_control('",$screen,"','step2');\" id = \"act_but_ok_add_write_jur_uf_control_",$screen,"\" style = \"display: none; align-items: center; justify-content: center; background-color: #008080; color: white; width: 100%; height: 100%;\">
далее
</div>

<div id = \"inact_but_ok_add_write_jur_uf_control_",$screen,"\" style = \"display: flex; align-items: center; justify-content: center;\">
далее
</div>


</td>
</tr>
</table>

";

}
ElseIf($step == "step2")
{

#echo "123";

#print_r($vals);

$screen = $vals['screen'];
$id_uf_device = $vals['id_uf_device'];
$usl_dezinf = $vals['usl_dezinf'];
$obj_dezinf = $vals['obj_dezinf'];
$vid_microb = $vals['vid_microb'];
$exposure_mode = $vals['exposure_mode'];

echo "

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td >

<table border = \"1\" width = \"100%\" height = \"30%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
время записи
</td>
</tr>
<tr>
<td>

<select id = \"sel_tbeg_jur_uf_control_",$screen,"\">";

$tb = 600+30;

For($i=600; $i<=1200; $i=$i+5)
{

$t = date("H:i",mktime(0,$i,0,1,1,1970));


echo "<option value = \"",$t,"\"";

If($i == $tb)
{
echo " selected";
}

echo ">",$t,"</option>";

}

echo "</select>

</td>
<td>

<select id = \"sel_tend_jur_uf_control_",$screen,"\">";

$te = 1200-30;

For($i=600; $i<=1200; $i=$i+5)
{

$t = date("H:i",mktime(0,$i,0,1,1,1970));

echo "<option value = \"",$t,"\"";

If($i == $te)
{
echo " selected";
}

echo ">",$t,"</option>";

}

echo "</select>

</td>
</tr>
</table>

</td>
</tr>
<tr height = \"15%\" style = \"cursor: pointer;\">

<td onclick = \"load_add_write_jur_uf_control('",$screen,"','step3');\" style = \"background-color: #008080; color: white; width: 100%;\">
далее
</td>
</tr>
</table>

<span id = \"f_id_uf_device_",$screen,"\" style = \"display: none;\">",$id_uf_device,"</span>
<span id = \"f_usl_dezinf_",$screen,"\" style = \"display: none;\">",$usl_dezinf,"</span>
<span id = \"f_obj_dezinf_",$screen,"\" style = \"display: none;\">",$obj_dezinf,"</span>
<span id = \"f_vid_microb_",$screen,"\" style = \"display: none;\">",$vid_microb,"</span>
<span id = \"f_exposure_mode_",$screen,"\" style = \"display: none;\">",$exposure_mode,"</span>



";


}
ElseIf($step == "step3")
{

#echo "321123";

#print_r($vals);
$screen = $vals['screen'];
$id_uf_device = $vals['id_uf_device'];
$usl_dezinf = $vals['usl_dezinf'];
$obj_dezinf = $vals['obj_dezinf'];
$vid_microb = $vals['vid_microb'];
$exposure_mode = $vals['exposure_mode'];
$tbeg_jur_uf_control = $vals['tbeg_jur_uf_control'];
$tend_jur_uf_control = $vals['tend_jur_uf_control'];



echo "

<script>

function load_calendar_jur_uf_control(screen,month,year)
{

if(year == '')
{
var sel_year_jur_uf_control = 'sel_year_jur_uf_control_' + screen;
var e = document.getElementById(sel_year_jur_uf_control);
var value = e.value;
var year = e.options[e.selectedIndex].value;
}

if(month == '')
{
var sel_month_jur_uf_control = 'sel_month_jur_uf_control_' + screen;
var e = document.getElementById(sel_month_jur_uf_control);
var value = e.value;
var month = e.options[e.selectedIndex].value;
}


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_calendar_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[month]=\" + encodeURIComponent(month) + \"&data[year]=\" + encodeURIComponent(year));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_jur_uf_control_step3 = 'f_jur_uf_control_step3_' + screen;

var cont = document.getElementById(f_jur_uf_control_step3);
cont.innerHTML = xmlhttp.responseText;

//alert(xmlhttp.responseText);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

</script>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"15%\">
<td>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; font-weight: bold; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<select onchange = \"load_calendar_jur_uf_control('",$screen,"',this.value,'');\" id = \"sel_month_jur_uf_control_",$screen,"\">";

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

$month_now = date("m");

Foreach($ar_months_rus as $km=>$nm)
{

echo "<option";

If($km == $month_now)
{
echo " selected";
}

echo " value = \"",$km,"\">",$nm,"</option>";

}

echo "
</select>

</td>
<td>
<select id = \"sel_year_jur_uf_control_",$screen,"\">";

$year_now = date("Y");
$year_past = $year_now-5;
$year_last = $year_now+5;

For($year_past;$year_past<=$year_last;$year_past++)
{
echo "<option";

If($year_past == $year_now)
{
echo " selected";
}

echo ">",$year_past,"</option>";
}

echo "</select>
</td>
</tr>
</table>


</td>
</tr>

<tr>
<td align = \"center\">

<div id = \"f_jur_uf_control_step3_",$screen,"\" style = \"width: 90%; height: 95%;\"></div>

</td>
</tr>
<tr height = \"15%\" style = \"background-color: #008080; color: white; \">
<td onclick = \"load_add_write_jur_uf_control('",$screen,"','step4');\">
далее
</td>
</tr>
</table>

<script>
load_calendar_jur_uf_control('",$screen,"','",$month_now,"','",$year_now,"');
</script>

<span id = \"f_id_uf_device_",$screen,"\" style = \"display: none;\">",$id_uf_device,"</span>
<span id = \"f_usl_dezinf_",$screen,"\" style = \"display: none;\">",$usl_dezinf,"</span>
<span id = \"f_obj_dezinf_",$screen,"\" style = \"display: none;\">",$obj_dezinf,"</span>
<span id = \"f_vid_microb_",$screen,"\" style = \"display: none;\">",$vid_microb,"</span>
<span id = \"f_exposure_mode_",$screen,"\" style = \"display: none;\">",$exposure_mode,"</span>

<span id = \"f_tbeg_jur_uf_control_",$screen,"\" style = \"display: none;\">",$tbeg_jur_uf_control,"</span>
<span id = \"f_tend_jur_uf_control_",$screen,"\" style = \"display: none;\">",$tend_jur_uf_control,"</span>


";



}

}

?>
