<?php

function load_block_price_self($vals)
{

#print_r($vals);
$id_price = $vals['id_price'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from price where id_price = '$id_price'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"center\" width = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

$row = mysqli_fetch_assoc($query);
$txt_price = $row['txt_price'];

If($txt_price !== "")
{

$ar_decoded = json_decode($txt_price,true);

Foreach($ar_decoded as $id_usl=>$ar_valls)
{
$name = $ar_valls['name'];
$cost = $ar_valls['cost'];

echo "
<tr style = \"background-color: #8A969C; cursor: pointer;\">
<td width = \"65%\">",$name,"
</td>
<td>",$cost,"р.
</td>
<td height = \"80px\" width = \"20%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"load_add_page_price('delete_usluga_price','",$screen,"','",$id_usl,"','",$id_price,"');\" style = \"background-color: #FF8080; cursor: pointer;\">
х
</td>
</tr>
<tr>
<td onclick = \"load_add_page_price('edit_usluga_price','",$screen,"','",$id_usl,"','",$id_price,"');\" style = \"background-color: #F5C211; color: black; cursor: pointer;\">
ред.
</td>
</tr>
</table>


</td>
</tr>
<tr height = \"30px\">
<td colspan = \"3\">
</td>
</tr>
";


}


#$json_ar = json_encode($ar_decoded, JSON_UNESCAPED_UNICODE);


}
Else{

echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
услуг не найдено
</td>
</tr>
</table>

";

}




echo "</table>";

}



}

?>
