<?php

function load_rooms_jur_uf_self($vals)
{


$screen = $vals['screen'];

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_misc_sets where id = '5'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['val'];
$arr = json_decode($json_arr,true);

echo "<table align = \"center\" border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

$i=1;

Foreach($arr as $id_room=>$ar_valls)
{

$name = $ar_valls['char']['name'];
$square = $ar_valls['char']['square'];
$number = $ar_valls['char']['number'];

echo "
<tr>

<td width = \"60px\">",$i,"
</td>

<td height = \"80px\">

<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
<input value = \"",$name,"\" placeholder = \"наименование помещения\">
</td>
</tr>
<tr>
<td>
<input value = \"\" placeholder = \"площадь помещения\">
</td>
</tr>
<tr>
<td>
<input value = \"\" placeholder = \"номер помещения\">
</td>
</tr>
</table>


</td>
<td onclick = \"open_room_jur_uf_control('",$screen,"','",$id_room,"');\" width = \"30%\" style = \"cursor: pointer;\">
&#9658;
</td>


</tr>
";

$i++;
}

echo "</table>";

//$str_ar_works = json_encode($ar_works, JSON_UNESCAPED_UNICODE);


}
Else{

echo "

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

нет данных

</td>
</tr>
</table>

";

}


}

?>
