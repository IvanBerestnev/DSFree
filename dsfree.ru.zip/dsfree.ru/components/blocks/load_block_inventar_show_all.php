<?php

function load_block_inventar_show_all($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$param = $vals['param'];




$ar_param = explode("@",$param);

#print_r($ar_param);

$name = $ar_param[0];
$type = $ar_param[1];

$ar_f_str = array();

If($name !== "")
{
$ar_f_str[] = " name like('%".$name."%')";
}

If($type !== "")
{
$ar_f_str[] = " type = '".$type."'";
}

If(!empty($ar_f_str))
{
$str_f_search = " where ".implode(" and ",$ar_f_str);
}
Else{
$str_f_search = "";
}

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

function review_data($limit)
{

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);

$ar_date = explode("-",$limit);
$year = $ar_date[0];
$month = $ar_date[1];
$day = $ar_date[2];

$rus_month = $ar_months_rus[$month];

$new_date = $day." ".$rus_month." ".$year;
$new_date_compare = $day."-".$month."-".$year;

$now_date = date("d-m-Y");

#echo $now_date," -- ",$new_date_compare,"====";


If(strtotime($now_date)<strtotime($new_date_compare))
{
$color = "lime";
}
Else{
$color = "red";
}

echo "<span style = \"color: ",$color,";\">до ".$new_date."</span>";

}

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from limit_list".$str_f_search." order by name ASC";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

echo "
<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; background-color: #2E3436; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
";

while($row = mysqli_fetch_assoc($query))
{
$id = $row['id'];
$name = $row['name'];
$type = $row['type'];
$limit = $row['limit'];
$comment = $row['comment'];

If($comment == "")
{
$comment = "нет комментария";
}

echo "
<tr>
<td height = \"35px\" colspan = \"2\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; background-color: #2E3436; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #22272B;\">
<td>
<span>
";

review_data($limit);

echo "
</span>
</td>
<td width = \"33%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; background-color: #22272B; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td onclick = \"show_comment_block_inventar('",$screen,"','",$id,"');\" width = \"33%\" style = \"background-color: #8080FF;\">

коммент



</td>
<td onclick = \"modal_page_inventar('",$screen,"','page_edit_item','",$id,"');\" width = \"33%\" style = \"background-color: #008080;\">
редакт
</td>
<td onclick = \"modal_page_inventar('",$screen,"','page_delete_item','",$id,"');\" style = \"background-color: #FF8080;\">
х
</td>
</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
<tr>
<td height = \"70px\">
<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">
",$name,"
</td>
<td width = \"25%\" rowspan = \"2\" align = \"center\" style = \"color: #F5C211;\">",$type,"</td>
</tr>

<tr>
<td height = \"60px\" id = \"id_comment_block_inventar_",$id,"_",$screen,"\" style = \"display: none; \"><textarea readonly class = \"class_textarea_block_inventar_",$screen,"\" style = \"width: 100%; height: 100%; background-color: #1A5FB4; color: white; border: 0px; font-weight: bold;\">",$comment,"</textarea></td>
</tr>

<tr style = \"background-color: #242424;\" height = \"35px\">
<td colspan = \"2\">
</td>
</tr>
";

}


echo "</table>";


}
Else{

echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; background-color: #2E3436; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
Нет результатов
</td>
</tr>
</table>

";

}

}

?>
