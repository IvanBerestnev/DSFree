<?php

function delete_cert_doc($vals)
{
	
$id_cert = $vals['id_cert'];
$screen = $vals['screen'];



echo "

<script>

function act_delete_cert_doc(id_cert,screen)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_cert_doc') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_cert]=\" + encodeURIComponent(id_cert));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_view_cert = 'f_view_cert_' + screen + '_' + id_cert;


var cont = document.getElementById(f_view_cert);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}



}

</script>

<table border = \"1\" height = \"50px\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"66%\" style = \"background-color: grey; color: white; font-weight: bold;\">
Удалить данный сертификат?
</td>
<td onclick = \"act_delete_cert_doc('",$id_cert,"','",$screen,"');\" style = \"background-color: green; color: white; font-weight: bold; cursor: pointer;\">
да
</td>
<td onclick = \"load_view_cert('",$id_cert,"','",$screen,"','edit');\" style = \"background-color: #ED8984; color: white; font-weight: bold; cursor: pointer;\">
нет
</td>
</tr>
</table>

";


}

?>
