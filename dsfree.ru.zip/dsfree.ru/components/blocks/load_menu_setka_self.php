<?php

function load_menu_setka_self($vals)
{


If(isset($_COOKIE['dsf_cookie']))
{
$cookie = $_COOKIE['dsf_cookie'];
}
Else{

echo "
<script>
location.reload();
</script>
";

}


$id_used_ssetka = $vals['id_used_ssetka'];

$ar_avail_triggers = array("Журнал пациентов"=>"jurnal_pacs","Массовое расписание врачей"=>"mass_doc_shed","Список врачей"=>"sp_docs");

//Получим используемые сохраненные тригеры
include_once("../components/functions/get_tab_ssetka_default.php");
$ar_ssetka_default = get_tab_ssetka_default($id_used_ssetka);

#print_r($ar_ssetka_default);


include_once("../users/_dsf.php");
$ar_user = dsf();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];


$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from dsf_users where id_user = (select id_user from auths where id_cookie = '$cookie')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$level = $row['level'];
$id_pers = $row['id_user'];
}


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_used_ssetka where id_used_ssetka = '$id_used_ssetka'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$json_arr = $row['vals'];
$arr = json_decode($json_arr,true);

}

$key = key($arr);

#print_r($arr);die();

echo "
<style>
input{
text-align: center;
}
</style>
";

If($key == "simple")
{

$a = $arr['simple']['padding']['a'];
$b = $arr['simple']['padding']['b'];
$cr = $arr['simple']['padding']['c'];
$d = $arr['simple']['padding']['d'];


$rows = $arr['simple']['params']['rows'];
$cols = $arr['simple']['params']['cols'];
$spacex = $arr['simple']['params']['spacex'];
$spacey = $arr['simple']['params']['spacey'];


echo "



<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td colspan = \"3\" align = \"center\">

<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','a',this.value);\" size = \"3\" value = \"",$a,"\" style = \"text-align: center;\">
</td>
<tr>
<td width = \"5%\" align = \"center\">

<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','d',this.value);\" size = \"3\" value = \"",$d,"\" style = \"text-align: center;\">

</td>
<td>
";

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; \" cellpadding=\"0\" cellspacing= \"0\">";

$x=1;

For($r=1;$r<=$rows;$r++)
{
echo "<tr>";

For($c=1;$c<=$cols;$c++)
{
echo "<td align = \"center\" style = \"background-color: grey; \">";

echo "

<span id = \"span_sel_add_tab_ssetka_default_",$x,"\">

<select class = \"sel_add_tab_ssetka_default\" id = \"sel_add_tab_ssetka_default_",$x,"\" onchange = \"add_tab_ssetka_default(this.value,'",$id_used_ssetka,"','",$x,"');\" style = \"text-align: center; \">
<option selected value = \"\">выбрать</option>
";

Foreach($ar_avail_triggers as $k=>$t)
{

If(in_array($t,$ar_ssetka_default))
{

$sc = array_search($t,$ar_ssetka_default);

If($sc !== $x)
{
continue;
}

}

echo "<option";

If(isset($ar_ssetka_default[$x]))
{
$param = $ar_ssetka_default[$x];
If($param == $t)
{
echo " selected";
}

If($param == "jurnal_pacs")
{
$display = "inline";
}
Else{
$display = "none";
}

}
Else{
$display = "none";	
}

echo " value = \"",$t,"\">",$k,"</option>";
}

echo "</select>

</span>

<button onclick = \"open_page_edit_default_ssetka('",$id_used_ssetka,"','",$x,"');\" id = \"but_edit_default_",$id_used_ssetka,"_",$x,"\" style = \"display: ",$display,";\">
настройка
</button>

";

echo "</td>";

If($spacey !== "0")
{
If($c < $cols)
{
echo "<td width = \"10px\"></td>";
}
}

$x++;
}

echo "</tr>";

If($spacex !== "0")
{
If($r < $rows)
{
echo "<tr height = \"10px\"><td align = \"center\" colspan = \"",$cols,"\"></td></tr>";
}

}
}

echo "</table>

</td>
<td width = \"5%\" align = \"center\">

<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','b',this.value);\" size = \"3\" value = \"",$b,"\" style = \"text-align: center;\">

</td>
</tr>
<tr height = \"10%\">
<td colspan = \"3\" align = \"center\">

<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','c',this.value);\" size = \"3\" value = \"",$cr,"\" style = \"text-align: center;\">

</td>
</tr>
</table>

";



}
ElseIf($key == "special")
{

$a = $arr['special']['padding']['a'];
$d = $arr['special']['padding']['d'];

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\">
<td colspan = \"3\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','a',this.value);\" size = \"3\" value = \"",$a,"\" style = \"text-align: center;\">
</td>
<tr>

<td width = \"5%\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','d',this.value);\" size = \"3\" value = \"",$d,"\" style = \"text-align: center;\">

</td>
<td style = \"color: white;\">
";

$count_tr = count($arr['special']['params']);
$name_special = $arr['special']['name'];
$working_cells = $arr['special']['working_cells'];

echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">";

$g=1;
$h=1;

For($c=0;$c<$count_tr;$c++)
{

$height = $arr['special']['params'][$c]['height'];
$cells = $arr['special']['params'][$c]['cells'];

If(isset($arr['special']['params'][$c]['x']))
{
$x = $arr['special']['params'][$c]['x'];
}

echo "<tr height = \"",$height,"\"><td >";
echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; color: white;\" cellpadding=\"0\" cellspacing= \"0\"><tr>";

For($td_c=0;$td_c<=$cells;$td_c++)
{

If(isset($x[$td_c]))
{
$v = $x[$td_c];
$width = " width=\"".$v."\"";
}
Else{
$width = "";
}


If(in_array($g,$working_cells))
{

echo "<td",$width," style= \"background-color: grey; font-weight: bold; color: white;\">

шир.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"#",$td_c,"',this.value);\" size = \"2\" value = \"",$v,"\">

";

echo "<select style = \"text-align: center;\">
<option selected>выбрать</option>
";

Foreach($ar_triggers as $k=>$t)
{
echo "<option value = \"",$t,"\">",$k,"</option>";
}

echo "</select>";

If($td_c == "0")
{
echo "<span style = \"float: left;\">выс.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"*",$td_c,"',this.value);\" size = \"2\" value = \"",$height,"\"></span>";
}

echo "</td>";

$h++;
}
Else{

echo "<td",$width," >";

If(!empty($x))
{
echo " шир.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"#",$td_c,"',this.value);\" size = \"2\" value = \"",$v,"\">";
}
Else{
echo " выс.<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','",$c,"*",$td_c,"',this.value);\" size = \"2\" value = \"",$height,"\">";
}

//

echo "</td>";

}




$g++;
}

echo "</tr></table>";
echo "</td></tr>";

$height = "";
$cells = "";
$x = array();

}

echo "</table>";

$b = $arr['special']['padding']['b'];
$c = $arr['special']['padding']['c'];

echo "

</td>
<td width = \"5%\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','b',this.value);\" size = \"3\" value = \"",$b,"\" style = \"text-align: center;\">

</td>
</tr>
<tr height = \"10%\">
<td colspan = \"3\" align = \"center\">
отступ
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','c',this.value);\" size = \"3\" value = \"",$c,"\" style = \"text-align: center;\">

</td>
</tr>
</table>


";

}


}


?>
