<?php

function recalc_select_end_jurpac($vals)
{

#print_r($vals);

$sel_beg = $vals['sel_beg'];
$add = $vals['add'];
$t_e_m_second = $vals['t_e_m_second'];
$screen = $vals['screen'];

If($add !== "")
{

$ar_button_period_time = array("0.5"=>"30","1"=>"60","1.5"=>"90","2"=>"120","2.5"=>"150","3"=>"180","3.5"=>"210","4"=>"240");
$add_min = $ar_button_period_time[$add];

$new_time = $sel_beg+$add_min;

If($new_time>$t_e_m_second)
{
$new_time = $t_e_m_second;
}

$t = date("H:i", mktime(0, $new_time, 0, 1, 1, 1970));
echo "
<span id = \"id_span_end_jurpac_",$screen,"\" style = \"display: none;\">",$new_time,"</span>
<span style = \"width: 85%; font-size: 20px; text-align: center; color: white;font-weight: bold;\">",$t,"</span>

";

}
Else{

$sel_beg_fp = $sel_beg;
$min_selected = $sel_beg_fp+180;

If($min_selected>$t_e_m_second)
{
$min_selected = $t_e_m_second;
}

echo "<select id = \"id_select_end_jurpac_",$screen,"\" style = \"width: 85%; font-size: 20px; text-align: center;\">";

$i=0;
For($sel_beg;$sel_beg<=$t_e_m_second;$sel_beg=$sel_beg+5)
{

If($i==0)
{
$i++;
continue;
}

$t = date("H:i", mktime(0, $sel_beg, 0, 1, 1, 1970));

echo "<option value = \"",$sel_beg,"\"";

If($sel_beg == $min_selected)
{
echo " selected";
}

echo ">",$t,"</option>";

}

echo "</select>";


}






}

?>
