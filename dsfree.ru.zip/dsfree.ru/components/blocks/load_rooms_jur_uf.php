<?php

function load_rooms_jur_uf($vals)
{

$screen = $vals['screen'];



echo "

<script>

function load_rooms_jur_uf_self(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_rooms_jur_uf_self') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_rooms_jur_uf_self = 'f_rooms_jur_uf_self_' + screen;

var cont = document.getElementById(f_rooms_jur_uf_self);
cont.innerHTML = xmlhttp.responseText;

//alert(xmlhttp.responseText);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}


}

function add_room_jur_uf_control(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_room_jur_uf_control') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {


var f_rooms_jur_uf_self = 'f_rooms_jur_uf_self_' + screen;

var cont = document.getElementById(f_rooms_jur_uf_self);
cont.innerHTML = xmlhttp.responseText;

//alert(xmlhttp.responseText);

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}

}
}
}

}


</script>

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div id = \"f_rooms_jur_uf_self_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">";






echo "
</div>

</td>
</tr>

<tr onclick = \"add_room_jur_uf_control('",$screen,"');\" height = \"15%\" style = \"background-color: #008080; color: white; cursor: pointer;\">
<td>
добавить помещение
</td>
</tr>

</table>


<script>
load_rooms_jur_uf_self('",$screen,"');
</script>

";

}

?>
