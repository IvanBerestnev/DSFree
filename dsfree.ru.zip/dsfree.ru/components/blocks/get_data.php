<?php

function get_data($vals)
{

#print_r($vals);

$direct = $vals['direct'];
$screen = $vals['screen'];
$dir_date = $vals['dir_date'];

$ar_dir_date = explode("-",$dir_date);
$day = $ar_dir_date[0];
$month = $ar_dir_date[1];
$year = $ar_dir_date[2];

If($direct == "back")
{
$sday = $day-1;

$date = date("d-m-Y", mktime(0, 0, 0, $month, $sday, $year));
echo $date;


}
ElseIf($direct == "next")
{
$sday = $day+1;

$date = date("d-m-Y", mktime(0, 0, 0, $month, $sday, $year));
echo $date;


}
ElseIf($direct == "now")
{


$date = date("d-m-Y");
echo $date;


}





}

?>
