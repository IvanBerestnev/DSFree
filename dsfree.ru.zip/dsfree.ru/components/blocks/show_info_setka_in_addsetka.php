<?php

function show_info_setka_in_addsetka($vals)
{

include_once("../components/functions/get_params_by_cookie.php");
$ar_vals = get_params_by_cookie();

$id_user_cookie = $ar_vals['id_user_cookie'];
$name_user_cookie= $ar_vals['name_user_cookie'];
$level_cookie = $ar_vals['level_cookie'];

$id_user = $vals['id_user'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_used_ssetka where id_pers = '$id_user'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$i=0;
while ($row = mysqli_fetch_assoc($query))
{
$i++;

}

If($i == "1")
{
$profile = "профиль";
}
ElseIf($i == "2" or $i == "3" or $i == "4")
{
$profile = "профиля";
}
Else{
$profile = "профилей";
}

echo "Всего ",$i," ",$profile;

}
Else{
echo "профилей сетки<br>не найдено";
}



}

?>
