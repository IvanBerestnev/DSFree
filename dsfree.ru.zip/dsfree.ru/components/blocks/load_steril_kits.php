<?php

function load_steril_kits($vals)
{

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");



echo "

<style>
.txtarea_sk_",$screen,":focus, input:focus{
outline: none;
}

.txtarea_sk_",$screen,"{
background-color: #8A969C;
color: white;
font-weight: bold;
font-size: 18px;
font-family: Arial;
}

</style>";

$sql = "select * from tab_steril_kit";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "
<table border = \"0\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
";


while($row = mysqli_fetch_assoc($query))
{

$id = $row['id'];
$name_short = $row['name_short'];
$name_full = $row['name_full'];
$items = $row['items'];

echo "
<tr height = \"35px\" style = \"background-color: #1A5FB4;\">
<td>
Набор № 
<input onkeyup = \"add_new_info_steril_kits(this.value,'name_short','",$id,"');\" size = \"1\" style = \"background-color: #1A5FB4; border: 0px; border-bottom: 1px solid white; color: white; font-weight: bold; font-size: 18px;\" value = \"",$name_short,"\">
</td>
<td onclick = \"page_cnfm_del_st_kit('",$id,"','",$screen,"');\" width = \"10%\" rowspan = \"2\" style = \"background-color: #FF8080; cursor: pointer;\">
X
</td>
</tr>
<tr>
<td height = \"100px\">

<textarea onkeyup = \"add_new_info_steril_kits(this.value,'items','",$id,"');\" class = \"txtarea_sk_",$screen,"\" style = \"width: 100%; height: 100%;\">",$items,"</textarea>

</td>
</tr>
<tr>
<td colspan = \"2\">
&nbsp;
</td>
</tr>


";

}





echo "</table>";

}
Else{

echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
нет доступных наборов
</td>
</tr>
</table>

";

}



}

?>
