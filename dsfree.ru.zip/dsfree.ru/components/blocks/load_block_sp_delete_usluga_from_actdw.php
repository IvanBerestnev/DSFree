<?php

function load_block_sp_delete_usluga_from_actdw($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];
$id_dw = $vals['id_dw'];

function review_no_cost($no_cost)
{
	
If($no_cost !== "")
{

$ar_no_cost = explode("-",$no_cost);
$n_cost = $ar_no_cost[0];
$o_cost = $ar_no_cost[1];

If($n_cost == $o_cost)
{
echo $n_cost," р.";
}
Else{

$part_n_cost = ($n_cost*100)/$o_cost;
$discont = 100-$part_n_cost;

echo $n_cost," р. (",$o_cost," р. - ",$discont,"%)";

}

}

}

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$works = $row['works'];

#echo $works;

$ar_works = json_decode($works,true);

If(isset($ar_works[$id_dw]))
{

$str_full_cost = $ar_works[$id_dw]['full_cost'];

$ar_str_full_cost = explode(";",$str_full_cost);

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">";


Foreach($ar_str_full_cost as $no_cost)
{

echo "
<tr style = \"cursor: pointer;\">
<td >";

review_no_cost($no_cost);

echo "
</td>
<td height = \"60px\" width = \"20%\" align = \"center\">

<div style=\"background-color: #FF8080; cursor: pointer; height: 65%; width: 55%; display: table; text-align: center;\">
<span onclick = \"act_delete_usluga_from_sp_dw('",$no_cost,"','",$id_visit,"','",$id_dw,"','",$screen,"');\" style=\"vertical-align: middle; display: table-cell; font-weight: bold;\">
х
</span>
</div>

</td>
</tr>
<tr style = \"background-color: #1D1D1D;\" height = \"15px\">
<td colspan = \"2\">
</td>
</tr>
";

}

echo "</table>";

}
Else{

echo "

<script>
close_mw('fon_modal_first_",$screen,"');
</script>

";

}





}



}

?>
