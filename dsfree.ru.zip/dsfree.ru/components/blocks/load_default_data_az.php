<?php

function load_default_data_az($vals)
{

$screen = $vals['screen'];

$day_now = date("d");
$month_now = date("m");
$year_now = date("Y");

$year_future = date("Y")+10;
$year_past = date("Y")-10;


$number = cal_days_in_month(CAL_GREGORIAN, $month_now, $year_now);

$ar_months_rus = array(
"01"=>"января",
"02"=>"февраля",
"03"=>"марта",
"04"=>"апреля",
"05"=>"мая",
"06"=>"июня",
"07"=>"июля",
"08"=>"августа",
"09"=>"сентября",
"10"=>"октября",
"11"=>"ноября",
"12"=>"декабря"
);



echo "<span id = \"f_select_day_az_",$screen,"\" >



<select id = \"select_day_az_",$screen,"\">";

For($i=1;$i<=$number;$i++)
{

$d = date("d", mktime(0, 0, 0, 1, $i, 1970));

echo "<option ";

If($i == $day_now)
{
echo " selected";
}

echo " value = \"",$d,"\">",$d,"</option>";
}


echo "
</select>

</span>

<select id = \"select_month_az_",$screen,"\" onchange = \"recalc_days_in_months_az('",$screen,"');\">
";


Foreach($ar_months_rus as $nm=>$rm)
{
echo "<option";

If($nm == $month_now)
{
echo " selected";
}

echo " value = \"",$nm,"\">",$rm,"</option>";
}



echo "

</select>



<select id = \"select_year_az_",$screen,"\" onchange = \"recalc_days_in_months_az('",$screen,"');\">";

For($year_past;$year_past<=$year_future;$year_past++)
{
echo "<option";

If($year_past == $year_now)
{
echo " selected";
}

echo " value = \"",$year_past,"\">",$year_past,"</option>";
}

echo "</select>

</span>
<br><br>";


}


?>
