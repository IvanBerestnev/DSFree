<?php

function load_jur_pso($vals)
{

#print_r($vals);


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from jur_pso order by date ASC";
$query = mysqli_query($connection,$sql);



If(mysqli_num_rows($query) !== 0)
{

echo "<table align = \"center\" border = \"1\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id = $row['id'];
$date = $row['date'];
$method = $row['method'];
$agent = $row['agent'];
$izd = $row['izd'];
$amount = $row['amount'];


echo "


<tr>
<td width = \"40px\" style = \"background-color: #FF8080; color: white; font-weight: bold; cursor: pointer;\">
X
</td>
<td>
",$date,"
</td>
<td>
",$method,"
</td>
<td>
",$agent,"
</td>
<td>
",$izd,"
</td>
<td>
",$amount,"
</td>

</tr>



";



}

echo "</table>";

}
Else{

echo "<table align = \"center\" border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #C0C0C0; text-align: center;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Нет записей в журнале предстерилизационной очистки
</td>
</tr>
</table>
";

}




}


?>
