<?php

function block_temple_medcart_visit_choice_selftemple($vals)
{


#print_r($vals);

$screen = $vals['screen'];
$id_ds = $vals['id_ds'];
$id_struct = $vals['id_struct'];
$id_razd = $vals['id_razd'];
$id_writed_razd = $vals['id_writed_razd'];


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from sp_dss where id_ds = '$id_ds'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$name_ds = $row['name_ds'];
$id_ds_sp = $row['id_ds']; 
}


$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

while($row = mysqli_fetch_assoc($query))
{

$text = $row['text'];
$text = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_text = json_decode($text,true);

If(isset($ar_text[$id_ds]))
{

$name_used_struct = $ar_text[$id_ds][$id_struct]['name'];
$name_used_razd = $ar_text[$id_ds][$id_struct]['cont'][$id_razd]['name'];

}

}

echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"10%\">
<td align = \"center\">

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"33%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td style = \"background-color: #8A969C;\">
",$name_ds,"
</td>
<td onclick = \"load_block_temple_razd_visit_self('','','','",$screen,"','",$id_writed_razd ,"');\" width = \"20%\" style = \"background-color: #FF8080; cursor: pointer;\">
x
</td>
</tr>
</table>

</td>
<td width = \"33%\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td style = \"background-color: #8A969C;\">
",$name_used_struct,"
</td>
<td onclick = \"load_block_temple_razd_visit_self('",$id_ds,"','','','",$screen,"','",$id_writed_razd ,"');\" width = \"20%\" style = \"background-color: #FF8080; cursor: pointer;\">
x
</td>
</tr>
</table>

</td>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td style = \"background-color: #8A969C;\">
",$name_used_razd,"
</td>
<td onclick = \"load_block_temple_razd_visit_self('",$id_ds,"','",$id_struct,"','','",$screen,"','",$id_writed_razd ,"');\" width = \"20%\" style = \"background-color: #FF8080; cursor: pointer;\">
x
</td>
</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>

<tr height = \"15%\">
<td align = \"center\">
выберете шаблон
</td>
</tr>
<tr>
<td>
<div style = \"width: 100%; height: 100%; overflow-y:scroll;\">";

$status = "";

$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
";

while($row = mysqli_fetch_assoc($query))
{

$text = $row['text'];
$text = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_text = json_decode($text,true);

If(isset($ar_text[$id_ds]))
{

$ar_all_struct = $ar_text[$id_ds];

Foreach($ar_all_struct as $id_struct_intemple=>$ar_valls_struct)
{

If($id_struct == $id_struct_intemple)
{

$ar_razd_intemple = $ar_valls_struct['cont'];

Foreach($ar_razd_intemple as $id_razd_intemple=>$ar_valls_razd)
{

If($id_razd == $id_razd_intemple)
{

$name = $ar_valls_razd['name'];
$ar_selftemple = $ar_valls_razd['cont'];

If(count($ar_selftemple) == 0)
{

}
Else{

$status = "1";

Foreach($ar_selftemple as $id_selftemple=>$text_selftemple)
{

//insert_temple_to_textarea(id_writed_razd,screen,id_stempl)
//load_block_temple_razd_visit_self('",$id_ds,"','",$id_struct_intemple,"','",$id_razd_intemple,"','",$screen,"')

echo "
<tr style = \"background-color: #C0C0C0; color: black; cursor: pointer;\" height = \"40px\">
<td id = \"f_saved_templ_text_",$id_selftemple,"_",$screen,"\" onclick = \"insert_temple_to_textarea('",$id_writed_razd,"','",$screen,"','",$id_selftemple,"');\">",$text_selftemple,"</td>
</tr>
<tr height = \"20px\"><td></td></tr>
";

}

}

}



}

}




}

}


#echo "<tr onclick = \"load_block_temple_razd_visit_self('",$id_ds_sp,"','",$id_struct,"','",$id_razd,"','",$screen,"');\" style = \"background-color: #C0C0C0; color: black; cursor: pointer;\" height = \"40px\"><td>",$name_ds,"</td></tr><tr height = \"20px\"><td></td></tr>";

}

echo "</table>";


If($status == "")
{
echo "
<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr><td align = \"center\">в данном разделе отсутствуют шаблоны</td>
</table>
";
}



}


echo "

</div>
</td>
</tr>
</table>

";


}

?>
