<?php

function erasing_excess_options_ssetka_default($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$id_used_ssetka = $vals['id_used_ssetka'];

$ar_avail_triggers_basa = array("Журнал пациентов"=>"jurnal_pacs","Массовое расписание врачей"=>"mass_doc_shed","Список врачей"=>"sp_docs");
$ar_avail_triggers = $ar_avail_triggers_basa;

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


#$sql = "select * from tab_ssetka_default where number_cell IN('$screen')";
$sql = "select * from tab_ssetka_default";
$query = mysqli_query($connection,$sql);
#echo $sql;

If(mysqli_num_rows ($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$param = $row['param'];

$ar_scr_param[$row['number_cell']] = $param;

If(in_array($param,$ar_avail_triggers))
{
unset($ar_avail_triggers[array_search($param,$ar_avail_triggers)]);
}


}

}
Else{
#$ar_exit = array();
}


#print_r($ar_avail_triggers);



Foreach($ar_avail_triggers as $k=>$v)
{

$ar_e[] = "<option value = \"".$v."\">".$k."</option>";

}

#$str_ar_e = "<select style = \"text-align: center;\"><option>выбрать</option>".implode("",$ar_e)."</select>";


$ar_screen = explode(",",$screen);

Foreach($ar_screen as $scr)
{

#$ar_str_exit[] = $scr."#".$str_ar_e;



If(isset($ar_scr_param[$scr]))
{

$p = $ar_scr_param[$scr];
$ru_p = array_search($p,$ar_avail_triggers_basa);

$add_option = "<option selected value = \"".$ar_scr_param[$scr]."\">".$ru_p."</option>";
}
Else{
$add_option = "";
}

$ar_str_exit[] = $scr."#"."<select class = \"sel_add_tab_ssetka_default\" id = \"sel_add_tab_ssetka_default_".$scr."\" onchange = \"add_tab_ssetka_default(this.value,'".$id_used_ssetka."','".$scr."');\" style = \"text-align: center;\"><option>выбрать</option>".$add_option.implode("",$ar_e)."</select>";

}

#print_r($ar_str_exit);


$str_exit = implode("@",$ar_str_exit);

echo $str_exit;

}

?>
