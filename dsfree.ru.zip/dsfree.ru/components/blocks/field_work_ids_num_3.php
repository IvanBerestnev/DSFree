<?php

function field_work_ids_num_3($vals)
{

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$screen = $vals['screen'];
$id_ids = $vals['type'];
$id_pac_selected = $vals['id_pac_selected'];

echo "



<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \" padding-bottom: 10px;\">

<div style = \"width: 100%; height: 100%; overflow-y: scroll; background-color: #2E3436; \">

<table border = \"0\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; margin-top: 10px; \" cellpadding=\"0\" cellspacing= \"0\">

";


$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac_selected'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_dogovor = $row['id_dogovor'];
$data_dogovor = $row['data_dogovor'];

echo "
<tr onclick = \"load_td_field_work_ids('",$screen,"','4','",$id_dogovor,"');\" height = \"80px\" style = \"background-color: #22272B; cursor: pointer; \">

<td style = \"position: relative;\">Договор №",$id_dogovor," от ",$data_dogovor,"


<span id = \"under_line_3_",$id_dogovor,"_",$screen,"\" class = \"under_line_3_",$screen,"\" style = \"position: absolute; bottom:0; left:0;width: 100%; height: 5px; bottom: 0px; background-color: #F5C211; display: none;\"></span>

</td>
</tr>
<tr>
<td >



</td>
</tr>

";
}


}


echo "

</table>



</div>

</td>
</tr>
</table>";



}


?>
