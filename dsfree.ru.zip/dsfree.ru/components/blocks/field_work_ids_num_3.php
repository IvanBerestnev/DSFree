<?php

function field_work_ids_num_3($vals)
{

$type = $vals['type'];
$screen = $vals['screen'];



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


echo "<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">

<tr height = \"50px\">
<td style = \"padding-top: 10px; padding-left: 10px; padding-right: 10px;\">

<div style = \" width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B;\">
Список врачей
</div>

</td>
</tr>

<tr>
<td style = \"padding-right: 10px; padding-left: 10px; padding-top: 10px;\">
<div style = \"width: 100%; height: 100%; overflow-y: scroll; \">

<table border = \"0\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">

";


$sql = "select * from tab_personal where type = 'doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];
$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];

echo "

<tr>
<td height = \"50px\">

<div onclick = \"load_td_field_work_ids('",$screen,"','4','",$id_pers,"');\" style = \" width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background-color: #22272B; cursor: pointer; position: relative;\" >

Др. 


",$surname_pers," ",$name_pers," ",$patronymic_pers,"  &nbsp;


";

$sql = "select * from tab_docs_cert where id_doc = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<select id = \"sel_cert_doc_ids_",$id_pers,"_",$screen,"\">";

while($row = mysqli_fetch_assoc($query))
{

$name_cert = $row['name_cert'];

echo "<option value = \"",$name_cert,"\">",$name_cert,"</option>";

}

echo "</select>";

}
Else{

echo "
<select id = \"sel_cert_doc_ids_",$id_pers,"_",$screen,"\">
<option value = \"\">Должность н.у.</option>
</select>
";

}


echo "







<span id = \"under_line_3_",$id_pers,"_",$screen,"\" class = \"under_line_3_",$screen,"\" style = \"position: absolute; width: 100%; height: 5px; bottom: 0px; background-color: orange; display: none;\"></span>

</div>



</td>
</tr>

<tr height = \"20px\">
<td>
</td>
</tr>

";

}

}


echo "

</table>

</div>

</td>
</tr>
</table>";


}


?>
