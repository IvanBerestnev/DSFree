<?php

function load_struct_templ_medcart($vals)
{

$id_ds_income = $vals['id_ds'];
$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

$spot = "0";

#print_r($vals);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_templ_medcart";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$z=0;

while($row = mysqli_fetch_assoc($query))
{
$id_tm = $row['id_tm'];
$text = $row['text'];
$time_edit = $row['time_edit'];



/*
If($z==0 or $z==1)
{
$z++;
continue;
}
*/

#echo $text;die();

#$s = htmlspecialchars_decode($text);

#echo $s;die();

#$json_ar = html_entity_decode(json_decode($text,true));

$text = preg_replace('/[[:cntrl:]]/', '', $text);


$ar_decoded = json_decode($text,true);

#var_dump(json_last_error());
#var_dump(json_last_error_msg());


#print_r($json_ar);die();

#$jsonData = stripslashes(html_entity_decode($text));

#$json = mb_convert_encoding($jsonData, "UTF-8");


#$ar_decoded = json_decode($json,true);

#var_dump(json_last_error());
#var_dump(json_last_error_msg());

#$error = json_last_error();

#echo $error;die();

#print_r($ar_decoded);

If(isset($ar_decoded[$id_ds_income]))
{

echo "<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

$ar_ds_decoded = $ar_decoded[$id_ds_income];

Foreach($ar_ds_decoded as $id_str_templ=>$ar_str_tmpl)
{
$name_str_tmpl = $ar_str_tmpl['name'];


echo "
<tr><td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border-top: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30px\">
<td onclick = \"edit_first_docum('edit_medcart_step3','",$id_ds_income,"@",$id_str_templ,"@",$id_tm,"@",$id_pac,"','",$screen,"');\" style = \"cursor: pointer; background-color: #008080;\">

открыть структурный шаблон
</td>
<td width = \"33%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>

<td onclick = \"page_delete_struct_templ_medcart('",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"','",$id_pac,"','",$screen,"');\" style = \"background-color: #FF8080;\">
Х
</td>
</tr>
</table>

</td>
</tr>
</table>

</td></tr>
<tr >
<td height = \"40px\" style = \"cursor: pointer;\">

<input onkeyup = \"act_rename_struct_templ_medcart(this.value,'",$id_tm,"','",$id_ds_income,"','",$id_str_templ,"','",$screen,"');\" style = \"width: 100%; height: 100%;\" value = \"",$name_str_tmpl,"\">

</td>

</tr>

<tr height = \"30px\">
<td>
</td>
</tr>
";

}

echo "</table>";

$spot++;

}





}

If($spot == 0)
{

echo "<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Нет зарегистрированных<br> структурных шаблонов <br> для данного диагноза
</td>
</tr>
</table>
";

}




}
Else{

echo "<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Вообще нет каких-либо<br> зарегистрированных<br> структурных шаблонов
</td>
</tr>
</table>
";

}


}


?>
