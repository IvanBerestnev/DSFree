<?php

function show_jurpac_bottom_menu($vals)
{

#print_r($vals);

$type = $vals['type'];
$screen = $vals['screen'];
$id_cell = $vals['id_cell'];
$id_doc = $vals['id_doc'];
$unit = $vals['unit'];

$ar_id_cell = explode("_",$id_cell);

$pre_date = $ar_id_cell[2];
$time = $ar_id_cell[3];

$ar_time = explode("-",$time);
$btime = $ar_time[0];
$etime = $ar_time[1];


If($type == "pacs_time")
{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$datetime_begin = $pre_date." ".$btime.":00";
$datetime_end = $pre_date." ".$etime.":00";


//получение инфы о пациенте

$sql = "select * from pacs_ent where begin = '$datetime_begin' and end = '$datetime_end' and doc = '$id_doc' and unit = '$unit'";

#echo $sql;

$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);

$id_pac = $row['id_pacs'];
$id_ent = $row['id_ent'];
$id_doc = $row['doc'];

$sql = "select * from tab_pacs where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row_pac = mysqli_fetch_assoc($query);

$surname_pac = $row_pac['surname_pac'];
$name_pac = $row_pac['name_pac'];
$patronymic_pac = $row_pac['patronymic_pac'];

$f_name_pac = mb_substr($name_pac, 0, 1);

If($f_name_pac !== "")
{
$f_np = $f_name_pac.".";
}
Else{
$f_np = "";
}


$f_patronymic_pac = mb_substr($patronymic_pac, 0, 1);

If($f_patronymic_pac !== "")
{
$f_pp = $f_patronymic_pac.".";
}
Else{
$f_pp = "";
}

}

}


//Инфа о враче

$sql = "select * from tab_personal where id_pers = '$id_doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row_pers = mysqli_fetch_assoc($query);

$surname_pers = $row_pers['surname_pers'];
$name_pers = $row_pers['name_pers'];
$patronymic_pers = $row_pers['patronymic_pers'];

$f_name_pers = mb_substr($name_pers, 0, 1);

If($f_name_pers !== "")
{
$f_npers = $f_name_pers.".";
}
Else{
$f_npers = "";
}

$f_patronymic_pers = mb_substr($patronymic_pers, 0, 1);

If($f_patronymic_pers !== "")
{
$f_ppers = $f_patronymic_pers.".";
}
Else{
$f_ppers = "";
}

}


echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; cursor: pointer; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"65%\">
<td colspan = \"2\" align = \"left\" style = \"padding-left: 5px;\">
<span style = \"font-weight: bold; color: Tomato;\">Прием пациента</span>
<br>
<span style = \"font-weight: bold; color: gold;\">дата/время:</span> ",$pre_date," / ",$time,"

<br>

<span style = \"font-weight: bold; color: YellowGreen;\">пациент:</span> ",$surname_pac," ",$f_np, $f_pp," (<span style = \"font-weight: bold; color: LightSkyBlue;\">врач:</span> ",$surname_pers," ",$f_npers,$f_ppers,")

</td>

</tr>
<tr style = \"font-weight: normal;\">
<td >

<select id = \"id_sel_run_act_bottom_jp_",$screen,"\" onchange = \"sel_run_act_bottom_jp(this.value,'",$screen,"','",$id_ent,"');\" style = \"text-align: center;\">
<option disabled selected>выберете действие</option>
<option value = \"cancel_ent\">отмена приема</option>
<option value = \"note_pac_modal\">заметка о приеме</option>
<option value = \"corr_time_ent_pac\">коррекция времени</option>
<option value = \"info_pac\">информация о пациенте</option>
<option value = \"change_pac_jurpac\">замена пациента</option>
<option value = \"primary_docums\">первичная документация</option>
</select>

</td>

<td onclick = \"reload_jurpacs_cell_colors('",$screen,"');\" width = \"30%\" style= \"color: red; font-size: 25px; font-weight: bold; background-color: black;\">
x
</td>

</tr>
</table>


";

}
ElseIf($type == "empty_time")
{

#print_r($vals);
$id_shedule = $vals['id_shedule'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

//Инфа о враче

$sql = "select * from tab_personal where id_pers = '$id_doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row_pers = mysqli_fetch_assoc($query);

$surname_pers = $row_pers['surname_pers'];
$name_pers = $row_pers['name_pers'];
$patronymic_pers = $row_pers['patronymic_pers'];

$f_name_pers = mb_substr($name_pers, 0, 1);

If($f_name_pers !== "")
{
$f_npers = $f_name_pers.".";
}
Else{
$f_npers = "";
}

$f_patronymic_pers = mb_substr($patronymic_pers, 0, 1);

If($f_patronymic_pers !== "")
{
$f_ppers = $f_patronymic_pers.".";
}
Else{
$f_ppers = "";
}

}


$datetime_begin = $pre_date." ".$btime.":00";
$datetime_end = $pre_date." ".$etime.":00";

$param = $datetime_begin."@".$datetime_end."#".$unit."#".$id_doc."#".$id_shedule;

#$sql = "select * from pacs_ent where begin between STR_TO_DATE('$datetime_begin', '%Y-%m-%d %H:%i:%s') and STR_TO_DATE('$datetime_end', '%Y-%m-%d %H:%i:%s') order by begin ASC";
#echo $sql;
#$query = mysqli_query($connection,$sql);


echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; cursor: pointer; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"65%\">
<td colspan = \"2\" align = \"left\" style = \"padding-left: 5px;\">
<span style = \"font-weight: bold; color: Tomato;\">Время врача</span>
<br>
<span style = \"font-weight: bold; color: gold;\">дата/время:</span> ",$pre_date," / ",$time,"

<br>

<span style = \"font-weight: bold; color: YellowGreen;\">врач:</span> ",$surname_pers," ",$f_npers,$f_ppers,"

</td>

</tr>
<tr style = \"font-weight: normal;\">
<td >

<select id = \"id_sel_run_act_bottom_jp_",$screen,"\" onchange = \"sel_run_act_bottom_jp(this.value,'",$screen,"','",$param,"');\" style = \"text-align: center;\">
<option disabled selected>выберете действие</option>
<option value = \"write_pac_ent_into_shedule\">запись пациента</option>
<option value = \"correct_shed_time_doc\">коррекция промежутка</option>
<option value = \"del_period_shed_time_doc\">удаление промежутка</option>
<option value = \"change_doc_shed_times\">замена врача</option>

</select>

</td>

<td onclick = \"reload_jurpacs_cell_colors('",$screen,"');\" width = \"30%\" style= \"color: red; font-size: 25px; font-weight: bold; background-color: black;\">
x
</td>

</tr>
</table>


";



}
ElseIf($type == "free_time")
{
	

$datetime_begin = $pre_date." ".$btime.":00";
$datetime_end = $pre_date." ".$etime.":00";

$param = $datetime_begin."@".$datetime_end."#".$unit;

echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; cursor: pointer; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"65%\">
<td colspan = \"2\" align = \"left\" style = \"padding-left: 5px;\">
<span style = \"font-weight: bold; color: Tomato;\">Свободное время</span>
<br>
<span style = \"font-weight: bold; color: gold;\">дата/время:</span> ",$pre_date," / ",$time,"



</td>

</tr>
<tr style = \"font-weight: normal;\">
<td >

<select id = \"id_sel_run_act_bottom_jp_",$screen,"\" style = \"text-align: center;\" onchange = \"sel_run_act_bottom_jp(this.value,'",$screen,"','",$param,"');\">
<option disabled selected>выберете действие</option>
<option value = \"write_doc_shed\">расписание врачу</option>
</select>

</td>

<td onclick = \"reload_jurpacs_cell_colors('",$screen,"');\" width = \"30%\" style= \"color: red; font-size: 25px; font-weight: bold; background-color: black;\">
x
</td>

</tr>
</table>


";



}



}

?>
