<?php

function load_doc_msd($vals)
{

#print_r($vals);
$id_pers = $vals['id_pers'];
$screen = $vals['screen'];

$ar_id_pers = explode(",",$id_pers);

$count_ar_id_pers = count($ar_id_pers);

$str_id_pers = implode("','",$ar_id_pers);

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_personal where id_pers IN ('$str_id_pers')";
$query = mysqli_query($connection,$sql);


//разделить массив на равные части

For($t=540; $t<=1200; $t=$t+5)
{
$arr_t[] = $t;
}

function splitMyArray(array $input_array, int $size, $preserve_keys = null): array
{
    $nr = (int)ceil(count($input_array) / $size);

    if ($nr > 0) {
        return array_chunk($input_array, $nr, $preserve_keys);
    }

    return $input_array;
}

$newArr = splitMyArray($arr_t, $count_ar_id_pers);

#print_r($newArr);

Foreach($newArr as $na=>$ar_na)
{

$max = end($ar_na);
$next_na = $na+1;

If(isset($newArr[$next_na]))
{

#$ar_qq[$na] = $ar_na;

array_unshift($newArr[$next_na], $max);

$ar_qq[$na] = $newArr[$na];

}
Else{

//$ar_qq[$na] = $ar_na;
#array_unshift($newArr[$na], $max);
$ar_qq[$na] = $newArr[$na];

}


}


#print_r($ar_qq);

Foreach($ar_qq as $s=>$ar_tt)
{

Foreach($ar_tt as $tt)
{


#$t = date("H:i", mktime(0, $tt, 0, 1, 1, 1970));

$ar_ss[$s][] = $tt;

}



}

#print_r($ar_ss);


If(mysqli_num_rows ($query) !== 0)
{

echo "

<script>



function replace_already_used_doc_msd(val_choiced,count_sp,screen)
{

//Выбранное значение из скрытого спана
var id_hid_sel_already_choiced_doc_msd = 'id_hid_sel_already_choiced_doc_msd_' + screen + '_' + count_sp;
var hid_sel_already_choiced_doc_msd = document.getElementById(id_hid_sel_already_choiced_doc_msd).innerHTML;


//выбранный id селекта
var id_sel_already_choiced_doc_msd = 'id_sel_already_choiced_doc_msd_' + screen + '_' + count_sp;


//запуск цикла класса

var class_sel_already_choiced_doc_msd = 'class_sel_already_choiced_doc_msd_' + screen;
var theOddOnes = document.getElementsByClassName(class_sel_already_choiced_doc_msd);

for(var i=0; i<theOddOnes.length; i++)
{

//получение ID из класса
var id_sel_already_choiced_doc_msd_circle = theOddOnes[i].id;

//получение выбранных значений селекта у перечисляемых в цикле
var x = document.getElementById(id_sel_already_choiced_doc_msd_circle);
var val_already_choiced_doc_msd_circle = x.options[x.selectedIndex].value;

if(id_sel_already_choiced_doc_msd !== id_sel_already_choiced_doc_msd_circle)
{

if(val_already_choiced_doc_msd_circle == val_choiced)
{


document.getElementById(id_sel_already_choiced_doc_msd_circle).options.namedItem(hid_sel_already_choiced_doc_msd).selected=true;

//замена скрытых спанов
//первоначальный скрытый спан
document.getElementById(id_hid_sel_already_choiced_doc_msd).innerHTML = val_choiced;

//второной скрытый спан
var id_hid_sel_already_choiced_doc_msd = 'id_hid_sel_already_choiced_doc_msd_' + screen + '_' + i;

document.getElementById(id_hid_sel_already_choiced_doc_msd).innerHTML = hid_sel_already_choiced_doc_msd;

}

}

}




}


function timeConvert_to_norm(n) {
var totalTimeInMin = n;
var h = Math.floor(totalTimeInMin / 60);
var m = totalTimeInMin % 60;
if(h < 10)
{
nh = '0' + h;
}
else{
nh = h;
}
if(m < 10)
{
nm = '0' + m;
}
else{
nm = m;
}
var exit = nh + ':' + nm;
return exit;
}


function timeConvert_to_min(n) {

var ar_n = n.split(':');
var h = Number(ar_n[0]);
var m = Number(ar_n[1]);

if(m == '00')
{
m = 0;
}
else if(m == '05')
{
m = 5;
}

var exit = (h*60) + m;

return exit;
}

function correct_time_msd(screen,i,type,val)
{

var d_val = Number(val);

if(type == 'up')
{

//id второго ползунка
var id_up_msd_time = 'id_up_msd_time_' + screen + '_' + i;

//Значение 2 ползунка
var up_msd_time = Number(document.getElementById(id_up_msd_time).value);

//преобразование входящих минут в норм время
var val_hm = timeConvert_to_norm(d_val);

if(d_val<up_msd_time)
{

//id 1го поля
var id_up_ntime_str = 'id_up_ntime_str_' + screen + '_' + i;
document.getElementById(id_up_ntime_str).innerHTML = val_hm;


}
else if(d_val>up_msd_time)
{

//id 2го поля
var id_down_ntime_str = 'id_down_ntime_str_' + screen + '_' + i;
document.getElementById(id_down_ntime_str).innerHTML = val_hm;

}
else if(d_val == up_msd_time)
{

//id 1го поля
var id_up_ntime_str = 'id_up_ntime_str_' + screen + '_' + i;
document.getElementById(id_up_ntime_str).innerHTML = val_hm;

//id 2го поля
var id_down_ntime_str = 'id_down_ntime_str_' + screen + '_' + i;
document.getElementById(id_down_ntime_str).innerHTML = val_hm;

}


}
else if(type == 'down')
{

//id первого ползунка
var id_low_msd_time = 'id_low_msd_time_' + screen + '_' + i;

//Значение 1 ползунка
var low_msd_time = Number(document.getElementById(id_low_msd_time).value);

//преобразование входящих минут в норм время
var val_hm = timeConvert_to_norm(d_val);

if(d_val<low_msd_time)
{

//id 1го поля
var id_up_ntime_str = 'id_up_ntime_str_' + screen + '_' + i;
document.getElementById(id_up_ntime_str).innerHTML = val_hm;


}
else if(d_val>low_msd_time)
{

//id 2го поля
var id_down_ntime_str = 'id_down_ntime_str_' + screen + '_' + i;
document.getElementById(id_down_ntime_str).innerHTML = val_hm;

}
else if(d_val == low_msd_time)
{

//id 1го поля
var id_up_ntime_str = 'id_up_ntime_str_' + screen + '_' + i;
document.getElementById(id_up_ntime_str).innerHTML = val_hm;

//id 2го поля
var id_down_ntime_str = 'id_down_ntime_str_' + screen + '_' + i;
document.getElementById(id_down_ntime_str).innerHTML = val_hm;

}


}

test_periods(screen);

}


function array_unique(arr) {
    var tmp_arr = new Array();
    for (i = 0; i < arr.length; i++) {
        if (tmp_arr.indexOf(arr[i]) == \"-1\") {
            tmp_arr.push(arr[i]);
        }
    }
    return tmp_arr;
}


function isAscending(arr) {
    return arr.every(function (x, i) {
        return i === 0 || x >= arr[i - 1];
    });
}



function multiDimensionalUnique(arr) {
     var uniques = [];
     var itemsFound = {};
     for(var i = 0, l = arr.length; i < l; i++) {
         var stringified = JSON.stringify(arr[i]);
         if(itemsFound[stringified]) { continue; }
         uniques.push(arr[i]);
         itemsFound[stringified] = true;
     }
     return uniques;
 }





function test_periods(screen)
{

var ar_ntime = new Array();
var ar_q = new Array();



var ntime = 'ntime_' + screen;

var theOddOnes = document.getElementsByClassName(ntime);


for(var i=0; i<theOddOnes.length; i++)
{

//var ar_q[i];

var ar_vls = new Array();

var v = theOddOnes[i].innerText;

var ar_v = v.split(' - ');

var beg_t = ar_v[0];
var end_t = ar_v[1];

var beg_t_min = timeConvert_to_min(beg_t);
var end_t_min = timeConvert_to_min(end_t);

for(beg_t_min; beg_t_min<=end_t_min; beg_t_min=beg_t_min+5)
{

ar_vls.push(beg_t_min);




}

ar_q.push(ar_vls);



var ar_vls =  '';



}


test_periods_2(ar_q);


//alert(array_intersect(ar_q));

}


function inArray(needle, haystack) {
    var length = haystack.length;
    for(var i = 0; i < length; i++) {
        if(haystack[i] == needle) return true;
    }
    return false;
}




function test_periods_2(arr)
{



//console.log(arr);

//бэкап входящего массива
var bu_arr = arr;

//статус
var stats = 'go';

//создать массив всего рабочего времени

var ar_wc = new Array();

for(var beg_t=540; beg_t<=1200; beg_t=beg_t+5)
{

ar_wc.push(beg_t);

}


var z=0;

for(var i=0; i<arr.length; i++)
{

var in_arr = arr[i];

var max_in_arr = Math.max.apply(Math, in_arr);
var min_in_arr = Math.min.apply(Math, in_arr);

ar_wc.push(max_in_arr);
//ar_wc.push(min_in_arr);


for(u=0; u<in_arr.length; u++)
{

var item = in_arr[u];

if(inArray(item, ar_wc))
{



var index = ar_wc.indexOf(item);
ar_wc.splice(index, 1);


}
else{

z++;

//alert(item);

}

}








}


if(z==0)
{

document.getElementById('but_save_active_msd').style.display = 'flex';
document.getElementById('but_save_inactive_msd').style.display = 'none';

//console.log(z);

}
else{

document.getElementById('but_save_inactive_msd').style.display = 'flex';
document.getElementById('but_save_active_msd').style.display = 'none';

//console.log(z);

}

var z = '';
}

</script>


";

//id_sel_already_choiced_doc_msd_1_1 -- 5bbed0bfc8ba7b7717d337d48be5b236

$c=0;
while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];
$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];
$color = $row['bg_color_gen'];

$ar_docs[$id_pers]['name_pers'] = $name_pers;
$ar_docs[$id_pers]['surname_pers'] = $surname_pers;
$ar_docs[$id_pers]['patronymic_pers'] = $patronymic_pers;

$ar_colors[$c] = $color;
$c++;
}


$count_ar_docs = count($ar_docs);






For($i=0;$i<$count_ar_docs;$i++)
{

$color = $ar_colors[$i];

echo "

<style>

.slider_",$screen,"_",$i," {

-webkit-appearance: none;
width: 100%;
height: 25px;
position: absolute;
background: #a4a4a4;
outline: none;


}

.slider_",$screen,"_",$i," input {

pointer-events: none;
position: absolute;
overflow: hidden;
left: 25%;
top: 15px;
width: 50%;
outline: none;
height: 18px;
margin: 0px;
padding: 0px;

}

.slider_",$screen,"_",$i,"::-webkit-slider-thumb {

-webkit-appearance: none;
appearance: none;
width: 35px;
height: 35px;
background: ",$color,";
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 1;
outline: 0;

}

.slider_",$screen,"_",$i,"::-moz-range-thumb {

width: 20px;
height: 20px;
background: #ea4550;
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 10;
-moz-appearance: none;
width: 9px;

}

.slider_",$screen,"_",$i," input::-moz-range-track {

position: relative;
z-index: -1;
border: 0;

}

.slider_",$screen,"_",$i," input:last-of-type::-moz-range-track {

-moz-appearance: none;
background: none transparent;
border: 0;

}

.slider_",$screen,"_",$i," input[type=range]::-moz-focus-outer {
border: 0;
}


</style>

<table border = \"0\" width = \"100%\" height = \"18%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">

";



If($i%2 == 0)
{
$bgc = "#222222";
}
Else{

$bgc = "#303030";
}

echo "

<tr style = \"background-color: ",$bgc,";\">

<td width = \"25%\">




<select style = \"font-weight: bold;\" onchange = \"replace_already_used_doc_msd(this.value,'",$i,"','",$screen,"');\" id = \"id_sel_already_choiced_doc_msd_",$screen,"_",$i,"\" class = \"class_sel_already_choiced_doc_msd_",$screen,"\">

";

$x=0;

Foreach($ar_docs as $id_pers=>$ar_vals)
{

$name_pers = $ar_vals['name_pers'];
$surname_pers = $ar_vals['surname_pers'];
$patronymic_pers = $ar_vals['patronymic_pers'];


echo "<option id = \"",$id_pers,"\" value = \"",$id_pers,"\"";

If($i == $x)
{

echo " selected";
$id_selected = $id_pers;
}

echo ">",$surname_pers," ",$name_pers," ",$patronymic_pers,"</option>";

$x++;
}


$count_hours = $ar_ss[$i];

$begin = array_shift($count_hours);
$end = end($count_hours);

echo "

</select>



<span id = \"id_hid_sel_already_choiced_doc_msd_",$screen,"_",$i,"\" style = \"display: none;\">",$id_selected,"</span>

</td>

<td style = \"position: relative; padding-bottom: 25px;\" align = \"left\">


<input oninput = \"correct_time_msd('",$screen,"','",$i,"','up',this.value);\" class=\"slider_",$screen,"_",$i,"\" id=\"id_low_msd_time_",$screen,"_",$i,"\" type=\"range\" step = \"5\" min=\"540\" max=\"1200\" value=\"",$begin,"\">
<input oninput = \"correct_time_msd('",$screen,"','",$i,"','down',this.value);\" class=\"slider_",$screen,"_",$i,"\" id=\"id_up_msd_time_",$screen,"_",$i,"\" type=\"range\" step = \"5\" min=\"540\" max=\"1200\" value=\"",$end,"\">


</td>

<td style = \"color: white; font-weight: bold;\" width = \"20%\">";

$t_begin = date("H:i", mktime(0, $begin, 0, 1, 1, 1970));
$t_end = date("H:i", mktime(0, $end, 0, 1, 1, 1970));

echo "<span style = \"cursor: default;\" id = \"id_ntime_",$screen,"_",$i,"\" class = \"ntime_",$screen,"\"><span id = \"id_up_ntime_str_",$screen,"_",$i,"\">",$t_begin,"</span> - <span id = \"id_down_ntime_str_",$screen,"_",$i,"\">",$t_end,"</span></span>";

echo "</td>

</tr>
</table>

";

}




}






}

?>
