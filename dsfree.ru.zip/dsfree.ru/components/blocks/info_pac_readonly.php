<?php

function info_pac_readonly($vals)
{

#print_r($vals);

$id_ent = $vals['param'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_ent where id_ent = '$id_ent'";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$id_pac = $row['id_pacs'];
}



include_once("../components/blocks/get_info_pac_by_id_pac.php");
$ar_pac = get_info_pac_by_id_pac($id_pac);

$ar_months_rus = array(""=>"месяц","01"=>"январь","02"=>"февраль","03"=>"март","04"=>"апрель","05"=>"май","06"=>"июнь","07"=>"июль","08"=>"август","09"=>"сентябрь","10"=>"октябрь","11"=>"ноябрь","12"=>"декабрь");

$ar_sex_pac = array(""=>"пол","w"=>"жен","m"=>"муж");

$sql = "select * from abbreviations where type in('atd','uds','tz')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
while($row_abr = mysqli_fetch_assoc($query))
{

$type = $row_abr['type'];
$name_short = $row_abr['name_short'];
$name_full = $row_abr['name_full'];

$ar_abr[$type][$name_short] = $name_full;
}
}

#print_r($ar_abr);

$ar_atd = $ar_abr['atd'];
$ar_uds = $ar_abr['uds'];
$ar_tz = $ar_abr['tz'];


#print_r($ar_atd);

echo "

<style>

* {
    box-sizing: border-box;
}

input{
width: 95%;
height: 70%;
 background: transparent;
 border: none;
    border-bottom: 1px solid grey;
color: white;
font-size: 18px;
font-weight: bold;
}

input:focus{
outline:none;

}

input::-webkit-input-placeholder {font-size:15px;}

select:focus{
outline:none;

}


</style>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #242424;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"10%\" style = \"background-color: black; color: white; font-weight: bold;\">
<td >
Информация о пациенте (только чтение)
</td>
</tr>
<tr height = \"30%\">
<td align = \"center\">

<table border = \"0\" width = \"99%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #242424;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"font-size: 13px; border: 0px;\">
<td>
установочные данные
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"25%\">
<input readonly placeholder = \"фамилия\" value = \"",$ar_pac['surname_pac'],"\">
</td>
<td width = \"25%\">
<input placeholder = \"имя\" value = \"",$ar_pac['name_pac'],"\" readonly>
</td>
<td width = \"25%\">
<input placeholder = \"отчество\" value = \"",$ar_pac['patronymic_pac'],"\" readonly>
</td>
<td>

<select disabled style = \"background-color: #2E3436; color: white;\">
";

Foreach($ar_sex_pac as $ss=>$srus)
{
echo "<option";

If($ss == $ar_pac['sex_pac'])
{
echo " selected";

}

echo " value = \"",$ss,"\">",$srus,"</option>";

}

echo "
</select>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>

<td>
<span id = \"span_sel_birth_pac_day\">

";

If($ar_pac['birth_pac_day'] !== "")
{

$birth_pac_day = $ar_pac['birth_pac_day'];

$birth_pac_month = $ar_pac['birth_pac_month'];
$birth_pac_year = $ar_pac['birth_pac_year'];

If($birth_pac_month !== "" and $birth_pac_year !== "")
{

$number = cal_days_in_month(CAL_GREGORIAN, $birth_pac_month, $birth_pac_year);

echo "

<select disabled style = \"width: 25%; background-color: #2E3436; color: white;\">
<option value = \"\">день</option>";

For($i=1;$i<=$number;$i++)
{

echo "<option";

If($i == $ar_pac['birth_pac_day'])
{
echo " selected";
}

echo " value = \"",$i,"\">",$i,"</option>";

}

echo "
</select>

";


}
Else{

echo "

<select disabled style = \"width: 25%; background-color: #2E3436; color: white;\">
<option value = \"\">день</option>
</select>
";

}


}
Else{

echo "

<select disabled style = \"width: 25%; background-color: #2E3436; color: white;\">
<option value = \"\">день</option>
</select>
";




}

echo "





</span>

<select disabled style = \"background-color: #2E3436; color: white;\">

";

Foreach($ar_months_rus as $nm=>$rusm)
{

echo "<option";

If($nm == $ar_pac['birth_pac_month'])
{
echo " selected";
}

echo " value = \"",$nm,"\">",$rusm,"</option>";

}

echo "
</select>

<input readonly style = \"width: 33%;\" placeholder = \"год рож-я\" value = \"",$ar_pac['birth_pac_year'],"\">
</td>

<td>
<input placeholder = \"телефон\" value = \"",$ar_pac['phone'],"\" readonly>
</td>
<td>

<input placeholder = \"электронная почта и тд\" value = \"",$ar_pac['email'],"\" readonly>

</td>
<td>

<input placeholder = \"род деятельности\" value = \"",$ar_pac['deyatel'],"\" readonly>

</td>

</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
</table>


</td>
</tr>
<tr height = \"30%\">
<td align = \"center\">

<table border = \"0\" width = \"99%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #242424;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"font-size: 13px; border: 0px;\">
<td>
адрес
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"50%\">
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\">
<td width = \"15%\">

<input placeholder = \"страна\" value = \"",$ar_pac['country_pac'],"\" readonly>

</td>
<td width = \"25%\">
<input placeholder = \"регион\" value = \"",$ar_pac['obl_pac'],"\" readonly>
</td>
<td width = \"25%\">


<select disabled style = \"background-color: #2E3436; color: white;\">
<option>тип АТД</option>
";

Foreach($ar_atd as $satd=>$fatd)
{
echo "<option";

If($satd == $ar_pac['type_atd_pac'])
{
echo " selected";
}

echo " value = \"",$satd,"\">",$fatd,"</option>";
}

echo "
</select>


</td>
<td>

<input placeholder = \"название АТД\" value = \"",$ar_pac['city_pac'],"\" readonly>

</td>
</tr>
</table>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"15%\">

<select disabled style = \"background-color: #2E3436; color: white;\">
<option>тип УДС</option>
";

Foreach($ar_uds as $suds=>$fuds)
{
echo "<option";

If($suds == $ar_pac['type_street_pac'])
{
echo " selected";
}

echo " value = \"",$suds,"\">",$fuds,"</option>";
}
echo "
</select>

</td>
<td width = \"20%\">

<input placeholder = \"название УДС\" value = \"",$ar_pac['street_pac'],"\" readonly>

</td>
<td width = \"15%\">

<select disabled style = \"background-color: #2E3436; color: white;\">
<option>тип здания</option>
";

Foreach($ar_tz as $stz=>$ftz)
{
echo "<option";

If($stz == $ar_pac['type_house_pac'])
{
echo " selected";
}

echo " value = \"",$stz,"\">",$ftz,"</option>";
}

echo "
</select>

</td>

<td width = \"15%\">

<input placeholder = \"номер здания\" value = \"",$ar_pac['house_pac'],"\" readonly>

</td>

<td width = \"10%\">

<input placeholder = \"квартира\" value = \"",$ar_pac['flat_pac'],"\" readonly>

</td>

</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>
</table>


</td>
</tr>
<tr height = \"17%\">
<td align = \"center\">

<table border = \"0\" width = \"99%\" height = \"100%\" style = \"border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"font-size: 13px; border: 0px; background-color: #242424;\">
<td>
документ и его сведения
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td align = \"center\">
<input placeholder = \"название документа и его данные\" value = \"",$ar_pac['docum'],"\" readonly>
</td>
</tr>
</table>

</td>
</tr>
<tr>
<td align = \"center\">

<table border = \"0\" width = \"99%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"5%\" style = \"font-size: 13px; border: 0px; background-color: #242424;\">
<td align = \"left\">
3-и лица
</td>
</tr>
<tr style = \"border: 1px solid grey;\">
<td align = \"center\">

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

</td>

</tr>
</table>

</td>
</tr>
</table>

</td>
</tr>
</table>

";


}

?>
