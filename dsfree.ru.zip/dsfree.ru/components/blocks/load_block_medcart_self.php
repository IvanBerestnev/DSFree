<?php

function load_block_medcart_self($vals)
{


#print_r($vals);

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_visits where id_visit = '$id_visit'";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$id_pac = $row['id_pac'];
$ds = $row['ds'];
#$date_time = $row['date_time'];

$txt_treat = $row['txt_treat'];
$ar_txt_treat = json_decode($txt_treat,true);

#print_r($ar_txt_treat);

echo "<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; background-color: black;\" cellpadding=\"0\" cellspacing= \"0\">";

If(isset($ar_txt_treat))
{

Foreach($ar_txt_treat as $id_writed_razd=>$ar_valls)
{

$cont = $ar_valls['cont'];
$name = $ar_valls['name'];
$templ = $ar_valls['templ'];

If($templ !== "")
{
$ar_templ = explode("@",$templ);
$id_struct = $ar_templ[0];
$id_razd = $ar_templ[1];
$id_ds_templ = $ar_templ[2];
}
Else{
$id_struct = "";
$id_razd = "";
$id_ds_templ = "";
}

echo "
<tr height = \"20px\">
<td>
</td>
</tr>
<tr >
<td height = \"30px\" style = \"background-color: #3A3A3A;\">

<table border = \"0\" align = \"left\" height =\"100%\" width = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td >
<span id = \"name_razdel_medcart_self_",$id_writed_razd,"_",$screen,"\" onclick = \"load_page_edit_param_medcart_self('",$id_visit,"','",$id_writed_razd,"','rename_razdel','",$screen,"');\" style = \"cursor: pointer;\">",$name,"</span>
</td>
<td onclick = \"save_new_txt_razd_visit('",$id_visit,"','",$id_writed_razd,"','",$screen,"');\" align = \"center\" width = \"10%\" style = \"background-color: green; padding-left: 20px; padding-right: 20px; cursor:pointer;\">сохранить
</td>
<td onclick = \"reload_txt_razd_visit('",$id_visit,"','",$id_writed_razd,"','",$screen,"');\" align = \"center\" width = \"10%\" style = \"background-color: orange; padding-left: 20px; padding-right: 20px; cursor:pointer;\">сброс
</td>
<td onclick = \"load_page_temple_razd_visit('",$id_visit,"','",$id_writed_razd,"','",$screen,"');\" align = \"center\" width = \"10%\" style = \"background-color: #008080; padding-left: 20px; padding-right: 20px; cursor:pointer;\">шаблон
</td>
<td onclick = \"load_page_edit_param_medcart_self('",$id_visit,"','",$id_writed_razd,"','delete_razdel','",$screen,"');\" align = \"center\" width = \"10%\" style = \"background-color: #FF8080; cursor:pointer;\">Х
</td>

</tr>
</table>


</td>
</tr>
<tr>
<td height = \"150px\">
<textarea id = \"textarea_",$id_writed_razd,"_",$screen,"\" style = \"width: 100%; height: 100%; background-color: #2E3336; color: white; font-weight: bold;\">",$cont,"</textarea></td>
</tr>

";

}

echo "</table>";

}
Else{

echo "

<table id = \"medcart_self_table_no_any_inf_",$screen,"\" border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; \" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td align = \"center\" valign = \"bottom\" style = \"cursor: default;\">
недостаточно данных для отображения структуры записи
</td>
</tr>
<tr height = \"10%\">
<td align = \"center\">
<span onclick = \"edit_first_docum('edit_medcart_step1','",$id_pac,"','",$screen,"');\" style = \"border: 1px solid white; padding: 20px; cursor: pointer; background-color: grey; color: white;\">перейти к шаблонам</span>
</td>
</tr>
<tr>
<td align = \"center\" valign = \"top\">
<span style = \"cursor: pointer;\" onclick = \"medcart_self_table_no_any_inf_hidden('",$screen,"');\">скрыть это сообщение и продолжить вручную</span>
</td>
</tr>

</table>

";
}

}
Else{

echo "<table border = \"1\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
данного посещения не существует
</td>
</tr>
</table>
";

}


}

?>
