<?php

function load_menu_ctlr_type_setka($vals)
{
#echo "123";
$id_used_ssetka = $vals['id_used_ssetka'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_used_ssetka where id_used_ssetka = '$id_used_ssetka'";
#echo $sql;die();
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$used = $row['used'];

$json_vals = $row['vals'];
$vals = json_decode($json_vals,true);

$key = key($vals);

If($key == "simple")
{

#print_r($vals);
$cols = $vals[$key]['params']['cols'];
$rows = $vals[$key]['params']['rows'];
$spacex = $vals[$key]['params']['spacex'];
$spacey = $vals[$key]['params']['spacey'];


echo "
<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td rowspan = \"2\">
Столбцов: 
<select onchange = \"change_settings_ssetka('",$id_used_ssetka,"','cols',this.value);\">
";

For($c=1;$c<=10;$c++)
{
echo "<option";
If($c==$cols)
{
echo " selected";
}
echo " value = \"",$c,"\">",$c,"</option>";
}

echo "
</select>

Строк: 

<select onchange = \"change_settings_ssetka('",$id_used_ssetka,"','rows',this.value);\">
";

For($r=1;$r<=10;$r++)
{
echo "<option";
If($r==$rows)
{
echo " selected";
}
echo " value = \"",$r,"\">",$r,"</option>";
}

echo "
</select>

</td>
<td>

Пространство между окнами

</td>

<td rowspan = \"2\">";

If($used == "")
{
echo "<button onclick = \"act_default_ssetka('",$id_used_ssetka,"');\" style = \"padding-left: 5px; padding-right: 5px; padding-top: 8px; padding-bottom: 8px;\">
Использовать по умолчанию
</button>";
}
Else{
echo "<button disabled style = \"padding-left: 5px; padding-right: 5px; padding-top: 8px; padding-bottom: 8px; font-weight: bold;\">
Используется по умолчанию
</button>";
}



echo "
</td>
<td width = \"10%\" rowspan = \"2\">


<button onclick = \"delete_ssetka_from_profile('",$id_used_ssetka,"');\" style = \"padding-left: 5px; padding-right: 5px; padding-top: 8px; padding-bottom: 8px;\">
Удалить
</button>

</td>
</tr>
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Ось Х
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','spacex',this.value);\" value = \"",$spacex,"\" size = \"2\" style = \"text-align: center;\">
</td>
<td>
Ось Y
<input onkeyup = \"change_settings_ssetka('",$id_used_ssetka,"','spacey',this.value);\" value = \"",$spacey,"\" size = \"2\" style = \"text-align: center;\">
</td>
</tr>
</table>

</td>
</tr>

</table>

<script>
load_menu_setka_self('",$id_used_ssetka,"');
</script>

";
}
ElseIf($key == "special")
{

echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; font-weight: bold; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>

<td>";

If($used == "")
{
echo "<button onclick = \"act_default_ssetka('",$id_used_ssetka,"');\" style = \"padding-left: 5px; padding-right: 5px; padding-top: 8px; padding-bottom: 8px;\">
Использовать по умолчанию
</button>";
}
Else{
echo "<button disabled style = \"padding-left: 5px; padding-right: 5px; padding-top: 8px; padding-bottom: 8px; font-weight: bold;\">
Используется по умолчанию
</button>";
}

echo "
</td>

<td align = \"center\">
<button onclick = \"load_menu_ctlr_type_setka('",$id_used_ssetka,"'); load_menu_setka_self('",$id_used_ssetka,"');\" id = \"id_but_reset_ssetka\" style = \"padding-left: 5px; padding-right: 5px; padding-top: 8px; padding-bottom: 8px; display: none;\">
Перезагрузить сетку
</button>
</td>

<td>

<button onclick = \"delete_ssetka_from_profile('",$id_used_ssetka,"');\" style = \"padding-left: 5px; padding-right: 5px; padding-top: 8px; padding-bottom: 8px;\">
Удалить
</button>

</td>
</tr>
</table>

<script>
load_menu_setka_self('",$id_used_ssetka,"');
</script>

";

}


}


}

?>
