<?php

function ctrl_jurpacs_doc_review($vals)
{

$id_pers = $vals['id_pers'];
$screen = $vals['screen'];
$act = $vals['act'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

If($act == "choice")
{

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");
$sql = "select * from tab_personal where id_pers = '$id_pers'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$surname = $row['surname_pers'];
$id_pers = $row['id_pers'];

echo "
<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td style = \"position: relative;\">

<span onclick = \"close_choice_pers('",$screen,"');\" style = \"position: absolute; top: 0px; right: 0px; padding: 5px 15px; background-color: red;\">X</span>
";

//load_jurpacs('",$screen,"');
//load_ctrl_jurpacs('doc','",$screen,"');

echo $surname;

echo "
<span style = \"display: none;\" id = \"f_ctrl_id_pers_",$screen,"\">",$id_pers,"</span>
</td>
</table>

<script>
load_jurpacs('",$screen,"');
</script>

";

}

}
ElseIf($act == "bg")
{



echo "bg";

}




}

?>
