<?php

function recalc_days_in_months_az($vals)
{

#print_r($vals);

$year = $vals['year'];
$month = $vals['month'];
$screen = $vals['screen'];



$number = cal_days_in_month(CAL_GREGORIAN, $month, $year);

echo "

<select id = \"select_day_az_",$screen,"\">";

For($i=1;$i<=$number;$i++)
{

$d = date("d", mktime(0, 0, 0, 1, $i, 1970));

echo "<option value = \"",$d,"\">",$d,"</option>";
}


echo "
</select>

";




}


?>
