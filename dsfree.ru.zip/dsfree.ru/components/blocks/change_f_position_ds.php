<?php

function change_f_position_ds($vals)
{

#print_r($vals);

$position_preds_income = $vals['position_preds'];
$screen = $vals['screen'];
$id_ds_income = $vals['id_ds_income'];
$id_str_templ = $vals['id_str_templ'];
$id_tm = $vals['id_tm'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_templ_medcart where id_tm = '$id_tm'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);
$text = $row['text'];
$json = preg_replace('/[[:cntrl:]]/', '', $text);

$ar_decoded = json_decode($json,true);

$ar_razd = $ar_decoded[$id_ds_income][$id_str_templ]['cont'];

$selected_position_ds_after_razd = $ar_decoded[$id_ds_income][$id_str_templ]['locat_ds'];

Foreach($ar_razd as $id_razd=>$ar_valls)
{
$name_razd = $ar_valls['name'];

If($name_razd == $position_preds_income)
{
continue;
}

$ar_razds[$name_razd] = $name_razd;
}

If(!empty($ar_razd))
{

If($position_preds_income == "disabled")
{
$ar_razd_ds_add['first_position'] = "Первая позиция";
}
Else{
$ar_razd_ds_add['after_preds'] = "После предварительного диагноза";
}

$ar_razd_ds_add['disabled'] = "Отключен";

$ar_razd_ds = array_merge($ar_razd_ds_add, $ar_razds);



#print_r($ar_razd);

echo "<select id = \"id_sel_position_ds_",$screen,"\" style = \"text-align: center; width: 75%;\">";

Foreach($ar_razd_ds as $key=>$val)
{
echo "<option";

If($key == $selected_position_ds_after_razd)
{
echo " selected";
}

echo " value = \"",$key,"\">",$val,"</option>";
}


echo "</select>";


}

}

}


?>
