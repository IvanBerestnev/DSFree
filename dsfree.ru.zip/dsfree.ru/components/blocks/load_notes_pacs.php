<?php

function load_notes_pacs($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$surname = $vals['surname'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_ent where mark_ent != ''";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
while($row = mysqli_fetch_assoc($query))
{

$ar_id_ent[] = $row['id_ent'];
$ar_id_pacs[] = $row['id_pacs'];

}



}
Else{

echo "
<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
В базе данных нет каких-либо заметок
</td>
</tr>
</table>
";

}

If(isset($ar_id_pacs))
{

$str_id_pacs = implode("','",$ar_id_pacs);

If($surname !== "")
{
$sql = "select * from tab_pacs where id_pac IN('$str_id_pacs') and surname_pac = '$surname' order by surname_pac ASC";
}
Else{
$sql = "select * from tab_pacs where id_pac IN('$str_id_pacs') order by surname_pac ASC";
}

$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\"  style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_pac = $row['id_pac'];
$surname_pac = $row['surname_pac'];
$name_pac = $row['name_pac'];

echo "
<tr class = \"tr_load_notes_pacs_",$screen,"\" style = \"cursor: pointer;\" height = \"40px\">
<td onclick = \"open_modal_mark_ent('",$screen,"','",$id_pac,"');\" align = \"left\" style = \"padding-left: 5px;\">
",$surname_pac," ",$name_pac,"
</td>
</tr>
<tr height = \"5px\">
<td></td>
</tr>
";

}

echo "</table>";


}
Else{

echo "
<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
нет клиентов, удовлетворяющим критериям поиска
</td>
</tr>
</table>
";

}


}




}

?>
