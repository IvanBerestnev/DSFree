<?php

function load_types_inventar($vals)
{

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select distinct(type) from limit_list";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{
echo "<select onchange = \"load_block_inventar('",$screen,"','show_all');\" id = \"sel_choice_type_load_block_inventar_",$screen,"\">
<option value = \"\">все категории</option>
";
while($row = mysqli_fetch_assoc($query))
{
$type = $row['type'];

echo "<option value=\"",$type,"\">",$type,"</option>";

}

echo "</select>";


}



}

?>
