<?php

function note_pac_modal($vals)
{

#print_r($vals);

$id_ent = $vals['param'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_ent where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$mark_ent = $row['mark_ent'];
}
Else{
$mark_ent = "";
}

echo "

<script>

function update_mark_ent(id_ent,val,screen)
{



var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('update_mark_ent') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[val]=\" + encodeURIComponent(val) + \"&data[id_ent]=\" + encodeURIComponent(id_ent));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var hidden_note_pac_modal = 'hidden_note_pac_modal_' + screen;

var cont = document.getElementById(hidden_note_pac_modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>

<style>
#note_textarea_",$screen,":focus, input:focus{
outline: none;
}
</style>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; text-align: center; color: white; cursor: pointer; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"background-color: black;\">
<td>
Заметка к приему
</td>
</tr>
<tr>
<td>
<textarea onkeyup = \"update_mark_ent('",$id_ent,"',this.value,'",$screen,"');\" style = \"width: 100%; height: 100%; padding: 10px; font-size: 20px;\" id = \"note_textarea_",$screen,"\" placeholder = \"текст заметки\">",$mark_ent,"</textarea>
</td>
</tr>

</table>

<span style = \"display: none;\" id = \"hidden_note_pac_modal_",$screen,"\"></span>

";

}

?>
