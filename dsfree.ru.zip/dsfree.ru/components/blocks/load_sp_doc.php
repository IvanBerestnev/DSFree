<?php

function load_sp_doc($vals)
{

#print_r($vals);
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_personal where type = 'doc'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows ($query) !== 0)
{
	


while($row = mysqli_fetch_assoc($query))
{

$id_pers = $row['id_pers'];

$name_pers = $row['name_pers'];
$surname_pers = $row['surname_pers'];
$patronymic_pers = $row['patronymic_pers'];

$color = $row['bg_color_gen'];


echo "
<table border = \"1\" height = \"150px\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #404040; color: white; margin-top: 10px;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td width = \"40%\">

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"table-layout: fixed; border-collapse: collapse; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"60%\" align = \"center\">
<td>

<input onkeyup = \"change_fio_doc('",$id_pers,"','surname_pers',this.value);\" placeholder = \"фамилия врача\" value = \"",$surname_pers,"\" style = \"width: 90%; height: 80%; font-weight: bold; font-size: 18px;\">

</td>
<td>

<input onkeyup = \"change_fio_doc('",$id_pers,"','name_pers',this.value);\" placeholder = \"имя врача\" value = \"",$name_pers,"\" style = \"width: 90%; height: 80%; font-weight: bold; font-size: 18px;\">

</td>
<td>

<input onkeyup = \"change_fio_doc('",$id_pers,"','patronymic_pers',this.value);\" placeholder = \"отчество врача\" value = \"",$patronymic_pers,"\" style = \"width: 90%; height: 80%; font-weight: bold; font-size: 18px;\">

</td>
</tr>
<tr>
<td onclick = \"change_color_doc('",$screen,"','",$id_pers,"');\" colspan = \"3\" style = \"background-color: ",$color,"; cursor: pointer;\">
</td>
</tr>
</table>

</td>
<td align = \"center\">



<table border = \"1\" height = \"90%\" width = \"98%\" style = \"border-collapse: collapse; table-layout: fixed; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<div id = \"f_certs_docs_",$id_pers,"_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\"></div>

</td>
<td onclick = \"add_cert_doc('",$screen,"','",$id_pers,"');\" width = \"60px\" style = \"background-color: green; color: white; font-weight: bold; cursor: pointer;\" align = \"center\">
+
</td>
</tr>
</table>

</td>
<td onclick = \"delete_doc('",$screen,"','",$id_pers,"');\" align = \"center\" width = \"3%\" style = \"background-color: #ED8984; color: white; font-weight: bold; cursor: pointer;\">
X
</td>
</tr>
</table>
<script>load_cert_doc('",$screen,"','",$id_pers,"');</script>
";

}


#echo "</table>";

}




}

?>
