<?php

function load_block_act_dw_admin($vals)
{

$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from pacs_visits where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{
$ar_visits[] = "'".$row['id_visit']."'";
}

$str_visits = implode(",",$ar_visits);

$sql = "select * from tab_act_dw where id_visit IN (".$str_visits.")";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "



<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; margin-top: 10px;\" cellpadding=\"0\" cellspacing= \"0\">




";

while($row = mysqli_fetch_assoc($query))
{

$id_act_dw = $row['id_act_dw'];
$status = $row['status'];
$date_write = $row['date_write'];



echo "
<tr >
<td height = \"120px\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border-bottom: 1px dashed #3A3A3A;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\">
<td align = \"left\" style = \"padding-left: 5px; background-color: #3A3A3A;\">",$date_write," 

</td>
</tr>
<tr>
<td style = \"background-color: #2E3336;\">
";


If($status == "0")
{
echo "<span style = \"color: #8080FF;\">Акт в стадии заполнения</span>";
}
ElseIf($status == "1")
{
echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border-bottom: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td colspan = \"2\">
Принять акт выполненных работ?
</td>
</tr>
<tr height = \"40%\">
<td width = \"50%\" onclick = \"act_block_act_dw_admin('admin_accept_no','",$id_act_dw,"','",$screen,"');\" style = \"background-color: #FF8080; cursor: pointer;\">
нет
</td>
<td style = \"background-color: #008080;\" onclick = \"act_block_act_dw_admin('admin_accept_yes','",$id_act_dw,"','",$screen,"');\">
да
</td>
</tr>
</table>



";
}
ElseIf($status == "2")
{
echo "


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border-bottom: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"30%\">
<td>

</td>
<td onclick = \"act_block_act_dw_admin('admin_accept_no','",$id_act_dw,"','",$screen,"');\" style = \"background-color: #FF8080; color: white; cursor: pointer;\">
отменить
</td>

</tr>

<tr>
<td colspan = \"2\">
Акт принят админом
</td>
</tr>

<tr height = \"30%\">
<td width = \"50%\" onclick = \"act_block_act_dw_admin('admin_accept_no','",$id_act_dw,"','",$screen,"');\" style = \"background-color: #8080FF; cursor: pointer;\">
печать
</td>
<td onclick = \"modal_block_act_dw_admin('page_accept_pay_pacient','",$id_act_dw,"','",$screen,"');\" style = \"background-color: #008080; cursor: pointer;\" onclick = \"act_block_act_dw_admin('admin_accept_yes','",$id_act_dw,"','",$screen,"');\">
оплатить
</td>
</tr>
</table>

";
}
ElseIf($status == "3")
{
echo "


<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; border-bottom: 1px solid black;\" cellpadding=\"0\" cellspacing= \"0\">
<tr >
<td style = \"color: #F5C211;\">
Акт оплачен пациентом
</td>
</tr>
</table>

";
}
ElseIf($status == "4")
{
echo "данное посещение без оплаты";
}

echo "

</td>
</tr>
</table>

</td>
</tr>
<tr height = \"30px\">
<td>

</td>
</tr>
";

}

echo "</table>";

}





}
Else{

echo "

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; margin-top: 10px;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Не найдено актов выполненных работ
</td>
</tr>
</table>

";

}


}

?>
