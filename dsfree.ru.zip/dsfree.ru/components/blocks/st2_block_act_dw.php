<?php

function st2_block_act_dw($vals)
{

$id_visit = $vals['id_visit'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_act_dw where id_visit = '$id_visit'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

$row = mysqli_fetch_assoc($query);

$works = $row['works'];
$discont = $row['discont'];

If($discont == "")
{
$discont = 0;
}

If($works !== "")
{

$ar = json_decode($works,true);


echo "

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td rowspan = \"2\" width = \"25%\" style = \"background-color: #111111;\">
</td>
<td>

<table border = \"0\" align = \"left\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\"> 
<td width = \"50%\" style = \"padding-left: 10px;\">
Выбрано:
</td>
<td align = \"center\">
<div style = \"background-color: #008080;\">
ПРИНЯТО
</div>
</td>
</tr>
<tr>
<td colspan = \"2\">
<div style = \"width: 100%; height: 100%; overflow-y: scroll;\">

<table border = \"0\" align = \"left\" width = \"100%\" style = \" border-collapse: collapse; text-align: left; color: white; font-weight: bold; background-color: #22272B;\" cellpadding=\"0\" cellspacing= \"0\">
";

$i=1;

Foreach($ar as $id_dw=>$ar_valls)
{

$name = $ar_valls['name'];
$full_cost = $ar_valls['full_cost'];
$ar_full_cost = explode(";",$full_cost);
$count_ar_full_cost = count($ar_full_cost);

Foreach($ar_full_cost as $no_cost)
{

$ar_no_cost = explode("-",$no_cost);
$n_cost = $ar_no_cost['0'];
$ar_n_cost[] = (int)$n_cost;

}

echo "
<tr>
<td style = \"padding-left: 10px;\">
",$i,") ",$name," (",$count_ar_full_cost," шт.)
</td>
</tr>
<tr height = \"15px\">
<td>
</td>
</tr>
";
$i++;
}

$summ_ar_n_cost = array_sum($ar_n_cost)-(array_sum($ar_n_cost)*$discont)/100;


echo "

</table>

</div>
</td>
</tr>
</table>



</td>
<td rowspan = \"2\" width = \"25%\" style = \"background-color: #111111;\">
</td>
</tr>
<tr height = \"15%\" style = \"background-color: #1D1D1D;\">
<td>Общая сумма ",$summ_ar_n_cost," р.
</td>
</tr>

</table>

";



}

}




}

?>
