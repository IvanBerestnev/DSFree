<?php

function load_sets_jurnal_pso($vals)
{

$name_page = $vals['name_page'];
$screen = $vals['screen'];

If($name_page == "azopiram")
{

echo "

<script>

function load_azopiram_agent(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_azopiram_agent') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_id_azopiram_agent = 'f_id_azopiram_agent_' + screen;

var cont = document.getElementById(f_id_azopiram_agent);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function add_new_azopiram_agent(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_azopiram_agent') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

load_azopiram_agent(screen);

}
}
}

}


function add_new_info_steril_kits(val,type,id)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('add_new_info_steril_kits') + \"&data[val]=\" + encodeURIComponent(val) + \"&data[type]=\" + encodeURIComponent(type) + \"&data[id]=\" + encodeURIComponent(id));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



}
}
}

}


function page_cnfm_del_st_kit(id,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_cnfm_del_st_kit') + \"&data[id]=\" + encodeURIComponent(id) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '30%';
document.getElementById(modal_first).style.height = '15%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}



}
}
}

}

function act_delete_st_kit(id,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('act_delete_st_kit') + \"&data[id]=\" + encodeURIComponent(id));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_'+ screen;
close_mw(fon_modal_first);
load_steril_kits(screen);


}
}
}


}

</script>

<table border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td>

<div id = \"f_id_azopiram_agent_",$screen,"\" style = \"height: 100%; overflow-y:scroll;\"></div>

</td>
</tr>

<tr height = \"10%\" style = \"background-color: #008080; font-weight: bold; cursor: pointer;\">
<td onclick = \"add_new_azopiram_agent('",$screen,"');\">
+
</td>
</tr>
</table>


<script>
load_azopiram_agent('",$screen,"');
</script>

";


}
ElseIf($name_page == "method")
{


include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


echo "
<script>
function load_method(screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_method') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_id_method_exclud = 'f_id_method_exclud_' + screen;

var cont = document.getElementById(f_id_method_exclud);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

}

function page_add_new_excludes_jur_pso(screen)
{


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_page=\" + encodeURIComponent('page_add_new_excludes_jur_pso') + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var fon_modal_first = 'fon_modal_first_' + screen;
document.getElementById(fon_modal_first).style.display = 'block';

var modal_first = 'modal_first_' + screen;

document.getElementById(modal_first).style.width = '20%';
document.getElementById(modal_first).style.height = '35%';

var cont = document.getElementById(modal_first);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}


}
}
}


}

function delete_from_jur_pso_excludes(num,screen)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('delete_from_jur_pso_excludes') + \"&data[num]=\" + encodeURIComponent(num) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

load_method(screen);

}
}
}

}

function change_method_default(screen,val)
{

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('change_method_default') + \"&data[val]=\" + encodeURIComponent(val) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



}
}
}


}


</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white;\" cellpadding=\"0\" cellspacing= \"0\">

<tr>
<td width = \"40%\" style = \"border-right: 1px solid black;\">

Используемый по умолчанию метод дезинфекции

<br>
<br>

<select onchange = \"change_method_default('",$screen,"',this.value);\">
";

$ar_methods = array("man"=>"ручной","mech"=>"механический");

$sql = "select * from tab_misc_sets where id = '4'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$val = $row['val'];
$ar_decoded = json_decode($val,true);
$def_methods = $ar_decoded['method']['default'];
}
Else{
$def_methods = "";
}

echo $def_methods;

Foreach($ar_methods as $k=>$m)
{
echo "<option";

If($k == $def_methods)
{
echo " selected";	
}

echo " value = \"",$k,"\">",$m,"</option>";
}

//<option>ручной</option>
//<option>механический</option>


echo "</select>

</td>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; color: white; cursor: default; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"15%\" style = \"border-bottom: 1px solid black;\">
<td>
Исключения:
</td>
</tr>
<tr>
<td>

<div id = \"f_id_method_exclud_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\"></div>

</td>
</tr>
<tr onclick = \"page_add_new_excludes_jur_pso('",$screen,"');\" height = \"10%\" style = \"background-color: #008080; color: white; font-weight: bold; cursor: pointer;\">
<td>
+
</td>
</tr>
</table>

</td>
</tr>
</table>

<script>
load_method('",$screen,"');
</script>

";

}

}

?>
