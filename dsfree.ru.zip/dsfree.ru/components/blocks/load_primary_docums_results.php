<?php

function load_primary_docums_results($vals)
{

#print_r($vals);
$surname_pac = $vals['surname_pac'];
$screen = $vals['screen'];

If($surname_pac == "")
{
	
#echo "пустой запрос";

echo "

<script>

function load_primary_docums_type_pacs(type,screen)
{


switch_selected_button_type_pac_primary_docums(type,screen);


var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"load_block=\" + encodeURIComponent('load_primary_docums_type_pacs') + \"&data[type]=\" + encodeURIComponent(type) + \"&data[screen]=\" + encodeURIComponent(screen));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {

var f_load_primary_docums_type_pacs = 'f_load_primary_docums_type_pacs_' + screen;

var cont = document.getElementById(f_load_primary_docums_type_pacs);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}

//


}


function switch_selected_button_type_pac_primary_docums(type,screen)
{

if(type == 'last_pacs')
{
var but_last_pacs_primary_docums = 'but_last_pacs_primary_docums_' + screen;
document.getElementById(but_last_pacs_primary_docums).style.backgroundColor = 'GreenYellow';
document.getElementById(but_last_pacs_primary_docums).style.color = 'black';

var but_all_pacs_primary_docums = 'but_all_pacs_primary_docums_' + screen;
document.getElementById(but_all_pacs_primary_docums).style.backgroundColor = '';
document.getElementById(but_all_pacs_primary_docums).style.color = 'white';

}

else if(type == 'all_pacs')
{
var but_last_pacs_primary_docums = 'but_last_pacs_primary_docums_' + screen;
document.getElementById(but_last_pacs_primary_docums).style.backgroundColor = '';
document.getElementById(but_last_pacs_primary_docums).style.color = 'white';

var but_all_pacs_primary_docums = 'but_all_pacs_primary_docums_' + screen;
document.getElementById(but_all_pacs_primary_docums).style.backgroundColor = 'GreenYellow';
document.getElementById(but_all_pacs_primary_docums).style.color = 'black';
}


}

</script>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; background-color: #2E3436; color: white;\" cellpadding=\"0\" cellspacing= \"0\">
<tr align = \"center\" height = \"5%\" style = \"cursor: pointer; color: black; font-weight: bold;\">
<td id = \"but_last_pacs_primary_docums_",$screen,"\" width = \"50%\" onclick = \"load_primary_docums_type_pacs('last_pacs','",$screen,"');\">
последние пациенты
</td>
<td id = \"but_all_pacs_primary_docums_",$screen,"\" onclick = \"load_primary_docums_type_pacs('all_pacs','",$screen,"');\">
все пациенты
</td>
</tr>
<tr>
<td colspan = \"2\">

<div id = \"f_load_primary_docums_type_pacs_",$screen,"\" style = \"width: 100%; height: 100%; overflow-y: scroll;\">
</div>

</td>
</tr>
</table>

<script>
load_primary_docums_type_pacs('last_pacs','",$screen,"');
</script>

";


}
Else{

echo "не пустой запрос";
}


}

?>
