<?php

function load_autoclav($vals)
{

$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

//параметры автоклава под id = 3 в tab_misc_sets

$sql = "select * from tab_misc_sets where id = '3'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "

<style>

.inp_name_autocl_",$screen,"::placeholder {
  font-weight: bold;
  opacity: 0.5;
  color: white;

}

.inp_name_autocl_",$screen,"{
background-color: #1A5FB4; color: white;
border: 0px; border-bottom: 1px solid white; font-weight: bold; font-size: 15px;
}


</style>

<table align = \"center\" border = \"0\" width = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #1A5FB4; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

$row = mysqli_fetch_assoc($query);
$val = $row['val'];

$ar_decoded = json_decode($val,true);

#print_r($ar_dec);die();


Foreach($ar_decoded as $id=>$ar_vals)
{

$name = $ar_vals['name'];
$temp0 = $ar_vals['mode0']['temp'];
$press0 = $ar_vals['mode0']['press'];
$time0 = $ar_vals['mode0']['time'];

$temp1 = $ar_vals['mode1']['temp'];
$press1 = $ar_vals['mode1']['press'];
$time1 = $ar_vals['mode1']['time'];


echo "
<tr >

<td  align = \"center\">

<input onkeyup = \"update_info_autoclav(this.value,'name','",$screen,"','",$id,"','');\" class = \"inp_name_autocl_",$screen,"\" style = \"  width: 90%;\" placeholder = \"Название автоклава\" value = \"",$name,"\">

</td>
<td width = \"60%\" height = \"70px\">

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: #1A5FB4; color: white; font-weight: bold; text-align: center; \" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

t <input onkeyup = \"update_info_autoclav(this.value,'temp','",$screen,"','",$id,"','mode0');\" class = \"inp_name_autocl_",$screen,"\" size = \"1\" style = \"text-align: center; font-size: 17px;\" value = \"",$temp0,"\">&deg;C

</td>
<td>

p <input onkeyup = \"update_info_autoclav(this.value,'press','",$screen,"','",$id,"','mode0');\" class = \"inp_name_autocl_",$screen,"\" size = \"1\" style = \"text-align: center; font-size: 17px;\" value = \"",$press0,"\">кПа

</td>
<td>

&#964; <input onkeyup = \"update_info_autoclav(this.value,'time','",$screen,"','",$id,"','mode0');\" class = \"inp_name_autocl_",$screen,"\" size = \"1\" style = \"text-align: center; font-size: 17px;\" value = \"",$time0,"\">мин

</td>
</tr>
<tr>

<td>

t <input onkeyup = \"update_info_autoclav(this.value,'temp','",$screen,"','",$id,"','mode1');\" class = \"inp_name_autocl_",$screen,"\" size = \"1\" style = \"text-align: center; font-size: 17px;\" value = \"",$temp1,"\">&deg;C

</td>
<td>

p <input onkeyup = \"update_info_autoclav(this.value,'press','",$screen,"','",$id,"','mode1');\" class = \"inp_name_autocl_",$screen,"\" size = \"1\" style = \"text-align: center; font-size: 17px;\" value = \"",$press1,"\">кПа

</td>
<td>

&#964; <input onkeyup = \"update_info_autoclav(this.value,'time','",$screen,"','",$id,"','mode1');\" class = \"inp_name_autocl_",$screen,"\" size = \"1\" style = \"text-align: center; font-size: 17px;\" value = \"",$time1,"\">мин

</td>

</tr>
</table>

</td>
<td onclick = \"delete_autoclav('",$id,"','",$screen,"');\" width = \"5%\" align = \"center\" style = \"background-color: #FF8080; color: white; font-weight: bold; cursor: pointer;\">

X

</td>


</tr>

<tr>
<td colspan = \"3\" style = \"background-color: #2E3436;\">
&nbsp;
</td>
</tr>


";

}

echo "</table>";


}
Else{

echo "

<table align = \"center\" border = \"1\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; background-color: grey; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td align = \"center\">
нет ни одного автоклава
</td>
</tr>
</table>

";

}


}

?>
