<?php

function corr_time_ent_pac($vals)
{

function convert_time_to_min($time_norm)
{
$ar_t_b = explode(":",$time_norm);
$hb = $ar_t_b['0'];
$mb = $ar_t_b['1'];
$time_b = ($hb*60)+$mb;
return $time_b;
}

$id_ent = $vals['param'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from pacs_ent where id_ent = '$id_ent'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$begin = $row['begin'];

$ar_begin = explode(" ",$begin);
$date_b = $ar_begin['0'];
$f_time_b = $ar_begin['1'];

$ar_f_time_b = explode(":",$f_time_b);
$hmb = $ar_f_time_b[0].":".$ar_f_time_b[1];

$end = $row['end'];

$ar_end = explode(" ",$end);
$date_e = $ar_end['0'];
$f_time_e = $ar_end['1'];

$ar_f_time_e = explode(":",$f_time_e);
$hme = $ar_f_time_e[0].":".$ar_f_time_e[1];

$chouse_t_period = $hmb."-".$hme;

$unit = $row['unit'];
$chousen_pers = $row['doc'];



}


$arr_utcsd['date'] = $date_b;
$arr_utcsd['dunit'] = $unit;
$arr_utcsd['chousen_schema'] = "dark";
$arr_utcsd['chousen_pers'] = $chousen_pers;
$arr_utcsd['screen'] = $screen;


include_once("used_times_correct_shed_doc.php");


$ar_exit = used_times_correct_shed_doc($arr_utcsd);

#print_r($ar_exit);

$i=0;

Foreach($ar_exit as $ar_vals)
{

$ar_times = $ar_vals['times'];
$f_b = array_shift($ar_times);
$f_e = end($ar_times);

$f_be = $f_b."-".$f_e;
$type = $ar_vals['type'];

If($f_be !== $chouse_t_period)
{
$ar_new[$i][$f_be] = $ar_vals;
}
Else{
$i++;
}

}

#print_r($ar_new);die();

If(isset($ar_new))
{



If(isset($ar_new[0]))
{

$ar_before = $ar_new[0];
$ar_last_before = end($ar_before);
$type_before = $ar_last_before['type'];

If($type_before == "empty_time")
{

$id_doc = $ar_last_before['id_doc'];

If($id_doc == $chousen_pers)
{
$start_avail_time = array_shift($ar_last_before['times']);
}
Else{
$start_avail_time = $hmb;
}




}
Else{
$start_avail_time = $hmb;
}

$min_start_avail_time = convert_time_to_min($start_avail_time);


}


If(isset($ar_new[1]))
{

$ar_after = $ar_new[1];
$ar_last_after = array_shift($ar_after);
$type_after = $ar_last_after['type'];

If($type_after == "empty_time")
{

$id_doc = $ar_last_after['id_doc'];

If($id_doc == $chousen_pers)
{
$end_avail_time = end($ar_last_after['times']);
}
Else{
$end_avail_time = $hme;
}


}
Else{
$end_avail_time = $hme;
}

$min_end_avail_time = convert_time_to_min($end_avail_time);

}




If(!isset($min_end_avail_time))
{
$min_end_avail_time = convert_time_to_min($hme);
}


If(!isset($min_start_avail_time))
{
$min_start_avail_time = convert_time_to_min($hmb);
}



$min_hmb = convert_time_to_min($hmb);
$min_hme = convert_time_to_min($hme);



}
Else{

#echo $hmb."--".$hme;

$min_start_avail_time = convert_time_to_min($hmb);
$min_end_avail_time = convert_time_to_min($hme);

$min_hmb = convert_time_to_min($hmb);
$min_hme = convert_time_to_min($hme);


}




echo "

<script>

function timeConvert_ent_pac(n) {
var totalTimeInMin = n;
var h = Math.floor(totalTimeInMin / 60);
var m = totalTimeInMin % 60;
if(h < 10)
{
nh = '0' + h;
}
else{
nh = h;
}
if(m < 10)
{
nm = '0' + m;
}
else{
nm = m;
}
var exit = nh + ':' + nm;
return exit;
}


function change_time_ent_pac_move(val,type,screen)
{

//конвертация времени с range
var low = timeConvert_ent_pac(val);

//переменная левая внизу экрана
var f_low_ent_pac = 'f_low_ent_pac_' + screen;

//переменная правая внизу экрана
var f_height_ent_pac = 'f_height_ent_pac_' + screen;

//переменная range слева
var id_low_corr_ent_pac = 'id_low_corr_ent_pac_' + screen;
//значение перменной range слева
var low_corr_ent_pac = document.getElementById(id_low_corr_ent_pac).value;
//пребразование переменной range справа в цифровой ф-т
var d_low_corr_ent_pac = Number(low_corr_ent_pac);

//переменная range справа
var id_height_corr_ent_pac = 'id_height_corr_ent_pac_' + screen;
//значение перменной range справа
var height_corr_ent_pac = document.getElementById(id_height_corr_ent_pac).value;
//пребразование переменной range справа в цифровой ф-т
var d_height_corr_ent_pac = Number(height_corr_ent_pac);


var f_id_write_change_cor_ent_pac_active = 'f_id_write_change_cor_ent_pac_active_' + screen;
var f_id_write_change_cor_ent_pac_inactive = 'f_id_write_change_cor_ent_pac_inactive_' + screen;

document.getElementById(f_id_write_change_cor_ent_pac_active).style.display = 'inline-table';
document.getElementById(f_id_write_change_cor_ent_pac_inactive).style.display = 'none';

if(type == 'low')
{

if(val < d_height_corr_ent_pac)
{
document.getElementById(f_low_ent_pac).innerHTML = low;
}
else if(val > d_height_corr_ent_pac)
{
document.getElementById(f_height_ent_pac).innerHTML = low;
}
else if(val == d_height_corr_ent_pac)
{

document.getElementById(f_low_ent_pac).innerHTML = low;
document.getElementById(f_height_ent_pac).innerHTML = low;

document.getElementById(f_id_write_change_cor_ent_pac_active).style.display = 'none';
document.getElementById(f_id_write_change_cor_ent_pac_inactive).style.display = 'inline-table';

}


}
else if(type == 'height')
{

if(val > d_low_corr_ent_pac)
{
document.getElementById(f_height_ent_pac).innerHTML = low;
}
else if(val < d_low_corr_ent_pac)
{
document.getElementById(f_low_ent_pac).innerHTML = low;
}
else if(val == d_low_corr_ent_pac)
{

document.getElementById(f_height_ent_pac).innerHTML = low;
document.getElementById(f_low_ent_pac).innerHTML = low;

document.getElementById(f_id_write_change_cor_ent_pac_active).style.display = 'none';
document.getElementById(f_id_write_change_cor_ent_pac_inactive).style.display = 'inline-table';

}


}



}



function send_new_period_ent_pac(screen,id_ent,date)
{

//новый период
//низ
var f_low_ent_pac = 'f_low_ent_pac_' + screen;
var low_ent_pac = document.getElementById(f_low_ent_pac).innerHTML;

//верх
var f_height_ent_pac = 'f_height_ent_pac_' + screen;
var height_ent_pac = document.getElementById(f_height_ent_pac).innerHTML;

var new_period = low_ent_pac + '-' + height_ent_pac;

var xmlhttp = getXmlHttp();
xmlhttp.open('POST', '../handle/handle.html', true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xmlhttp.send(\"act=\" + encodeURIComponent('send_new_period_ent_pac') + \"&data[screen]=\" + encodeURIComponent(screen) + \"&data[id_ent]=\" + encodeURIComponent(id_ent) + \"&data[new_period]=\" + encodeURIComponent(new_period) + \"&data[date]=\" + encodeURIComponent(date));

xmlhttp.onreadystatechange = function() {
if (xmlhttp.readyState == 4) {
if(xmlhttp.status == 200) {



var modal = 'modal_' + screen;

var cont = document.getElementById(modal);
cont.innerHTML = xmlhttp.responseText;

var elements = cont.getElementsByTagName('script');
var len = elements.length;
for (var i = 0; i < len; i++) {
eval.call(window, elements[i].innerHTML);  
}
}
}
}


}

</script>


<style>

.slider {

-webkit-appearance: none;
width: 100%;
height: 25px;
position: absolute;
background: #C0C0C0;
outline: none;


}

.slider input {

pointer-events: none;
position: absolute;
overflow: hidden;
left: 25%;
top: 15px;
width: 50%;
outline: none;
height: 18px;
margin: 0px;
padding: 0px;

}

.slider::-webkit-slider-thumb {

-webkit-appearance: none;
appearance: none;
width: 35px;
height: 35px;
background: #8080FF;
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 1;
outline: 0;

}

.slider::-moz-range-thumb {

width: 20px;
height: 20px;
background: #8080FF;
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 10;
-moz-appearance: none;
width: 9px;

}

.slider input::-moz-range-track {

position: relative;
z-index: -1;
border: 0;

}

.slider input:last-of-type::-moz-range-track {

-moz-appearance: none;
background: none transparent;
border: 0;

}

.slider input[type=range]::-moz-focus-outer {
border: 0;
}

</style>

<table border = \"0\" width = \"100%\" height = \"100.5%\" style = \" border-collapse: collapse; text-align: center; background-color: #2E3436; color: white; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr height = \"20%\" style = \"color: white; font-weight: bold; background-color: black;\">
<td colspan = \"2\" align = \"left\">
Коррекция времени пациента
</td>
</tr>

<tr>
<td colspan = \"2\">

<div style = \"float: left;\">
<input class=\"slider\" id=\"id_low_corr_ent_pac_",$screen,"\" oninput = \"change_time_ent_pac_move(this.value,'low','",$screen,"');\" type=\"range\" step = \"5\" min=\"",$min_start_avail_time,"\" max=\"",$min_end_avail_time,"\" value=\"",$min_hmb,"\">
<input class=\"slider\" id=\"id_height_corr_ent_pac_",$screen,"\" oninput = \"change_time_ent_pac_move(this.value,'height','",$screen,"');\" type=\"range\" step = \"5\" min=\"",$min_start_avail_time,"\" max=\"",$min_end_avail_time,"\" value=\"",$min_hme,"\">
</div>

</td>
</tr>

<tr height = \"20%\">

<td width = \"50%\">
<span id=\"f_low_ent_pac_",$screen,"\" style = \"font-weight: bold; color: white;\">",$hmb,"</span>
</td>

<td width = \"50%\">
<span id=\"f_height_ent_pac_",$screen,"\" style = \"font-weight: bold; color: white;\">",$hme,"</span>
</td>
</tr>

<tr height = \"20%\">
<td colspan = \"2\">

<table id = \"f_id_write_change_cor_ent_pac_active_",$screen,"\" border = \"1\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; background-color: green; color: white; font-weight: bold; cursor: pointer; display: inline-table;\" cellpadding=\"0\" cellspacing= \"0\">
<tr onclick = \"send_new_period_ent_pac('",$screen,"','",$id_ent,"','",$date_b,"');\">
<td>
Записать
</td>
</tr>
</table>

<table id = \"f_id_write_change_cor_ent_pac_inactive_",$screen,"\" border = \"1\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; background-color: grey; color: white; font-weight: bold; cursor: pointer; display: none;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
Записать
</td>
</tr>
</table>

</td>
</tr>

</table>


";



}

?>
