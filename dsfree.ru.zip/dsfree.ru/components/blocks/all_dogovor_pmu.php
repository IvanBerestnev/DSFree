<?php

function all_dogovor_pmu($vals)
{

#print_r($vals);

$id_pac = $vals['id_pac'];
$screen = $vals['screen'];

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");

$sql = "select * from tab_pacs_dogovors where id_pac = '$id_pac'";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

while($row = mysqli_fetch_assoc($query))
{

$id_dogovor_pmu = $row['id_dogovor'];

$ar_dogovor_pmu[$id_dogovor_pmu]['data_dogovor'] = $row['data_dogovor'];
$ar_dogovor_pmu[$id_dogovor_pmu]['age'] = $row['age'];
$ar_dogovor_pmu[$id_dogovor_pmu]['whopaid'] = $row['whopaid'];


If($row['whopaid'] !== "self")
{
$ar_whopaid[] = $row['whopaid'];
}


}


If(isset($ar_whopaid))
{
$str_whopaid = "'".implode("','",$ar_whopaid)."'";

$sql = "select * from tab_pacs where id_pac IN ($str_whopaid)";
#echo $sql;
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{
while($row = mysqli_fetch_assoc($query))
{
$ar_other_lico[$row['id_pac']] = $row['surname_pac'];
}
}
}
Else{
$ar_other_lico = array();
}


$ar_ages = array("do18"=>"до 18","posle18"=>"18 и старше");
$ar_rus_month = array("01"=>"января","02"=>"февраля","03"=>"марта","04"=>"апреля","05"=>"мая","06"=>"июня","07"=>"июля","08"=>"августа","09"=>"сентября","10"=>"октября","11"=>"ноября","12"=>"декабря");


echo "<table border = \"0\" align = \"center\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">";

Foreach($ar_dogovor_pmu as $id_dog=>$ar_vals)
{

$data_dogovor = $ar_vals['data_dogovor'];
$age = $ar_vals['age'];
$whopaid = $ar_vals['whopaid'];



echo "

<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"50px\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>№
",$id_dog,"
</td>
<td width = \"30%\">

<select onchange = \"change_param_dogovor_pmu('",$id_dog,"','age',this.value,'",$screen,"');\" style = \"text-align: center; font-weight: bold;\">";

Foreach($ar_ages as $k_age=>$v_age)
{

echo "<option";

If($k_age == $age)
{
echo " selected";
}

echo " value = \"",$k_age,"\">",$v_age,"</option>";

}

echo "</select>

";


echo "
</td>
</tr>
<tr>
<td style = \"cursor: pointer;\">
";

If($whopaid == "self")
{
echo "<div onclick=\"open_page_other_lica_dogovor_pmu('",$id_pac,"','",$screen,"','",$id_dog,"','inn');\">оплачивает сам</div>";
}
Else{
echo "опл-т ",$ar_other_lico[$whopaid]," <span onclick = \"act_add_otherlico_dogovor_pmu('",$id_pac,"','','",$id_dog,"','",$screen,"');\" style = \"background-color: red; border: 1px solid black; padding-right: 10px; padding-left: 10px; cursor: pointer;\">х</span>";
}

echo "
</td>
<td>
";

$ar_data_dogovor = explode("-",$data_dogovor);

$year_dd = $ar_data_dogovor[0];
$month_dd = $ar_data_dogovor[1];
$day_dd = $ar_data_dogovor[2];

$year_dd_min = $year_dd-5;
$year_dd_max = $year_dd+5;

#$ar_rus_month

echo "<select onchange = \"change_param_dogovor_pmu('",$id_dog,"','day',this.value,'",$screen,"');\" style = \"text-align: center; font-weight: bold;\">";

For($i=1;$i<=31;$i++)
{
echo "<option";

If($i == $day_dd)
{
echo " selected";
}

echo " value = \"",$i,"\">",$i,"</option>";
}

echo "</select> ";

echo "<select onchange = \"change_param_dogovor_pmu('",$id_dog,"','month',this.value,'",$screen,"');\" style = \"text-align: center; font-weight: bold;\">";

Foreach($ar_rus_month as $num_m=>$name_m)
{

echo "<option";

If($num_m == $month_dd)
{
echo " selected";
}

echo " value = \"",$num_m,"\">",$name_m,"</option>";

}

echo "</select>";

echo "
<select onchange = \"change_param_dogovor_pmu('",$id_dog,"','year',this.value,'",$screen,"');\" style = \"text-align: center; font-weight: bold;\">

";

For($year_dd_min;$year_dd_min<=$year_dd_max;$year_dd_min++)
{
echo "<option";

If($year_dd_min == $year_dd)
{
echo " selected";
}

echo " value = \"",$year_dd_min,"\">",$year_dd_min,"</option>";
}

echo "

</select>

";


echo "
</td>
</tr>
</table>


</td>
<td width = \"15%\">

<table border = \"0\" align = \"center\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold; cursor: pointer;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>

<td onclick = \"print_primary_docums('dogovor_pmu','",$id_dog,"','",$screen,"');\" style = \"background-color: #008080;\" width = \"50%\">печать</td>
<td onclick = \"act_delete_dogovor_pmu('",$id_dog,"','",$screen,"','",$id_pac,"');\" style = \"background-color: #FF8080;\" >х</td>
</tr>
</table>

</td>
</tr>
</table>


</td>
</tr>

<tr height = \"20px\">
<td></td>
</tr>

";

}

echo "</table>";


}
Else{

echo "

<table border = \"0\" align = \"center\" height = \"100%\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white; font-weight: bold;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
нет зарегистрированных договоров
</td>
</tr>
</table>
";

}




}

?>
