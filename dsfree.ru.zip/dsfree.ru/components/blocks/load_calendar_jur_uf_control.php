<?php

function load_calendar_jur_uf_control($vals)
{

$year = $vals['year'];
$month = $vals['month'];
$screen = $vals['screen'];

$num_wd = date("N",mktime(0, 0, 0, $month, 1, $year));
$q_days = cal_days_in_month(CAL_GREGORIAN, $month, $year);

$day_now = date("j");
$month_now = date("n");
$year_now = date("Y");

echo "

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>

<table border = \"0\" width = \"100%\" height = \"100%\" style = \"border-collapse: collapse; table-layout: fixed; text-align: center; background-color: #2E3436; \" cellpadding=\"0\" cellspacing= \"0\">
<tr style = \"background-color: #2E3436; text-align: center; font-weight: bold; color: white;\" height = \"15px\"><td>Пн</td><td>Вт</td><td>Ср</td><td>Чт</td><td>Пт</td><td>Сб</td><td style = \"color: #FF8080;\">Вс</td></tr>
";

For($i=1,$u=1;$i<36,$u<=$q_days;$i++)
{

$ud = date("d",mktime(0,0,0,1,$u,1970));

If($i==8 or $i==15 or $i==22 or $i==29 or $i==36)
{
echo "</tr><tr>";
}

If($i>=$num_wd)
{
echo "<td style = \"font-weight: bold; background-color: ";

If($month_now > $month)
{

If($year_now < $year)
{



echo "#888A85";
$color_txt = "black";


}
ElseIf($year_now == $year)
{

echo "#555753";
$color_txt = "white";

}

Else{

echo "#888A85";
$color_txt = "black";

}



}
ElseIf($month_now == $month)
{

If($year_now < $year)
{

echo "#888A85";
$color_txt = "black";


}
ElseIf($year_now == $year)
{

If($day_now < $u)
{
echo "#888A85";
$color_txt = "black";
}
Else{
echo "#555753";
$color_txt = "white";
}

}
Else{

echo "#555753";
$color_txt = "white";

}



}
Else{


If($year_now < $year)
{

echo "#555753";
$color_txt = "white";


}
ElseIf($year_now == $year)
{

echo "#888A85";
$color_txt = "black";



}
Else{

echo "#555753";
$color_txt = "white";

}

//echo "#888A85";
//$color_txt = "black";
}


echo "; color: ",$color_txt,";\"><input class = \"days_calendar_uf_control_",$screen,"\" type = \"checkbox\" value = \"",$ud,"\"> ";

If($u<10)
{
echo "&nbsp; ";
}

echo $u,"</td>";
$u++;
}

Else{
echo "<td></td>";
}
}

echo "
</table>


</td>
</tr>
</table>

";





}

?>
