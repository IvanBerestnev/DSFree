<?php

function load_all_clients_otherlica_ids($vals)
{

#print_r($vals);

$screen = $vals['screen'];
$surname_pac = $vals['surname_pac'];
$id_pac_income = $vals['id_pac_income'];



include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");






$sql = "select * from tab_pacs where surname_pac like ('$surname_pac%')";
$query = mysqli_query($connection,$sql);

If(mysqli_num_rows($query) !== 0)
{

echo "<table border = \"0\" width = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">";

while($row = mysqli_fetch_assoc($query))
{

$id_pac = $row['id_pac'];
$name_pac = $row['name_pac'];
$surname_pac = $row['surname_pac'];
$patronymic_pac = $row['patronymic_pac'];


If($id_pac_income == $id_pac)
{
continue;
}

echo "
<tr height = \"50px\">
<td id = \"ids_pacs_other_lica_",$id_pac,"_",$screen,"\" class = \"class_ids_pacs_other_lica_",$screen,"\" onclick = \"choice_pac_other_lica_ids('",$id_pac,"','",$screen,"');\" style = \"padding-top: 10px; padding-left: 10px; padding-right: 10px; cursor: pointer; background-color: #22272B;\">",$surname_pac," ",$name_pac," ",$patronymic_pac,"
</td>
</tr>
<tr>
<td height = \"20px\" style = \"background-color: #2E3436;\">
</td>
</tr>
";

}

echo "</table>";

}
Else{

echo "
<table border = \"0\" width = \"100%\" height = \"100%\" style = \" border-collapse: collapse; text-align: center; color: white;  font-weight: bold; background-color: #2E3436;\" cellpadding=\"0\" cellspacing= \"0\">
<tr>
<td>
пациент не найден
</td>
</tr>
</table>

<script>

</script>

";

}









}

?>
