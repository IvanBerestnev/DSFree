<?php

function check_permissions($level_cookie,$page,$chapt)
{

include_once("../users/administrator.php");
$ar_user = user();
$name_user = $ar_user['name'];
$pass_user = $ar_user['pass'];
$db = $ar_user['db'];

$connection = mysqli_connect ("localhost",$name_user,$pass_user);
mysqli_select_db($connection,$db);
mysqli_set_charset($connection, "utf8");


$sql = "select * from tab_permissions where id_permission = '1'";
$query = mysqli_query($connection,$sql);


If(mysqli_num_rows ($query) !== 0)
{
$row = mysqli_fetch_assoc($query);
$ar_permissions = $row['permissions'];
$ar = json_decode($ar_permissions,true);
}

#print_r($ar);

If(isset($ar[$page]['content']))
{

If(isset($ar[$page]['content'][$chapt]))
{
$return = $ar[$page]['content'][$chapt]['levels'][$level_cookie];
}
Else{

$return = "";

}



}
Else{

$return = $ar[$page]['levels'][$level_cookie];

}



return $return;



}

?>
