<style>

.slider {

-webkit-appearance: none;
width: 90%;
height: 25px;
position: absolute;
background: #a4a4a4;
outline: none;

}

.slider input {

pointer-events: none;
position: absolute;
overflow: hidden;
left: 25%;
top: 15px;
width: 50%;
outline: none;
height: 18px;
margin: 0;
padding: 0;

}

.slider::-webkit-slider-thumb {

-webkit-appearance: none;
appearance: none;
width: 35px;
height: 35px;
background: #ea4550;
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 1;
outline: 0;

}

.slider::-moz-range-thumb {

width: 20px;
height: 20px;
background: #ea4550;
cursor: pointer;
pointer-events: all;
position: relative;
z-index: 10;
-moz-appearance: none;
width: 9px;

}

.slider input::-moz-range-track {

position: relative;
z-index: -1;
border: 0;

}

.slider input:last-of-type::-moz-range-track {

-moz-appearance: none;
background: none transparent;
border: 0;

}

.slider input[type=range]::-moz-focus-outer {
border: 0;
}

</style>

<input type="range" min="12" max="2175" value="12" class="slider" id="lower">
<input type="range" min="12" max="2175" value="2175" class="slider" id="higher">
